// lib: , url: bKm

// class id: 1048886, size: 0x8
class :: {
}

// class id: 5406, size: 0xc, field offset: 0x8
abstract class NJ<X0> extends Object {
}

// class id: 5407, size: 0xc, field offset: 0x8
//   const constructor, 
class MJ extends Object {
}

// class id: 5408, size: 0x10, field offset: 0x8
//   const constructor, 
class LJ extends Object {

  bool field_8;
  yI field_c;
}

// class id: 7345, size: 0x18, field offset: 0x14
enum PJ<X0> extends _Enum
    implements NJ<X0> {

  _Mint field_8;
  _OneByteString field_10;
  static late Map<Type, PJ<Object>> _geh; // offset: 0x1150
}
