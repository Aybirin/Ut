// lib: , url: Agn

// class id: 1049886, size: 0x8
class :: {
}

// class id: 1441, size: 0x14, field offset: 0x8
class Ufb extends Object {
}

// class id: 1442, size: 0x20, field offset: 0x8
class Tfb extends Object {

  late bool sTi; // offset: 0xc
  late int wTi; // offset: 0x1c
}

// class id: 1443, size: 0x18, field offset: 0x8
class Sfb extends Object {
}

// class id: 1444, size: 0x18, field offset: 0x8
class Rfb extends Object {
}

// class id: 1445, size: 0x24, field offset: 0x8
class Qfb extends Object {
}

// class id: 1446, size: 0x20, field offset: 0x8
class Pfb extends Object {

  late bool ETi; // offset: 0x14
  late int DTi; // offset: 0x10
  late bool XXf; // offset: 0x8
}

// class id: 1447, size: 0x10, field offset: 0x8
class Ofb extends Object {
}

// class id: 1448, size: 0xc, field offset: 0x8
class Nfb extends Object {
}

// class id: 1449, size: 0x1c, field offset: 0x8
class Mfb extends Object {
}

// class id: 1450, size: 0x8, field offset: 0x8
class Lfb extends Object {
}

// class id: 1451, size: 0xc, field offset: 0x8
class Kfb extends Object {

  late int iTi; // offset: 0x8
}
