// lib: , url: dcn

// class id: 1049659, size: 0x8
class :: {
}

// class id: 4136, size: 0x28, field offset: 0x14
class _zXa extends Xu<dynamic> {

  [closure] Future<void> <anonymous closure>(dynamic, iR) async {
    // ** addr: 0xbc1868, size: 0x1a8
    // 0xbc1868: EnterFrame
    //     0xbc1868: stp             fp, lr, [SP, #-0x10]!
    //     0xbc186c: mov             fp, SP
    // 0xbc1870: AllocStack(0x28)
    //     0xbc1870: sub             SP, SP, #0x28
    // 0xbc1874: SetupParameters(_zXa this /* r1 */)
    //     0xbc1874: stur            NULL, [fp, #-8]
    //     0xbc1878: movz            x0, #0
    //     0xbc187c: add             x1, fp, w0, sxtw #2
    //     0xbc1880: ldr             x1, [x1, #0x18]
    //     0xbc1884: ldur            w2, [x1, #0x17]
    //     0xbc1888: add             x2, x2, HEAP, lsl #32
    //     0xbc188c: stur            x2, [fp, #-0x10]
    // 0xbc1890: CheckStackOverflow
    //     0xbc1890: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbc1894: cmp             SP, x16
    //     0xbc1898: b.ls            #0xbc19e8
    // 0xbc189c: InitAsync() -> Future<void?>
    //     0xbc189c: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xbc18a0: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbc18a4: ldur            x2, [fp, #-0x10]
    // 0xbc18a8: LoadField: r0 = r2->field_b
    //     0xbc18a8: ldur            w0, [x2, #0xb]
    // 0xbc18ac: DecompressPointer r0
    //     0xbc18ac: add             x0, x0, HEAP, lsl #32
    // 0xbc18b0: stur            x0, [fp, #-0x20]
    // 0xbc18b4: LoadField: r1 = r0->field_1b
    //     0xbc18b4: ldur            w1, [x0, #0x1b]
    // 0xbc18b8: DecompressPointer r1
    //     0xbc18b8: add             x1, x1, HEAP, lsl #32
    // 0xbc18bc: LoadField: r3 = r0->field_f
    //     0xbc18bc: ldur            w3, [x0, #0xf]
    // 0xbc18c0: DecompressPointer r3
    //     0xbc18c0: add             x3, x3, HEAP, lsl #32
    // 0xbc18c4: stur            x3, [fp, #-0x18]
    // 0xbc18c8: LoadField: d0 = r3->field_1f
    //     0xbc18c8: ldur            d0, [x3, #0x1f]
    // 0xbc18cc: r4 = LoadInt32Instr(r1)
    //     0xbc18cc: sbfx            x4, x1, #1, #0x1f
    //     0xbc18d0: tbz             w1, #0, #0xbc18d8
    //     0xbc18d4: ldur            x4, [x1, #7]
    // 0xbc18d8: scvtf           d1, x4
    // 0xbc18dc: fmul            d2, d1, d0
    // 0xbc18e0: mov             v0.16b, v2.16b
    // 0xbc18e4: stp             fp, lr, [SP, #-0x10]!
    // 0xbc18e8: mov             fp, SP
    // 0xbc18ec: CallRuntime_LibcRound(double) -> double
    //     0xbc18ec: and             SP, SP, #0xfffffffffffffff0
    //     0xbc18f0: mov             sp, SP
    //     0xbc18f4: ldr             x16, [THR, #0x598]  ; THR::LibcRound
    //     0xbc18f8: str             x16, [THR, #0x7a0]  ; THR::vm_tag
    //     0xbc18fc: blr             x16
    //     0xbc1900: movz            x16, #0x8
    //     0xbc1904: str             x16, [THR, #0x7a0]  ; THR::vm_tag
    //     0xbc1908: ldr             x16, [THR, #0x768]  ; THR::saved_stack_limit
    //     0xbc190c: sub             sp, x16, #1, lsl #12
    //     0xbc1910: mov             SP, fp
    //     0xbc1914: ldp             fp, lr, [SP], #0x10
    // 0xbc1918: fcmp            d0, d0
    // 0xbc191c: b.vs            #0xbc19f0
    // 0xbc1920: fcvtzs          x0, d0
    // 0xbc1924: asr             x16, x0, #0x1e
    // 0xbc1928: cmp             x16, x0, asr #63
    // 0xbc192c: b.ne            #0xbc19f0
    // 0xbc1930: lsl             x0, x0, #1
    // 0xbc1934: ldur            x1, [fp, #-0x18]
    // 0xbc1938: LoadField: r2 = r1->field_b
    //     0xbc1938: ldur            w2, [x1, #0xb]
    // 0xbc193c: DecompressPointer r2
    //     0xbc193c: add             x2, x2, HEAP, lsl #32
    // 0xbc1940: cmp             w2, NULL
    // 0xbc1944: b.eq            #0xbc1a0c
    // 0xbc1948: LoadField: r1 = r2->field_b
    //     0xbc1948: ldur            w1, [x2, #0xb]
    // 0xbc194c: DecompressPointer r1
    //     0xbc194c: add             x1, x1, HEAP, lsl #32
    // 0xbc1950: stur            x1, [fp, #-0x18]
    // 0xbc1954: r2 = LoadInt32Instr(r0)
    //     0xbc1954: sbfx            x2, x0, #1, #0x1f
    //     0xbc1958: tbz             w0, #0, #0xbc1960
    //     0xbc195c: ldur            x2, [x0, #7]
    // 0xbc1960: r16 = 1000
    //     0xbc1960: movz            x16, #0x3e8
    // 0xbc1964: mul             x0, x2, x16
    // 0xbc1968: stur            x0, [fp, #-0x28]
    // 0xbc196c: r0 = Ea()
    //     0xbc196c: bl              #0xb0a61c  ; AllocateEaStub -> Ea (size=0x10)
    // 0xbc1970: mov             x1, x0
    // 0xbc1974: ldur            x0, [fp, #-0x28]
    // 0xbc1978: StoreField: r1->field_7 = r0
    //     0xbc1978: stur            x0, [x1, #7]
    // 0xbc197c: mov             x2, x1
    // 0xbc1980: ldur            x1, [fp, #-0x18]
    // 0xbc1984: r0 = __unknown_function__()
    //     0xbc1984: bl              #0xbc1a10  ; [] ::__unknown_function__
    // 0xbc1988: mov             x1, x0
    // 0xbc198c: stur            x1, [fp, #-0x18]
    // 0xbc1990: r0 = Await()
    //     0xbc1990: bl              #0xb0c534  ; AwaitStub
    // 0xbc1994: ldur            x0, [fp, #-0x20]
    // 0xbc1998: LoadField: r3 = r0->field_f
    //     0xbc1998: ldur            w3, [x0, #0xf]
    // 0xbc199c: DecompressPointer r3
    //     0xbc199c: add             x3, x3, HEAP, lsl #32
    // 0xbc19a0: stur            x3, [fp, #-0x18]
    // 0xbc19a4: LoadField: r1 = r3->field_f
    //     0xbc19a4: ldur            w1, [x3, #0xf]
    // 0xbc19a8: DecompressPointer r1
    //     0xbc19a8: add             x1, x1, HEAP, lsl #32
    // 0xbc19ac: cmp             w1, NULL
    // 0xbc19b0: b.eq            #0xbc19d0
    // 0xbc19b4: ldur            x2, [fp, #-0x10]
    // 0xbc19b8: r1 = Function '<anonymous closure>':.
    //     0xbc19b8: add             x1, PP, #0x49, lsl #12  ; [pp+0x49720] AnonymousClosure: (0x6a8ea0), in [Ixn] _kGb::<anonymous closure> (0x759d20)
    //     0xbc19bc: ldr             x1, [x1, #0x720]
    // 0xbc19c0: r0 = AllocateClosure()
    //     0xbc19c0: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xbc19c4: ldur            x1, [fp, #-0x18]
    // 0xbc19c8: mov             x2, x0
    // 0xbc19cc: r0 = call 0x461da4
    //     0xbc19cc: bl              #0x461da4
    // 0xbc19d0: ldur            x0, [fp, #-0x20]
    // 0xbc19d4: LoadField: r1 = r0->field_f
    //     0xbc19d4: ldur            w1, [x0, #0xf]
    // 0xbc19d8: DecompressPointer r1
    //     0xbc19d8: add             x1, x1, HEAP, lsl #32
    // 0xbc19dc: r0 = call 0x6a8cb4
    //     0xbc19dc: bl              #0x6a8cb4
    // 0xbc19e0: r0 = Null
    //     0xbc19e0: mov             x0, NULL
    // 0xbc19e4: r0 = ReturnAsyncNotFuture()
    //     0xbc19e4: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbc19e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc19e8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc19ec: b               #0xbc189c
    // 0xbc19f0: SaveReg d0
    //     0xbc19f0: str             q0, [SP, #-0x10]!
    // 0xbc19f4: r0 = 74
    //     0xbc19f4: movz            x0, #0x4a
    // 0xbc19f8: r30 = DoubleToIntegerStub
    //     0xbc19f8: ldr             lr, [PP, #0x1958]  ; [pp+0x1958] Stub: DoubleToInteger (0x3519d4)
    // 0xbc19fc: LoadField: r30 = r30->field_7
    //     0xbc19fc: ldur            lr, [lr, #7]
    // 0xbc1a00: blr             lr
    // 0xbc1a04: RestoreReg d0
    //     0xbc1a04: ldr             q0, [SP], #0x10
    // 0xbc1a08: b               #0xbc1934
    // 0xbc1a0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbc1a0c: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void sJc(dynamic) {
    // ** addr: 0x814d34, size: -0x1
  }
  [closure] Ava <anonymous closure>(dynamic, iva, xXa, Mca?) {
    // ** addr: 0x6a7d4c, size: -0x1
  }
  [closure] void _Cyi(dynamic) {
    // ** addr: 0x6a9b3c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6a8d5c, size: -0x1
  }
  [closure] void _Dyi(dynamic) {
    // ** addr: 0x6a9630, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6a94e4, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6a935c, size: -0x1
  }
  [closure] Ava <anonymous closure>(dynamic, iva, wca) {
    // ** addr: 0x6a8878, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, nR) {
    // ** addr: 0x6a9028, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, jR) {
    // ** addr: 0x6a8ec8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6a9ae0, size: -0x1
  }
}

// class id: 5067, size: 0x1c, field offset: 0xc
//   const constructor, 
class yXa extends Vu {
}
