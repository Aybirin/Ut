// lib: , url: jcn

// class id: 1049665, size: 0x8
class :: {
}

// class id: 5903, size: 0x8, field offset: 0x8
class NXa extends MXa {

  [closure] LXa <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x75ee74, size: -0x1
  }
  [closure] PXa <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x75f5d0, size: -0x1
  }
}
