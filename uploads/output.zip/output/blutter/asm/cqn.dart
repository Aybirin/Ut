// lib: , url: cqn

// class id: 1050309, size: 0x8
class :: {
}

// class id: 850, size: 0xc, field offset: 0x8
class jsb extends Object
    implements Ja {
}
