// lib: , url: zUm

// class id: 1049386, size: 0x8
class :: {
}

// class id: 2482, size: 0x14, field offset: 0x8
//   const constructor, 
class DGa extends Object {
}
