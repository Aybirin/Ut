// lib: , url: qRm

// class id: 1049231, size: 0x8
class :: {
}

// class id: 2696, size: 0x24, field offset: 0x8
class Hpa extends Object {

  [closure] void _Ypd(dynamic, Hpa) {
    // ** addr: 0x476438, size: -0x1
  }
  [closure] void _bqd(dynamic, Hpa) {
    // ** addr: 0x476500, size: -0x1
  }
  [closure] Map<Object?, Object?> <anonymous closure>(dynamic) {
    // ** addr: 0x4760fc, size: -0x1
  }
  [closure] List<Hpa> <anonymous closure>(dynamic) {
    // ** addr: 0x5d9ac0, size: -0x1
  }
}

// class id: 6158, size: 0x3c, field offset: 0x24
class hoa extends Tu {

  [closure] Future<void> _Bpd(dynamic, MethodCall) {
    // ** addr: 0x475348, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x4767cc, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x475998, size: -0x1
  }
}
