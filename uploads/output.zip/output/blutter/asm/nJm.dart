// lib: , url: nJm

// class id: 1048870, size: 0x8
class :: {

  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x6c64c4, size: -0x1
  }
}

// class id: 5490, size: 0x8, field offset: 0x8
//   const constructor, 
class BH extends Object
    implements Ja {
}

// class id: 5491, size: 0x18, field offset: 0x8
class AH<X0> extends Object {
}
