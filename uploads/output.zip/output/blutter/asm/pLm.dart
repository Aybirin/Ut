// lib: , url: pLm

// class id: 1048928, size: 0x8
class :: {
}

// class id: 3614, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class bN<X0> extends Object {
}

// class id: 3615, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class rM extends bN<dynamic> {
}

// class id: 3616, size: 0xc, field offset: 0xc
//   const constructor, 
class _kN extends rM {
}

// class id: 3617, size: 0x10, field offset: 0xc
//   const constructor, 
class jN extends rM {
}

// class id: 3618, size: 0x20, field offset: 0xc
//   const constructor, 
class iN extends rM {

  Dr field_c;
  Dr field_10;
  Dr field_14;
  Dr field_18;
  Dr field_1c;
}

// class id: 3619, size: 0x2c, field offset: 0xc
//   const constructor, 
class hN extends rM {

  _Double field_c;
  _Double field_14;
  _Double field_1c;
  _Double field_24;
}

// class id: 3620, size: 0x14, field offset: 0xc
//   const constructor, 
class gN extends rM {

  _Double field_c;
}

// class id: 3621, size: 0x1c, field offset: 0xc
//   const constructor, 
class fN extends rM {
}

// class id: 3622, size: 0x20, field offset: 0xc
//   const constructor, 
class eN extends rM {

  _Double field_c;
  _Double field_14;
  hN field_1c;
}

// class id: 3623, size: 0x14, field offset: 0xc
//   const constructor, 
class dN extends rM {

  _Mint field_c;
}

// class id: 3624, size: 0xc, field offset: 0xc
//   const constructor, 
class _cN extends rM {
}
