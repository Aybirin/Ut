// lib: , url: Nqn

// class id: 1050346, size: 0x8
class :: {
}

// class id: 5887, size: 0x8, field offset: 0x8
abstract class ptb extends Ez {

  static late ptb _UMc; // offset: 0x1978
  static late final Object _Hcd; // offset: 0x1974
}
