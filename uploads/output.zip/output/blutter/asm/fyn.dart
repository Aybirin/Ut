// lib: , url: fyn

// class id: 1050716, size: 0x8
class :: {
}

// class id: 540, size: 0x30, field offset: 0x28
class CHb extends tzb<dynamic> {
}

// class id: 3985, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _AHb extends Xu<dynamic>
     with OZ<X0 bound Vu> {
}

// class id: 3986, size: 0x1c, field offset: 0x18
class _BHb extends _AHb {

  late CHb JAj; // offset: 0x18

  [closure] void sJc(dynamic) {
    // ** addr: 0x816714, size: -0x1
  }
}

// class id: 4955, size: 0x18, field offset: 0xc
//   const constructor, 
class zHb extends Vu {
}
