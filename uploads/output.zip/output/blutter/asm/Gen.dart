// lib: , url: Gen

// class id: 1049776, size: 0x8
class :: {
}

// class id: 1577, size: 0x2c, field offset: 0x2c
abstract class Gcb extends Icb {
}
