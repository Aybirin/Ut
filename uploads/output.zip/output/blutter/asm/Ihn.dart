// lib: , url: Ihn

// class id: 1050004, size: 0x8
class :: {
}

// class id: 1344, size: 0x20, field offset: 0x8
class Jib extends Object {
}
