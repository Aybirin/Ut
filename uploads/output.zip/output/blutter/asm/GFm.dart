// lib: , url: GFm

// class id: 1048694, size: 0x8
class :: {
}

// class id: 6024, size: 0x10, field offset: 0x8
class qy extends Object {
}
