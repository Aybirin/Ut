// lib: , url: Jdn

// class id: 1049875, size: 0x8
class :: {
}

// class id: 1536, size: 0x10, field offset: 0x8
class wfb extends Edb {

  late jhb OWb; // offset: 0xc
}
