// lib: , url: GNm

// class id: 1049040, size: 0x8
class :: {
}

// class id: 3806, size: 0xc, field offset: 0x8
//   const constructor, 
class MX extends _FM {
}
