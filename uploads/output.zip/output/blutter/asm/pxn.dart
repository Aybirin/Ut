// lib: , url: pxn

// class id: 1050674, size: 0x8
class :: {
}

// class id: 4045, size: 0x14, field offset: 0x14
class REb extends Xu<dynamic> {

  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xbec318, size: 0xdc
    // 0xbec318: EnterFrame
    //     0xbec318: stp             fp, lr, [SP, #-0x10]!
    //     0xbec31c: mov             fp, SP
    // 0xbec320: AllocStack(0x20)
    //     0xbec320: sub             SP, SP, #0x20
    // 0xbec324: SetupParameters(REb this /* r1 */)
    //     0xbec324: stur            NULL, [fp, #-8]
    //     0xbec328: movz            x0, #0
    //     0xbec32c: add             x1, fp, w0, sxtw #2
    //     0xbec330: ldr             x1, [x1, #0x10]
    //     0xbec334: ldur            w2, [x1, #0x17]
    //     0xbec338: add             x2, x2, HEAP, lsl #32
    //     0xbec33c: stur            x2, [fp, #-0x10]
    // 0xbec340: CheckStackOverflow
    //     0xbec340: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbec344: cmp             SP, x16
    //     0xbec348: b.ls            #0xbec3e8
    // 0xbec34c: InitAsync() -> Future<void?>
    //     0xbec34c: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xbec350: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbec354: ldur            x0, [fp, #-0x10]
    // 0xbec358: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbec358: ldur            w1, [x0, #0x17]
    // 0xbec35c: DecompressPointer r1
    //     0xbec35c: add             x1, x1, HEAP, lsl #32
    // 0xbec360: tbnz            w1, #4, #0xbec36c
    // 0xbec364: r0 = call 0x6fb7d8
    //     0xbec364: bl              #0x6fb7d8
    // 0xbec368: b               #0xbec3e0
    // 0xbec36c: LoadField: r1 = r0->field_f
    //     0xbec36c: ldur            w1, [x0, #0xf]
    // 0xbec370: DecompressPointer r1
    //     0xbec370: add             x1, x1, HEAP, lsl #32
    // 0xbec374: LoadField: r2 = r1->field_b
    //     0xbec374: ldur            w2, [x1, #0xb]
    // 0xbec378: DecompressPointer r2
    //     0xbec378: add             x2, x2, HEAP, lsl #32
    // 0xbec37c: cmp             w2, NULL
    // 0xbec380: b.eq            #0xbec3f0
    // 0xbec384: LoadField: r1 = r2->field_13
    //     0xbec384: ldur            w1, [x2, #0x13]
    // 0xbec388: DecompressPointer r1
    //     0xbec388: add             x1, x1, HEAP, lsl #32
    // 0xbec38c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbec38c: ldur            w2, [x1, #0x17]
    // 0xbec390: DecompressPointer r2
    //     0xbec390: add             x2, x2, HEAP, lsl #32
    // 0xbec394: mov             x1, x2
    // 0xbec398: r0 = __unknown_function__()
    //     0xbec398: bl              #0xbeb448  ; [] ::__unknown_function__
    // 0xbec39c: mov             x1, x0
    // 0xbec3a0: stur            x1, [fp, #-0x18]
    // 0xbec3a4: r0 = Await()
    //     0xbec3a4: bl              #0xb0c534  ; AwaitStub
    // 0xbec3a8: r16 = true
    //     0xbec3a8: add             x16, NULL, #0x20  ; true
    // 0xbec3ac: cmp             w0, w16
    // 0xbec3b0: b.ne            #0xbec3e0
    // 0xbec3b4: ldur            x0, [fp, #-0x10]
    // 0xbec3b8: LoadField: r1 = r0->field_13
    //     0xbec3b8: ldur            w1, [x0, #0x13]
    // 0xbec3bc: DecompressPointer r1
    //     0xbec3bc: add             x1, x1, HEAP, lsl #32
    // 0xbec3c0: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xbec3c0: ldur            w0, [x1, #0x17]
    // 0xbec3c4: DecompressPointer r0
    //     0xbec3c4: add             x0, x0, HEAP, lsl #32
    // 0xbec3c8: cmp             w0, NULL
    // 0xbec3cc: b.eq            #0xbec3e0
    // 0xbec3d0: r16 = <Object?>
    //     0xbec3d0: ldr             x16, [PP, #0xfc8]  ; [pp+0xfc8] TypeArguments: <Object?>
    // 0xbec3d4: str             x16, [SP]
    // 0xbec3d8: r4 = const [0x1, 0, 0, 0, null]
    //     0xbec3d8: ldr             x4, [PP, #0x60]  ; [pp+0x60] List(5) [0x1, 0, 0, 0, Null]
    // 0xbec3dc: r0 = call 0x6d24a0
    //     0xbec3dc: bl              #0x6d24a0
    // 0xbec3e0: r0 = Null
    //     0xbec3e0: mov             x0, NULL
    // 0xbec3e4: r0 = ReturnAsyncNotFuture()
    //     0xbec3e4: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbec3e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec3e8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec3ec: b               #0xbec34c
    // 0xbec3f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbec3f0: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4995, size: 0x18, field offset: 0xc
//   const constructor, 
class QEb extends Vu {
}
