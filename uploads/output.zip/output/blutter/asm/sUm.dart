// lib: , url: sUm

// class id: 1049379, size: 0x8
class :: {
}

// class id: 2494, size: 0x8, field offset: 0x8
abstract class uGa extends sGa {
}
