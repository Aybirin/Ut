// lib: , url: dzn

// class id: 1050767, size: 0x8
class :: {
}

// class id: 4678, size: 0x20, field offset: 0xc
//   const constructor, 
class FJb extends Zu {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x874b48, size: -0x1
  }
}
