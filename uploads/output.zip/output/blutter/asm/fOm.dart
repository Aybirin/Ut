// lib: , url: fOm

// class id: 1049067, size: 0x8
class :: {
}

// class id: 3790, size: 0x30, field offset: 0x8
//   const constructor, 
class mba extends _FM {
}
