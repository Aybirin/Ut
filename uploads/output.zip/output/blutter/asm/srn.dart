// lib: , url: srn

// class id: 1050371, size: 0x8
class :: {
}

// class id: 800, size: 0x1c, field offset: 0x8
class _iub extends jub
    implements gub {

  int dyn:get:length(_iub) {
    // ** addr: 0xb2282c, size: 0x50
    // 0xb2282c: ldr             x2, [SP]
    // 0xb22830: LoadField: r3 = r2->field_13
    //     0xb22830: ldur            x3, [x2, #0x13]
    // 0xb22834: LoadField: r4 = r2->field_b
    //     0xb22834: ldur            x4, [x2, #0xb]
    // 0xb22838: sub             x2, x3, x4
    // 0xb2283c: r0 = BoxInt64Instr(r2)
    //     0xb2283c: sbfiz           x0, x2, #1, #0x1f
    //     0xb22840: cmp             x2, x0, asr #1
    //     0xb22844: b.eq            #0xb22860
    //     0xb22848: stp             fp, lr, [SP, #-0x10]!
    //     0xb2284c: mov             fp, SP
    //     0xb22850: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb22854: mov             SP, fp
    //     0xb22858: ldp             fp, lr, [SP], #0x10
    //     0xb2285c: stur            x2, [x0, #7]
    // 0xb22860: ret
    //     0xb22860: ret             
  }
  int Rn(_iub, nub) {
    // ** addr: 0xb2287c, size: 0x64
    // 0xb2287c: EnterFrame
    //     0xb2287c: stp             fp, lr, [SP, #-0x10]!
    //     0xb22880: mov             fp, SP
    // 0xb22884: CheckStackOverflow
    //     0xb22884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb22888: cmp             SP, x16
    //     0xb2288c: b.ls            #0xb228c0
    // 0xb22890: ldr             x1, [fp, #0x18]
    // 0xb22894: ldr             x2, [fp, #0x10]
    // 0xb22898: r0 = call 0x4d04ac
    //     0xb22898: bl              #0x4d04ac
    // 0xb2289c: mov             x2, x0
    // 0xb228a0: r0 = BoxInt64Instr(r2)
    //     0xb228a0: sbfiz           x0, x2, #1, #0x1f
    //     0xb228a4: cmp             x2, x0, asr #1
    //     0xb228a8: b.eq            #0xb228b4
    //     0xb228ac: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb228b0: stur            x2, [x0, #7]
    // 0xb228b4: LeaveFrame
    //     0xb228b4: mov             SP, fp
    //     0xb228b8: ldp             fp, lr, [SP], #0x10
    // 0xb228bc: ret
    //     0xb228bc: ret             
    // 0xb228c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb228c0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb228c4: b               #0xb22890
  }
}

// class id: 803, size: 0x8, field offset: 0x8
abstract class gub extends Object
    implements hub {
}

// class id: 806, size: 0x14, field offset: 0x8
class dub extends eub
    implements fub {
}

// class id: 807, size: 0x18, field offset: 0x8
class cub extends Object {

  int dyn:get:length(cub) {
    // ** addr: 0xb229b0, size: 0x2c
    // 0xb229b0: ldr             x1, [SP]
    // 0xb229b4: LoadField: r2 = r1->field_f
    //     0xb229b4: ldur            w2, [x1, #0xf]
    // 0xb229b8: DecompressPointer r2
    //     0xb229b8: add             x2, x2, HEAP, lsl #32
    // 0xb229bc: LoadField: r0 = r2->field_13
    //     0xb229bc: ldur            w0, [x2, #0x13]
    // 0xb229c0: ret
    //     0xb229c0: ret             
  }
}
