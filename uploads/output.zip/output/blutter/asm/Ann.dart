// lib: SDn, url: Ann

// class id: 1050197, size: 0x8
class :: {
}

// class id: 996, size: 0xc, field offset: 0xc
class fob extends hnb {

  static late final fqb GEg; // offset: 0x1020

  [closure] static fob <anonymous closure>(dynamic) {
    // ** addr: 0x40dfd8, size: -0x1
  }
  [closure] static fob _VJg(dynamic, String, enb, dnb, za, za, List<int>) {
    // ** addr: 0x40e0f0, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40df80, size: -0x1
  }
}
