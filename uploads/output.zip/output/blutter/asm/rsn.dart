// lib: , url: rsn

// class id: 1050422, size: 0x8
class :: {
}

// class id: 719, size: 0x14, field offset: 0x8
class ewb extends awb {
}

// class id: 748, size: 0x1c, field offset: 0x8
abstract class Tvb extends nvb {
}
