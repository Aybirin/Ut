// lib: , url: tEm

// class id: 1048633, size: 0x8
class :: {

  [closure] static Fv <anonymous closure>(dynamic, Fv) {
    // ** addr: 0x647a30, size: -0x1
  }
}
