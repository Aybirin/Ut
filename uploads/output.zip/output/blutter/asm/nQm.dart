// lib: , url: nQm

// class id: 1049176, size: 0x8
class :: {
}

// class id: 3050, size: 0x58, field offset: 0x58
abstract class ria extends _Tka {
}
