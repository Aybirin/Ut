// lib: , url: Jan

// class id: 1049651, size: 0x8
class :: {
}

// class id: 1742, size: 0xc, field offset: 0xc
class yVa extends IWa {

  static late final Lrb _EXh; // offset: 0x1688

  [closure] static yVa SFc(dynamic) {
    // ** addr: 0xa9cdc0, size: -0x1
  }
}
