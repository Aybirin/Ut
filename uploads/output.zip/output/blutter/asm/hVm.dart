// lib: , url: hVm

// class id: 1049420, size: 0x8
class :: {

  static late Map<String, String> Twh; // offset: 0x1304
}

// class id: 2441, size: 0x10, field offset: 0x8
class Context<X0> extends Object {
}

// class id: 4588, size: 0x10, field offset: 0x10
//   const constructor, 
class QHa extends Gw {
}
