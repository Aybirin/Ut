// lib: , url: rfn

// class id: 1049821, size: 0x8
class :: {
}

// class id: 1514, size: 0x1c, field offset: 0x8
class Rdb extends Object {
}
