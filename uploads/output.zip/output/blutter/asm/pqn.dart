// lib: , url: pqn

// class id: 1050322, size: 0x8
class :: {
}

// class id: 840, size: 0x18, field offset: 0x10
class _Asb<C1X0> extends ysb<C1X0, dynamic> {

  [closure] void ffc(dynamic, Object?) {
    // ** addr: 0x9365b4, size: -0x1
  }
  [closure] void Ncc(dynamic, Object, ua) {
    // ** addr: 0x936488, size: -0x1
  }
  [closure] void gfc(dynamic) {
    // ** addr: 0x9363a0, size: -0x1
  }
}

// class id: 6899, size: 0x14, field offset: 0xc
class Bsb<C1X0> extends Ob<C1X0, dynamic> {

  [closure] _Asb<C1X0> <anonymous closure>(dynamic) {
    // ** addr: 0x936798, size: -0x1
  }
}
