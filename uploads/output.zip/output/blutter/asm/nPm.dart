// lib: , url: nPm

// class id: 1049120, size: 0x8
class :: {
}

// class id: 3236, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SZ extends Object {

  SZ +(SZ, SZ) {
    // ** addr: 0xbafd48, size: 0x68
    // 0xbafd48: EnterFrame
    //     0xbafd48: stp             fp, lr, [SP, #-0x10]!
    //     0xbafd4c: mov             fp, SP
    // 0xbafd50: ldr             x0, [fp, #0x10]
    // 0xbafd54: r2 = Null
    //     0xbafd54: mov             x2, NULL
    // 0xbafd58: r1 = Null
    //     0xbafd58: mov             x1, NULL
    // 0xbafd5c: r4 = 60
    //     0xbafd5c: movz            x4, #0x3c
    // 0xbafd60: branchIfSmi(r0, 0xbafd6c)
    //     0xbafd60: tbz             w0, #0, #0xbafd6c
    // 0xbafd64: r4 = LoadClassIdInstr(r0)
    //     0xbafd64: ldur            x4, [x0, #-1]
    //     0xbafd68: ubfx            x4, x4, #0xc, #0x14
    // 0xbafd6c: sub             x4, x4, #0xca5
    // 0xbafd70: cmp             x4, #0xf
    // 0xbafd74: b.ls            #0xbafd8c
    // 0xbafd78: r8 = SZ
    //     0xbafd78: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b028] Type: SZ
    //     0xbafd7c: ldr             x8, [x8, #0x28]
    // 0xbafd80: r3 = Null
    //     0xbafd80: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4ed48] Null
    //     0xbafd84: ldr             x3, [x3, #0xd48]
    // 0xbafd88: r0 = DefaultTypeTest()
    //     0xbafd88: bl              #0xc5360c  ; DefaultTypeTestStub
    // 0xbafd8c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xbafd8c: ldr             x0, [PP, #0x168]  ; [pp+0x168] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xbafd90: r0 = Throw()
    //     0xbafd90: bl              #0xc53a04  ; ThrowStub
    // 0xbafd94: brk             #0
  }
}

// class id: 3242, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Nfa extends SZ {

  [closure] static Nfa? pJc(dynamic, Nfa?, Nfa?, double) {
    // ** addr: 0x8a9038, size: -0x1
  }
}

// class id: 3726, size: 0x20, field offset: 0x8
//   const constructor, 
class Mfa extends _FM {

  Lr field_8;
  _Mint field_c;
  Lfa field_14;
  _Double field_18;
}

// class id: 7273, size: 0x14, field offset: 0x14
enum Lfa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
