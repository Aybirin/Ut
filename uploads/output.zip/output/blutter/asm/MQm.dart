// lib: , url: MQm

// class id: 1049483, size: 0x8
class :: {
}

// class id: 2379, size: 0x18, field offset: 0x8
//   const constructor, 
class LJa extends Object {

  _Mint field_8;
  _Mint field_10;
}
