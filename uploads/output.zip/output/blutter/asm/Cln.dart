// lib: , url: Cln

// class id: 1050114, size: 0x8
class :: {
}

// class id: 1115, size: 0x10, field offset: 0xc
class Mkb<X0> extends ckb<X0> {
}
