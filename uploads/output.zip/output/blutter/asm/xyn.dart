// lib: , url: xyn

// class id: 1050735, size: 0x8
class :: {
}

// class id: 4706, size: 0xc, field offset: 0xc
//   const constructor, 
class CIb extends Zu {
}
