// lib: , url: Cdn

// class id: 1049786, size: 0x8
class :: {
}

// class id: 1571, size: 0x14, field offset: 0x8
class Mcb extends Object
    implements ja<X0> {
}
