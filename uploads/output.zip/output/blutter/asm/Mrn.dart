// lib: , url: Mrn

// class id: 1050391, size: 0x8
class :: {
}

// class id: 764, size: 0x8, field offset: 0x8
abstract class Wub extends Object
    implements Tub, Uub {
}

// class id: 765, size: 0xc, field offset: 0x8
class _Vub extends Object {

  static late final Map<String, _Vub> adg; // offset: 0xbdc
}
