// lib: , url: msn

// class id: 1050417, size: 0x8
class :: {
}

// class id: 721, size: 0x18, field offset: 0x8
class Yvb<X0> extends Object {
}

// class id: 733, size: 0x8, field offset: 0x8
abstract class Bvb extends Object {
}

// class id: 735, size: 0x8, field offset: 0x8
abstract class zvb extends Object {
}

// class id: 737, size: 0x8, field offset: 0x8
abstract class xvb extends Object {
}

// class id: 739, size: 0x8, field offset: 0x8
abstract class vvb extends Object {
}

// class id: 741, size: 0x8, field offset: 0x8
abstract class tvb extends Object {
}

// class id: 744, size: 0x8, field offset: 0x8
abstract class qvb extends Object {
}
