// lib: , url: bSm

// class id: 1049267, size: 0x8
class :: {
}

// class id: 2653, size: 0x18, field offset: 0x8
//   const constructor, 
class _Mta extends Object {

  _Mint field_8;
  _Double field_10;

  const double dyn:get:value(_Mta) {
    // ** addr: 0xb91120, size: 0x6c
    // 0xb91120: EnterFrame
    //     0xb91120: stp             fp, lr, [SP, #-0x10]!
    //     0xb91124: mov             fp, SP
    // 0xb91128: ldr             x1, [fp, #0x10]
    // 0xb9112c: LoadField: d0 = r1->field_f
    //     0xb9112c: ldur            d0, [x1, #0xf]
    // 0xb91130: r0 = inline_Allocate_Double()
    //     0xb91130: ldp             x0, x1, [THR, #0x50]  ; THR::top
    //     0xb91134: add             x0, x0, #0x10
    //     0xb91138: cmp             x1, x0
    //     0xb9113c: b.ls            #0xb91164
    //     0xb91140: str             x0, [THR, #0x50]  ; THR::top
    //     0xb91144: sub             x0, x0, #0xf
    //     0xb91148: movz            x1, #0xe15c
    //     0xb9114c: movk            x1, #0x3, lsl #16
    //     0xb91150: stur            x1, [x0, #-1]
    // 0xb91154: StoreField: r0->field_7 = d0
    //     0xb91154: stur            d0, [x0, #7]
    // 0xb91158: LeaveFrame
    //     0xb91158: mov             SP, fp
    //     0xb9115c: ldp             fp, lr, [SP], #0x10
    // 0xb91160: ret
    //     0xb91160: ret             
    // 0xb91164: SaveReg d0
    //     0xb91164: str             q0, [SP, #-0x10]!
    // 0xb91168: r0 = AllocateDouble()
    //     0xb91168: bl              #0xc557a0  ; AllocateDoubleStub
    // 0xb9116c: RestoreReg d0
    //     0xb9116c: ldr             q0, [SP], #0x10
    // 0xb91170: b               #0xb91154
  }
}

// class id: 2655, size: 0x18, field offset: 0x8
//   const constructor, 
class Kta extends Object {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 2963, size: 0x68, field offset: 0x5c
class _Jta extends oX {
}

// class id: 3139, size: 0xc, field offset: 0x8
//   const constructor, 
class _bua extends iha {
}

// class id: 3768, size: 0x18, field offset: 0x14
class _jua extends Hqa<dynamic> {
}

// class id: 3769, size: 0x18, field offset: 0x14
class _hua extends Hqa<dynamic> {
}

// class id: 3770, size: 0x20, field offset: 0x14
class _gua<X0 bound fua> extends Hqa<X0 bound fua> {
}

// class id: 3771, size: 0x2c, field offset: 0x14
class _eua<X0 bound fua> extends Hqa<X0 bound fua> {
}

// class id: 3772, size: 0x20, field offset: 0x14
class _cua<X0 bound dua> extends Hqa<X0 bound dua> {
}

// class id: 4203, size: 0x18, field offset: 0x14
class _Yta extends Xu<dynamic>
    implements vqa {

  [closure] bool <anonymous closure>(dynamic, WQ<YQ>) {
    // ** addr: 0x49eb24, size: -0x1
  }
  [closure] void sJc(dynamic) {
    // ** addr: 0x813f30, size: -0x1
  }
}

// class id: 4204, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _Pta extends Xu<dynamic>
     with OZ<X0 bound Vu> {
}

// class id: 4205, size: 0x18, field offset: 0x18
//   transformed mixin,
abstract class _Qta extends _Pta
     with mw {
}

// class id: 4206, size: 0x20, field offset: 0x18
//   transformed mixin,
abstract class _Rta extends _Qta
     with eC<X0 bound Vu> {

  [closure] void _KId(dynamic) {
    // ** addr: 0x5812b8, size: -0x1
  }
}

// class id: 4207, size: 0x20, field offset: 0x20
//   transformed mixin,
abstract class _Sta extends _Rta
     with uqa {
}

// class id: 4208, size: 0x20, field offset: 0x20
//   transformed mixin,
abstract class _Tta extends _Sta
     with Wna {
}

// class id: 4209, size: 0xf4, field offset: 0x20
class Uta extends _Tta
    implements rea {

  late final yia NYd; // offset: 0xcc
  late final CM _pae; // offset: 0x28
  late MDa _Fae; // offset: 0x6c
  late Dt _hZc; // offset: 0x70
  late final _gua<fua> _gbe; // offset: 0xec
  late final Map<Type, Gqa<Fqa>> _hbe; // offset: 0xf0
  late final Gqa<vEa> _ebe; // offset: 0xe4
  late final Gqa<xEa> _fbe; // offset: 0xe8
  late final Gqa<yEa> _dbe; // offset: 0xe0
  late double _Wae; // offset: 0xb8

  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xbbe0d4, size: 0x16c
    // 0xbbe0d4: EnterFrame
    //     0xbbe0d4: stp             fp, lr, [SP, #-0x10]!
    //     0xbbe0d8: mov             fp, SP
    // 0xbbe0dc: AllocStack(0x20)
    //     0xbbe0dc: sub             SP, SP, #0x20
    // 0xbbe0e0: SetupParameters(Uta this /* r1 */)
    //     0xbbe0e0: stur            NULL, [fp, #-8]
    //     0xbbe0e4: movz            x0, #0
    //     0xbbe0e8: add             x1, fp, w0, sxtw #2
    //     0xbbe0ec: ldr             x1, [x1, #0x10]
    //     0xbbe0f0: ldur            w2, [x1, #0x17]
    //     0xbbe0f4: add             x2, x2, HEAP, lsl #32
    //     0xbbe0f8: stur            x2, [fp, #-0x10]
    // 0xbbe0fc: CheckStackOverflow
    //     0xbbe0fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbbe100: cmp             SP, x16
    //     0xbbe104: b.ls            #0xbbe230
    // 0xbbe108: InitAsync() -> Future<void?>
    //     0xbbe108: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xbbe10c: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbbe110: ldur            x0, [fp, #-0x10]
    // 0xbbe114: LoadField: r3 = r0->field_b
    //     0xbbe114: ldur            w3, [x0, #0xb]
    // 0xbbe118: DecompressPointer r3
    //     0xbbe118: add             x3, x3, HEAP, lsl #32
    // 0xbbe11c: stur            x3, [fp, #-0x18]
    // 0xbbe120: LoadField: r1 = r3->field_13
    //     0xbbe120: ldur            w1, [x3, #0x13]
    // 0xbbe124: DecompressPointer r1
    //     0xbbe124: add             x1, x1, HEAP, lsl #32
    // 0xbbe128: LoadField: r2 = r3->field_f
    //     0xbbe128: ldur            w2, [x3, #0xf]
    // 0xbbe12c: DecompressPointer r2
    //     0xbbe12c: add             x2, x2, HEAP, lsl #32
    // 0xbbe130: LoadField: r4 = r2->field_b
    //     0xbbe130: ldur            w4, [x2, #0xb]
    // 0xbbe134: DecompressPointer r4
    //     0xbbe134: add             x4, x4, HEAP, lsl #32
    // 0xbbe138: cmp             w4, NULL
    // 0xbbe13c: b.eq            #0xbbe238
    // 0xbbe140: LoadField: r2 = r4->field_b
    //     0xbbe140: ldur            w2, [x4, #0xb]
    // 0xbbe144: DecompressPointer r2
    //     0xbbe144: add             x2, x2, HEAP, lsl #32
    // 0xbbe148: LoadField: r4 = r2->field_27
    //     0xbbe148: ldur            w4, [x2, #0x27]
    // 0xbbe14c: DecompressPointer r4
    //     0xbbe14c: add             x4, x4, HEAP, lsl #32
    // 0xbbe150: LoadField: r2 = r4->field_7
    //     0xbbe150: ldur            w2, [x4, #7]
    // 0xbbe154: DecompressPointer r2
    //     0xbbe154: add             x2, x2, HEAP, lsl #32
    // 0xbbe158: r0 = call 0x4861fc
    //     0xbbe158: bl              #0x4861fc
    // 0xbbe15c: LoadField: r1 = r0->field_7
    //     0xbbe15c: ldur            w1, [x0, #7]
    // 0xbbe160: cbz             w1, #0xbbe228
    // 0xbbe164: ldur            x4, [fp, #-0x10]
    // 0xbbe168: ldur            x6, [fp, #-0x18]
    // 0xbbe16c: LoadField: r1 = r6->field_f
    //     0xbbe16c: ldur            w1, [x6, #0xf]
    // 0xbbe170: DecompressPointer r1
    //     0xbbe170: add             x1, x1, HEAP, lsl #32
    // 0xbbe174: LoadField: r2 = r1->field_73
    //     0xbbe174: ldur            w2, [x1, #0x73]
    // 0xbbe178: DecompressPointer r2
    //     0xbbe178: add             x2, x2, HEAP, lsl #32
    // 0xbbe17c: LoadField: r3 = r4->field_f
    //     0xbbe17c: ldur            w3, [x4, #0xf]
    // 0xbbe180: DecompressPointer r3
    //     0xbbe180: add             x3, x3, HEAP, lsl #32
    // 0xbbe184: LoadField: r5 = r3->field_7
    //     0xbbe184: ldur            w5, [x3, #7]
    // 0xbbe188: DecompressPointer r5
    //     0xbbe188: add             x5, x5, HEAP, lsl #32
    // 0xbbe18c: LoadField: r3 = r1->field_b
    //     0xbbe18c: ldur            w3, [x1, #0xb]
    // 0xbbe190: DecompressPointer r3
    //     0xbbe190: add             x3, x3, HEAP, lsl #32
    // 0xbbe194: cmp             w3, NULL
    // 0xbbe198: b.eq            #0xbbe23c
    // 0xbbe19c: LoadField: r1 = r3->field_23
    //     0xbbe19c: ldur            w1, [x3, #0x23]
    // 0xbbe1a0: DecompressPointer r1
    //     0xbbe1a0: add             x1, x1, HEAP, lsl #32
    // 0xbbe1a4: mov             x16, x5
    // 0xbbe1a8: mov             x5, x2
    // 0xbbe1ac: mov             x2, x16
    // 0xbbe1b0: mov             x16, x1
    // 0xbbe1b4: mov             x1, x5
    // 0xbbe1b8: mov             x5, x16
    // 0xbbe1bc: mov             x3, x0
    // 0xbbe1c0: r0 = __unknown_function__()
    //     0xbbe1c0: bl              #0xbbe240  ; [] ::__unknown_function__
    // 0xbbe1c4: mov             x1, x0
    // 0xbbe1c8: stur            x1, [fp, #-0x20]
    // 0xbbe1cc: r0 = Await()
    //     0xbbe1cc: bl              #0xb0c534  ; AwaitStub
    // 0xbbe1d0: stur            x0, [fp, #-0x10]
    // 0xbbe1d4: cmp             w0, NULL
    // 0xbbe1d8: b.eq            #0xbbe214
    // 0xbbe1dc: ldur            x2, [fp, #-0x18]
    // 0xbbe1e0: LoadField: r1 = r2->field_f
    //     0xbbe1e0: ldur            w1, [x2, #0xf]
    // 0xbbe1e4: DecompressPointer r1
    //     0xbbe1e4: add             x1, x1, HEAP, lsl #32
    // 0xbbe1e8: r0 = call 0x6852d0
    //     0xbbe1e8: bl              #0x6852d0
    // 0xbbe1ec: tbnz            w0, #4, #0xbbe20c
    // 0xbbe1f0: ldur            x0, [fp, #-0x18]
    // 0xbbe1f4: LoadField: r1 = r0->field_f
    //     0xbbe1f4: ldur            w1, [x0, #0xf]
    // 0xbbe1f8: DecompressPointer r1
    //     0xbbe1f8: add             x1, x1, HEAP, lsl #32
    // 0xbbe1fc: ldur            x3, [fp, #-0x10]
    // 0xbbe200: r2 = Instance_tqa
    //     0xbbe200: ldr             x2, [PP, #0x4d40]  ; [pp+0x4d40] Obj!tqa@69bcb1
    // 0xbbe204: r0 = call 0x684a80
    //     0xbbe204: bl              #0x684a80
    // 0xbbe208: b               #0xbbe228
    // 0xbbe20c: ldur            x0, [fp, #-0x18]
    // 0xbbe210: b               #0xbbe218
    // 0xbbe214: ldur            x0, [fp, #-0x18]
    // 0xbbe218: LoadField: r1 = r0->field_f
    //     0xbbe218: ldur            w1, [x0, #0xf]
    // 0xbbe21c: DecompressPointer r1
    //     0xbbe21c: add             x1, x1, HEAP, lsl #32
    // 0xbbe220: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xbbe220: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xbbe224: r0 = call 0x49bcdc
    //     0xbbe224: bl              #0x49bcdc
    // 0xbbe228: r0 = Null
    //     0xbbe228: mov             x0, NULL
    // 0xbbe22c: r0 = ReturnAsyncNotFuture()
    //     0xbbe22c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbbe230: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbe230: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbe234: b               #0xbbe108
    // 0xbbe238: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbe238: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbbe23c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbbe23c: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void mtd(dynamic, String) {
    // ** addr: 0x49d88c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x47ac48, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x47ad28, size: -0x1
  }
  [closure] void _vce(dynamic, YAa) {
    // ** addr: 0x4865ec, size: -0x1
  }
  [closure] Er <anonymous closure>(dynamic, Ht) {
    // ** addr: 0x489888, size: -0x1
  }
  [closure] Er <anonymous closure>(dynamic, Er, Er) {
    // ** addr: 0x489854, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x487ab4, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x489c38, size: -0x1
  }
  [closure] void _Zbe(dynamic) {
    // ** addr: 0x495204, size: -0x1
  }
  [closure] void _Mce(dynamic) {
    // ** addr: 0x48ba68, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, r) {
    // ** addr: 0x48b740, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x48b9bc, size: -0x1
  }
  [closure] void _Ice(dynamic) {
    // ** addr: 0x48da24, size: -0x1
  }
  [closure] Mca <anonymous closure>(dynamic, iva) {
    // ** addr: 0x492af4, size: -0x1
  }
  [closure] Vna <anonymous closure>(dynamic, Vna, hqa) {
    // ** addr: 0x490f24, size: -0x1
  }
  [closure] void _pce(dynamic) {
    // ** addr: 0x491024, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x491238, size: -0x1
  }
  [closure] void _Vce(dynamic, [Ea?]) {
    // ** addr: 0x494184, size: -0x1
  }
  [closure] void _nce(dynamic) {
    // ** addr: 0x495604, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x686168, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x686398, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6868d8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6860d0, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x686894, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x686850, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x68680c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x686708, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x685238, size: -0x1
  }
  [closure] void _Qce(dynamic) {
    // ** addr: 0x5ee2d8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x68611c, size: -0x1
  }
  [closure] void sJc(dynamic) {
    // ** addr: 0x813ed4, size: -0x1
  }
  [closure] void _Fde(dynamic, XR) {
    // ** addr: 0x68d75c, size: -0x1
  }
  [closure] Rra <anonymous closure>(dynamic, iva, Uma) {
    // ** addr: 0x68a13c, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, YAa) {
    // ** addr: 0x68a0dc, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, Vna?, Vna) {
    // ** addr: 0x689fcc, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Vna) {
    // ** addr: 0x689f7c, size: -0x1
  }
  [closure] Vna <anonymous closure>(dynamic, Vna) {
    // ** addr: 0x689f3c, size: -0x1
  }
  [closure] void _Tce(dynamic, Yia) {
    // ** addr: 0x689e74, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x68c234, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x68be18, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x68bfe4, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x68c1b0, size: -0x1
  }
  [closure] Future<void> <anonymous closure>(dynamic, tEa) {
    // ** addr: 0x68d614, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x4cf790, size: -0x1
  }
  [closure] void _Rce(dynamic) {
    // ** addr: 0x5edcc8, size: -0x1
  }
  [closure] void _Abe(dynamic) {
    // ** addr: 0x7cd9d4, size: -0x1
  }
  [closure] void _zbe(dynamic) {
    // ** addr: 0x7cd948, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5ee2b8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x5edc28, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x5edbe0, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x7e832c, size: -0x1
  }
  [closure] Object? _Ede(dynamic, Wqa) {
    // ** addr: 0xa01e48, size: -0x1
  }
  [closure] void _Dde(dynamic, xEa) {
    // ** addr: 0xa01f80, size: -0x1
  }
  [closure] void _Cde(dynamic, sEa) {
    // ** addr: 0xa02068, size: -0x1
  }
  [closure] void _Bde(dynamic, LBa) {
    // ** addr: 0xa021f8, size: -0x1
  }
  [closure] void _Ade(dynamic, rEa) {
    // ** addr: 0xa0248c, size: -0x1
  }
  [closure] void _zde(dynamic, vEa) {
    // ** addr: 0xa0259c, size: -0x1
  }
  [closure] void _yde(dynamic, yEa) {
    // ** addr: 0xa025fc, size: -0x1
  }
  [closure] iha _wde(dynamic) {
    // ** addr: 0xa038b0, size: -0x1
  }
  [closure] iha _vde(dynamic) {
    // ** addr: 0xa03960, size: -0x1
  }
  [closure] iha _ude(dynamic) {
    // ** addr: 0xa05c7c, size: -0x1
  }
  [closure] iha _tde(dynamic) {
    // ** addr: 0xa060d0, size: -0x1
  }
  [closure] iha _sde(dynamic) {
    // ** addr: 0xa03a10, size: -0x1
  }
  [closure] Jt _rde(dynamic, Jt, bool, iha) {
    // ** addr: 0xa07808, size: -0x1
  }
  [closure] Jt _ode(dynamic, Jt, bool, iha) {
    // ** addr: 0xa07c78, size: -0x1
  }
  Map<Type, Gqa<Fqa>> _hbe(Uta) {
    // ** addr: 0x68c2a0, size: -0x1
  }
}

// class id: 4382, size: 0x1c, field offset: 0x18
//   const constructor, 
class _Zta extends aua {

  Ot field_c;
  dsa field_14;
  Pg field_18;
}

// class id: 4470, size: 0xb0, field offset: 0x10
class _Vta extends Fea {
}

// class id: 4514, size: 0x18, field offset: 0x10
//   const constructor, 
class _Ita extends xL {
}

// class id: 5115, size: 0x20, field offset: 0xc
//   const constructor, 
class _Xta extends Vu {
}

// class id: 5116, size: 0x12c, field offset: 0xc
class Ota extends Vu {
}

// class id: 5252, size: 0x20, field offset: 0xc
class _Nta extends CM {
}

// class id: 6204, size: 0x2c, field offset: 0x2c
class ada extends Tz<dynamic> {
}
