// lib: , url: Mfn

// class id: 1049842, size: 0x8
class :: {
}

// class id: 1495, size: 0x14, field offset: 0x8
class _xeb extends Object {
}

// class id: 1496, size: 0x38, field offset: 0x8
class web extends Object {

  late jhb OWb; // offset: 0x8
  static late final Uint8List oHh; // offset: 0x1464
}
