// lib: ZCn, url: aon

// class id: 1050226, size: 0x8
class :: {
}

// class id: 959, size: 0x14, field offset: 0x8
class lpb extends jpb {

  static late final fqb GEg; // offset: 0xf4c

  [closure] static (dynamic) => lpb <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x402318, size: -0x1
  }
  [closure] static lpb <anonymous closure>(dynamic) {
    // ** addr: 0x40236c, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x4022b4, size: -0x1
  }
}
