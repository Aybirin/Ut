// lib: , url: zEm

// class id: 1048639, size: 0x8
class :: {
}

// class id: 6093, size: 0xc, field offset: 0x8
class tw extends Object {

  static late final tw ZLc; // offset: 0xc58
}
