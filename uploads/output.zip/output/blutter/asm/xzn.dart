// lib: , url: xzn

// class id: 1050787, size: 0x8
class :: {
}

// class id: 3945, size: 0x1c, field offset: 0x14
class _sKb<C1X0> extends Xu<C1X0> {

  late final tKb _rWj; // offset: 0x14

  [closure] void sJc(dynamic) {
    // ** addr: 0x816d8c, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic, bool) {
    // ** addr: 0x7bad3c, size: -0x1
  }
}

// class id: 4925, size: 0x24, field offset: 0xc
//   const constructor, 
class rKb<X0> extends Vu {
}
