// lib: eDn, url: eon

// class id: 1050230, size: 0x8
class :: {
}

// class id: 954, size: 0x8, field offset: 0x8
class tpb extends upb {

  static late final fqb GEg; // offset: 0xf60

  [closure] static tpb <anonymous closure>(dynamic) {
    // ** addr: 0x401788, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x401730, size: -0x1
  }
}
