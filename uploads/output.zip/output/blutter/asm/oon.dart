// lib: yEn, url: oon

// class id: 1050240, size: 0x8
class :: {
}

// class id: 1051, size: 0x30, field offset: 0x8
abstract class Olb extends Object
    implements vlb {

  late Uint8List _yGg; // offset: 0x1c
  late int _vGg; // offset: 0x10
  late Uint8List _xGg; // offset: 0x18
  late bool _MEg; // offset: 0xc
  late int _CGg; // offset: 0x2c
}
