// lib: , url: Hxn

// class id: 1050692, size: 0x8
class :: {
}

// class id: 4720, size: 0x14, field offset: 0xc
//   const constructor, 
class iGb extends Zu {
}

// class id: 4721, size: 0x10, field offset: 0xc
//   const constructor, 
class hGb extends Zu {
}

// class id: 7037, size: 0x14, field offset: 0x14
enum gGb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
