// lib: , url: zOm

// class id: 1049085, size: 0x8
class :: {
}

// class id: 3746, size: 0x10, field offset: 0x8
//   const constructor, 
class Yca extends _FM {
}
