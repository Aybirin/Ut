// lib: , url: NFm

// class id: 1048699, size: 0x8
class :: {
}
