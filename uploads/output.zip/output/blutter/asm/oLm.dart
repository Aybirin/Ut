// lib: , url: oLm

// class id: 1048927, size: 0x8
class :: {
}

// class id: 3626, size: 0xc, field offset: 0x8
abstract class KM<X0> extends Object {
}

// class id: 5275, size: 0x14, field offset: 0xc
//   transformed mixin,
abstract class _WM<X0> extends oM<X0>
     with MM {
}

// class id: 5276, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _XM<X0> extends _WM<X0>
     with xM {
}

// class id: 5277, size: 0x1c, field offset: 0x18
//   transformed mixin,
abstract class _YM<X0> extends _XM<X0>
     with zM {
}

// class id: 5278, size: 0x2c, field offset: 0x1c
abstract class ZM<X0> extends _YM<X0> {

  [closure] void _Qpf(dynamic) {
    // ** addr: 0x96fda0, size: -0x1
  }
  [closure] void _Ppf(dynamic, nM) {
    // ** addr: 0x96fcd0, size: -0x1
  }
}

// class id: 5280, size: 0x2c, field offset: 0x2c
class aN<X0 bound num> extends ZM<X0 bound num> {

  X0 dyn:get:value(aN<X0>) {
    // ** addr: 0xbb00e4, size: 0x48
    // 0xbb00e4: EnterFrame
    //     0xbb00e4: stp             fp, lr, [SP, #-0x10]!
    //     0xbb00e8: mov             fp, SP
    // 0xbb00ec: CheckStackOverflow
    //     0xbb00ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbb00f0: cmp             SP, x16
    //     0xbb00f4: b.ls            #0xbb010c
    // 0xbb00f8: ldr             x1, [fp, #0x10]
    // 0xbb00fc: r0 = call 0x4cd008
    //     0xbb00fc: bl              #0x4cd008
    // 0xbb0100: LeaveFrame
    //     0xbb0100: mov             SP, fp
    //     0xbb0104: ldp             fp, lr, [SP], #0x10
    // 0xbb0108: ret
    //     0xbb0108: ret             
    // 0xbb010c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb010c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb0110: b               #0xbb00f8
  }
}

// class id: 5284, size: 0x1c, field offset: 0xc
class SM extends _TM {

  double dyn:get:value(SM) {
    // ** addr: 0xb9feb0, size: 0x48
    // 0xb9feb0: EnterFrame
    //     0xb9feb0: stp             fp, lr, [SP, #-0x10]!
    //     0xb9feb4: mov             fp, SP
    // 0xb9feb8: CheckStackOverflow
    //     0xb9feb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb9febc: cmp             SP, x16
    //     0xb9fec0: b.ls            #0xb9fed8
    // 0xb9fec4: ldr             x1, [fp, #0x10]
    // 0xb9fec8: r0 = call 0x4cca80
    //     0xb9fec8: bl              #0x4cca80
    // 0xb9fecc: LeaveFrame
    //     0xb9fecc: mov             SP, fp
    //     0xb9fed0: ldp             fp, lr, [SP], #0x10
    // 0xb9fed4: ret
    //     0xb9fed4: ret             
    // 0xb9fed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9fed8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9fedc: b               #0xb9fec4
  }
  [closure] void _aqf(dynamic, nM) {
    // ** addr: 0x517a2c, size: -0x1
  }
}

// class id: 5285, size: 0x14, field offset: 0xc
//   transformed mixin,
abstract class _LM extends oM<dynamic>
     with MM {
}

// class id: 5286, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _QM extends _LM
     with zM {
}

// class id: 5287, size: 0x1c, field offset: 0x18
class RM extends _QM {

  double dyn:get:value(RM) {
    // ** addr: 0xb9f948, size: 0x48
    // 0xb9f948: EnterFrame
    //     0xb9f948: stp             fp, lr, [SP, #-0x10]!
    //     0xb9f94c: mov             fp, SP
    // 0xb9f950: CheckStackOverflow
    //     0xb9f950: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb9f954: cmp             SP, x16
    //     0xb9f958: b.ls            #0xb9f970
    // 0xb9f95c: ldr             x1, [fp, #0x10]
    // 0xb9f960: r0 = call 0x4cc9e4
    //     0xb9f960: bl              #0x4cc9e4
    // 0xb9f964: LeaveFrame
    //     0xb9f964: mov             SP, fp
    //     0xb9f968: ldp             fp, lr, [SP], #0x10
    // 0xb9f96c: ret
    //     0xb9f96c: ret             
    // 0xb9f970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9f970: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9f974: b               #0xb9f95c
  }
  [closure] void _Wpf(dynamic, nM) {
    // ** addr: 0x4fb2a8, size: -0x1
  }
}

// class id: 5288, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class _NM extends _LM
     with xM {

  [closure] void lid(dynamic) {
    // ** addr: 0x4fb270, size: -0x1
  }
}

// class id: 5289, size: 0x1c, field offset: 0x18
//   transformed mixin,
abstract class _OM extends _NM
     with zM {

  [closure] void hpf(dynamic, nM) {
    // ** addr: 0x4fb234, size: -0x1
  }
}

// class id: 5290, size: 0x28, field offset: 0x1c
class PM extends _OM {

  double dyn:get:value(PM) {
    // ** addr: 0xbb2274, size: 0x48
    // 0xbb2274: EnterFrame
    //     0xbb2274: stp             fp, lr, [SP, #-0x10]!
    //     0xbb2278: mov             fp, SP
    // 0xbb227c: CheckStackOverflow
    //     0xbb227c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbb2280: cmp             SP, x16
    //     0xbb2284: b.ls            #0xbb229c
    // 0xbb2288: ldr             x1, [fp, #0x10]
    // 0xbb228c: r0 = call 0x4cc92c
    //     0xbb228c: bl              #0x4cc92c
    // 0xbb2290: LeaveFrame
    //     0xbb2290: mov             SP, fp
    //     0xbb2294: ldp             fp, lr, [SP], #0x10
    // 0xbb2298: ret
    //     0xbb2298: ret             
    // 0xbb229c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb229c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb22a0: b               #0xbb2288
  }
}

// class id: 5291, size: 0x10, field offset: 0xc
//   const constructor, 
class JM<X0> extends oM<X0> {

  Lr field_c;
}

// class id: 5292, size: 0xc, field offset: 0xc
//   const constructor, 
class _IM extends oM<dynamic> {

  double dyn:get:value(_IM) {
    // ** addr: 0xbb0940, size: 0x20
    // 0xbb0940: r0 = 0.000000
    //     0xbb0940: ldr             x0, [PP, #0x4530]  ; [pp+0x4530] 0
    // 0xbb0944: ret
    //     0xbb0944: ret             
  }
}

// class id: 5293, size: 0xc, field offset: 0xc
//   const constructor, 
class _HM extends oM<dynamic> {

  double dyn:get:value(_HM) {
    // ** addr: 0xbaffe4, size: 0x20
    // 0xbaffe4: r0 = 1.000000
    //     0xbaffe4: ldr             x0, [PP, #0x45f8]  ; [pp+0x45f8] 1
    // 0xbaffe8: ret
    //     0xbaffe8: ret             
  }
}

// class id: 5297, size: 0x2c, field offset: 0x14
class VM extends _yM {

  double dyn:get:value(VM) {
    // ** addr: 0xbb0058, size: 0x74
    // 0xbb0058: EnterFrame
    //     0xbb0058: stp             fp, lr, [SP, #-0x10]!
    //     0xbb005c: mov             fp, SP
    // 0xbb0060: CheckStackOverflow
    //     0xbb0060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbb0064: cmp             SP, x16
    //     0xbb0068: b.ls            #0xbb00a8
    // 0xbb006c: ldr             x0, [fp, #0x10]
    // 0xbb0070: LoadField: r1 = r0->field_13
    //     0xbb0070: ldur            w1, [x0, #0x13]
    // 0xbb0074: DecompressPointer r1
    //     0xbb0074: add             x1, x1, HEAP, lsl #32
    // 0xbb0078: cmp             w1, NULL
    // 0xbb007c: b.eq            #0xbb00b0
    // 0xbb0080: r0 = LoadClassIdInstr(r1)
    //     0xbb0080: ldur            x0, [x1, #-1]
    //     0xbb0084: ubfx            x0, x0, #0xc, #0x14
    // 0xbb0088: r0 = GDT[cid_x0 + 0x13c7e]()
    //     0xbb0088: movz            x17, #0x3c7e
    //     0xbb008c: movk            x17, #0x1, lsl #16
    //     0xbb0090: add             lr, x0, x17
    //     0xbb0094: ldr             lr, [x21, lr, lsl #3]
    //     0xbb0098: blr             lr
    // 0xbb009c: LeaveFrame
    //     0xbb009c: mov             SP, fp
    //     0xbb00a0: ldp             fp, lr, [SP], #0x10
    // 0xbb00a4: ret
    //     0xbb00a4: ret             
    // 0xbb00a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb00a8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb00ac: b               #0xbb006c
    // 0xbb00b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb00b0: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _Wpf(dynamic, nM) {
    // ** addr: 0x5e4eb8, size: -0x1
  }
  [closure] void _Xpf(dynamic) {
    // ** addr: 0x5e4aec, size: -0x1
  }
}

// class id: 7336, size: 0x14, field offset: 0x14
enum _UM extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
