// lib: , url: BTm

// class id: 1049349, size: 0x8
class :: {
}

// class id: 3652, size: 0x8, field offset: 0x8
//   const constructor, 
class yEa extends Fqa {
}

// class id: 3653, size: 0x14, field offset: 0x8
//   const constructor, 
class xEa extends Fqa {
}

// class id: 3654, size: 0xc, field offset: 0x8
//   const constructor, 
class wEa extends Fqa {

  tqa field_8;
}

// class id: 3655, size: 0x18, field offset: 0x8
//   const constructor, 
class vEa extends Fqa {
}

// class id: 3656, size: 0xc, field offset: 0x8
//   const constructor, 
class uEa extends Fqa {

  tqa field_8;
}

// class id: 3657, size: 0xc, field offset: 0x8
//   const constructor, 
class tEa extends Fqa {

  tqa field_8;
}

// class id: 3658, size: 0x10, field offset: 0x8
//   const constructor, 
class kua extends Fqa {

  tqa field_8;
  bool field_c;
}

// class id: 3659, size: 0xc, field offset: 0x8
//   const constructor, 
class iua extends Fqa {

  tqa field_8;
}

// class id: 3660, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class dua extends Fqa {
}

// class id: 3661, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class sEa extends dua {
}

// class id: 3662, size: 0xc, field offset: 0xc
//   const constructor, 
class rEa extends dua {

  bool field_8;
}

// class id: 3663, size: 0x18, field offset: 0xc
//   const constructor, 
abstract class fua extends dua {
}

// class id: 3664, size: 0x18, field offset: 0x18
//   const constructor, 
class qEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3665, size: 0x18, field offset: 0x18
//   const constructor, 
class pEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3666, size: 0x18, field offset: 0x18
//   const constructor, 
class oEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3667, size: 0x18, field offset: 0x18
//   const constructor, 
class nEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3668, size: 0x18, field offset: 0x18
//   const constructor, 
class mEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3669, size: 0x18, field offset: 0x18
//   const constructor, 
class lEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3670, size: 0x18, field offset: 0x18
//   const constructor, 
class kEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3671, size: 0x18, field offset: 0x18
//   const constructor, 
class jEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3672, size: 0x18, field offset: 0x18
//   const constructor, 
class iEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3673, size: 0x18, field offset: 0x18
//   const constructor, 
class hEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3674, size: 0x18, field offset: 0x18
//   const constructor, 
class gEa extends fua {

  bool field_8;
  bool field_c;
  bool field_10;
  bool field_14;
}

// class id: 3675, size: 0xc, field offset: 0xc
//   const constructor, 
class fEa extends dua {

  bool field_8;
}

// class id: 3676, size: 0xc, field offset: 0xc
//   const constructor, 
class eEa extends dua {

  bool field_8;
}

// class id: 3677, size: 0xc, field offset: 0xc
//   const constructor, 
class dEa extends dua {

  bool field_8;
}

// class id: 3678, size: 0x8, field offset: 0x8
//   const constructor, 
class cEa extends Fqa {
}
