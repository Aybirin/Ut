// lib: , url: file:///var/www/html/flutter/yc202-app/.dart_tool/flutter_build/dart_plugin_registrant.dart

// class id: 1048595, size: 0x8
class :: {
}

// class id: 6248, size: 0x8, field offset: 0x8
class _PluginRegistrant extends Object {

  static void register() {
    // ** addr: 0xc56618, size: 0x2f4
    // 0xc56618: EnterFrame
    //     0xc56618: stp             fp, lr, [SP, #-0x10]!
    //     0xc5661c: mov             fp, SP
    // 0xc56620: AllocStack(0x38)
    //     0xc56620: sub             SP, SP, #0x38
    // 0xc56624: CheckStackOverflow
    //     0xc56624: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc56628: cmp             SP, x16
    //     0xc5662c: b.ls            #0xc56904
    // 0xc56630: r0 = call 0xb04530
    //     0xc56630: bl              #0xb04530
    // 0xc56634: r0 = Null
    //     0xc56634: mov             x0, NULL
    // 0xc56638: b               #0xc5667c
    // 0xc5663c: sub             SP, fp, #0x38
    // 0xc56640: stur            x0, [fp, #-0x30]
    // 0xc56644: r1 = Null
    //     0xc56644: mov             x1, NULL
    // 0xc56648: r2 = 6
    //     0xc56648: movz            x2, #0x6
    // 0xc5664c: r0 = AllocateArray()
    //     0xc5664c: bl              #0xc55848  ; AllocateArrayStub
    // 0xc56650: r16 = "`camera_android_camerax` threw an error: "
    //     0xc56650: ldr             x16, [PP, #0x5a20]  ; [pp+0x5a20] "`camera_android_camerax` threw an error: "
    // 0xc56654: StoreField: r0->field_f = r16
    //     0xc56654: stur            w16, [x0, #0xf]
    // 0xc56658: ldur            x1, [fp, #-0x30]
    // 0xc5665c: StoreField: r0->field_13 = r1
    //     0xc5665c: stur            w1, [x0, #0x13]
    // 0xc56660: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc56660: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc56664: ArrayStore: r0[0] = r16  ; List_4
    //     0xc56664: stur            w16, [x0, #0x17]
    // 0xc56668: str             x0, [SP]
    // 0xc5666c: r0 = _interpolate()
    //     0xc5666c: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc56670: mov             x1, x0
    // 0xc56674: r0 = call 0x63acb4
    //     0xc56674: bl              #0x63acb4
    // 0xc56678: ldur            x0, [fp, #-0x30]
    // 0xc5667c: stur            x0, [fp, #-0x30]
    // 0xc56680: r0 = call 0xb04438
    //     0xc56680: bl              #0xb04438
    // 0xc56684: ldur            x0, [fp, #-0x30]
    // 0xc56688: b               #0xc566cc
    // 0xc5668c: sub             SP, fp, #0x38
    // 0xc56690: stur            x0, [fp, #-0x30]
    // 0xc56694: r1 = Null
    //     0xc56694: mov             x1, NULL
    // 0xc56698: r2 = 6
    //     0xc56698: movz            x2, #0x6
    // 0xc5669c: r0 = AllocateArray()
    //     0xc5669c: bl              #0xc55848  ; AllocateArrayStub
    // 0xc566a0: r16 = "`flutter_inappwebview_android` threw an error: "
    //     0xc566a0: ldr             x16, [PP, #0x5a30]  ; [pp+0x5a30] "`flutter_inappwebview_android` threw an error: "
    // 0xc566a4: StoreField: r0->field_f = r16
    //     0xc566a4: stur            w16, [x0, #0xf]
    // 0xc566a8: ldur            x1, [fp, #-0x30]
    // 0xc566ac: StoreField: r0->field_13 = r1
    //     0xc566ac: stur            w1, [x0, #0x13]
    // 0xc566b0: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc566b0: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc566b4: ArrayStore: r0[0] = r16  ; List_4
    //     0xc566b4: stur            w16, [x0, #0x17]
    // 0xc566b8: str             x0, [SP]
    // 0xc566bc: r0 = _interpolate()
    //     0xc566bc: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc566c0: mov             x1, x0
    // 0xc566c4: r0 = call 0x63acb4
    //     0xc566c4: bl              #0x63acb4
    // 0xc566c8: ldur            x0, [fp, #-0x30]
    // 0xc566cc: stur            x0, [fp, #-0x30]
    // 0xc566d0: r0 = call 0xb0430c
    //     0xc566d0: bl              #0xb0430c
    // 0xc566d4: ldur            x0, [fp, #-0x30]
    // 0xc566d8: b               #0xc5671c
    // 0xc566dc: sub             SP, fp, #0x38
    // 0xc566e0: stur            x0, [fp, #-0x30]
    // 0xc566e4: r1 = Null
    //     0xc566e4: mov             x1, NULL
    // 0xc566e8: r2 = 6
    //     0xc566e8: movz            x2, #0x6
    // 0xc566ec: r0 = AllocateArray()
    //     0xc566ec: bl              #0xc55848  ; AllocateArrayStub
    // 0xc566f0: r16 = "`flutter_local_notifications` threw an error: "
    //     0xc566f0: ldr             x16, [PP, #0x5a38]  ; [pp+0x5a38] "`flutter_local_notifications` threw an error: "
    // 0xc566f4: StoreField: r0->field_f = r16
    //     0xc566f4: stur            w16, [x0, #0xf]
    // 0xc566f8: ldur            x1, [fp, #-0x30]
    // 0xc566fc: StoreField: r0->field_13 = r1
    //     0xc566fc: stur            w1, [x0, #0x13]
    // 0xc56700: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc56700: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc56704: ArrayStore: r0[0] = r16  ; List_4
    //     0xc56704: stur            w16, [x0, #0x17]
    // 0xc56708: str             x0, [SP]
    // 0xc5670c: r0 = _interpolate()
    //     0xc5670c: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc56710: mov             x1, x0
    // 0xc56714: r0 = call 0x63acb4
    //     0xc56714: bl              #0x63acb4
    // 0xc56718: ldur            x0, [fp, #-0x30]
    // 0xc5671c: stur            x0, [fp, #-0x30]
    // 0xc56720: r0 = call 0xb041f4
    //     0xc56720: bl              #0xb041f4
    // 0xc56724: ldur            x0, [fp, #-0x30]
    // 0xc56728: b               #0xc5676c
    // 0xc5672c: sub             SP, fp, #0x38
    // 0xc56730: stur            x0, [fp, #-0x30]
    // 0xc56734: r1 = Null
    //     0xc56734: mov             x1, NULL
    // 0xc56738: r2 = 6
    //     0xc56738: movz            x2, #0x6
    // 0xc5673c: r0 = AllocateArray()
    //     0xc5673c: bl              #0xc55848  ; AllocateArrayStub
    // 0xc56740: r16 = "`image_picker_android` threw an error: "
    //     0xc56740: ldr             x16, [PP, #0x5a40]  ; [pp+0x5a40] "`image_picker_android` threw an error: "
    // 0xc56744: StoreField: r0->field_f = r16
    //     0xc56744: stur            w16, [x0, #0xf]
    // 0xc56748: ldur            x1, [fp, #-0x30]
    // 0xc5674c: StoreField: r0->field_13 = r1
    //     0xc5674c: stur            w1, [x0, #0x13]
    // 0xc56750: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc56750: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc56754: ArrayStore: r0[0] = r16  ; List_4
    //     0xc56754: stur            w16, [x0, #0x17]
    // 0xc56758: str             x0, [SP]
    // 0xc5675c: r0 = _interpolate()
    //     0xc5675c: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc56760: mov             x1, x0
    // 0xc56764: r0 = call 0x63acb4
    //     0xc56764: bl              #0x63acb4
    // 0xc56768: ldur            x0, [fp, #-0x30]
    // 0xc5676c: stur            x0, [fp, #-0x30]
    // 0xc56770: r0 = call 0xb040e0
    //     0xc56770: bl              #0xb040e0
    // 0xc56774: ldur            x0, [fp, #-0x30]
    // 0xc56778: b               #0xc567bc
    // 0xc5677c: sub             SP, fp, #0x38
    // 0xc56780: stur            x0, [fp, #-0x30]
    // 0xc56784: r1 = Null
    //     0xc56784: mov             x1, NULL
    // 0xc56788: r2 = 6
    //     0xc56788: movz            x2, #0x6
    // 0xc5678c: r0 = AllocateArray()
    //     0xc5678c: bl              #0xc55848  ; AllocateArrayStub
    // 0xc56790: r16 = "`path_provider_android` threw an error: "
    //     0xc56790: ldr             x16, [PP, #0x5a48]  ; [pp+0x5a48] "`path_provider_android` threw an error: "
    // 0xc56794: StoreField: r0->field_f = r16
    //     0xc56794: stur            w16, [x0, #0xf]
    // 0xc56798: ldur            x1, [fp, #-0x30]
    // 0xc5679c: StoreField: r0->field_13 = r1
    //     0xc5679c: stur            w1, [x0, #0x13]
    // 0xc567a0: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc567a0: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc567a4: ArrayStore: r0[0] = r16  ; List_4
    //     0xc567a4: stur            w16, [x0, #0x17]
    // 0xc567a8: str             x0, [SP]
    // 0xc567ac: r0 = _interpolate()
    //     0xc567ac: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc567b0: mov             x1, x0
    // 0xc567b4: r0 = call 0x63acb4
    //     0xc567b4: bl              #0x63acb4
    // 0xc567b8: ldur            x0, [fp, #-0x30]
    // 0xc567bc: stur            x0, [fp, #-0x30]
    // 0xc567c0: r0 = call 0xb03ee0
    //     0xc567c0: bl              #0xb03ee0
    // 0xc567c4: ldur            x0, [fp, #-0x30]
    // 0xc567c8: b               #0xc5680c
    // 0xc567cc: sub             SP, fp, #0x38
    // 0xc567d0: stur            x0, [fp, #-0x30]
    // 0xc567d4: r1 = Null
    //     0xc567d4: mov             x1, NULL
    // 0xc567d8: r2 = 6
    //     0xc567d8: movz            x2, #0x6
    // 0xc567dc: r0 = AllocateArray()
    //     0xc567dc: bl              #0xc55848  ; AllocateArrayStub
    // 0xc567e0: r16 = "`shared_preferences_android` threw an error: "
    //     0xc567e0: ldr             x16, [PP, #0x5a50]  ; [pp+0x5a50] "`shared_preferences_android` threw an error: "
    // 0xc567e4: StoreField: r0->field_f = r16
    //     0xc567e4: stur            w16, [x0, #0xf]
    // 0xc567e8: ldur            x1, [fp, #-0x30]
    // 0xc567ec: StoreField: r0->field_13 = r1
    //     0xc567ec: stur            w1, [x0, #0x13]
    // 0xc567f0: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc567f0: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc567f4: ArrayStore: r0[0] = r16  ; List_4
    //     0xc567f4: stur            w16, [x0, #0x17]
    // 0xc567f8: str             x0, [SP]
    // 0xc567fc: r0 = _interpolate()
    //     0xc567fc: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc56800: mov             x1, x0
    // 0xc56804: r0 = call 0x63acb4
    //     0xc56804: bl              #0x63acb4
    // 0xc56808: ldur            x0, [fp, #-0x30]
    // 0xc5680c: stur            x0, [fp, #-0x30]
    // 0xc56810: r0 = call 0xb03de8
    //     0xc56810: bl              #0xb03de8
    // 0xc56814: ldur            x0, [fp, #-0x30]
    // 0xc56818: b               #0xc5685c
    // 0xc5681c: sub             SP, fp, #0x38
    // 0xc56820: stur            x0, [fp, #-0x30]
    // 0xc56824: r1 = Null
    //     0xc56824: mov             x1, NULL
    // 0xc56828: r2 = 6
    //     0xc56828: movz            x2, #0x6
    // 0xc5682c: r0 = AllocateArray()
    //     0xc5682c: bl              #0xc55848  ; AllocateArrayStub
    // 0xc56830: r16 = "`sqflite_android` threw an error: "
    //     0xc56830: ldr             x16, [PP, #0x5a58]  ; [pp+0x5a58] "`sqflite_android` threw an error: "
    // 0xc56834: StoreField: r0->field_f = r16
    //     0xc56834: stur            w16, [x0, #0xf]
    // 0xc56838: ldur            x1, [fp, #-0x30]
    // 0xc5683c: StoreField: r0->field_13 = r1
    //     0xc5683c: stur            w1, [x0, #0x13]
    // 0xc56840: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc56840: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc56844: ArrayStore: r0[0] = r16  ; List_4
    //     0xc56844: stur            w16, [x0, #0x17]
    // 0xc56848: str             x0, [SP]
    // 0xc5684c: r0 = _interpolate()
    //     0xc5684c: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc56850: mov             x1, x0
    // 0xc56854: r0 = call 0x63acb4
    //     0xc56854: bl              #0x63acb4
    // 0xc56858: ldur            x0, [fp, #-0x30]
    // 0xc5685c: stur            x0, [fp, #-0x30]
    // 0xc56860: r0 = call 0xb03cd4
    //     0xc56860: bl              #0xb03cd4
    // 0xc56864: ldur            x0, [fp, #-0x30]
    // 0xc56868: b               #0xc568ac
    // 0xc5686c: sub             SP, fp, #0x38
    // 0xc56870: stur            x0, [fp, #-0x30]
    // 0xc56874: r1 = Null
    //     0xc56874: mov             x1, NULL
    // 0xc56878: r2 = 6
    //     0xc56878: movz            x2, #0x6
    // 0xc5687c: r0 = AllocateArray()
    //     0xc5687c: bl              #0xc55848  ; AllocateArrayStub
    // 0xc56880: r16 = "`url_launcher_android` threw an error: "
    //     0xc56880: ldr             x16, [PP, #0x5a60]  ; [pp+0x5a60] "`url_launcher_android` threw an error: "
    // 0xc56884: StoreField: r0->field_f = r16
    //     0xc56884: stur            w16, [x0, #0xf]
    // 0xc56888: ldur            x1, [fp, #-0x30]
    // 0xc5688c: StoreField: r0->field_13 = r1
    //     0xc5688c: stur            w1, [x0, #0x13]
    // 0xc56890: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc56890: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc56894: ArrayStore: r0[0] = r16  ; List_4
    //     0xc56894: stur            w16, [x0, #0x17]
    // 0xc56898: str             x0, [SP]
    // 0xc5689c: r0 = _interpolate()
    //     0xc5689c: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc568a0: mov             x1, x0
    // 0xc568a4: r0 = call 0x63acb4
    //     0xc568a4: bl              #0x63acb4
    // 0xc568a8: ldur            x0, [fp, #-0x30]
    // 0xc568ac: stur            x0, [fp, #-0x30]
    // 0xc568b0: r0 = call 0xb03b3c
    //     0xc568b0: bl              #0xb03b3c
    // 0xc568b4: b               #0xc568f4
    // 0xc568b8: sub             SP, fp, #0x38
    // 0xc568bc: stur            x0, [fp, #-0x30]
    // 0xc568c0: r1 = Null
    //     0xc568c0: mov             x1, NULL
    // 0xc568c4: r2 = 6
    //     0xc568c4: movz            x2, #0x6
    // 0xc568c8: r0 = AllocateArray()
    //     0xc568c8: bl              #0xc55848  ; AllocateArrayStub
    // 0xc568cc: r16 = "`video_player_android` threw an error: "
    //     0xc568cc: ldr             x16, [PP, #0x5a68]  ; [pp+0x5a68] "`video_player_android` threw an error: "
    // 0xc568d0: StoreField: r0->field_f = r16
    //     0xc568d0: stur            w16, [x0, #0xf]
    // 0xc568d4: ldur            x1, [fp, #-0x30]
    // 0xc568d8: StoreField: r0->field_13 = r1
    //     0xc568d8: stur            w1, [x0, #0x13]
    // 0xc568dc: r16 = ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    //     0xc568dc: ldr             x16, [PP, #0x5a28]  ; [pp+0x5a28] ". The app may not function as expected until you remove this plugin from pubspec.yaml"
    // 0xc568e0: ArrayStore: r0[0] = r16  ; List_4
    //     0xc568e0: stur            w16, [x0, #0x17]
    // 0xc568e4: str             x0, [SP]
    // 0xc568e8: r0 = _interpolate()
    //     0xc568e8: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc568ec: mov             x1, x0
    // 0xc568f0: r0 = call 0x63acb4
    //     0xc568f0: bl              #0x63acb4
    // 0xc568f4: r0 = Null
    //     0xc568f4: mov             x0, NULL
    // 0xc568f8: LeaveFrame
    //     0xc568f8: mov             SP, fp
    //     0xc568fc: ldp             fp, lr, [SP], #0x10
    // 0xc56900: ret
    //     0xc56900: ret             
    // 0xc56904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc56904: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc56908: b               #0xc56630
  }
}
