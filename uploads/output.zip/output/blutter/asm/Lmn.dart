// lib: ECn, url: Lmn

// class id: 1050156, size: 0x8
class :: {
}

// class id: 1041, size: 0x38, field offset: 0x2c
class xmb extends tmb
    implements ZC {

  static late final fqb GEg; // offset: 0xee4

  [closure] static xmb <anonymous closure>(dynamic) {
    // ** addr: 0x41e9c8, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x41e970, size: -0x1
  }
}
