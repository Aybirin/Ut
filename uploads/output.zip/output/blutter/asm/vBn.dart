// lib: , url: vBn

// class id: 1050876, size: 0x8
class :: {
}

// class id: 696, size: 0x28, field offset: 0xc
class KOb extends ywb<dynamic>
    implements LOb {

  late final NOb uQb; // offset: 0x24

  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xb2d2e4, size: 0x9c
    // 0xb2d2e4: EnterFrame
    //     0xb2d2e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d2e8: mov             fp, SP
    // 0xb2d2ec: AllocStack(0x48)
    //     0xb2d2ec: sub             SP, SP, #0x48
    // 0xb2d2f0: SetupParameters(KOb this /* r1, fp-0x48 */)
    //     0xb2d2f0: stur            NULL, [fp, #-8]
    //     0xb2d2f4: movz            x0, #0
    //     0xb2d2f8: add             x1, fp, w0, sxtw #2
    //     0xb2d2fc: ldr             x1, [x1, #0x10]
    //     0xb2d300: stur            x1, [fp, #-0x48]
    //     0xb2d304: ldur            w2, [x1, #0x17]
    //     0xb2d308: add             x2, x2, HEAP, lsl #32
    //     0xb2d30c: stur            x2, [fp, #-0x40]
    // 0xb2d310: CheckStackOverflow
    //     0xb2d310: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2d314: cmp             SP, x16
    //     0xb2d318: b.ls            #0xb2d378
    // 0xb2d31c: InitAsync() -> Future<void?>
    //     0xb2d31c: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xb2d320: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb2d324: ldur            x0, [fp, #-0x40]
    // 0xb2d328: LoadField: r1 = r0->field_f
    //     0xb2d328: ldur            w1, [x0, #0xf]
    // 0xb2d32c: DecompressPointer r1
    //     0xb2d32c: add             x1, x1, HEAP, lsl #32
    // 0xb2d330: r2 = Null
    //     0xb2d330: mov             x2, NULL
    // 0xb2d334: r3 = Null
    //     0xb2d334: mov             x3, NULL
    // 0xb2d338: r0 = __unknown_function__()
    //     0xb2d338: bl              #0xb2d380  ; [] ::__unknown_function__
    // 0xb2d33c: mov             x1, x0
    // 0xb2d340: stur            x1, [fp, #-0x40]
    // 0xb2d344: r0 = Await()
    //     0xb2d344: bl              #0xb0c534  ; AwaitStub
    // 0xb2d348: b               #0xb2d368
    // 0xb2d34c: sub             SP, fp, #0x48
    // 0xb2d350: r2 = 60
    //     0xb2d350: movz            x2, #0x3c
    // 0xb2d354: branchIfSmi(r0, 0xb2d360)
    //     0xb2d354: tbz             w0, #0, #0xb2d360
    // 0xb2d358: r2 = LoadClassIdInstr(r0)
    //     0xb2d358: ldur            x2, [x0, #-1]
    //     0xb2d35c: ubfx            x2, x2, #0xc, #0x14
    // 0xb2d360: cmp             x2, #0xd7
    // 0xb2d364: b.ne            #0xb2d370
    // 0xb2d368: r0 = Null
    //     0xb2d368: mov             x0, NULL
    // 0xb2d36c: r0 = ReturnAsyncNotFuture()
    //     0xb2d36c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb2d370: r0 = ReThrow()
    //     0xb2d370: bl              #0xc539d8  ; ReThrowStub
    // 0xb2d374: brk             #0
    // 0xb2d378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d378: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d37c: b               #0xb2d31c
  }
  [closure] void <anonymous closure>(dynamic, Object?) {
    // ** addr: 0xb2d47c, size: 0x1e0
    // 0xb2d47c: EnterFrame
    //     0xb2d47c: stp             fp, lr, [SP, #-0x10]!
    //     0xb2d480: mov             fp, SP
    // 0xb2d484: AllocStack(0x60)
    //     0xb2d484: sub             SP, SP, #0x60
    // 0xb2d488: SetupParameters([dynamic _ /* r0 */])
    //     0xb2d488: ldr             x0, [fp, #0x18]
    //     0xb2d48c: ldur            w3, [x0, #0x17]
    //     0xb2d490: add             x3, x3, HEAP, lsl #32
    //     0xb2d494: stur            x3, [fp, #-0x50]
    // 0xb2d498: CheckStackOverflow
    //     0xb2d498: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2d49c: cmp             SP, x16
    //     0xb2d4a0: b.ls            #0xb2d654
    // 0xb2d4a4: ldr             x4, [fp, #0x10]
    // 0xb2d4a8: r0 = 60
    //     0xb2d4a8: movz            x0, #0x3c
    // 0xb2d4ac: branchIfSmi(r4, 0xb2d4b8)
    //     0xb2d4ac: tbz             w4, #0, #0xb2d4b8
    // 0xb2d4b0: r0 = LoadClassIdInstr(r4)
    //     0xb2d4b0: ldur            x0, [x4, #-1]
    //     0xb2d4b4: ubfx            x0, x0, #0xc, #0x14
    // 0xb2d4b8: sub             x16, x0, #0x5e
    // 0xb2d4bc: cmp             x16, #1
    // 0xb2d4c0: b.hi            #0xb2d4d8
    // 0xb2d4c4: LoadField: r1 = r3->field_f
    //     0xb2d4c4: ldur            w1, [x3, #0xf]
    // 0xb2d4c8: DecompressPointer r1
    //     0xb2d4c8: add             x1, x1, HEAP, lsl #32
    // 0xb2d4cc: mov             x2, x4
    // 0xb2d4d0: r0 = call 0x3ed3d8
    //     0xb2d4d0: bl              #0x3ed3d8
    // 0xb2d4d4: b               #0xb2d5ac
    // 0xb2d4d8: sub             x16, x0, #0x74
    // 0xb2d4dc: cmp             x16, #3
    // 0xb2d4e0: b.hi            #0xb2d4f8
    // 0xb2d4e4: LoadField: r1 = r3->field_f
    //     0xb2d4e4: ldur            w1, [x3, #0xf]
    // 0xb2d4e8: DecompressPointer r1
    //     0xb2d4e8: add             x1, x1, HEAP, lsl #32
    // 0xb2d4ec: mov             x2, x4
    // 0xb2d4f0: r0 = call 0x3ed3d8
    //     0xb2d4f0: bl              #0x3ed3d8
    // 0xb2d4f4: b               #0xb2d5ac
    // 0xb2d4f8: mov             x0, x4
    // 0xb2d4fc: r2 = Null
    //     0xb2d4fc: mov             x2, NULL
    // 0xb2d500: r1 = Null
    //     0xb2d500: mov             x1, NULL
    // 0xb2d504: cmp             w0, NULL
    // 0xb2d508: b.eq            #0xb2d554
    // 0xb2d50c: branchIfSmi(r0, 0xb2d554)
    //     0xb2d50c: tbz             w0, #0, #0xb2d554
    // 0xb2d510: r3 = SubtypeTestCache
    //     0xb2d510: add             x3, PP, #0xb, lsl #12  ; [pp+0xb860] SubtypeTestCache
    //     0xb2d514: ldr             x3, [x3, #0x860]
    // 0xb2d518: r30 = Subtype2TestCacheStub
    //     0xb2d518: ldr             lr, [PP, #0x30]  ; [pp+0x30] Stub: Subtype2TestCache (0x352e54)
    // 0xb2d51c: LoadField: r30 = r30->field_7
    //     0xb2d51c: ldur            lr, [lr, #7]
    // 0xb2d520: blr             lr
    // 0xb2d524: cmp             w7, NULL
    // 0xb2d528: b.eq            #0xb2d534
    // 0xb2d52c: tbnz            w7, #4, #0xb2d554
    // 0xb2d530: b               #0xb2d55c
    // 0xb2d534: r8 = List<int>
    //     0xb2d534: add             x8, PP, #0xb, lsl #12  ; [pp+0xb868] Type: List<int>
    //     0xb2d538: ldr             x8, [x8, #0x868]
    // 0xb2d53c: r3 = SubtypeTestCache
    //     0xb2d53c: add             x3, PP, #0xb, lsl #12  ; [pp+0xb870] SubtypeTestCache
    //     0xb2d540: ldr             x3, [x3, #0x870]
    // 0xb2d544: r30 = InstanceOfStub
    //     0xb2d544: ldr             lr, [PP, #0x328]  ; [pp+0x328] Stub: InstanceOf (0x341240)
    // 0xb2d548: LoadField: r30 = r30->field_7
    //     0xb2d548: ldur            lr, [lr, #7]
    // 0xb2d54c: blr             lr
    // 0xb2d550: b               #0xb2d560
    // 0xb2d554: r0 = false
    //     0xb2d554: add             x0, NULL, #0x30  ; false
    // 0xb2d558: b               #0xb2d560
    // 0xb2d55c: r0 = true
    //     0xb2d55c: add             x0, NULL, #0x20  ; true
    // 0xb2d560: tbnz            w0, #4, #0xb2d5bc
    // 0xb2d564: ldur            x0, [fp, #-0x50]
    // 0xb2d568: LoadField: r3 = r0->field_f
    //     0xb2d568: ldur            w3, [x0, #0xf]
    // 0xb2d56c: DecompressPointer r3
    //     0xb2d56c: add             x3, x3, HEAP, lsl #32
    // 0xb2d570: ldr             x2, [fp, #0x10]
    // 0xb2d574: stur            x3, [fp, #-0x58]
    // 0xb2d578: r1 = Null
    //     0xb2d578: mov             x1, NULL
    // 0xb2d57c: r0 = call 0x373f68
    //     0xb2d57c: bl              #0x373f68
    // 0xb2d580: ldur            x1, [fp, #-0x58]
    // 0xb2d584: mov             x2, x0
    // 0xb2d588: r0 = call 0x3ed3d8
    //     0xb2d588: bl              #0x3ed3d8
    // 0xb2d58c: b               #0xb2d5ac
    // 0xb2d590: sub             SP, fp, #0x60
    // 0xb2d594: r2 = 60
    //     0xb2d594: movz            x2, #0x3c
    // 0xb2d598: branchIfSmi(r0, 0xb2d5a4)
    //     0xb2d598: tbz             w0, #0, #0xb2d5a4
    // 0xb2d59c: r2 = LoadClassIdInstr(r0)
    //     0xb2d59c: ldur            x2, [x0, #-1]
    //     0xb2d5a0: ubfx            x2, x2, #0xc, #0x14
    // 0xb2d5a4: cmp             x2, #0xd7
    // 0xb2d5a8: b.ne            #0xb2d64c
    // 0xb2d5ac: r0 = Null
    //     0xb2d5ac: mov             x0, NULL
    // 0xb2d5b0: LeaveFrame
    //     0xb2d5b0: mov             SP, fp
    //     0xb2d5b4: ldp             fp, lr, [SP], #0x10
    // 0xb2d5b8: ret
    //     0xb2d5b8: ret             
    // 0xb2d5bc: r0 = UnsupportedError()
    //     0xb2d5bc: bl              #0xb08c40  ; AllocateUnsupportedErrorStub -> UnsupportedError (size=0x10)
    // 0xb2d5c0: r1 = Null
    //     0xb2d5c0: mov             x1, NULL
    // 0xb2d5c4: r2 = 4
    //     0xb2d5c4: movz            x2, #0x4
    // 0xb2d5c8: stur            x0, [fp, #-0x50]
    // 0xb2d5cc: r0 = AllocateArray()
    //     0xb2d5cc: bl              #0xc55848  ; AllocateArrayStub
    // 0xb2d5d0: stur            x0, [fp, #-0x58]
    // 0xb2d5d4: r16 = "Cannot send "
    //     0xb2d5d4: add             x16, PP, #0xb, lsl #12  ; [pp+0xb878] "Cannot send "
    //     0xb2d5d8: ldr             x16, [x16, #0x878]
    // 0xb2d5dc: StoreField: r0->field_f = r16
    //     0xb2d5dc: stur            w16, [x0, #0xf]
    // 0xb2d5e0: ldr             x16, [fp, #0x10]
    // 0xb2d5e4: str             x16, [SP]
    // 0xb2d5e8: r0 = runtimeType()
    //     0xb2d5e8: bl              #0xc1e308  ; [dart:core] Object::runtimeType
    // 0xb2d5ec: ldur            x1, [fp, #-0x58]
    // 0xb2d5f0: ArrayStore: r1[1] = r0  ; List_4
    //     0xb2d5f0: add             x25, x1, #0x13
    //     0xb2d5f4: str             w0, [x25]
    //     0xb2d5f8: tbz             w0, #0, #0xb2d614
    //     0xb2d5fc: ldurb           w16, [x1, #-1]
    //     0xb2d600: ldurb           w17, [x0, #-1]
    //     0xb2d604: and             x16, x17, x16, lsr #2
    //     0xb2d608: tst             x16, HEAP, lsr #32
    //     0xb2d60c: b.eq            #0xb2d614
    //     0xb2d610: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xb2d614: ldur            x16, [fp, #-0x58]
    // 0xb2d618: str             x16, [SP]
    // 0xb2d61c: r0 = _interpolate()
    //     0xb2d61c: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xb2d620: ldur            x1, [fp, #-0x50]
    // 0xb2d624: StoreField: r1->field_b = r0
    //     0xb2d624: stur            w0, [x1, #0xb]
    //     0xb2d628: ldurb           w16, [x1, #-1]
    //     0xb2d62c: ldurb           w17, [x0, #-1]
    //     0xb2d630: and             x16, x17, x16, lsr #2
    //     0xb2d634: tst             x16, HEAP, lsr #32
    //     0xb2d638: b.eq            #0xb2d640
    //     0xb2d63c: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xb2d640: mov             x0, x1
    // 0xb2d644: r0 = Throw()
    //     0xb2d644: bl              #0xc53a04  ; ThrowStub
    // 0xb2d648: brk             #0
    // 0xb2d64c: r0 = ReThrow()
    //     0xb2d64c: bl              #0xc539d8  ; ReThrowStub
    // 0xb2d650: brk             #0
    // 0xb2d654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2d654: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2d658: b               #0xb2d4a4
  }
  [closure] Null <anonymous closure>(dynamic, lp) {
    // ** addr: 0x3ed248, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic, Object) {
    // ** addr: 0x3ed0b0, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, FOb) {
    // ** addr: 0x3ed444, size: -0x1
  }
}

// class id: 5971, size: 0x14, field offset: 0x10
class _MOb extends pz<dynamic>
    implements NOb {
}
