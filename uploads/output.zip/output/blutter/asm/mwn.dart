// lib: , url: mwn

// class id: 1050618, size: 0x8
class :: {
}

// class id: 4757, size: 0x14, field offset: 0xc
//   const constructor, 
class fCb extends Zu {

  [closure] Mca <anonymous closure>(dynamic, Ra<int, Mwb>) {
    // ** addr: 0x8572f0, size: -0x1
  }
}
