// lib: , url: aLm

// class id: 1048910, size: 0x8
class :: {
}

// class id: 5340, size: 0x14, field offset: 0xc
abstract class WL<X0 bound uq, X1 bound uq> extends gM<X0 bound uq, X1 bound uq> {
}
