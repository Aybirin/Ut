// lib: , url: Azn

// class id: 1050790, size: 0x8
class :: {
}

// class id: 395, size: 0x8, field offset: 0x8
abstract class zKb extends Object {

  [closure] static Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xc12ac8, size: 0xb8
    // 0xc12ac8: EnterFrame
    //     0xc12ac8: stp             fp, lr, [SP, #-0x10]!
    //     0xc12acc: mov             fp, SP
    // 0xc12ad0: AllocStack(0x38)
    //     0xc12ad0: sub             SP, SP, #0x38
    // 0xc12ad4: SetupParameters(dynamic _ /* r1 */)
    //     0xc12ad4: stur            NULL, [fp, #-8]
    //     0xc12ad8: movz            x0, #0
    //     0xc12adc: add             x1, fp, w0, sxtw #2
    //     0xc12ae0: ldr             x1, [x1, #0x10]
    //     0xc12ae4: ldur            w2, [x1, #0x17]
    //     0xc12ae8: add             x2, x2, HEAP, lsl #32
    //     0xc12aec: stur            x2, [fp, #-0x10]
    // 0xc12af0: CheckStackOverflow
    //     0xc12af0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc12af4: cmp             SP, x16
    //     0xc12af8: b.ls            #0xc12b78
    // 0xc12afc: InitAsync() -> Future<void?>
    //     0xc12afc: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xc12b00: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc12b04: ldur            x0, [fp, #-0x10]
    // 0xc12b08: LoadField: r2 = r0->field_13
    //     0xc12b08: ldur            w2, [x0, #0x13]
    // 0xc12b0c: DecompressPointer r2
    //     0xc12b0c: add             x2, x2, HEAP, lsl #32
    // 0xc12b10: stur            x2, [fp, #-0x18]
    // 0xc12b14: cmp             w2, NULL
    // 0xc12b18: b.ne            #0xc12b24
    // 0xc12b1c: r0 = Null
    //     0xc12b1c: mov             x0, NULL
    // 0xc12b20: r0 = ReturnAsyncNotFuture()
    //     0xc12b20: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc12b24: LoadField: r1 = r0->field_f
    //     0xc12b24: ldur            w1, [x0, #0xf]
    // 0xc12b28: DecompressPointer r1
    //     0xc12b28: add             x1, x1, HEAP, lsl #32
    // 0xc12b2c: r0 = call 0x7d702c
    //     0xc12b2c: bl              #0x7d702c
    // 0xc12b30: stur            x0, [fp, #-0x20]
    // 0xc12b34: r0 = dDb()
    //     0xc12b34: bl              #0xc12b80  ; AllocatedDbStub -> dDb (size=0x14)
    // 0xc12b38: mov             x1, x0
    // 0xc12b3c: ldur            x0, [fp, #-0x18]
    // 0xc12b40: StoreField: r1->field_b = r0
    //     0xc12b40: stur            w0, [x1, #0xb]
    // 0xc12b44: ldur            x0, [fp, #-0x20]
    // 0xc12b48: StoreField: r1->field_f = r0
    //     0xc12b48: stur            w0, [x1, #0xf]
    // 0xc12b4c: stp             x1, NULL, [SP, #8]
    // 0xc12b50: r16 = false
    //     0xc12b50: add             x16, NULL, #0x30  ; false
    // 0xc12b54: str             x16, [SP]
    // 0xc12b58: r4 = const [0x1, 0x2, 0x2, 0x1, QEd, 0x1, null]
    //     0xc12b58: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e4e0] List(7) [0x1, 0x2, 0x2, 0x1, "QEd", 0x1, Null]
    //     0xc12b5c: ldr             x4, [x4, #0x4e0]
    // 0xc12b60: r0 = call 0x719130
    //     0xc12b60: bl              #0x719130
    // 0xc12b64: mov             x1, x0
    // 0xc12b68: stur            x1, [fp, #-0x18]
    // 0xc12b6c: r0 = Await()
    //     0xc12b6c: bl              #0xb0c534  ; AwaitStub
    // 0xc12b70: r0 = Null
    //     0xc12b70: mov             x0, NULL
    // 0xc12b74: r0 = ReturnAsyncNotFuture()
    //     0xc12b74: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc12b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12b78: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc12b7c: b               #0xc12afc
  }
  [closure] static Future<bool> <anonymous closure>(dynamic, String) async {
    // ** addr: 0xc12b8c, size: 0xc4
    // 0xc12b8c: EnterFrame
    //     0xc12b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xc12b90: mov             fp, SP
    // 0xc12b94: AllocStack(0x28)
    //     0xc12b94: sub             SP, SP, #0x28
    // 0xc12b98: SetupParameters(dynamic _ /* r1 */, dynamic _ /* r3, fp-0x18 */)
    //     0xc12b98: stur            NULL, [fp, #-8]
    //     0xc12b9c: movz            x0, #0
    //     0xc12ba0: add             x1, fp, w0, sxtw #2
    //     0xc12ba4: ldr             x1, [x1, #0x18]
    //     0xc12ba8: add             x3, fp, w0, sxtw #2
    //     0xc12bac: ldr             x3, [x3, #0x10]
    //     0xc12bb0: stur            x3, [fp, #-0x18]
    //     0xc12bb4: ldur            w2, [x1, #0x17]
    //     0xc12bb8: add             x2, x2, HEAP, lsl #32
    //     0xc12bbc: stur            x2, [fp, #-0x10]
    // 0xc12bc0: CheckStackOverflow
    //     0xc12bc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc12bc4: cmp             SP, x16
    //     0xc12bc8: b.ls            #0xc12c40
    // 0xc12bcc: InitAsync() -> Future<bool>
    //     0xc12bcc: ldr             x0, [PP, #0x1a20]  ; [pp+0x1a20] TypeArguments: <bool>
    //     0xc12bd0: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc12bd4: r4 = 0
    //     0xc12bd4: movz            x4, #0
    // 0xc12bd8: ldur            x0, [fp, #-0x10]
    // 0xc12bdc: stur            x4, [fp, #-0x20]
    // 0xc12be0: CheckStackOverflow
    //     0xc12be0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc12be4: cmp             SP, x16
    //     0xc12be8: b.ls            #0xc12c48
    // 0xc12bec: LoadField: r1 = r0->field_f
    //     0xc12bec: ldur            w1, [x0, #0xf]
    // 0xc12bf0: DecompressPointer r1
    //     0xc12bf0: add             x1, x1, HEAP, lsl #32
    // 0xc12bf4: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xc12bf4: ldur            w2, [x0, #0x17]
    // 0xc12bf8: DecompressPointer r2
    //     0xc12bf8: add             x2, x2, HEAP, lsl #32
    // 0xc12bfc: ldur            x3, [fp, #-0x18]
    // 0xc12c00: r0 = __unknown_function__()
    //     0xc12c00: bl              #0xc12c50  ; [] ::__unknown_function__
    // 0xc12c04: mov             x1, x0
    // 0xc12c08: stur            x1, [fp, #-0x28]
    // 0xc12c0c: r0 = Await()
    //     0xc12c0c: bl              #0xb0c534  ; AwaitStub
    // 0xc12c10: r16 = true
    //     0xc12c10: add             x16, NULL, #0x20  ; true
    // 0xc12c14: cmp             w0, w16
    // 0xc12c18: b.ne            #0xc12c28
    // 0xc12c1c: ldur            x1, [fp, #-0x20]
    // 0xc12c20: add             x4, x1, #1
    // 0xc12c24: b               #0xc12bd8
    // 0xc12c28: ldur            x1, [fp, #-0x20]
    // 0xc12c2c: cmp             x1, #0
    // 0xc12c30: r16 = true
    //     0xc12c30: add             x16, NULL, #0x20  ; true
    // 0xc12c34: r17 = false
    //     0xc12c34: add             x17, NULL, #0x30  ; false
    // 0xc12c38: csel            x0, x16, x17, gt
    // 0xc12c3c: r0 = ReturnAsyncNotFuture()
    //     0xc12c3c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc12c40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12c40: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc12c44: b               #0xc12bcc
    // 0xc12c48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12c48: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc12c4c: b               #0xc12bec
  }
  [closure] static Yra <anonymous closure>(dynamic, iva) {
    // ** addr: 0x7d7058, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, Tv) {
    // ** addr: 0x7d7700, size: -0x1
  }
  [closure] static lKb <anonymous closure>(dynamic, iva, uv) {
    // ** addr: 0x7d72bc, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x7d7694, size: -0x1
  }
  [closure] static CKb <anonymous closure>(dynamic, iva, kKb, Mca, (dynamic) => void, ((dynamic) => void)?) {
    // ** addr: 0x7d7624, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, Object) {
    // ** addr: 0x7d73a4, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x7d7584, size: -0x1
  }
  [closure] static Future<bool> <anonymous closure>(dynamic, String) {
    // ** addr: 0x7d7940, size: -0x1
  }
  [closure] static Future<void> <anonymous closure>(dynamic) {
    // ** addr: 0x7d78d0, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x7d7988, size: -0x1
  }
}

// class id: 396, size: 0x10, field offset: 0x8
class yKb extends Object {
}

// class id: 397, size: 0x14, field offset: 0x8
//   const constructor, 
class xKb extends Object {
}

// class id: 398, size: 0x18, field offset: 0x8
class wKb extends Object {
}

// class id: 3943, size: 0x18, field offset: 0x14
class DKb extends Xu<dynamic> {

  late bool _dhe; // offset: 0x14

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7bc34c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7bc260, size: -0x1
  }
}

// class id: 3944, size: 0x20, field offset: 0x14
class _BKb extends Xu<dynamic> {

  late final List<Gv> _rsj; // offset: 0x14

  [closure] fx <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x7bb50c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7bb490, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Tv) {
    // ** addr: 0x7bb6b4, size: -0x1
  }
  [closure] lKb <anonymous closure>(dynamic, iva, uv) {
    // ** addr: 0x7bb620, size: -0x1
  }
  [closure] Mca _WRj(dynamic, iva, kKb, Mca, (dynamic) => void, ((dynamic) => void)?) {
    // ** addr: 0x7bba2c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x7bb86c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7bb9b4, size: -0x1
  }
  [closure] void sJc(dynamic) {
    // ** addr: 0x816de8, size: -0x1
  }
}

// class id: 4923, size: 0x24, field offset: 0xc
//   const constructor, 
class CKb extends Vu {
}

// class id: 4924, size: 0x14, field offset: 0xc
//   const constructor, 
class AKb extends Vu {
}

// class id: 7030, size: 0x14, field offset: 0x14
enum vKb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
