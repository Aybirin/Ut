// lib: , url: vun

// class id: 1050528, size: 0x8
class :: {
}

// class id: 4098, size: 0x18, field offset: 0x14
class _Izb<C1X0> extends Xu<C1X0> {

  late final Ytb<Etb<C1X0?>> _XBj; // offset: 0x14

  [closure] Mca <anonymous closure>(dynamic, iva) {
    // ** addr: 0x6d77f4, size: -0x1
  }
  [closure] Future<void> _WAj(dynamic) {
    // ** addr: 0x6d7b8c, size: -0x1
  }
}

// class id: 5040, size: 0x1c, field offset: 0xc
//   const constructor, 
class Hzb<X0> extends Vu {
}
