// lib: , url: jtn

// class id: 1050466, size: 0x8
class :: {
}

// class id: 639, size: 0x8, field offset: 0x8
abstract class Fxb extends Object {

  [closure] static oxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8311c8, size: -0x1
  }
  [closure] static wxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x740fd4, size: -0x1
  }
  [closure] static wxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x7406f4, size: -0x1
  }
  [closure] static Bxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x833e20, size: -0x1
  }
  [closure] static fxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x83065c, size: -0x1
  }
  [closure] static lxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x82fe5c, size: -0x1
  }
  [closure] static wxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xaeea1c, size: -0x1
  }
  [closure] static wxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xaee9cc, size: -0x1
  }
  [closure] static wxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xaee97c, size: -0x1
  }
  [closure] static wxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xaee92c, size: -0x1
  }
  [closure] static yxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x74fcc8, size: -0x1
  }
  [closure] static ixb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xaeea6c, size: -0x1
  }
}
