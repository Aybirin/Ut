// lib: , url: eln

// class id: 1050090, size: 0x8
class :: {
}

// class id: 1105, size: 0x24, field offset: 0x8
class ikb<X0> extends Object
    implements ja<X0> {

  late X0 current; // offset: 0x20
}
