// lib: , url: ipn

// class id: 1050284, size: 0x8
class :: {
}

// class id: 7055, size: 0x28, field offset: 0x14
enum hrb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
  _Mint field_14;
  _Mint field_1c;
  _ConstSet<int> field_24;
}
