// lib: , url: eEm

// class id: 1048618, size: 0x8
class :: {
}

// class id: 6120, size: 0x54, field offset: 0x8
//   const constructor, 
class Qv extends Object {

  bool field_8;
  Hv field_c;
  _Mint field_14;
  _Mint field_1c;
  _Mint field_24;
  bool field_2c;
  bool field_30;
  _Mint field_34;
  bool field_3c;
  bool field_4c;
  Iv field_50;
}

// class id: 6121, size: 0x1c, field offset: 0x8
//   const constructor, 
class Nv extends Object {

  _Mint field_8;
  Jv field_10;
  bool field_14;
  Mv field_18;

  Map<String, dynamic> Gxc(Nv) {
    // ** addr: 0xb7fee4, size: 0x48
    // 0xb7fee4: EnterFrame
    //     0xb7fee4: stp             fp, lr, [SP, #-0x10]!
    //     0xb7fee8: mov             fp, SP
    // 0xb7feec: CheckStackOverflow
    //     0xb7feec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7fef0: cmp             SP, x16
    //     0xb7fef4: b.ls            #0xb7ff0c
    // 0xb7fef8: ldr             x1, [fp, #0x10]
    // 0xb7fefc: r0 = call 0x460724
    //     0xb7fefc: bl              #0x460724
    // 0xb7ff00: LeaveFrame
    //     0xb7ff00: mov             SP, fp
    //     0xb7ff04: ldp             fp, lr, [SP], #0x10
    // 0xb7ff08: ret
    //     0xb7ff08: ret             
    // 0xb7ff0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7ff0c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7ff10: b               #0xb7fef8
  }
}

// class id: 6122, size: 0x14, field offset: 0x8
//   const constructor, 
class Mv extends Object {

  bool field_8;
  Kv field_c;
  Lv field_10;

  Map<String, dynamic> Gxc(Mv) {
    // ** addr: 0xb7fe9c, size: 0x48
    // 0xb7fe9c: EnterFrame
    //     0xb7fe9c: stp             fp, lr, [SP, #-0x10]!
    //     0xb7fea0: mov             fp, SP
    // 0xb7fea4: CheckStackOverflow
    //     0xb7fea4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7fea8: cmp             SP, x16
    //     0xb7feac: b.ls            #0xb7fec4
    // 0xb7feb0: ldr             x1, [fp, #0x10]
    // 0xb7feb4: r0 = call 0x460624
    //     0xb7feb4: bl              #0x460624
    // 0xb7feb8: LeaveFrame
    //     0xb7feb8: mov             SP, fp
    //     0xb7febc: ldp             fp, lr, [SP], #0x10
    // 0xb7fec0: ret
    //     0xb7fec0: ret             
    // 0xb7fec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7fec4: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7fec8: b               #0xb7feb0
  }
}

// class id: 7398, size: 0x14, field offset: 0x14
enum Pv extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  String Gxc(Pv) {
    // ** addr: 0xbe6478, size: 0x54
    // 0xbe6478: ldr             x1, [SP]
    // 0xbe647c: LoadField: r2 = r1->field_7
    //     0xbe647c: ldur            x2, [x1, #7]
    // 0xbe6480: cmp             x2, #1
    // 0xbe6484: b.gt            #0xbe64a8
    // 0xbe6488: cmp             x2, #0
    // 0xbe648c: b.gt            #0xbe649c
    // 0xbe6490: r0 = "immediately"
    //     0xbe6490: add             x0, PP, #0x25, lsl #12  ; [pp+0x25860] "immediately"
    //     0xbe6494: ldr             x0, [x0, #0x860]
    // 0xbe6498: b               #0xbe64b0
    // 0xbe649c: r0 = "after_countdown"
    //     0xbe649c: add             x0, PP, #0x25, lsl #12  ; [pp+0x25868] "after_countdown"
    //     0xbe64a0: ldr             x0, [x0, #0x868]
    // 0xbe64a4: b               #0xbe64b0
    // 0xbe64a8: r0 = "on_complete"
    //     0xbe64a8: add             x0, PP, #0x25, lsl #12  ; [pp+0x25870] "on_complete"
    //     0xbe64ac: ldr             x0, [x0, #0x870]
    // 0xbe64b0: ret
    //     0xbe64b0: ret             
  }
}

// class id: 7399, size: 0x14, field offset: 0x14
enum Ov extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  String Gxc(Ov) {
    // ** addr: 0xb80970, size: 0x54
    // 0xb80970: ldr             x1, [SP]
    // 0xb80974: LoadField: r2 = r1->field_7
    //     0xb80974: ldur            x2, [x1, #7]
    // 0xb80978: cmp             x2, #1
    // 0xb8097c: b.gt            #0xb809a0
    // 0xb80980: cmp             x2, #0
    // 0xb80984: b.gt            #0xb80994
    // 0xb80988: r0 = "top"
    //     0xb80988: add             x0, PP, #0x25, lsl #12  ; [pp+0x25908] "top"
    //     0xb8098c: ldr             x0, [x0, #0x908]
    // 0xb80990: b               #0xb809a8
    // 0xb80994: r0 = "bottom"
    //     0xb80994: add             x0, PP, #0x25, lsl #12  ; [pp+0x25910] "bottom"
    //     0xb80998: ldr             x0, [x0, #0x910]
    // 0xb8099c: b               #0xb809a8
    // 0xb809a0: r0 = "sticky"
    //     0xb809a0: add             x0, PP, #0x25, lsl #12  ; [pp+0x25270] "sticky"
    //     0xb809a4: ldr             x0, [x0, #0x270]
    // 0xb809a8: ret
    //     0xb809a8: ret             
  }
}

// class id: 7400, size: 0x14, field offset: 0x14
enum Lv extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  String Gxc(Lv) {
    // ** addr: 0xb7fdf4, size: 0x40
    // 0xb7fdf4: ldr             x1, [SP]
    // 0xb7fdf8: LoadField: r2 = r1->field_7
    //     0xb7fdf8: ldur            x2, [x1, #7]
    // 0xb7fdfc: cmp             x2, #0
    // 0xb7fe00: b.gt            #0xb7fe10
    // 0xb7fe04: r0 = "bottom_center"
    //     0xb7fe04: add             x0, PP, #0x25, lsl #12  ; [pp+0x259d8] "bottom_center"
    //     0xb7fe08: ldr             x0, [x0, #0x9d8]
    // 0xb7fe0c: b               #0xb7fe18
    // 0xb7fe10: r0 = "top_center"
    //     0xb7fe10: add             x0, PP, #0x25, lsl #12  ; [pp+0x259e0] "top_center"
    //     0xb7fe14: ldr             x0, [x0, #0x9e0]
    // 0xb7fe18: ret
    //     0xb7fe18: ret             
  }
}

// class id: 7401, size: 0x14, field offset: 0x14
enum Kv extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  String Gxc(Kv) {
    // ** addr: 0xb7fe34, size: 0x68
    // 0xb7fe34: ldr             x1, [SP]
    // 0xb7fe38: LoadField: r2 = r1->field_7
    //     0xb7fe38: ldur            x2, [x1, #7]
    // 0xb7fe3c: cmp             x2, #1
    // 0xb7fe40: b.gt            #0xb7fe64
    // 0xb7fe44: cmp             x2, #0
    // 0xb7fe48: b.gt            #0xb7fe58
    // 0xb7fe4c: r0 = "dots"
    //     0xb7fe4c: add             x0, PP, #0x25, lsl #12  ; [pp+0x259c0] "dots"
    //     0xb7fe50: ldr             x0, [x0, #0x9c0]
    // 0xb7fe54: b               #0xb7fe80
    // 0xb7fe58: r0 = "numbers"
    //     0xb7fe58: add             x0, PP, #0x25, lsl #12  ; [pp+0x259c8] "numbers"
    //     0xb7fe5c: ldr             x0, [x0, #0x9c8]
    // 0xb7fe60: b               #0xb7fe80
    // 0xb7fe64: cmp             x2, #2
    // 0xb7fe68: b.gt            #0xb7fe78
    // 0xb7fe6c: r0 = "line"
    //     0xb7fe6c: add             x0, PP, #0x25, lsl #12  ; [pp+0x259d0] "line"
    //     0xb7fe70: ldr             x0, [x0, #0x9d0]
    // 0xb7fe74: b               #0xb7fe80
    // 0xb7fe78: r0 = "none"
    //     0xb7fe78: add             x0, PP, #0x25, lsl #12  ; [pp+0x259a0] "none"
    //     0xb7fe7c: ldr             x0, [x0, #0x9a0]
    // 0xb7fe80: ret
    //     0xb7fe80: ret             
  }
}

// class id: 7402, size: 0x14, field offset: 0x14
enum Jv extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  String Gxc(Jv) {
    // ** addr: 0xb7ff2c, size: 0x54
    // 0xb7ff2c: ldr             x1, [SP]
    // 0xb7ff30: LoadField: r2 = r1->field_7
    //     0xb7ff30: ldur            x2, [x1, #7]
    // 0xb7ff34: cmp             x2, #1
    // 0xb7ff38: b.gt            #0xb7ff5c
    // 0xb7ff3c: cmp             x2, #0
    // 0xb7ff40: b.gt            #0xb7ff50
    // 0xb7ff44: r0 = "slide"
    //     0xb7ff44: add             x0, PP, #0x25, lsl #12  ; [pp+0x25990] "slide"
    //     0xb7ff48: ldr             x0, [x0, #0x990]
    // 0xb7ff4c: b               #0xb7ff64
    // 0xb7ff50: r0 = "fade"
    //     0xb7ff50: add             x0, PP, #0x25, lsl #12  ; [pp+0x25998] "fade"
    //     0xb7ff54: ldr             x0, [x0, #0x998]
    // 0xb7ff58: b               #0xb7ff64
    // 0xb7ff5c: r0 = "none"
    //     0xb7ff5c: add             x0, PP, #0x25, lsl #12  ; [pp+0x259a0] "none"
    //     0xb7ff60: ldr             x0, [x0, #0x9a0]
    // 0xb7ff64: ret
    //     0xb7ff64: ret             
  }
}

// class id: 7403, size: 0x14, field offset: 0x14
enum Iv extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  String Gxc(Iv) {
    // ** addr: 0xbba7a8, size: 0x68
    // 0xbba7a8: ldr             x1, [SP]
    // 0xbba7ac: LoadField: r2 = r1->field_7
    //     0xbba7ac: ldur            x2, [x1, #7]
    // 0xbba7b0: cmp             x2, #1
    // 0xbba7b4: b.gt            #0xbba7d8
    // 0xbba7b8: cmp             x2, #0
    // 0xbba7bc: b.gt            #0xbba7cc
    // 0xbba7c0: r0 = "bottom_left"
    //     0xbba7c0: add             x0, PP, #0x25, lsl #12  ; [pp+0x258a8] "bottom_left"
    //     0xbba7c4: ldr             x0, [x0, #0x8a8]
    // 0xbba7c8: b               #0xbba7f4
    // 0xbba7cc: r0 = "bottom_right"
    //     0xbba7cc: add             x0, PP, #0x25, lsl #12  ; [pp+0x258a0] "bottom_right"
    //     0xbba7d0: ldr             x0, [x0, #0x8a0]
    // 0xbba7d4: b               #0xbba7f4
    // 0xbba7d8: cmp             x2, #2
    // 0xbba7dc: b.gt            #0xbba7ec
    // 0xbba7e0: r0 = "top_left"
    //     0xbba7e0: add             x0, PP, #0x25, lsl #12  ; [pp+0x25898] "top_left"
    //     0xbba7e4: ldr             x0, [x0, #0x898]
    // 0xbba7e8: b               #0xbba7f4
    // 0xbba7ec: r0 = "top_right"
    //     0xbba7ec: add             x0, PP, #0x25, lsl #12  ; [pp+0x25890] "top_right"
    //     0xbba7f0: ldr             x0, [x0, #0x890]
    // 0xbba7f4: ret
    //     0xbba7f4: ret             
  }
}

// class id: 7404, size: 0x14, field offset: 0x14
enum Hv extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  String Gxc(Hv) {
    // ** addr: 0xbba740, size: 0x68
    // 0xbba740: ldr             x1, [SP]
    // 0xbba744: LoadField: r2 = r1->field_7
    //     0xbba744: ldur            x2, [x1, #7]
    // 0xbba748: cmp             x2, #1
    // 0xbba74c: b.gt            #0xbba770
    // 0xbba750: cmp             x2, #0
    // 0xbba754: b.gt            #0xbba764
    // 0xbba758: r0 = "top_right"
    //     0xbba758: add             x0, PP, #0x25, lsl #12  ; [pp+0x25890] "top_right"
    //     0xbba75c: ldr             x0, [x0, #0x890]
    // 0xbba760: b               #0xbba78c
    // 0xbba764: r0 = "top_left"
    //     0xbba764: add             x0, PP, #0x25, lsl #12  ; [pp+0x25898] "top_left"
    //     0xbba768: ldr             x0, [x0, #0x898]
    // 0xbba76c: b               #0xbba78c
    // 0xbba770: cmp             x2, #2
    // 0xbba774: b.gt            #0xbba784
    // 0xbba778: r0 = "bottom_right"
    //     0xbba778: add             x0, PP, #0x25, lsl #12  ; [pp+0x258a0] "bottom_right"
    //     0xbba77c: ldr             x0, [x0, #0x8a0]
    // 0xbba780: b               #0xbba78c
    // 0xbba784: r0 = "bottom_left"
    //     0xbba784: add             x0, PP, #0x25, lsl #12  ; [pp+0x258a8] "bottom_left"
    //     0xbba788: ldr             x0, [x0, #0x8a8]
    // 0xbba78c: ret
    //     0xbba78c: ret             
  }
}
