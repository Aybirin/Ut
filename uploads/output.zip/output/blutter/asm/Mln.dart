// lib: , url: Mln

// class id: 1050127, size: 0x8
class :: {
}

// class id: 1097, size: 0x8, field offset: 0x8
abstract class zkb extends Object {
}
