// lib: , url: ORm

// class id: 1049256, size: 0x8
class :: {
}

// class id: 2657, size: 0xc, field offset: 0x8
class qta extends Object {

  [closure] Mca <anonymous closure>(dynamic, iva) {
    // ** addr: 0x47c52c, size: -0x1
  }
}
