// lib: qEn, url: tin

// class id: 1049977, size: 0x8
class :: {

  [closure] static String SDh(dynamic, String?) {
    // ** addr: 0x4e9a9c, size: -0x1
  }
  [closure] static String KYi(dynamic, String) {
    // ** addr: 0x4e9a6c, size: -0x1
  }
  [closure] static String JYi(dynamic, String) {
    // ** addr: 0x4e9a3c, size: -0x1
  }
  [closure] static String <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x4e989c, size: -0x1
  }
  [closure] static String <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x4e93bc, size: -0x1
  }
  [closure] static String <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x4e93b0, size: -0x1
  }
  [closure] static String _IYi(dynamic, String) {
    // ** addr: 0x4e9300, size: -0x1
  }
}

// class id: 1374, size: 0xc, field offset: 0x8
class fib extends Object
    implements Ja {
}

// class id: 1375, size: 0x8, field offset: 0x8
abstract class eib extends Object {
}

// class id: 1376, size: 0x14, field offset: 0x8
class cib<X0> extends Object
    implements eib {

  bool Jl(cib<X0>, String) {
    // ** addr: 0xc1264c, size: 0x84
    // 0xc1264c: EnterFrame
    //     0xc1264c: stp             fp, lr, [SP, #-0x10]!
    //     0xc12650: mov             fp, SP
    // 0xc12654: CheckStackOverflow
    //     0xc12654: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc12658: cmp             SP, x16
    //     0xc1265c: b.ls            #0xc126b0
    // 0xc12660: ldr             x0, [fp, #0x10]
    // 0xc12664: r2 = Null
    //     0xc12664: mov             x2, NULL
    // 0xc12668: r1 = Null
    //     0xc12668: mov             x1, NULL
    // 0xc1266c: r4 = 60
    //     0xc1266c: movz            x4, #0x3c
    // 0xc12670: branchIfSmi(r0, 0xc1267c)
    //     0xc12670: tbz             w0, #0, #0xc1267c
    // 0xc12674: r4 = LoadClassIdInstr(r0)
    //     0xc12674: ldur            x4, [x0, #-1]
    //     0xc12678: ubfx            x4, x4, #0xc, #0x14
    // 0xc1267c: sub             x4, x4, #0x5e
    // 0xc12680: cmp             x4, #1
    // 0xc12684: b.ls            #0xc12698
    // 0xc12688: r8 = String
    //     0xc12688: ldr             x8, [PP, #0x9c8]  ; [pp+0x9c8] Type: String
    // 0xc1268c: r3 = Null
    //     0xc1268c: add             x3, PP, #0x31, lsl #12  ; [pp+0x312e8] Null
    //     0xc12690: ldr             x3, [x3, #0x2e8]
    // 0xc12694: r0 = String()
    //     0xc12694: bl              #0xc5a588  ; IsType_String_Stub
    // 0xc12698: ldr             x1, [fp, #0x18]
    // 0xc1269c: ldr             x2, [fp, #0x10]
    // 0xc126a0: r0 = call 0x7d5ce8
    //     0xc126a0: bl              #0x7d5ce8
    // 0xc126a4: LeaveFrame
    //     0xc126a4: mov             SP, fp
    //     0xc126a8: ldp             fp, lr, [SP], #0x10
    // 0xc126ac: ret
    //     0xc126ac: ret             
    // 0xc126b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc126b0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc126b4: b               #0xc12660
  }
  X0 [](cib<X0>, String) {
    // ** addr: 0xc126dc, size: 0x84
    // 0xc126dc: EnterFrame
    //     0xc126dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc126e0: mov             fp, SP
    // 0xc126e4: CheckStackOverflow
    //     0xc126e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc126e8: cmp             SP, x16
    //     0xc126ec: b.ls            #0xc12740
    // 0xc126f0: ldr             x0, [fp, #0x10]
    // 0xc126f4: r2 = Null
    //     0xc126f4: mov             x2, NULL
    // 0xc126f8: r1 = Null
    //     0xc126f8: mov             x1, NULL
    // 0xc126fc: r4 = 60
    //     0xc126fc: movz            x4, #0x3c
    // 0xc12700: branchIfSmi(r0, 0xc1270c)
    //     0xc12700: tbz             w0, #0, #0xc1270c
    // 0xc12704: r4 = LoadClassIdInstr(r0)
    //     0xc12704: ldur            x4, [x0, #-1]
    //     0xc12708: ubfx            x4, x4, #0xc, #0x14
    // 0xc1270c: sub             x4, x4, #0x5e
    // 0xc12710: cmp             x4, #1
    // 0xc12714: b.ls            #0xc12728
    // 0xc12718: r8 = String
    //     0xc12718: ldr             x8, [PP, #0x9c8]  ; [pp+0x9c8] Type: String
    // 0xc1271c: r3 = Null
    //     0xc1271c: add             x3, PP, #0x31, lsl #12  ; [pp+0x31300] Null
    //     0xc12720: ldr             x3, [x3, #0x300]
    // 0xc12724: r0 = String()
    //     0xc12724: bl              #0xc5a588  ; IsType_String_Stub
    // 0xc12728: ldr             x1, [fp, #0x18]
    // 0xc1272c: ldr             x2, [fp, #0x10]
    // 0xc12730: r0 = call 0x7d5e10
    //     0xc12730: bl              #0x7d5e10
    // 0xc12734: LeaveFrame
    //     0xc12734: mov             SP, fp
    //     0xc12738: ldp             fp, lr, [SP], #0x10
    // 0xc1273c: ret
    //     0xc1273c: ret             
    // 0xc12740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12740: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc12744: b               #0xc126f0
  }
}
