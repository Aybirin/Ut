// lib: , url: DBn

// class id: 1050884, size: 0x8
class :: {
}

// class id: 205, size: 0xc, field offset: 0x8
abstract class UOb extends Object
    implements Ja {
}
