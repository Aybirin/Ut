// lib: , url: EQm

// class id: 1049193, size: 0x8
class :: {
}

// class id: 2788, size: 0x14, field offset: 0x8
//   const constructor, 
class Nma extends Object {
}

// class id: 2869, size: 0x50, field offset: 0x50
abstract class Mma extends Xha {
}

// class id: 2892, size: 0x6c, field offset: 0x58
//   transformed mixin,
abstract class _Oma<X0 bound Yha> extends jP
     with Iea<X0 bound Xha, X1 bound Yha> {

  [closure] Fla? Dve(dynamic, Object?) {
    // ** addr: 0x55d914, size: -0x1
  }
  [closure] Fla? Cve(dynamic, Object?) {
    // ** addr: 0x55da38, size: -0x1
  }
}

// class id: 2893, size: 0x90, field offset: 0x6c
abstract class Qma<X0 bound Yha> extends _Oma<X0 bound Yha>
    implements Mma {

  [closure] void cLd(dynamic, {Xha? dLd, Er? FKc, Ea Tbc, rM eLd}) {
    // ** addr: 0x5637bc, size: -0x1
  }
  [closure] void _yve(dynamic, xja, Dr) {
    // ** addr: 0x534c34, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, Fla) {
    // ** addr: 0x53bad0, size: -0x1
  }
}

// class id: 2896, size: 0x9c, field offset: 0x90
class Sma extends Qma<dynamic> {

  late double _cef; // offset: 0x94
  late double _Jte; // offset: 0x90
}

// class id: 2897, size: 0xa8, field offset: 0x90
class Rma extends Qma<dynamic> {

  late double _Ite; // offset: 0x9c
  late double _Jte; // offset: 0xa0
}

// class id: 7244, size: 0x14, field offset: 0x14
enum Lma extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
