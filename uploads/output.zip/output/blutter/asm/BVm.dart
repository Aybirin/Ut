// lib: , url: BVm

// class id: 1049434, size: 0x8
class :: {
}

// class id: 5936, size: 0x8, field offset: 0x8
class tIa extends uIa {
}
