// lib: , url: Zin

// class id: 1050012, size: 0x8
class :: {
}

// class id: 1354, size: 0x34, field offset: 0x34
class Rib extends zib {
}
