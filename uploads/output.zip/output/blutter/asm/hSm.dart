// lib: , url: hSm

// class id: 1049274, size: 0x8
class :: {
}

// class id: 2632, size: 0x2c, field offset: 0x8
class _Lva extends Object {

  late PM _jje; // offset: 0x18
  static late final mM<double> _mje; // offset: 0x818
  late oN<Er?> gje; // offset: 0xc

  [closure] void Zzd(dynamic) {
    // ** addr: 0x81933c, size: -0x1
  }
  [closure] void _rje(dynamic, nM) {
    // ** addr: 0x818e38, size: -0x1
  }
  [closure] void yMl(dynamic) {
    // ** addr: 0x819290, size: -0x1
  }
  [closure] Mca _pje(dynamic, iva) {
    // ** addr: 0x99720c, size: -0x1
  }
  [closure] vsa <anonymous closure>(dynamic, iva, Mca?) {
    // ** addr: 0x9973d4, size: -0x1
  }
}

// class id: 2633, size: 0x44, field offset: 0x8
class _Kva extends Object {

  late final bool nRc; // offset: 0x40
  late final Er Tje; // offset: 0x3c
  late final Er Sje; // offset: 0x38
}

// class id: 4198, size: 0x20, field offset: 0x14
class _Jva extends Xu<dynamic> {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x996fe0, size: -0x1
  }
}

// class id: 5109, size: 0x24, field offset: 0xc
//   const constructor, 
class Iva extends Vu {

  [closure] static void zam(dynamic, rva, Object) {
    // ** addr: 0x998238, size: -0x1
  }
  [closure] static void iqd(dynamic, Zsa) {
    // ** addr: 0x997efc, size: -0x1
  }
}

// class id: 6000, size: 0x10, field offset: 0x8
class Mva extends Ky {

  [closure] void <anonymous closure>(dynamic, Ea) {
    // ** addr: 0x9987ac, size: -0x1
  }
  [closure] void _Gje(dynamic, _Lva) {
    // ** addr: 0x998770, size: -0x1
  }
  [closure] Mca _Ije(dynamic, iva, oM<double>, Hva, iva, iva) {
    // ** addr: 0x9983fc, size: -0x1
  }
  [closure] qE <anonymous closure>(dynamic, iva, Mca?) {
    // ** addr: 0x998610, size: -0x1
  }
  [closure] bool Gym(dynamic, _Lva) {
    // ** addr: 0x9941e0, size: -0x1
  }
}

// class id: 7208, size: 0x14, field offset: 0x14
enum Hva extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
