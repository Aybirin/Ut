// lib: , url: Kqn

// class id: 1050343, size: 0x8
class :: {
}

// class id: 3093, size: 0x1c, field offset: 0x14
class ntb extends Lla {
}
