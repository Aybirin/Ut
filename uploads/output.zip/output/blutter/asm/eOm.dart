// lib: , url: eOm

// class id: 1049066, size: 0x8
class :: {
}

// class id: 3791, size: 0x34, field offset: 0x8
//   const constructor, 
class lba extends _FM {
}
