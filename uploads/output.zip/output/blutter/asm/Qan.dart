// lib: , url: Qan

// class id: 1049625, size: 0x8
class :: {
}

// class id: 1850, size: 0xc, field offset: 0x8
//   const constructor, 
class _zUa extends Object {
}

// class id: 1851, size: 0xc, field offset: 0x8
//   const constructor, 
class _yUa extends Object {
}

// class id: 1852, size: 0x30, field offset: 0x8
class _xUa extends Object {
}

// class id: 1853, size: 0x3c, field offset: 0x8
class wUa extends Object {

  [closure] Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xbf6d98, size: 0x650
    // 0xbf6d98: EnterFrame
    //     0xbf6d98: stp             fp, lr, [SP, #-0x10]!
    //     0xbf6d9c: mov             fp, SP
    // 0xbf6da0: AllocStack(0xc0)
    //     0xbf6da0: sub             SP, SP, #0xc0
    // 0xbf6da4: SetupParameters(wUa this /* r1, fp-0x90 */)
    //     0xbf6da4: stur            NULL, [fp, #-8]
    //     0xbf6da8: movz            x0, #0
    //     0xbf6dac: add             x1, fp, w0, sxtw #2
    //     0xbf6db0: ldr             x1, [x1, #0x10]
    //     0xbf6db4: stur            x1, [fp, #-0x90]
    //     0xbf6db8: ldur            w2, [x1, #0x17]
    //     0xbf6dbc: add             x2, x2, HEAP, lsl #32
    //     0xbf6dc0: stur            x2, [fp, #-0x88]
    // 0xbf6dc4: CheckStackOverflow
    //     0xbf6dc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf6dc8: cmp             SP, x16
    //     0xbf6dcc: b.ls            #0xbf73e0
    // 0xbf6dd0: InitAsync() -> Future<Null?>
    //     0xbf6dd0: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xbf6dd4: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbf6dd8: ldur            x1, [fp, #-0x88]
    // 0xbf6ddc: LoadField: r2 = r1->field_f
    //     0xbf6ddc: ldur            w2, [x1, #0xf]
    // 0xbf6de0: DecompressPointer r2
    //     0xbf6de0: add             x2, x2, HEAP, lsl #32
    // 0xbf6de4: mov             x0, x2
    // 0xbf6de8: stur            x2, [fp, #-0x90]
    // 0xbf6dec: r0 = Await()
    //     0xbf6dec: bl              #0xb0c534  ; AwaitStub
    // 0xbf6df0: stur            x0, [fp, #-0xa8]
    // 0xbf6df4: LoadField: r5 = r0->field_7
    //     0xbf6df4: ldur            w5, [x0, #7]
    // 0xbf6df8: DecompressPointer r5
    //     0xbf6df8: add             x5, x5, HEAP, lsl #32
    // 0xbf6dfc: cmp             w5, NULL
    // 0xbf6e00: b.ne            #0xbf7054
    // 0xbf6e04: ldur            x3, [fp, #-0x88]
    // 0xbf6e08: LoadField: r4 = r0->field_b
    //     0xbf6e08: ldur            w4, [x0, #0xb]
    // 0xbf6e0c: DecompressPointer r4
    //     0xbf6e0c: add             x4, x4, HEAP, lsl #32
    // 0xbf6e10: stur            x4, [fp, #-0xa0]
    // 0xbf6e14: LoadField: r5 = r3->field_b
    //     0xbf6e14: ldur            w5, [x3, #0xb]
    // 0xbf6e18: DecompressPointer r5
    //     0xbf6e18: add             x5, x5, HEAP, lsl #32
    // 0xbf6e1c: stur            x5, [fp, #-0x98]
    // 0xbf6e20: LoadField: r1 = r5->field_1f
    //     0xbf6e20: ldur            w1, [x5, #0x1f]
    // 0xbf6e24: DecompressPointer r1
    //     0xbf6e24: add             x1, x1, HEAP, lsl #32
    // 0xbf6e28: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf6e28: ldur            w2, [x1, #0x17]
    // 0xbf6e2c: DecompressPointer r2
    //     0xbf6e2c: add             x2, x2, HEAP, lsl #32
    // 0xbf6e30: LoadField: r1 = r2->field_f
    //     0xbf6e30: ldur            w1, [x2, #0xf]
    // 0xbf6e34: DecompressPointer r1
    //     0xbf6e34: add             x1, x1, HEAP, lsl #32
    // 0xbf6e38: ArrayLoad: r6 = r2[0]  ; List_4
    //     0xbf6e38: ldur            w6, [x2, #0x17]
    // 0xbf6e3c: DecompressPointer r6
    //     0xbf6e3c: add             x6, x6, HEAP, lsl #32
    // 0xbf6e40: LoadField: r7 = r2->field_1b
    //     0xbf6e40: ldur            w7, [x2, #0x1b]
    // 0xbf6e44: DecompressPointer r7
    //     0xbf6e44: add             x7, x7, HEAP, lsl #32
    // 0xbf6e48: LoadField: r2 = r1->field_27
    //     0xbf6e48: ldur            w2, [x1, #0x27]
    // 0xbf6e4c: DecompressPointer r2
    //     0xbf6e4c: add             x2, x2, HEAP, lsl #32
    // 0xbf6e50: cmp             w2, w6
    // 0xbf6e54: b.ne            #0xbf6fcc
    // 0xbf6e58: LoadField: r2 = r6->field_7
    //     0xbf6e58: ldur            x2, [x6, #7]
    // 0xbf6e5c: ArrayLoad: r6 = r1[0]  ; List_8
    //     0xbf6e5c: ldur            x6, [x1, #0x17]
    // 0xbf6e60: cmp             x2, x6
    // 0xbf6e64: b.ne            #0xbf6fcc
    // 0xbf6e68: LoadField: r2 = r1->field_1f
    //     0xbf6e68: ldur            x2, [x1, #0x1f]
    // 0xbf6e6c: r1 = LoadInt32Instr(r7)
    //     0xbf6e6c: sbfx            x1, x7, #1, #0x1f
    //     0xbf6e70: tbz             w7, #0, #0xbf6e78
    //     0xbf6e74: ldur            x1, [x7, #7]
    // 0xbf6e78: cmp             x1, x2
    // 0xbf6e7c: b.ne            #0xbf6fcc
    // 0xbf6e80: cmp             w4, NULL
    // 0xbf6e84: b.eq            #0xbf6fcc
    // 0xbf6e88: LoadField: r6 = r4->field_7
    //     0xbf6e88: ldur            w6, [x4, #7]
    // 0xbf6e8c: DecompressPointer r6
    //     0xbf6e8c: add             x6, x6, HEAP, lsl #32
    // 0xbf6e90: stur            x6, [fp, #-0x90]
    // 0xbf6e94: r16 = Instance_AUa
    //     0xbf6e94: add             x16, PP, #0x29, lsl #12  ; [pp+0x29158] Obj!AUa@699de1
    //     0xbf6e98: ldr             x16, [x16, #0x158]
    // 0xbf6e9c: cmp             w6, w16
    // 0xbf6ea0: b.eq            #0xbf6fcc
    // 0xbf6ea4: r1 = Null
    //     0xbf6ea4: mov             x1, NULL
    // 0xbf6ea8: r2 = 20
    //     0xbf6ea8: movz            x2, #0x14
    // 0xbf6eac: r0 = AllocateArray()
    //     0xbf6eac: bl              #0xc55848  ; AllocateArrayStub
    // 0xbf6eb0: mov             x2, x0
    // 0xbf6eb4: r16 = "router config request failed: domain="
    //     0xbf6eb4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d5b8] "router config request failed: domain="
    //     0xbf6eb8: ldr             x16, [x16, #0x5b8]
    // 0xbf6ebc: StoreField: r2->field_f = r16
    //     0xbf6ebc: stur            w16, [x2, #0xf]
    // 0xbf6ec0: ldur            x3, [fp, #-0x88]
    // 0xbf6ec4: LoadField: r0 = r3->field_13
    //     0xbf6ec4: ldur            w0, [x3, #0x13]
    // 0xbf6ec8: DecompressPointer r0
    //     0xbf6ec8: add             x0, x0, HEAP, lsl #32
    // 0xbf6ecc: StoreField: r2->field_13 = r0
    //     0xbf6ecc: stur            w0, [x2, #0x13]
    // 0xbf6ed0: r16 = ", kind="
    //     0xbf6ed0: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d5c0] ", kind="
    //     0xbf6ed4: ldr             x16, [x16, #0x5c0]
    // 0xbf6ed8: ArrayStore: r2[0] = r16  ; List_4
    //     0xbf6ed8: stur            w16, [x2, #0x17]
    // 0xbf6edc: ldur            x0, [fp, #-0x90]
    // 0xbf6ee0: LoadField: r1 = r0->field_f
    //     0xbf6ee0: ldur            w1, [x0, #0xf]
    // 0xbf6ee4: DecompressPointer r1
    //     0xbf6ee4: add             x1, x1, HEAP, lsl #32
    // 0xbf6ee8: StoreField: r2->field_1b = r1
    //     0xbf6ee8: stur            w1, [x2, #0x1b]
    // 0xbf6eec: r16 = ", attempts="
    //     0xbf6eec: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d5c8] ", attempts="
    //     0xbf6ef0: ldr             x16, [x16, #0x5c8]
    // 0xbf6ef4: StoreField: r2->field_1f = r16
    //     0xbf6ef4: stur            w16, [x2, #0x1f]
    // 0xbf6ef8: ldur            x0, [fp, #-0xa8]
    // 0xbf6efc: LoadField: r4 = r0->field_f
    //     0xbf6efc: ldur            x4, [x0, #0xf]
    // 0xbf6f00: r0 = BoxInt64Instr(r4)
    //     0xbf6f00: sbfiz           x0, x4, #1, #0x1f
    //     0xbf6f04: cmp             x4, x0, asr #1
    //     0xbf6f08: b.eq            #0xbf6f14
    //     0xbf6f0c: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf6f10: stur            x4, [x0, #7]
    // 0xbf6f14: mov             x1, x2
    // 0xbf6f18: ArrayStore: r1[5] = r0  ; List_4
    //     0xbf6f18: add             x25, x1, #0x23
    //     0xbf6f1c: str             w0, [x25]
    //     0xbf6f20: tbz             w0, #0, #0xbf6f3c
    //     0xbf6f24: ldurb           w16, [x1, #-1]
    //     0xbf6f28: ldurb           w17, [x0, #-1]
    //     0xbf6f2c: and             x16, x17, x16, lsr #2
    //     0xbf6f30: tst             x16, HEAP, lsr #32
    //     0xbf6f34: b.eq            #0xbf6f3c
    //     0xbf6f38: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xbf6f3c: r16 = ", status="
    //     0xbf6f3c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c68] ", status="
    //     0xbf6f40: ldr             x16, [x16, #0xc68]
    // 0xbf6f44: StoreField: r2->field_27 = r16
    //     0xbf6f44: stur            w16, [x2, #0x27]
    // 0xbf6f48: ldur            x4, [fp, #-0xa0]
    // 0xbf6f4c: LoadField: r0 = r4->field_f
    //     0xbf6f4c: ldur            w0, [x4, #0xf]
    // 0xbf6f50: DecompressPointer r0
    //     0xbf6f50: add             x0, x0, HEAP, lsl #32
    // 0xbf6f54: cmp             w0, NULL
    // 0xbf6f58: b.ne            #0xbf6f60
    // 0xbf6f5c: r0 = "-"
    //     0xbf6f5c: ldr             x0, [PP, #0x2ef0]  ; [pp+0x2ef0] "-"
    // 0xbf6f60: mov             x1, x2
    // 0xbf6f64: ArrayStore: r1[7] = r0  ; List_4
    //     0xbf6f64: add             x25, x1, #0x2b
    //     0xbf6f68: str             w0, [x25]
    //     0xbf6f6c: tbz             w0, #0, #0xbf6f88
    //     0xbf6f70: ldurb           w16, [x1, #-1]
    //     0xbf6f74: ldurb           w17, [x0, #-1]
    //     0xbf6f78: and             x16, x17, x16, lsr #2
    //     0xbf6f7c: tst             x16, HEAP, lsr #32
    //     0xbf6f80: b.eq            #0xbf6f88
    //     0xbf6f84: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xbf6f88: r16 = ", message="
    //     0xbf6f88: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c70] ", message="
    //     0xbf6f8c: ldr             x16, [x16, #0xc70]
    // 0xbf6f90: StoreField: r2->field_2f = r16
    //     0xbf6f90: stur            w16, [x2, #0x2f]
    // 0xbf6f94: LoadField: r0 = r4->field_b
    //     0xbf6f94: ldur            w0, [x4, #0xb]
    // 0xbf6f98: DecompressPointer r0
    //     0xbf6f98: add             x0, x0, HEAP, lsl #32
    // 0xbf6f9c: mov             x1, x2
    // 0xbf6fa0: ArrayStore: r1[9] = r0  ; List_4
    //     0xbf6fa0: add             x25, x1, #0x33
    //     0xbf6fa4: str             w0, [x25]
    //     0xbf6fa8: tbz             w0, #0, #0xbf6fc4
    //     0xbf6fac: ldurb           w16, [x1, #-1]
    //     0xbf6fb0: ldurb           w17, [x0, #-1]
    //     0xbf6fb4: and             x16, x17, x16, lsr #2
    //     0xbf6fb8: tst             x16, HEAP, lsr #32
    //     0xbf6fbc: b.eq            #0xbf6fc4
    //     0xbf6fc0: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xbf6fc4: str             x2, [SP]
    // 0xbf6fc8: r0 = _interpolate()
    //     0xbf6fc8: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xbf6fcc: ldur            x2, [fp, #-0x98]
    // 0xbf6fd0: LoadField: r0 = r2->field_27
    //     0xbf6fd0: ldur            w0, [x2, #0x27]
    // 0xbf6fd4: DecompressPointer r0
    //     0xbf6fd4: add             x0, x0, HEAP, lsl #32
    // 0xbf6fd8: r1 = LoadInt32Instr(r0)
    //     0xbf6fd8: sbfx            x1, x0, #1, #0x1f
    //     0xbf6fdc: tbz             w0, #0, #0xbf6fe4
    //     0xbf6fe0: ldur            x1, [x0, #7]
    // 0xbf6fe4: sub             x3, x1, #1
    // 0xbf6fe8: r0 = BoxInt64Instr(r3)
    //     0xbf6fe8: sbfiz           x0, x3, #1, #0x1f
    //     0xbf6fec: cmp             x3, x0, asr #1
    //     0xbf6ff0: b.eq            #0xbf6ffc
    //     0xbf6ff4: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf6ff8: stur            x3, [x0, #7]
    // 0xbf6ffc: StoreField: r2->field_27 = r0
    //     0xbf6ffc: stur            w0, [x2, #0x27]
    //     0xbf7000: tbz             w0, #0, #0xbf701c
    //     0xbf7004: ldurb           w16, [x2, #-1]
    //     0xbf7008: ldurb           w17, [x0, #-1]
    //     0xbf700c: and             x16, x17, x16, lsr #2
    //     0xbf7010: tst             x16, HEAP, lsr #32
    //     0xbf7014: b.eq            #0xbf701c
    //     0xbf7018: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xbf701c: cbnz            x3, #0xbf704c
    // 0xbf7020: LoadField: r1 = r2->field_23
    //     0xbf7020: ldur            w1, [x2, #0x23]
    // 0xbf7024: DecompressPointer r1
    //     0xbf7024: add             x1, x1, HEAP, lsl #32
    // 0xbf7028: LoadField: r0 = r1->field_b
    //     0xbf7028: ldur            w0, [x1, #0xb]
    // 0xbf702c: DecompressPointer r0
    //     0xbf702c: add             x0, x0, HEAP, lsl #32
    // 0xbf7030: LoadField: r2 = r0->field_b
    //     0xbf7030: ldur            x2, [x0, #0xb]
    // 0xbf7034: tst             x2, #0x1e
    // 0xbf7038: b.ne            #0xbf704c
    // 0xbf703c: r16 = false
    //     0xbf703c: add             x16, NULL, #0x30  ; false
    // 0xbf7040: str             x16, [SP]
    // 0xbf7044: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbf7044: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbf7048: r0 = call 0x9eda78
    //     0xbf7048: bl              #0x9eda78
    // 0xbf704c: r0 = Null
    //     0xbf704c: mov             x0, NULL
    // 0xbf7050: r0 = ReturnAsyncNotFuture()
    //     0xbf7050: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf7054: ldur            x0, [fp, #-0x88]
    // 0xbf7058: LoadField: r2 = r0->field_b
    //     0xbf7058: ldur            w2, [x0, #0xb]
    // 0xbf705c: DecompressPointer r2
    //     0xbf705c: add             x2, x2, HEAP, lsl #32
    // 0xbf7060: LoadField: r1 = r2->field_1f
    //     0xbf7060: ldur            w1, [x2, #0x1f]
    // 0xbf7064: DecompressPointer r1
    //     0xbf7064: add             x1, x1, HEAP, lsl #32
    // 0xbf7068: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xbf7068: ldur            w4, [x1, #0x17]
    // 0xbf706c: DecompressPointer r4
    //     0xbf706c: add             x4, x4, HEAP, lsl #32
    // 0xbf7070: stur            x4, [fp, #-0x98]
    // 0xbf7074: LoadField: r1 = r4->field_f
    //     0xbf7074: ldur            w1, [x4, #0xf]
    // 0xbf7078: DecompressPointer r1
    //     0xbf7078: add             x1, x1, HEAP, lsl #32
    // 0xbf707c: ArrayLoad: r8 = r4[0]  ; List_4
    //     0xbf707c: ldur            w8, [x4, #0x17]
    // 0xbf7080: DecompressPointer r8
    //     0xbf7080: add             x8, x8, HEAP, lsl #32
    // 0xbf7084: stur            x8, [fp, #-0x90]
    // 0xbf7088: LoadField: r3 = r4->field_1b
    //     0xbf7088: ldur            w3, [x4, #0x1b]
    // 0xbf708c: DecompressPointer r3
    //     0xbf708c: add             x3, x3, HEAP, lsl #32
    // 0xbf7090: LoadField: r6 = r1->field_27
    //     0xbf7090: ldur            w6, [x1, #0x27]
    // 0xbf7094: DecompressPointer r6
    //     0xbf7094: add             x6, x6, HEAP, lsl #32
    // 0xbf7098: cmp             w6, w8
    // 0xbf709c: b.ne            #0xbf7188
    // 0xbf70a0: LoadField: r9 = r8->field_7
    //     0xbf70a0: ldur            x9, [x8, #7]
    // 0xbf70a4: stur            x9, [fp, #-0xb8]
    // 0xbf70a8: ArrayLoad: r6 = r1[0]  ; List_8
    //     0xbf70a8: ldur            x6, [x1, #0x17]
    // 0xbf70ac: cmp             x9, x6
    // 0xbf70b0: b.ne            #0xbf7188
    // 0xbf70b4: LoadField: r6 = r1->field_1f
    //     0xbf70b4: ldur            x6, [x1, #0x1f]
    // 0xbf70b8: r10 = LoadInt32Instr(r3)
    //     0xbf70b8: sbfx            x10, x3, #1, #0x1f
    //     0xbf70bc: tbz             w3, #0, #0xbf70c4
    //     0xbf70c0: ldur            x10, [x3, #7]
    // 0xbf70c4: stur            x10, [fp, #-0xb0]
    // 0xbf70c8: cmp             x10, x6
    // 0xbf70cc: b.ne            #0xbf7188
    // 0xbf70d0: LoadField: r1 = r2->field_f
    //     0xbf70d0: ldur            w1, [x2, #0xf]
    // 0xbf70d4: DecompressPointer r1
    //     0xbf70d4: add             x1, x1, HEAP, lsl #32
    // 0xbf70d8: ArrayLoad: r3 = r2[0]  ; List_4
    //     0xbf70d8: ldur            w3, [x2, #0x17]
    // 0xbf70dc: DecompressPointer r3
    //     0xbf70dc: add             x3, x3, HEAP, lsl #32
    // 0xbf70e0: LoadField: r6 = r2->field_13
    //     0xbf70e0: ldur            w6, [x2, #0x13]
    // 0xbf70e4: DecompressPointer r6
    //     0xbf70e4: add             x6, x6, HEAP, lsl #32
    // 0xbf70e8: LoadField: r7 = r2->field_1b
    //     0xbf70e8: ldur            w7, [x2, #0x1b]
    // 0xbf70ec: DecompressPointer r7
    //     0xbf70ec: add             x7, x7, HEAP, lsl #32
    // 0xbf70f0: r2 = LoadInt32Instr(r7)
    //     0xbf70f0: sbfx            x2, x7, #1, #0x1f
    //     0xbf70f4: tbz             w7, #0, #0xbf70fc
    //     0xbf70f8: ldur            x2, [x7, #7]
    // 0xbf70fc: mov             x16, x6
    // 0xbf7100: mov             x6, x3
    // 0xbf7104: mov             x3, x16
    // 0xbf7108: mov             x16, x2
    // 0xbf710c: mov             x2, x6
    // 0xbf7110: mov             x6, x16
    // 0xbf7114: r7 = Instance_vUa
    //     0xbf7114: add             x7, PP, #0x2d, lsl #12  ; [pp+0x2d5d0] Obj!vUa@699f81
    //     0xbf7118: ldr             x7, [x7, #0x5d0]
    // 0xbf711c: r0 = call 0x78a91c
    //     0xbf711c: bl              #0x78a91c
    // 0xbf7120: mov             x1, x0
    // 0xbf7124: stur            x1, [fp, #-0xa0]
    // 0xbf7128: r0 = Await()
    //     0xbf7128: bl              #0xb0c534  ; AwaitStub
    // 0xbf712c: ldur            x0, [fp, #-0x98]
    // 0xbf7130: LoadField: r1 = r0->field_f
    //     0xbf7130: ldur            w1, [x0, #0xf]
    // 0xbf7134: DecompressPointer r1
    //     0xbf7134: add             x1, x1, HEAP, lsl #32
    // 0xbf7138: LoadField: r0 = r1->field_27
    //     0xbf7138: ldur            w0, [x1, #0x27]
    // 0xbf713c: DecompressPointer r0
    //     0xbf713c: add             x0, x0, HEAP, lsl #32
    // 0xbf7140: ldur            x2, [fp, #-0x90]
    // 0xbf7144: cmp             w0, w2
    // 0xbf7148: b.ne            #0xbf717c
    // 0xbf714c: ldur            x0, [fp, #-0xb8]
    // 0xbf7150: ArrayLoad: r2 = r1[0]  ; List_8
    //     0xbf7150: ldur            x2, [x1, #0x17]
    // 0xbf7154: cmp             x0, x2
    // 0xbf7158: b.ne            #0xbf717c
    // 0xbf715c: ldur            x0, [fp, #-0xb0]
    // 0xbf7160: LoadField: r2 = r1->field_1f
    //     0xbf7160: ldur            x2, [x1, #0x1f]
    // 0xbf7164: cmp             x0, x2
    // 0xbf7168: r16 = true
    //     0xbf7168: add             x16, NULL, #0x20  ; true
    // 0xbf716c: r17 = false
    //     0xbf716c: add             x17, NULL, #0x30  ; false
    // 0xbf7170: csel            x1, x16, x17, eq
    // 0xbf7174: mov             x0, x1
    // 0xbf7178: b               #0xbf7180
    // 0xbf717c: r0 = false
    //     0xbf717c: add             x0, NULL, #0x30  ; false
    // 0xbf7180: ldur            x2, [fp, #-0x88]
    // 0xbf7184: b               #0xbf721c
    // 0xbf7188: LoadField: r0 = r2->field_27
    //     0xbf7188: ldur            w0, [x2, #0x27]
    // 0xbf718c: DecompressPointer r0
    //     0xbf718c: add             x0, x0, HEAP, lsl #32
    // 0xbf7190: r1 = LoadInt32Instr(r0)
    //     0xbf7190: sbfx            x1, x0, #1, #0x1f
    //     0xbf7194: tbz             w0, #0, #0xbf719c
    //     0xbf7198: ldur            x1, [x0, #7]
    // 0xbf719c: sub             x3, x1, #1
    // 0xbf71a0: r0 = BoxInt64Instr(r3)
    //     0xbf71a0: sbfiz           x0, x3, #1, #0x1f
    //     0xbf71a4: cmp             x3, x0, asr #1
    //     0xbf71a8: b.eq            #0xbf71b4
    //     0xbf71ac: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf71b0: stur            x3, [x0, #7]
    // 0xbf71b4: StoreField: r2->field_27 = r0
    //     0xbf71b4: stur            w0, [x2, #0x27]
    //     0xbf71b8: tbz             w0, #0, #0xbf71d4
    //     0xbf71bc: ldurb           w16, [x2, #-1]
    //     0xbf71c0: ldurb           w17, [x0, #-1]
    //     0xbf71c4: and             x16, x17, x16, lsr #2
    //     0xbf71c8: tst             x16, HEAP, lsr #32
    //     0xbf71cc: b.eq            #0xbf71d4
    //     0xbf71d0: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xbf71d4: cbnz            x3, #0xbf7204
    // 0xbf71d8: LoadField: r1 = r2->field_23
    //     0xbf71d8: ldur            w1, [x2, #0x23]
    // 0xbf71dc: DecompressPointer r1
    //     0xbf71dc: add             x1, x1, HEAP, lsl #32
    // 0xbf71e0: LoadField: r0 = r1->field_b
    //     0xbf71e0: ldur            w0, [x1, #0xb]
    // 0xbf71e4: DecompressPointer r0
    //     0xbf71e4: add             x0, x0, HEAP, lsl #32
    // 0xbf71e8: LoadField: r2 = r0->field_b
    //     0xbf71e8: ldur            x2, [x0, #0xb]
    // 0xbf71ec: tst             x2, #0x1e
    // 0xbf71f0: b.ne            #0xbf7204
    // 0xbf71f4: r16 = false
    //     0xbf71f4: add             x16, NULL, #0x30  ; false
    // 0xbf71f8: str             x16, [SP]
    // 0xbf71fc: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbf71fc: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbf7200: r0 = call 0x9eda78
    //     0xbf7200: bl              #0x9eda78
    // 0xbf7204: r0 = Null
    //     0xbf7204: mov             x0, NULL
    // 0xbf7208: r0 = ReturnAsyncNotFuture()
    //     0xbf7208: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf720c: sub             SP, fp, #0xc0
    // 0xbf7210: ldur            x0, [fp, #-0x28]
    // 0xbf7214: mov             x2, x0
    // 0xbf7218: r0 = false
    //     0xbf7218: add             x0, NULL, #0x30  ; false
    // 0xbf721c: stur            x2, [fp, #-0x88]
    // 0xbf7220: tbnz            w0, #4, #0xbf7258
    // 0xbf7224: LoadField: r0 = r2->field_b
    //     0xbf7224: ldur            w0, [x2, #0xb]
    // 0xbf7228: DecompressPointer r0
    //     0xbf7228: add             x0, x0, HEAP, lsl #32
    // 0xbf722c: LoadField: r1 = r0->field_23
    //     0xbf722c: ldur            w1, [x0, #0x23]
    // 0xbf7230: DecompressPointer r1
    //     0xbf7230: add             x1, x1, HEAP, lsl #32
    // 0xbf7234: LoadField: r0 = r1->field_b
    //     0xbf7234: ldur            w0, [x1, #0xb]
    // 0xbf7238: DecompressPointer r0
    //     0xbf7238: add             x0, x0, HEAP, lsl #32
    // 0xbf723c: LoadField: r3 = r0->field_b
    //     0xbf723c: ldur            x3, [x0, #0xb]
    // 0xbf7240: tst             x3, #0x1e
    // 0xbf7244: b.ne            #0xbf7258
    // 0xbf7248: r16 = true
    //     0xbf7248: add             x16, NULL, #0x20  ; true
    // 0xbf724c: str             x16, [SP]
    // 0xbf7250: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbf7250: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbf7254: r0 = call 0x9eda78
    //     0xbf7254: bl              #0x9eda78
    // 0xbf7258: ldur            x0, [fp, #-0x88]
    // 0xbf725c: LoadField: r2 = r0->field_b
    //     0xbf725c: ldur            w2, [x0, #0xb]
    // 0xbf7260: DecompressPointer r2
    //     0xbf7260: add             x2, x2, HEAP, lsl #32
    // 0xbf7264: LoadField: r0 = r2->field_27
    //     0xbf7264: ldur            w0, [x2, #0x27]
    // 0xbf7268: DecompressPointer r0
    //     0xbf7268: add             x0, x0, HEAP, lsl #32
    // 0xbf726c: r1 = LoadInt32Instr(r0)
    //     0xbf726c: sbfx            x1, x0, #1, #0x1f
    //     0xbf7270: tbz             w0, #0, #0xbf7278
    //     0xbf7274: ldur            x1, [x0, #7]
    // 0xbf7278: sub             x3, x1, #1
    // 0xbf727c: r0 = BoxInt64Instr(r3)
    //     0xbf727c: sbfiz           x0, x3, #1, #0x1f
    //     0xbf7280: cmp             x3, x0, asr #1
    //     0xbf7284: b.eq            #0xbf7290
    //     0xbf7288: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf728c: stur            x3, [x0, #7]
    // 0xbf7290: StoreField: r2->field_27 = r0
    //     0xbf7290: stur            w0, [x2, #0x27]
    //     0xbf7294: tbz             w0, #0, #0xbf72b0
    //     0xbf7298: ldurb           w16, [x2, #-1]
    //     0xbf729c: ldurb           w17, [x0, #-1]
    //     0xbf72a0: and             x16, x17, x16, lsr #2
    //     0xbf72a4: tst             x16, HEAP, lsr #32
    //     0xbf72a8: b.eq            #0xbf72b0
    //     0xbf72ac: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xbf72b0: cbnz            x3, #0xbf72e0
    // 0xbf72b4: LoadField: r1 = r2->field_23
    //     0xbf72b4: ldur            w1, [x2, #0x23]
    // 0xbf72b8: DecompressPointer r1
    //     0xbf72b8: add             x1, x1, HEAP, lsl #32
    // 0xbf72bc: LoadField: r0 = r1->field_b
    //     0xbf72bc: ldur            w0, [x1, #0xb]
    // 0xbf72c0: DecompressPointer r0
    //     0xbf72c0: add             x0, x0, HEAP, lsl #32
    // 0xbf72c4: LoadField: r2 = r0->field_b
    //     0xbf72c4: ldur            x2, [x0, #0xb]
    // 0xbf72c8: tst             x2, #0x1e
    // 0xbf72cc: b.ne            #0xbf72e0
    // 0xbf72d0: r16 = false
    //     0xbf72d0: add             x16, NULL, #0x30  ; false
    // 0xbf72d4: str             x16, [SP]
    // 0xbf72d8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbf72d8: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbf72dc: r0 = call 0x9eda78
    //     0xbf72dc: bl              #0x9eda78
    // 0xbf72e0: r0 = Null
    //     0xbf72e0: mov             x0, NULL
    // 0xbf72e4: r0 = ReturnAsyncNotFuture()
    //     0xbf72e4: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf72e8: sub             SP, fp, #0xc0
    // 0xbf72ec: mov             x3, x0
    // 0xbf72f0: mov             x2, x1
    // 0xbf72f4: stur            x0, [fp, #-0x88]
    // 0xbf72f8: ldur            x0, [fp, #-0x58]
    // 0xbf72fc: stur            x1, [fp, #-0x90]
    // 0xbf7300: r16 = true
    //     0xbf7300: add             x16, NULL, #0x20  ; true
    // 0xbf7304: cmp             w0, w16
    // 0xbf7308: b.ne            #0xbf7348
    // 0xbf730c: ldur            x0, [fp, #-0x20]
    // 0xbf7310: LoadField: r1 = r0->field_b
    //     0xbf7310: ldur            w1, [x0, #0xb]
    // 0xbf7314: DecompressPointer r1
    //     0xbf7314: add             x1, x1, HEAP, lsl #32
    // 0xbf7318: LoadField: r4 = r1->field_23
    //     0xbf7318: ldur            w4, [x1, #0x23]
    // 0xbf731c: DecompressPointer r4
    //     0xbf731c: add             x4, x4, HEAP, lsl #32
    // 0xbf7320: LoadField: r1 = r4->field_b
    //     0xbf7320: ldur            w1, [x4, #0xb]
    // 0xbf7324: DecompressPointer r1
    //     0xbf7324: add             x1, x1, HEAP, lsl #32
    // 0xbf7328: LoadField: r5 = r1->field_b
    //     0xbf7328: ldur            x5, [x1, #0xb]
    // 0xbf732c: tst             x5, #0x1e
    // 0xbf7330: b.ne            #0xbf7348
    // 0xbf7334: r16 = true
    //     0xbf7334: add             x16, NULL, #0x20  ; true
    // 0xbf7338: str             x16, [SP]
    // 0xbf733c: mov             x1, x4
    // 0xbf7340: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbf7340: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbf7344: r0 = call 0x9eda78
    //     0xbf7344: bl              #0x9eda78
    // 0xbf7348: ldur            x0, [fp, #-0x20]
    // 0xbf734c: LoadField: r2 = r0->field_b
    //     0xbf734c: ldur            w2, [x0, #0xb]
    // 0xbf7350: DecompressPointer r2
    //     0xbf7350: add             x2, x2, HEAP, lsl #32
    // 0xbf7354: LoadField: r0 = r2->field_27
    //     0xbf7354: ldur            w0, [x2, #0x27]
    // 0xbf7358: DecompressPointer r0
    //     0xbf7358: add             x0, x0, HEAP, lsl #32
    // 0xbf735c: r1 = LoadInt32Instr(r0)
    //     0xbf735c: sbfx            x1, x0, #1, #0x1f
    //     0xbf7360: tbz             w0, #0, #0xbf7368
    //     0xbf7364: ldur            x1, [x0, #7]
    // 0xbf7368: sub             x3, x1, #1
    // 0xbf736c: r0 = BoxInt64Instr(r3)
    //     0xbf736c: sbfiz           x0, x3, #1, #0x1f
    //     0xbf7370: cmp             x3, x0, asr #1
    //     0xbf7374: b.eq            #0xbf7380
    //     0xbf7378: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbf737c: stur            x3, [x0, #7]
    // 0xbf7380: StoreField: r2->field_27 = r0
    //     0xbf7380: stur            w0, [x2, #0x27]
    //     0xbf7384: tbz             w0, #0, #0xbf73a0
    //     0xbf7388: ldurb           w16, [x2, #-1]
    //     0xbf738c: ldurb           w17, [x0, #-1]
    //     0xbf7390: and             x16, x17, x16, lsr #2
    //     0xbf7394: tst             x16, HEAP, lsr #32
    //     0xbf7398: b.eq            #0xbf73a0
    //     0xbf739c: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xbf73a0: cbnz            x3, #0xbf73d0
    // 0xbf73a4: LoadField: r1 = r2->field_23
    //     0xbf73a4: ldur            w1, [x2, #0x23]
    // 0xbf73a8: DecompressPointer r1
    //     0xbf73a8: add             x1, x1, HEAP, lsl #32
    // 0xbf73ac: LoadField: r0 = r1->field_b
    //     0xbf73ac: ldur            w0, [x1, #0xb]
    // 0xbf73b0: DecompressPointer r0
    //     0xbf73b0: add             x0, x0, HEAP, lsl #32
    // 0xbf73b4: LoadField: r2 = r0->field_b
    //     0xbf73b4: ldur            x2, [x0, #0xb]
    // 0xbf73b8: tst             x2, #0x1e
    // 0xbf73bc: b.ne            #0xbf73d0
    // 0xbf73c0: r16 = false
    //     0xbf73c0: add             x16, NULL, #0x30  ; false
    // 0xbf73c4: str             x16, [SP]
    // 0xbf73c8: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbf73c8: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbf73cc: r0 = call 0x9eda78
    //     0xbf73cc: bl              #0x9eda78
    // 0xbf73d0: ldur            x0, [fp, #-0x88]
    // 0xbf73d4: ldur            x1, [fp, #-0x90]
    // 0xbf73d8: r0 = ReThrow()
    //     0xbf73d8: bl              #0xc539d8  ; ReThrowStub
    // 0xbf73dc: brk             #0
    // 0xbf73e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf73e0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf73e4: b               #0xbf6dd0
  }
  [closure] Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xbf73e8, size: 0x134
    // 0xbf73e8: EnterFrame
    //     0xbf73e8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf73ec: mov             fp, SP
    // 0xbf73f0: AllocStack(0x60)
    //     0xbf73f0: sub             SP, SP, #0x60
    // 0xbf73f4: SetupParameters(wUa this /* r1, fp-0x58 */)
    //     0xbf73f4: stur            NULL, [fp, #-8]
    //     0xbf73f8: movz            x0, #0
    //     0xbf73fc: add             x1, fp, w0, sxtw #2
    //     0xbf7400: ldr             x1, [x1, #0x10]
    //     0xbf7404: stur            x1, [fp, #-0x58]
    //     0xbf7408: ldur            w2, [x1, #0x17]
    //     0xbf740c: add             x2, x2, HEAP, lsl #32
    //     0xbf7410: stur            x2, [fp, #-0x50]
    // 0xbf7414: CheckStackOverflow
    //     0xbf7414: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf7418: cmp             SP, x16
    //     0xbf741c: b.ls            #0xbf7514
    // 0xbf7420: InitAsync() -> Future<Null?>
    //     0xbf7420: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xbf7424: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbf7428: ldur            x1, [fp, #-0x50]
    // 0xbf742c: LoadField: r2 = r1->field_2b
    //     0xbf742c: ldur            w2, [x1, #0x2b]
    // 0xbf7430: DecompressPointer r2
    //     0xbf7430: add             x2, x2, HEAP, lsl #32
    // 0xbf7434: mov             x0, x2
    // 0xbf7438: stur            x2, [fp, #-0x58]
    // 0xbf743c: r0 = Await()
    //     0xbf743c: bl              #0xb0c534  ; AwaitStub
    // 0xbf7440: ldur            x0, [fp, #-0x50]
    // 0xbf7444: b               #0xbf7450
    // 0xbf7448: sub             SP, fp, #0x60
    // 0xbf744c: ldur            x0, [fp, #-0x20]
    // 0xbf7450: stur            x0, [fp, #-0x50]
    // 0xbf7454: LoadField: r1 = r0->field_f
    //     0xbf7454: ldur            w1, [x0, #0xf]
    // 0xbf7458: DecompressPointer r1
    //     0xbf7458: add             x1, x1, HEAP, lsl #32
    // 0xbf745c: LoadField: r2 = r0->field_13
    //     0xbf745c: ldur            w2, [x0, #0x13]
    // 0xbf7460: DecompressPointer r2
    //     0xbf7460: add             x2, x2, HEAP, lsl #32
    // 0xbf7464: LoadField: r3 = r0->field_1f
    //     0xbf7464: ldur            w3, [x0, #0x1f]
    // 0xbf7468: DecompressPointer r3
    //     0xbf7468: add             x3, x3, HEAP, lsl #32
    // 0xbf746c: LoadField: r4 = r1->field_27
    //     0xbf746c: ldur            w4, [x1, #0x27]
    // 0xbf7470: DecompressPointer r4
    //     0xbf7470: add             x4, x4, HEAP, lsl #32
    // 0xbf7474: cmp             w4, w2
    // 0xbf7478: b.ne            #0xbf74f4
    // 0xbf747c: LoadField: r4 = r2->field_7
    //     0xbf747c: ldur            x4, [x2, #7]
    // 0xbf7480: ArrayLoad: r5 = r1[0]  ; List_8
    //     0xbf7480: ldur            x5, [x1, #0x17]
    // 0xbf7484: cmp             x4, x5
    // 0xbf7488: b.ne            #0xbf74f4
    // 0xbf748c: LoadField: r4 = r1->field_1f
    //     0xbf748c: ldur            x4, [x1, #0x1f]
    // 0xbf7490: r6 = LoadInt32Instr(r3)
    //     0xbf7490: sbfx            x6, x3, #1, #0x1f
    //     0xbf7494: tbz             w3, #0, #0xbf749c
    //     0xbf7498: ldur            x6, [x3, #7]
    // 0xbf749c: cmp             x6, x4
    // 0xbf74a0: b.ne            #0xbf74f4
    // 0xbf74a4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xbf74a4: ldur            w3, [x0, #0x17]
    // 0xbf74a8: DecompressPointer r3
    //     0xbf74a8: add             x3, x3, HEAP, lsl #32
    // 0xbf74ac: LoadField: r5 = r0->field_1b
    //     0xbf74ac: ldur            w5, [x0, #0x1b]
    // 0xbf74b0: DecompressPointer r5
    //     0xbf74b0: add             x5, x5, HEAP, lsl #32
    // 0xbf74b4: LoadField: r7 = r0->field_23
    //     0xbf74b4: ldur            w7, [x0, #0x23]
    // 0xbf74b8: DecompressPointer r7
    //     0xbf74b8: add             x7, x7, HEAP, lsl #32
    // 0xbf74bc: r0 = __unknown_function__()
    //     0xbf74bc: bl              #0xbf751c  ; [] ::__unknown_function__
    // 0xbf74c0: mov             x1, x0
    // 0xbf74c4: stur            x1, [fp, #-0x58]
    // 0xbf74c8: r0 = Await()
    //     0xbf74c8: bl              #0xb0c534  ; AwaitStub
    // 0xbf74cc: mov             x1, x0
    // 0xbf74d0: ldur            x0, [fp, #-0x50]
    // 0xbf74d4: LoadField: r2 = r0->field_27
    //     0xbf74d4: ldur            w2, [x0, #0x27]
    // 0xbf74d8: DecompressPointer r2
    //     0xbf74d8: add             x2, x2, HEAP, lsl #32
    // 0xbf74dc: str             x1, [SP]
    // 0xbf74e0: mov             x1, x2
    // 0xbf74e4: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbf74e4: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbf74e8: r0 = call 0x9eda78
    //     0xbf74e8: bl              #0x9eda78
    // 0xbf74ec: r0 = Null
    //     0xbf74ec: mov             x0, NULL
    // 0xbf74f0: r0 = ReturnAsyncNotFuture()
    //     0xbf74f0: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf74f4: LoadField: r1 = r0->field_27
    //     0xbf74f4: ldur            w1, [x0, #0x27]
    // 0xbf74f8: DecompressPointer r1
    //     0xbf74f8: add             x1, x1, HEAP, lsl #32
    // 0xbf74fc: r16 = false
    //     0xbf74fc: add             x16, NULL, #0x30  ; false
    // 0xbf7500: str             x16, [SP]
    // 0xbf7504: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xbf7504: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xbf7508: r0 = call 0x9eda78
    //     0xbf7508: bl              #0x9eda78
    // 0xbf750c: r0 = Null
    //     0xbf750c: mov             x0, NULL
    // 0xbf7510: r0 = ReturnAsyncNotFuture()
    //     0xbf7510: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf7514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7514: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7518: b               #0xbf7420
  }
  [closure] Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xbf7828, size: 0x118
    // 0xbf7828: EnterFrame
    //     0xbf7828: stp             fp, lr, [SP, #-0x10]!
    //     0xbf782c: mov             fp, SP
    // 0xbf7830: AllocStack(0x68)
    //     0xbf7830: sub             SP, SP, #0x68
    // 0xbf7834: SetupParameters(wUa this /* r1, fp-0x60 */)
    //     0xbf7834: stur            NULL, [fp, #-8]
    //     0xbf7838: movz            x0, #0
    //     0xbf783c: add             x1, fp, w0, sxtw #2
    //     0xbf7840: ldr             x1, [x1, #0x10]
    //     0xbf7844: stur            x1, [fp, #-0x60]
    //     0xbf7848: ldur            w2, [x1, #0x17]
    //     0xbf784c: add             x2, x2, HEAP, lsl #32
    //     0xbf7850: stur            x2, [fp, #-0x58]
    // 0xbf7854: CheckStackOverflow
    //     0xbf7854: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf7858: cmp             SP, x16
    //     0xbf785c: b.ls            #0xbf7938
    // 0xbf7860: InitAsync() -> Future<Null?>
    //     0xbf7860: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xbf7864: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbf7868: ldur            x1, [fp, #-0x58]
    // 0xbf786c: LoadField: r2 = r1->field_1f
    //     0xbf786c: ldur            w2, [x1, #0x1f]
    // 0xbf7870: DecompressPointer r2
    //     0xbf7870: add             x2, x2, HEAP, lsl #32
    // 0xbf7874: mov             x0, x2
    // 0xbf7878: stur            x2, [fp, #-0x60]
    // 0xbf787c: r0 = Await()
    //     0xbf787c: bl              #0xb0c534  ; AwaitStub
    // 0xbf7880: ldur            x0, [fp, #-0x58]
    // 0xbf7884: b               #0xbf7890
    // 0xbf7888: sub             SP, fp, #0x68
    // 0xbf788c: ldur            x0, [fp, #-0x20]
    // 0xbf7890: stur            x0, [fp, #-0x68]
    // 0xbf7894: LoadField: r1 = r0->field_f
    //     0xbf7894: ldur            w1, [x0, #0xf]
    // 0xbf7898: DecompressPointer r1
    //     0xbf7898: add             x1, x1, HEAP, lsl #32
    // 0xbf789c: LoadField: r2 = r0->field_13
    //     0xbf789c: ldur            w2, [x0, #0x13]
    // 0xbf78a0: DecompressPointer r2
    //     0xbf78a0: add             x2, x2, HEAP, lsl #32
    // 0xbf78a4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xbf78a4: ldur            w3, [x0, #0x17]
    // 0xbf78a8: DecompressPointer r3
    //     0xbf78a8: add             x3, x3, HEAP, lsl #32
    // 0xbf78ac: LoadField: r4 = r1->field_27
    //     0xbf78ac: ldur            w4, [x1, #0x27]
    // 0xbf78b0: DecompressPointer r4
    //     0xbf78b0: add             x4, x4, HEAP, lsl #32
    // 0xbf78b4: cmp             w4, w2
    // 0xbf78b8: b.ne            #0xbf7930
    // 0xbf78bc: LoadField: r4 = r2->field_7
    //     0xbf78bc: ldur            x4, [x2, #7]
    // 0xbf78c0: ArrayLoad: r2 = r1[0]  ; List_8
    //     0xbf78c0: ldur            x2, [x1, #0x17]
    // 0xbf78c4: cmp             x4, x2
    // 0xbf78c8: b.ne            #0xbf7930
    // 0xbf78cc: LoadField: r2 = r1->field_1f
    //     0xbf78cc: ldur            x2, [x1, #0x1f]
    // 0xbf78d0: r4 = LoadInt32Instr(r3)
    //     0xbf78d0: sbfx            x4, x3, #1, #0x1f
    //     0xbf78d4: tbz             w3, #0, #0xbf78dc
    //     0xbf78d8: ldur            x4, [x3, #7]
    // 0xbf78dc: cmp             x4, x2
    // 0xbf78e0: b.ne            #0xbf7930
    // 0xbf78e4: LoadField: r3 = r1->field_7
    //     0xbf78e4: ldur            w3, [x1, #7]
    // 0xbf78e8: DecompressPointer r3
    //     0xbf78e8: add             x3, x3, HEAP, lsl #32
    // 0xbf78ec: stur            x3, [fp, #-0x60]
    // 0xbf78f0: LoadField: r4 = r0->field_1b
    //     0xbf78f0: ldur            w4, [x0, #0x1b]
    // 0xbf78f4: DecompressPointer r4
    //     0xbf78f4: add             x4, x4, HEAP, lsl #32
    // 0xbf78f8: mov             x2, x0
    // 0xbf78fc: stur            x4, [fp, #-0x58]
    // 0xbf7900: r1 = Function '<anonymous closure>':.
    //     0xbf7900: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d5f0] AnonymousClosure: (0x78b01c), in [Qan] wUa::<anonymous closure> (0xbf7828)
    //     0xbf7904: ldr             x1, [x1, #0x5f0]
    // 0xbf7908: r0 = AllocateClosure()
    //     0xbf7908: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xbf790c: ldur            x1, [fp, #-0x60]
    // 0xbf7910: ldur            x2, [fp, #-0x58]
    // 0xbf7914: mov             x3, x0
    // 0xbf7918: r0 = __unknown_function__()
    //     0xbf7918: bl              #0xbf7940  ; [] ::__unknown_function__
    // 0xbf791c: mov             x1, x0
    // 0xbf7920: stur            x1, [fp, #-0x58]
    // 0xbf7924: r0 = Await()
    //     0xbf7924: bl              #0xb0c534  ; AwaitStub
    // 0xbf7928: r0 = Null
    //     0xbf7928: mov             x0, NULL
    // 0xbf792c: r0 = ReturnAsyncNotFuture()
    //     0xbf792c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf7930: r0 = Null
    //     0xbf7930: mov             x0, NULL
    // 0xbf7934: r0 = ReturnAsyncNotFuture()
    //     0xbf7934: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf7938: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7938: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf793c: b               #0xbf7860
  }
  [closure] Future<_yUa?> <anonymous closure>(dynamic) async {
    // ** addr: 0xbfb7a8, size: 0xc8
    // 0xbfb7a8: EnterFrame
    //     0xbfb7a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb7ac: mov             fp, SP
    // 0xbfb7b0: AllocStack(0x58)
    //     0xbfb7b0: sub             SP, SP, #0x58
    // 0xbfb7b4: SetupParameters(wUa this /* r1, fp-0x58 */)
    //     0xbfb7b4: stur            NULL, [fp, #-8]
    //     0xbfb7b8: movz            x0, #0
    //     0xbfb7bc: add             x1, fp, w0, sxtw #2
    //     0xbfb7c0: ldr             x1, [x1, #0x10]
    //     0xbfb7c4: stur            x1, [fp, #-0x58]
    //     0xbfb7c8: ldur            w2, [x1, #0x17]
    //     0xbfb7cc: add             x2, x2, HEAP, lsl #32
    //     0xbfb7d0: stur            x2, [fp, #-0x50]
    // 0xbfb7d4: CheckStackOverflow
    //     0xbfb7d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb7d8: cmp             SP, x16
    //     0xbfb7dc: b.ls            #0xbfb868
    // 0xbfb7e0: InitAsync() -> Future<_yUa?>
    //     0xbfb7e0: add             x0, PP, #0x28, lsl #12  ; [pp+0x28b68] TypeArguments: <_yUa?>
    //     0xbfb7e4: ldr             x0, [x0, #0xb68]
    //     0xbfb7e8: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbfb7ec: ldur            x1, [fp, #-0x50]
    // 0xbfb7f0: LoadField: r2 = r1->field_1b
    //     0xbfb7f0: ldur            w2, [x1, #0x1b]
    // 0xbfb7f4: DecompressPointer r2
    //     0xbfb7f4: add             x2, x2, HEAP, lsl #32
    // 0xbfb7f8: mov             x0, x2
    // 0xbfb7fc: stur            x2, [fp, #-0x58]
    // 0xbfb800: r0 = Await()
    //     0xbfb800: bl              #0xb0c534  ; AwaitStub
    // 0xbfb804: ldur            x0, [fp, #-0x50]
    // 0xbfb808: b               #0xbfb814
    // 0xbfb80c: sub             SP, fp, #0x58
    // 0xbfb810: ldur            x0, [fp, #-0x20]
    // 0xbfb814: LoadField: r2 = r0->field_13
    //     0xbfb814: ldur            w2, [x0, #0x13]
    // 0xbfb818: DecompressPointer r2
    //     0xbfb818: add             x2, x2, HEAP, lsl #32
    // 0xbfb81c: LoadField: r1 = r2->field_7
    //     0xbfb81c: ldur            x1, [x2, #7]
    // 0xbfb820: LoadField: r3 = r0->field_f
    //     0xbfb820: ldur            w3, [x0, #0xf]
    // 0xbfb824: DecompressPointer r3
    //     0xbfb824: add             x3, x3, HEAP, lsl #32
    // 0xbfb828: ArrayLoad: r4 = r3[0]  ; List_8
    //     0xbfb828: ldur            x4, [x3, #0x17]
    // 0xbfb82c: cmp             x1, x4
    // 0xbfb830: b.ne            #0xbfb844
    // 0xbfb834: LoadField: r1 = r3->field_27
    //     0xbfb834: ldur            w1, [x3, #0x27]
    // 0xbfb838: DecompressPointer r1
    //     0xbfb838: add             x1, x1, HEAP, lsl #32
    // 0xbfb83c: cmp             w1, w2
    // 0xbfb840: b.eq            #0xbfb84c
    // 0xbfb844: r0 = Null
    //     0xbfb844: mov             x0, NULL
    // 0xbfb848: r0 = ReturnAsyncNotFuture()
    //     0xbfb848: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbfb84c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbfb84c: ldur            w1, [x0, #0x17]
    // 0xbfb850: DecompressPointer r1
    //     0xbfb850: add             x1, x1, HEAP, lsl #32
    // 0xbfb854: mov             x16, x1
    // 0xbfb858: mov             x1, x3
    // 0xbfb85c: mov             x3, x16
    // 0xbfb860: r0 = __unknown_function__()
    //     0xbfb860: bl              #0xbfb870  ; [] ::__unknown_function__
    // 0xbfb864: r0 = ReturnAsync()
    //     0xbfb864: b               #0xb13694  ; ReturnAsyncStub
    // 0xbfb868: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb868: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb86c: b               #0xbfb7e0
  }
  [closure] bool BGd(dynamic) {
    // ** addr: 0x78b270, size: -0x1
  }
  [closure] Future<DUa> <anonymous closure>(dynamic) {
    // ** addr: 0x78b188, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic, Object, ua) {
    // ** addr: 0x78aa80, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic) {
    // ** addr: 0x78b01c, size: -0x1
  }
}

// class id: 7146, size: 0x14, field offset: 0x14
enum vUa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
