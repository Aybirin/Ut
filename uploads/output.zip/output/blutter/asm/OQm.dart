// lib: , url: OQm

// class id: 1049201, size: 0x8
class :: {
}

// class id: 2763, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class ona extends Object {
}

// class id: 2764, size: 0xc, field offset: 0xc
//   const constructor, 
class Mna extends ona {

  _OneByteString field_8;
}

// class id: 2765, size: 0xc, field offset: 0xc
//   const constructor, 
class Lna extends ona {

  _OneByteString field_8;
}

// class id: 2766, size: 0xc, field offset: 0xc
//   const constructor, 
class Kna extends ona {

  _OneByteString field_8;
}

// class id: 2767, size: 0x10, field offset: 0xc
//   const constructor, 
class Jna extends ona {
}

// class id: 2768, size: 0x18, field offset: 0xc
//   const constructor, 
class Ina extends ona {
}

// class id: 7238, size: 0x14, field offset: 0x14
enum Hna extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
