// lib: , url: vkn

// class id: 1050058, size: 0x8
class :: {
}

// class id: 5897, size: 0x8, field offset: 0x8
abstract class pjb extends Ez {

  static late pjb _UMc; // offset: 0x18ac
  static late final Object _Hcd; // offset: 0x18a8
}
