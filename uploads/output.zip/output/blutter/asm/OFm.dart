// lib: , url: OFm

// class id: 1048700, size: 0x8
class :: {
}

// class id: 6019, size: 0x78, field offset: 0x8
//   const constructor, 
class vy extends Object {
}

// class id: 6020, size: 0xa4, field offset: 0x8
class uy extends Object {

  static late final uy ZLc; // offset: 0xd8c
}
