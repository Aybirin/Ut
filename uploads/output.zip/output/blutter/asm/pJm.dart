// lib: , url: pJm

// class id: 1048872, size: 0x8
class :: {
}

// class id: 5475, size: 0xc, field offset: 0x8
//   const constructor, 
class LH extends Object {

  [closure] void <anonymous closure>(dynamic, JH, KH) {
    // ** addr: 0x42deb8, size: -0x1
  }
}

// class id: 5476, size: 0x10, field offset: 0x8
//   const constructor, 
class KH extends Object {

  bool field_8;
  _OneByteString field_c;
}

// class id: 5477, size: 0xc, field offset: 0x8
//   const constructor, 
class JH extends Object {

  _OneByteString field_8;
}
