// lib: , url: vfn

// class id: 1049825, size: 0x8
class :: {
}

// class id: 1520, size: 0x1c, field offset: 0x1c
abstract class Ydb extends Jdb {
}

// class id: 1525, size: 0x30, field offset: 0x1c
class Zdb extends Ldb
    implements Ydb {
}
