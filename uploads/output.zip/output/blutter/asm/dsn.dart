// lib: , url: dsn

// class id: 1050408, size: 0x8
class :: {
}

// class id: 753, size: 0x28, field offset: 0x8
class jvb extends Object
    implements Ja {

  [closure] String <anonymous closure>(dynamic, Object?) {
    // ** addr: 0x917990, size: -0x1
  }
}
