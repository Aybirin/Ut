// lib: , url: FHm

// class id: 1048786, size: 0x8
class :: {
}

// class id: 5773, size: 0x10, field offset: 0x8
class XB extends Object
    implements WB {

  [closure] Future<void> gze(dynamic, {Ea? Tbc, rM? eLd}) {
    // ** addr: 0x7524a0, size: -0x1
  }
  [closure] Future<void> fze(dynamic, {Ea? Tbc, rM? eLd}) {
    // ** addr: 0x752250, size: -0x1
  }
}

// class id: 5774, size: 0x8, field offset: 0x8
abstract class WB extends Object {
}
