// lib: , url: Ren

// class id: 1049795, size: 0x8
class :: {
}

// class id: 7514, size: 0x18, field offset: 0xc
class Ucb extends Iterable<dynamic>
    implements Lr {

  late int data; // offset: 0x14

  const int length(Ucb) {
    // ** addr: 0xbae77c, size: 0x48
    // 0xbae77c: ldr             x2, [SP]
    // 0xbae780: LoadField: r3 = r2->field_b
    //     0xbae780: ldur            x3, [x2, #0xb]
    // 0xbae784: r0 = BoxInt64Instr(r3)
    //     0xbae784: sbfiz           x0, x3, #1, #0x1f
    //     0xbae788: cmp             x3, x0, asr #1
    //     0xbae78c: b.eq            #0xbae7a8
    //     0xbae790: stp             fp, lr, [SP, #-0x10]!
    //     0xbae794: mov             fp, SP
    //     0xbae798: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbae79c: mov             SP, fp
    //     0xbae7a0: ldp             fp, lr, [SP], #0x10
    //     0xbae7a4: stur            x3, [x0, #7]
    // 0xbae7a8: ret
    //     0xbae7a8: ret             
  }
  num [](Ucb, int) {
    // ** addr: 0xbdc154, size: 0xa4
    // 0xbdc154: EnterFrame
    //     0xbdc154: stp             fp, lr, [SP, #-0x10]!
    //     0xbdc158: mov             fp, SP
    // 0xbdc15c: CheckStackOverflow
    //     0xbdc15c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdc160: cmp             SP, x16
    //     0xbdc164: b.ls            #0xbdc1d8
    // 0xbdc168: ldr             x0, [fp, #0x10]
    // 0xbdc16c: r2 = Null
    //     0xbdc16c: mov             x2, NULL
    // 0xbdc170: r1 = Null
    //     0xbdc170: mov             x1, NULL
    // 0xbdc174: branchIfSmi(r0, 0xbdc19c)
    //     0xbdc174: tbz             w0, #0, #0xbdc19c
    // 0xbdc178: r4 = LoadClassIdInstr(r0)
    //     0xbdc178: ldur            x4, [x0, #-1]
    //     0xbdc17c: ubfx            x4, x4, #0xc, #0x14
    // 0xbdc180: sub             x4, x4, #0x3c
    // 0xbdc184: cmp             x4, #1
    // 0xbdc188: b.ls            #0xbdc19c
    // 0xbdc18c: r8 = int
    //     0xbdc18c: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xbdc190: r3 = Null
    //     0xbdc190: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3bd50] Null
    //     0xbdc194: ldr             x3, [x3, #0xd50]
    // 0xbdc198: r0 = int()
    //     0xbdc198: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xbdc19c: ldr             x0, [fp, #0x10]
    // 0xbdc1a0: r2 = LoadInt32Instr(r0)
    //     0xbdc1a0: sbfx            x2, x0, #1, #0x1f
    //     0xbdc1a4: tbz             w0, #0, #0xbdc1ac
    //     0xbdc1a8: ldur            x2, [x0, #7]
    // 0xbdc1ac: ldr             x1, [fp, #0x18]
    // 0xbdc1b0: r0 = call 0x70d440
    //     0xbdc1b0: bl              #0x70d440
    // 0xbdc1b4: mov             x2, x0
    // 0xbdc1b8: r0 = BoxInt64Instr(r2)
    //     0xbdc1b8: sbfiz           x0, x2, #1, #0x1f
    //     0xbdc1bc: cmp             x2, x0, asr #1
    //     0xbdc1c0: b.eq            #0xbdc1cc
    //     0xbdc1c4: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbdc1c8: stur            x2, [x0, #7]
    // 0xbdc1cc: LeaveFrame
    //     0xbdc1cc: mov             SP, fp
    //     0xbdc1d0: ldp             fp, lr, [SP], #0x10
    // 0xbdc1d4: ret
    //     0xbdc1d4: ret             
    // 0xbdc1d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdc1d8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdc1dc: b               #0xbdc168
  }
}
