// lib: , url: tIm

// class id: 1048832, size: 0x8
class :: {
}

// class id: 5617, size: 0x10, field offset: 0x8
class yF extends Object {
}
