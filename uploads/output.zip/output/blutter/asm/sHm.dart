// lib: , url: sHm

// class id: 1048773, size: 0x8
class :: {
}

// class id: 5956, size: 0x1c, field offset: 0x8
class HB extends aA {

  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xb98610, size: 0xec
    // 0xb98610: EnterFrame
    //     0xb98610: stp             fp, lr, [SP, #-0x10]!
    //     0xb98614: mov             fp, SP
    // 0xb98618: AllocStack(0x40)
    //     0xb98618: sub             SP, SP, #0x40
    // 0xb9861c: SetupParameters([dynamic _ /* r0 */])
    //     0xb9861c: ldr             x0, [fp, #0x18]
    //     0xb98620: ldur            w1, [x0, #0x17]
    //     0xb98624: add             x1, x1, HEAP, lsl #32
    // 0xb98628: CheckStackOverflow
    //     0xb98628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb9862c: cmp             SP, x16
    //     0xb98630: b.ls            #0xb986f0
    // 0xb98634: LoadField: r0 = r1->field_f
    //     0xb98634: ldur            w0, [x1, #0xf]
    // 0xb98638: DecompressPointer r0
    //     0xb98638: add             x0, x0, HEAP, lsl #32
    // 0xb9863c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xb9863c: ldur            w3, [x0, #0x17]
    // 0xb98640: DecompressPointer r3
    //     0xb98640: add             x3, x3, HEAP, lsl #32
    // 0xb98644: stur            x3, [fp, #-0x38]
    // 0xb98648: cmp             w3, NULL
    // 0xb9864c: b.eq            #0xb986f8
    // 0xb98650: ldr             x0, [fp, #0x10]
    // 0xb98654: r2 = Null
    //     0xb98654: mov             x2, NULL
    // 0xb98658: r1 = Null
    //     0xb98658: mov             x1, NULL
    // 0xb9865c: r8 = Map
    //     0xb9865c: ldr             x8, [PP, #0x200]  ; [pp+0x200] Type: Map
    // 0xb98660: r3 = Null
    //     0xb98660: add             x3, PP, #0x3a, lsl #12  ; [pp+0x3a998] Null
    //     0xb98664: ldr             x3, [x3, #0x998]
    // 0xb98668: r0 = Map()
    //     0xb98668: bl              #0xc5c180  ; IsType_Map_Stub
    // 0xb9866c: ldr             x1, [fp, #0x10]
    // 0xb98670: r0 = call 0x4ac978
    //     0xb98670: bl              #0x4ac978
    // 0xb98674: ldur            x1, [fp, #-0x38]
    // 0xb98678: mov             x2, x0
    // 0xb9867c: r0 = call 0x377920
    //     0xb9867c: bl              #0x377920
    // 0xb98680: r0 = Null
    //     0xb98680: mov             x0, NULL
    // 0xb98684: LeaveFrame
    //     0xb98684: mov             SP, fp
    //     0xb98688: ldp             fp, lr, [SP], #0x10
    // 0xb9868c: ret
    //     0xb9868c: ret             
    // 0xb98690: sub             SP, fp, #0x40
    // 0xb98694: r2 = 60
    //     0xb98694: movz            x2, #0x3c
    // 0xb98698: branchIfSmi(r0, 0xb986a4)
    //     0xb98698: tbz             w0, #0, #0xb986a4
    // 0xb9869c: r2 = LoadClassIdInstr(r0)
    //     0xb9869c: ldur            x2, [x0, #-1]
    //     0xb986a0: ubfx            x2, x2, #0xc, #0x14
    // 0xb986a4: cmp             x2, #0xaaf
    // 0xb986a8: b.ne            #0xb986e8
    // 0xb986ac: LoadField: r1 = r0->field_7
    //     0xb986ac: ldur            w1, [x0, #7]
    // 0xb986b0: DecompressPointer r1
    //     0xb986b0: add             x1, x1, HEAP, lsl #32
    // 0xb986b4: stur            x1, [fp, #-0x40]
    // 0xb986b8: LoadField: r2 = r0->field_b
    //     0xb986b8: ldur            w2, [x0, #0xb]
    // 0xb986bc: DecompressPointer r2
    //     0xb986bc: add             x2, x2, HEAP, lsl #32
    // 0xb986c0: stur            x2, [fp, #-0x38]
    // 0xb986c4: r0 = LB()
    //     0xb986c4: bl              #0xb81210  ; AllocateLBStub -> LB (size=0x10)
    // 0xb986c8: mov             x1, x0
    // 0xb986cc: ldur            x0, [fp, #-0x40]
    // 0xb986d0: StoreField: r1->field_7 = r0
    //     0xb986d0: stur            w0, [x1, #7]
    // 0xb986d4: ldur            x0, [fp, #-0x38]
    // 0xb986d8: StoreField: r1->field_b = r0
    //     0xb986d8: stur            w0, [x1, #0xb]
    // 0xb986dc: mov             x0, x1
    // 0xb986e0: r0 = Throw()
    //     0xb986e0: bl              #0xc53a04  ; ThrowStub
    // 0xb986e4: brk             #0
    // 0xb986e8: r0 = ReThrow()
    //     0xb986e8: bl              #0xc539d8  ; ReThrowStub
    // 0xb986ec: brk             #0
    // 0xb986f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb986f0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb986f4: b               #0xb98634
    // 0xb986f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb986f8: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, MethodCall) {
    // ** addr: 0x465f70, size: -0x1
  }
  [closure] void _zQg(dynamic) {
    // ** addr: 0x4ac89c, size: -0x1
  }
  [closure] void _CQg(dynamic) {
    // ** addr: 0x4662c0, size: -0x1
  }
  [closure] void _qed(dynamic) {
    // ** addr: 0x466288, size: -0x1
  }
  [closure] MethodChannel <anonymous closure>(dynamic) {
    // ** addr: 0x9c579c, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic, AB) {
    // ** addr: 0x9c5750, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic, Object, ua) {
    // ** addr: 0x9c569c, size: -0x1
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, MethodCall) {
    // ** addr: 0x9c5848, size: -0x1
  }
  [closure] KB <anonymous closure>(dynamic, Map<dynamic, dynamic>) {
    // ** addr: 0x9c8c68, size: -0x1
  }
}
