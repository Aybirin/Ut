// lib: , url: tkn

// class id: 1050056, size: 0x8
class :: {
}

// class id: 5898, size: 0x8, field offset: 0x8
class ojb extends pjb {
}
