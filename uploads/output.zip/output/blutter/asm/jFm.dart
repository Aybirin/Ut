// lib: , url: jFm

// class id: 1048671, size: 0x8
class :: {
}

// class id: 6046, size: 0x5c, field offset: 0x8
class Ux extends Object {

  late final Map<String, dynamic> _Atg; // offset: 0x58
  late final String Smc; // offset: 0xc

  Map<String, dynamic> Gxc(Ux) {
    // ** addr: 0xbbafb4, size: 0x48
    // 0xbbafb4: EnterFrame
    //     0xbbafb4: stp             fp, lr, [SP, #-0x10]!
    //     0xbbafb8: mov             fp, SP
    // 0xbbafbc: CheckStackOverflow
    //     0xbbafbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbbafc0: cmp             SP, x16
    //     0xbbafc4: b.ls            #0xbbafdc
    // 0xbbafc8: ldr             x1, [fp, #0x10]
    // 0xbbafcc: r0 = call 0x651bbc
    //     0xbbafcc: bl              #0x651bbc
    // 0xbbafd0: LeaveFrame
    //     0xbbafd0: mov             SP, fp
    //     0xbbafd4: ldp             fp, lr, [SP], #0x10
    // 0xbbafd8: ret
    //     0xbbafd8: ret             
    // 0xbbafdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbafdc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbafe0: b               #0xbbafc8
  }
}
