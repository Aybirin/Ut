// lib: , url: fKm

// class id: 1048890, size: 0x8
class :: {

  [closure] static Future<Y1> <anonymous closure>(dynamic, Y0) {
    // ** addr: 0x6c8918, size: -0x1
  }
  [closure] static FutureOr<Y1> <anonymous closure>(dynamic) {
    // ** addr: 0x3e0b48, size: -0x1
  }
}
