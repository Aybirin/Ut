// lib: , url: hHm

// class id: 1048762, size: 0x8
class :: {
}

// class id: 4889, size: 0x14, field offset: 0xc
//   const constructor, 
class Yz extends Zu {

  [closure] kA <anonymous closure>(dynamic, iva, Object?, Mca?) {
    // ** addr: 0x84030c, size: -0x1
  }
}
