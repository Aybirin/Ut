// lib: , url: Cwn

// class id: 1050636, size: 0x8
class :: {
}

// class id: 421, size: 0x8, field offset: 0x8
abstract class LCb extends Object {

  static late final Tz<BTa> FPh; // offset: 0x1be0
  static late final Tz<int> yRj; // offset: 0x1bdc
  static late final Tz<int> EZh; // offset: 0x1bd8
  static late final MCb IRj; // offset: 0x1c08
  static late final Tz<int> BRj; // offset: 0x1bec
  static late final Tz<int> ARj; // offset: 0x1be8
  static late final MCb HRj; // offset: 0x1c04
  static late final MCb GRj; // offset: 0x1c00
  static late final MCb FRj; // offset: 0x1bfc
  static late final Tz<yWa?> ERj; // offset: 0x1bf8
  static late final Tz<({ZVa vm, qWa? ASb})?> DRj; // offset: 0x1bf4
  static late final Tz<({ZVa vm, qWa? ASb})?> CRj; // offset: 0x1bf0
  static late final Tz<int> zRj; // offset: 0x1be4
  static late final List<int> _KRj; // offset: 0x1c10
  static late final Tz<int?> JRj; // offset: 0x1c0c
}

// class id: 6136, size: 0x24, field offset: 0x24
class MCb extends Tu {
}
