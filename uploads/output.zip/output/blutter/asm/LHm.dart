// lib: , url: LHm

// class id: 1048791, size: 0x8
class :: {
}

// class id: 5769, size: 0x8, field offset: 0x8
abstract class kC extends Object
    implements ja<X0> {
}

// class id: 5770, size: 0x8, field offset: 0x8
abstract class jC extends Object
    implements Iterable<X0> {
}
