// lib: , url: Xvn

// class id: 1050603, size: 0x8
class :: {
}

// class id: 441, size: 0xc, field offset: 0x8
class HBb extends Object {
}
