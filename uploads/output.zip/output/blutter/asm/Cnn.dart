// lib: UDn, url: Cnn

// class id: 1050199, size: 0x8
class :: {
}

// class id: 994, size: 0xc, field offset: 0xc
class job extends hnb {

  static late final fqb GEg; // offset: 0x1028

  [closure] static job <anonymous closure>(dynamic) {
    // ** addr: 0x40dcb8, size: -0x1
  }
  [closure] static job _VJg(dynamic, String, enb, dnb, za, za, List<int>) {
    // ** addr: 0x40ddd0, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40dc60, size: -0x1
  }
}
