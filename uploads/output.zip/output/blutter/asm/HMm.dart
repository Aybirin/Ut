// lib: , url: HMm

// class id: 1048992, size: 0x8
class :: {
}

// class id: 3445, size: 0x4c, field offset: 0x24
//   transformed mixin,
abstract class _eU extends cT
     with _dU {
}

// class id: 3446, size: 0xac, field offset: 0x4c
abstract class fU extends _eU {

  late NT _Koe; // offset: 0x94
  late double _IGe; // offset: 0x98
  late double _cif; // offset: 0x9c

  [closure] void PJd(dynamic, VQ) {
    // ** addr: 0x949238, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5b1bec, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x88efd4, size: -0x1
  }
}

// class id: 3448, size: 0xac, field offset: 0xac
class gU extends fU {
}

// class id: 3449, size: 0x24, field offset: 0x24
abstract class _dU extends cT {
}

// class id: 3858, size: 0x10, field offset: 0x8
class cU extends _FM {
}

// class id: 3859, size: 0x1c, field offset: 0x8
class bU extends _FM {
}

// class id: 3860, size: 0x18, field offset: 0x8
class aU extends _FM {
}

// class id: 3861, size: 0x18, field offset: 0x8
class ZT extends _FM {
}

// class id: 3862, size: 0x18, field offset: 0x8
class YT extends _FM {
}

// class id: 7319, size: 0x14, field offset: 0x14
enum _wT extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
