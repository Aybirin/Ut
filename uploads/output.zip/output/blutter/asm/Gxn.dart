// lib: , url: Gxn

// class id: 1050691, size: 0x8
class :: {
}

// class id: 4722, size: 0x18, field offset: 0xc
//   const constructor, 
class fGb extends Zu {
}
