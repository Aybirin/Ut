// lib: , url: Uon

// class id: 1050270, size: 0x8
class :: {
}

// class id: 905, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Iqb<X0> extends Object {
}

// class id: 906, size: 0xc, field offset: 0xc
//   const constructor, 
class Jqb<X0> extends Iqb<X0> {
}
