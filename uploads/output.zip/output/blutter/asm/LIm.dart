// lib: , url: LIm

// class id: 1048849, size: 0x8
class :: {

  [closure] static void <anonymous closure>(dynamic, Y0, Jb<Uint8List>) {
    // ** addr: 0x3fb660, size: -0x1
  }
}
