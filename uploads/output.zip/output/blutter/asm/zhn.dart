// lib: , url: zhn

// class id: 1049937, size: 0x8
class :: {
}

// class id: 7478, size: 0xc, field offset: 0xc
class fhb extends Iterable<dynamic>
    implements tgb {

  static late final Ggb TNh; // offset: 0x14a4

  int length(fhb) {
    // ** addr: 0xc4fcf8, size: 0x20
    // 0xc4fcf8: r0 = 0
    //     0xc4fcf8: movz            x0, #0
    // 0xc4fcfc: ret
    //     0xc4fcfc: ret             
  }
  num [](fhb, int) {
    // ** addr: 0xbd5600, size: 0x64
    // 0xbd5600: EnterFrame
    //     0xbd5600: stp             fp, lr, [SP, #-0x10]!
    //     0xbd5604: mov             fp, SP
    // 0xbd5608: ldr             x0, [fp, #0x10]
    // 0xbd560c: r2 = Null
    //     0xbd560c: mov             x2, NULL
    // 0xbd5610: r1 = Null
    //     0xbd5610: mov             x1, NULL
    // 0xbd5614: branchIfSmi(r0, 0xbd563c)
    //     0xbd5614: tbz             w0, #0, #0xbd563c
    // 0xbd5618: r4 = LoadClassIdInstr(r0)
    //     0xbd5618: ldur            x4, [x0, #-1]
    //     0xbd561c: ubfx            x4, x4, #0xc, #0x14
    // 0xbd5620: sub             x4, x4, #0x3c
    // 0xbd5624: cmp             x4, #1
    // 0xbd5628: b.ls            #0xbd563c
    // 0xbd562c: r8 = int
    //     0xbd562c: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xbd5630: r3 = Null
    //     0xbd5630: add             x3, PP, #0x32, lsl #12  ; [pp+0x32ec0] Null
    //     0xbd5634: ldr             x3, [x3, #0xec0]
    // 0xbd5638: r0 = int()
    //     0xbd5638: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xbd563c: r0 = 0
    //     0xbd563c: movz            x0, #0
    // 0xbd5640: LeaveFrame
    //     0xbd5640: mov             SP, fp
    //     0xbd5644: ldp             fp, lr, [SP], #0x10
    // 0xbd5648: ret
    //     0xbd5648: ret             
  }
}
