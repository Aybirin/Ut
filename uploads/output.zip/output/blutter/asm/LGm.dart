// lib: , url: LGm

// class id: 1048749, size: 0x8
class :: {
}

// class id: 5969, size: 0x10, field offset: 0x10
class _Az<X0> extends qz<X0> {

  [closure] Null <anonymous closure>(dynamic, dynamic, ua) {
    // ** addr: 0x9a6710, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x9a67bc, size: -0x1
  }
}

// class id: 6917, size: 0x10, field offset: 0xc
class zz<X0> extends Stream<X0> {
}
