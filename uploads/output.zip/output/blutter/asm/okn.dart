// lib: , url: okn

// class id: 1050051, size: 0x8
class :: {
}

// class id: 1160, size: 0xc, field offset: 0x8
class WJ extends Object {

  [closure] Future<Y0> YPk(dynamic) {
    // ** addr: 0xaa90d8, size: -0x1
  }
  [closure] Future<Y0> <anonymous closure>(dynamic, void) {
    // ** addr: 0xaa9020, size: -0x1
  }
}
