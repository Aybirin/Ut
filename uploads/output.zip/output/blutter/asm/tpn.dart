// lib: , url: tpn

// class id: 1050295, size: 0x8
class :: {
}

// class id: 876, size: 0x14, field offset: 0x8
//   const constructor, 
class trb extends srb {

  Lr field_8;
  _Double field_c;
}
