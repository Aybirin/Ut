// lib: , url: nln

// class id: 1050099, size: 0x8
class :: {

  [closure] static okb Wdj(dynamic, Iterable<skb>) {
    // ** addr: 0x5b9f94, size: -0x1
  }
  [closure] static int <anonymous closure>(dynamic, skb, skb) {
    // ** addr: 0x5ba91c, size: -0x1
  }
  [closure] static int <anonymous closure>(dynamic, int, skb) {
    // ** addr: 0x5ba8cc, size: -0x1
  }
}
