// lib: , url: IZm

// class id: 1049575, size: 0x8
class :: {
}

// class id: 5909, size: 0x8, field offset: 0x8
abstract class WLa extends XLa {
}

// class id: 5912, size: 0xc, field offset: 0x8
class YLa extends WLa {

  [closure] Future<void> _Qed(dynamic, MethodCall) {
    // ** addr: 0xb073fc, size: -0x1
  }
}
