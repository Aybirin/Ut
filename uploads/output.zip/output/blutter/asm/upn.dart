// lib: , url: upn

// class id: 1050296, size: 0x8
class :: {

  static late final bool Gij; // offset: 0x1960
}
