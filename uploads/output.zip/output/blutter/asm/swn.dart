// lib: , url: swn

// class id: 1050626, size: 0x8
class :: {
}

// class id: 4088, size: 0x1c, field offset: 0x14
class _uCb extends Xu<dynamic> {

  [closure] void _gBj(dynamic) {
    // ** addr: 0x7d62a0, size: -0x1
  }
  [closure] void sJc(dynamic) {
    // ** addr: 0x815630, size: -0x1
  }
}

// class id: 5032, size: 0x10, field offset: 0xc
//   const constructor, 
class tCb extends Vu {
}
