// lib: , url: iUm

// class id: 1049369, size: 0x8
class :: {
}

// class id: 2503, size: 0x8, field offset: 0x8
abstract class iGa extends gGa {
}
