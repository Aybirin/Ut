// lib: , url: Srn

// class id: 1050397, size: 0x8
class :: {
}

// class id: 785, size: 0x14, field offset: 0x8
abstract class zub extends Object {
}

// class id: 7050, size: 0x14, field offset: 0x14
enum avb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
