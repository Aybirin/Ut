// lib: , url: Jkn

// class id: 1050072, size: 0x8
class :: {
}

// class id: 1141, size: 0x10, field offset: 0x8
class Njb extends Object {
}

// class id: 5795, size: 0x8, field offset: 0x8
//   const constructor, 
class _iA extends uA {
}

// class id: 7059, size: 0x14, field offset: 0x14
enum Ljb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
