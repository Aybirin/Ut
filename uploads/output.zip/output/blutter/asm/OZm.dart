// lib: , url: OZm

// class id: 1049581, size: 0x8
class :: {
}

// class id: 2259, size: 0xd0, field offset: 0x8
//   const constructor, 
class rMa extends Object {
}
