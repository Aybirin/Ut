// lib: , url: ozn

// class id: 1050778, size: 0x8
class :: {
}

// class id: 4669, size: 0x10, field offset: 0xc
//   const constructor, 
class VJb extends Zu {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x878d70, size: -0x1
  }
}
