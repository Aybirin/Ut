// lib: , url: aIm

// class id: 1048806, size: 0x8
class :: {
}

// class id: 5746, size: 0xc, field offset: 0x8
//   const constructor, transformed mixin,
abstract class _HC<X0> extends Object
     with B<X0> {

  List<X0> +(_HC<X0>, List<X0>) {
    // ** addr: 0xb7f5d0, size: 0x4c
    // 0xb7f5d0: EnterFrame
    //     0xb7f5d0: stp             fp, lr, [SP, #-0x10]!
    //     0xb7f5d4: mov             fp, SP
    // 0xb7f5d8: CheckStackOverflow
    //     0xb7f5d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7f5dc: cmp             SP, x16
    //     0xb7f5e0: b.ls            #0xb7f5fc
    // 0xb7f5e4: ldr             x1, [fp, #0x18]
    // 0xb7f5e8: ldr             x2, [fp, #0x10]
    // 0xb7f5ec: r0 = call 0x396188
    //     0xb7f5ec: bl              #0x396188
    // 0xb7f5f0: LeaveFrame
    //     0xb7f5f0: mov             SP, fp
    //     0xb7f5f4: ldp             fp, lr, [SP], #0x10
    // 0xb7f5f8: ret
    //     0xb7f5f8: ret             
    // 0xb7f5fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7f5fc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7f600: b               #0xb7f5e4
  }
  Iterable<Y0> Lk<Y0>(_HC<X0>, (dynamic, X0) => Y0) {
    // ** addr: 0xb7f604, size: 0x98
    // 0xb7f604: EnterFrame
    //     0xb7f604: stp             fp, lr, [SP, #-0x10]!
    //     0xb7f608: mov             fp, SP
    // 0xb7f60c: AllocStack(0x20)
    //     0xb7f60c: sub             SP, SP, #0x20
    // 0xb7f610: SetupParameters([dynamic _, dynamic _ /* r3 */])
    //     0xb7f610: ldur            w0, [x4, #0xf]
    //     0xb7f614: cbnz            w0, #0xb7f620
    //     0xb7f618: mov             x4, NULL
    //     0xb7f61c: b               #0xb7f630
    //     0xb7f620: ldur            w0, [x4, #0x17]
    //     0xb7f624: add             x1, fp, w0, sxtw #2
    //     0xb7f628: ldr             x1, [x1, #0x10]
    //     0xb7f62c: mov             x4, x1
    //     0xb7f630: ldr             x3, [fp, #0x18]
    //     0xb7f634: stur            x4, [fp, #-8]
    // 0xb7f638: CheckStackOverflow
    //     0xb7f638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7f63c: cmp             SP, x16
    //     0xb7f640: b.ls            #0xb7f694
    // 0xb7f644: LoadField: r2 = r3->field_7
    //     0xb7f644: ldur            w2, [x3, #7]
    // 0xb7f648: DecompressPointer r2
    //     0xb7f648: add             x2, x2, HEAP, lsl #32
    // 0xb7f64c: ldr             x0, [fp, #0x10]
    // 0xb7f650: mov             x1, x4
    // 0xb7f654: r8 = (dynamic this, X0) => Y0
    //     0xb7f654: add             x8, PP, #0x3e, lsl #12  ; [pp+0x3e820] FunctionType: (dynamic this, X0) => Y0
    //     0xb7f658: ldr             x8, [x8, #0x820]
    // 0xb7f65c: LoadField: r9 = r8->field_7
    //     0xb7f65c: ldur            x9, [x8, #7]
    // 0xb7f660: r3 = Null
    //     0xb7f660: add             x3, PP, #0x3e, lsl #12  ; [pp+0x3e828] Null
    //     0xb7f664: ldr             x3, [x3, #0x828]
    // 0xb7f668: blr             x9
    // 0xb7f66c: ldur            x16, [fp, #-8]
    // 0xb7f670: ldr             lr, [fp, #0x18]
    // 0xb7f674: stp             lr, x16, [SP, #8]
    // 0xb7f678: ldr             x16, [fp, #0x10]
    // 0xb7f67c: str             x16, [SP]
    // 0xb7f680: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb7f680: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb7f684: r0 = call 0x5aa1e8
    //     0xb7f684: bl              #0x5aa1e8
    // 0xb7f688: LeaveFrame
    //     0xb7f688: mov             SP, fp
    //     0xb7f68c: ldp             fp, lr, [SP], #0x10
    // 0xb7f690: ret
    //     0xb7f690: ret             
    // 0xb7f694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7f694: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7f698: b               #0xb7f644
  }
  void gk(_HC<X0>, (dynamic, X0) => void) {
    // ** addr: 0xb7f6b4, size: 0x78
    // 0xb7f6b4: EnterFrame
    //     0xb7f6b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb7f6b8: mov             fp, SP
    // 0xb7f6bc: CheckStackOverflow
    //     0xb7f6bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7f6c0: cmp             SP, x16
    //     0xb7f6c4: b.ls            #0xb7f70c
    // 0xb7f6c8: ldr             x3, [fp, #0x18]
    // 0xb7f6cc: LoadField: r2 = r3->field_7
    //     0xb7f6cc: ldur            w2, [x3, #7]
    // 0xb7f6d0: DecompressPointer r2
    //     0xb7f6d0: add             x2, x2, HEAP, lsl #32
    // 0xb7f6d4: ldr             x0, [fp, #0x10]
    // 0xb7f6d8: r1 = Null
    //     0xb7f6d8: mov             x1, NULL
    // 0xb7f6dc: r8 = (dynamic this, X0) => void?
    //     0xb7f6dc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb8f0] FunctionType: (dynamic this, X0) => void?
    //     0xb7f6e0: ldr             x8, [x8, #0x8f0]
    // 0xb7f6e4: LoadField: r9 = r8->field_7
    //     0xb7f6e4: ldur            x9, [x8, #7]
    // 0xb7f6e8: r3 = Null
    //     0xb7f6e8: add             x3, PP, #0x35, lsl #12  ; [pp+0x35458] Null
    //     0xb7f6ec: ldr             x3, [x3, #0x458]
    // 0xb7f6f0: blr             x9
    // 0xb7f6f4: ldr             x1, [fp, #0x18]
    // 0xb7f6f8: ldr             x2, [fp, #0x10]
    // 0xb7f6fc: r0 = call 0x588b10
    //     0xb7f6fc: bl              #0x588b10
    // 0xb7f700: LeaveFrame
    //     0xb7f700: mov             SP, fp
    //     0xb7f704: ldp             fp, lr, [SP], #0x10
    // 0xb7f708: ret
    //     0xb7f708: ret             
    // 0xb7f70c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7f70c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7f710: b               #0xb7f6c8
  }
  bool dyn:get:isEmpty(_HC<X0>) {
    // ** addr: 0xb7f72c, size: 0x64
    // 0xb7f72c: EnterFrame
    //     0xb7f72c: stp             fp, lr, [SP, #-0x10]!
    //     0xb7f730: mov             fp, SP
    // 0xb7f734: AllocStack(0x8)
    //     0xb7f734: sub             SP, SP, #8
    // 0xb7f738: CheckStackOverflow
    //     0xb7f738: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7f73c: cmp             SP, x16
    //     0xb7f740: b.ls            #0xb7f770
    // 0xb7f744: ldr             x16, [fp, #0x10]
    // 0xb7f748: str             x16, [SP]
    // 0xb7f74c: r0 = length()
    //     0xb7f74c: bl              #0xbae910  ; [aIm] IC::length
    // 0xb7f750: cbz             w0, #0xb7f75c
    // 0xb7f754: r1 = false
    //     0xb7f754: add             x1, NULL, #0x30  ; false
    // 0xb7f758: b               #0xb7f760
    // 0xb7f75c: r1 = true
    //     0xb7f75c: add             x1, NULL, #0x20  ; true
    // 0xb7f760: mov             x0, x1
    // 0xb7f764: LeaveFrame
    //     0xb7f764: mov             SP, fp
    //     0xb7f768: ldp             fp, lr, [SP], #0x10
    // 0xb7f76c: ret
    //     0xb7f76c: ret             
    // 0xb7f770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7f770: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7f774: b               #0xb7f744
  }
  [closure] bool Ck(dynamic, Object?) {
    // ** addr: 0x579644, size: -0x1
  }
}

// class id: 5747, size: 0x20, field offset: 0xc
class IC<X0> extends _HC<X0>
    implements se<X0> {

  IC<Y0> Zk<Y0>(IC<X0>) {
    // ** addr: 0xba7e08, size: 0x8c
    // 0xba7e08: EnterFrame
    //     0xba7e08: stp             fp, lr, [SP, #-0x10]!
    //     0xba7e0c: mov             fp, SP
    // 0xba7e10: AllocStack(0x10)
    //     0xba7e10: sub             SP, SP, #0x10
    // 0xba7e14: SetupParameters([dynamic _ /* r0 */])
    //     0xba7e14: ldur            w0, [x4, #0xf]
    //     0xba7e18: cbnz            w0, #0xba7e24
    //     0xba7e1c: mov             x1, NULL
    //     0xba7e20: b               #0xba7e30
    //     0xba7e24: ldur            w0, [x4, #0x17]
    //     0xba7e28: add             x1, fp, w0, sxtw #2
    //     0xba7e2c: ldr             x1, [x1, #0x10]
    //     0xba7e30: ldr             x0, [fp, #0x10]
    // 0xba7e34: CheckStackOverflow
    //     0xba7e34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xba7e38: cmp             SP, x16
    //     0xba7e3c: b.ls            #0xba7e8c
    // 0xba7e40: LoadField: r2 = r0->field_7
    //     0xba7e40: ldur            w2, [x0, #7]
    // 0xba7e44: DecompressPointer r2
    //     0xba7e44: add             x2, x2, HEAP, lsl #32
    // 0xba7e48: r3 = <X0, Y0>
    //     0xba7e48: add             x3, PP, #0x15, lsl #12  ; [pp+0x15638] TypeArguments: <X0, Y0>
    //     0xba7e4c: ldr             x3, [x3, #0x638]
    // 0xba7e50: r0 = Null
    //     0xba7e50: mov             x0, NULL
    // 0xba7e54: cmp             x2, x0
    // 0xba7e58: b.ne            #0xba7e64
    // 0xba7e5c: cmp             x1, x0
    // 0xba7e60: b.eq            #0xba7e70
    // 0xba7e64: r30 = InstantiateTypeArgumentsStub
    //     0xba7e64: ldr             lr, [PP, #0x1f8]  ; [pp+0x1f8] Stub: InstantiateTypeArguments (0x340f10)
    // 0xba7e68: LoadField: r30 = r30->field_7
    //     0xba7e68: ldur            lr, [lr, #7]
    // 0xba7e6c: blr             lr
    // 0xba7e70: ldr             x16, [fp, #0x10]
    // 0xba7e74: stp             x16, x0, [SP]
    // 0xba7e78: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xba7e78: ldr             x4, [PP, #0x19f8]  ; [pp+0x19f8] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xba7e7c: r0 = call 0x58fb28
    //     0xba7e7c: bl              #0x58fb28
    // 0xba7e80: LeaveFrame
    //     0xba7e80: mov             SP, fp
    //     0xba7e84: ldp             fp, lr, [SP], #0x10
    // 0xba7e88: ret
    //     0xba7e88: ret             
    // 0xba7e8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7e8c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7e90: b               #0xba7e40
  }
  int length(IC<X0>) {
    // ** addr: 0xbae910, size: 0x1d0
    // 0xbae910: EnterFrame
    //     0xbae910: stp             fp, lr, [SP, #-0x10]!
    //     0xbae914: mov             fp, SP
    // 0xbae918: AllocStack(0x18)
    //     0xbae918: sub             SP, SP, #0x18
    // 0xbae91c: CheckStackOverflow
    //     0xbae91c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbae920: cmp             SP, x16
    //     0xbae924: b.ls            #0xbaeac0
    // 0xbae928: ldr             x2, [fp, #0x10]
    // 0xbae92c: r3 = LoadClassIdInstr(r2)
    //     0xbae92c: ldur            x3, [x2, #-1]
    //     0xbae930: ubfx            x3, x3, #0xc, #0x14
    // 0xbae934: stur            x3, [fp, #-8]
    // 0xbae938: r17 = 5747
    //     0xbae938: movz            x17, #0x1673
    // 0xbae93c: cmp             x3, x17
    // 0xbae940: b.ne            #0xbae954
    // 0xbae944: ArrayLoad: r0 = r2[0]  ; List_8
    //     0xbae944: ldur            x0, [x2, #0x17]
    // 0xbae948: mov             x2, x0
    // 0xbae94c: mov             x0, x3
    // 0xbae950: b               #0xbae9bc
    // 0xbae954: LoadField: r0 = r2->field_1f
    //     0xbae954: ldur            w0, [x2, #0x1f]
    // 0xbae958: DecompressPointer r0
    //     0xbae958: add             x0, x0, HEAP, lsl #32
    // 0xbae95c: r1 = LoadClassIdInstr(r0)
    //     0xbae95c: ldur            x1, [x0, #-1]
    //     0xbae960: ubfx            x1, x1, #0xc, #0x14
    // 0xbae964: r17 = 5747
    //     0xbae964: movz            x17, #0x1673
    // 0xbae968: cmp             x1, x17
    // 0xbae96c: b.ne            #0xbae97c
    // 0xbae970: ArrayLoad: r1 = r0[0]  ; List_8
    //     0xbae970: ldur            x1, [x0, #0x17]
    // 0xbae974: mov             x0, x1
    // 0xbae978: b               #0xbae9b4
    // 0xbae97c: LoadField: r1 = r0->field_1f
    //     0xbae97c: ldur            w1, [x0, #0x1f]
    // 0xbae980: DecompressPointer r1
    //     0xbae980: add             x1, x1, HEAP, lsl #32
    // 0xbae984: r0 = LoadClassIdInstr(r1)
    //     0xbae984: ldur            x0, [x1, #-1]
    //     0xbae988: ubfx            x0, x0, #0xc, #0x14
    // 0xbae98c: r17 = 5747
    //     0xbae98c: movz            x17, #0x1673
    // 0xbae990: cmp             x0, x17
    // 0xbae994: b.ne            #0xbae9a0
    // 0xbae998: ArrayLoad: r0 = r1[0]  ; List_8
    //     0xbae998: ldur            x0, [x1, #0x17]
    // 0xbae99c: b               #0xbae9b4
    // 0xbae9a0: r0 = LoadClassIdInstr(r1)
    //     0xbae9a0: ldur            x0, [x1, #-1]
    //     0xbae9a4: ubfx            x0, x0, #0xc, #0x14
    // 0xbae9a8: r0 = GDT[cid_x0 + -0xfe7]()
    //     0xbae9a8: sub             lr, x0, #0xfe7
    //     0xbae9ac: ldr             lr, [x21, lr, lsl #3]
    //     0xbae9b0: blr             lr
    // 0xbae9b4: mov             x2, x0
    // 0xbae9b8: ldur            x0, [fp, #-8]
    // 0xbae9bc: stur            x2, [fp, #-0x10]
    // 0xbae9c0: r17 = 5747
    //     0xbae9c0: movz            x17, #0x1673
    // 0xbae9c4: cmp             x0, x17
    // 0xbae9c8: b.ne            #0xbae9e8
    // 0xbae9cc: ldr             x3, [fp, #0x10]
    // 0xbae9d0: LoadField: r0 = r3->field_f
    //     0xbae9d0: ldur            x0, [x3, #0xf]
    // 0xbae9d4: mov             x16, x2
    // 0xbae9d8: mov             x2, x0
    // 0xbae9dc: mov             x0, x16
    // 0xbae9e0: mov             x1, x3
    // 0xbae9e4: b               #0xbaea58
    // 0xbae9e8: ldr             x3, [fp, #0x10]
    // 0xbae9ec: LoadField: r0 = r3->field_1f
    //     0xbae9ec: ldur            w0, [x3, #0x1f]
    // 0xbae9f0: DecompressPointer r0
    //     0xbae9f0: add             x0, x0, HEAP, lsl #32
    // 0xbae9f4: r1 = LoadClassIdInstr(r0)
    //     0xbae9f4: ldur            x1, [x0, #-1]
    //     0xbae9f8: ubfx            x1, x1, #0xc, #0x14
    // 0xbae9fc: r17 = 5747
    //     0xbae9fc: movz            x17, #0x1673
    // 0xbaea00: cmp             x1, x17
    // 0xbaea04: b.ne            #0xbaea14
    // 0xbaea08: LoadField: r1 = r0->field_f
    //     0xbaea08: ldur            x1, [x0, #0xf]
    // 0xbaea0c: mov             x0, x1
    // 0xbaea10: b               #0xbaea4c
    // 0xbaea14: LoadField: r1 = r0->field_1f
    //     0xbaea14: ldur            w1, [x0, #0x1f]
    // 0xbaea18: DecompressPointer r1
    //     0xbaea18: add             x1, x1, HEAP, lsl #32
    // 0xbaea1c: r0 = LoadClassIdInstr(r1)
    //     0xbaea1c: ldur            x0, [x1, #-1]
    //     0xbaea20: ubfx            x0, x0, #0xc, #0x14
    // 0xbaea24: r17 = 5747
    //     0xbaea24: movz            x17, #0x1673
    // 0xbaea28: cmp             x0, x17
    // 0xbaea2c: b.ne            #0xbaea38
    // 0xbaea30: LoadField: r0 = r1->field_f
    //     0xbaea30: ldur            x0, [x1, #0xf]
    // 0xbaea34: b               #0xbaea4c
    // 0xbaea38: r0 = LoadClassIdInstr(r1)
    //     0xbaea38: ldur            x0, [x1, #-1]
    //     0xbaea3c: ubfx            x0, x0, #0xc, #0x14
    // 0xbaea40: r0 = GDT[cid_x0 + -0xfd9]()
    //     0xbaea40: sub             lr, x0, #0xfd9
    //     0xbaea44: ldr             lr, [x21, lr, lsl #3]
    //     0xbaea48: blr             lr
    // 0xbaea4c: mov             x2, x0
    // 0xbaea50: ldr             x1, [fp, #0x10]
    // 0xbaea54: ldur            x0, [fp, #-0x10]
    // 0xbaea58: sub             x3, x0, x2
    // 0xbaea5c: stur            x3, [fp, #-8]
    // 0xbaea60: LoadField: r0 = r1->field_b
    //     0xbaea60: ldur            w0, [x1, #0xb]
    // 0xbaea64: DecompressPointer r0
    //     0xbaea64: add             x0, x0, HEAP, lsl #32
    // 0xbaea68: r1 = LoadClassIdInstr(r0)
    //     0xbaea68: ldur            x1, [x0, #-1]
    //     0xbaea6c: ubfx            x1, x1, #0xc, #0x14
    // 0xbaea70: str             x0, [SP]
    // 0xbaea74: mov             x0, x1
    // 0xbaea78: r0 = GDT[cid_x0 + 0xc99d]()
    //     0xbaea78: movz            x17, #0xc99d
    //     0xbaea7c: add             lr, x0, x17
    //     0xbaea80: ldr             lr, [x21, lr, lsl #3]
    //     0xbaea84: blr             lr
    // 0xbaea88: r2 = LoadInt32Instr(r0)
    //     0xbaea88: sbfx            x2, x0, #1, #0x1f
    //     0xbaea8c: tbz             w0, #0, #0xbaea94
    //     0xbaea90: ldur            x2, [x0, #7]
    // 0xbaea94: sub             x3, x2, #1
    // 0xbaea98: ldur            x2, [fp, #-8]
    // 0xbaea9c: and             x4, x2, x3
    // 0xbaeaa0: r0 = BoxInt64Instr(r4)
    //     0xbaeaa0: sbfiz           x0, x4, #1, #0x1f
    //     0xbaeaa4: cmp             x4, x0, asr #1
    //     0xbaeaa8: b.eq            #0xbaeab4
    //     0xbaeaac: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbaeab0: stur            x4, [x0, #7]
    // 0xbaeab4: LeaveFrame
    //     0xbaeab4: mov             SP, fp
    //     0xbaeab8: ldp             fp, lr, [SP], #0x10
    // 0xbaeabc: ret
    //     0xbaeabc: ret             
    // 0xbaeac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbaeac0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbaeac4: b               #0xbae928
  }
  X0 [](IC<X0>, int) {
    // ** addr: 0xb7f548, size: 0x88
    // 0xb7f548: EnterFrame
    //     0xb7f548: stp             fp, lr, [SP, #-0x10]!
    //     0xb7f54c: mov             fp, SP
    // 0xb7f550: AllocStack(0x10)
    //     0xb7f550: sub             SP, SP, #0x10
    // 0xb7f554: CheckStackOverflow
    //     0xb7f554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7f558: cmp             SP, x16
    //     0xb7f55c: b.ls            #0xb7f5b0
    // 0xb7f560: ldr             x0, [fp, #0x10]
    // 0xb7f564: r2 = Null
    //     0xb7f564: mov             x2, NULL
    // 0xb7f568: r1 = Null
    //     0xb7f568: mov             x1, NULL
    // 0xb7f56c: branchIfSmi(r0, 0xb7f594)
    //     0xb7f56c: tbz             w0, #0, #0xb7f594
    // 0xb7f570: r4 = LoadClassIdInstr(r0)
    //     0xb7f570: ldur            x4, [x0, #-1]
    //     0xb7f574: ubfx            x4, x4, #0xc, #0x14
    // 0xb7f578: sub             x4, x4, #0x3c
    // 0xb7f57c: cmp             x4, #1
    // 0xb7f580: b.ls            #0xb7f594
    // 0xb7f584: r8 = int
    //     0xb7f584: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xb7f588: r3 = Null
    //     0xb7f588: add             x3, PP, #0x15, lsl #12  ; [pp+0x155b8] Null
    //     0xb7f58c: ldr             x3, [x3, #0x5b8]
    // 0xb7f590: r0 = int()
    //     0xb7f590: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xb7f594: ldr             x16, [fp, #0x18]
    // 0xb7f598: ldr             lr, [fp, #0x10]
    // 0xb7f59c: stp             lr, x16, [SP]
    // 0xb7f5a0: r0 = call 0x45e0c0
    //     0xb7f5a0: bl              #0x45e0c0
    // 0xb7f5a4: LeaveFrame
    //     0xb7f5a4: mov             SP, fp
    //     0xb7f5a8: ldp             fp, lr, [SP], #0x10
    // 0xb7f5ac: ret
    //     0xb7f5ac: ret             
    // 0xb7f5b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7f5b0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7f5b4: b               #0xb7f560
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x45c264, size: -0x1
  }
}

// class id: 5748, size: 0x24, field offset: 0x20
class _JC<C1X0, C1X1> extends IC<C1X0> {
}
