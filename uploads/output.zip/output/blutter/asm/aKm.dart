// lib: XDn, url: aKm

// class id: 1050202, size: 0x8
class :: {
}

// class id: 991, size: 0xc, field offset: 0xc
class pob extends hnb {

  static late final fqb GEg; // offset: 0x1034

  [closure] static pob <anonymous closure>(dynamic) {
    // ** addr: 0x40d820, size: -0x1
  }
  [closure] static pob _VJg(dynamic, String, enb, dnb, za, za, List<int>?) {
    // ** addr: 0x40d920, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40d7c8, size: -0x1
  }
}
