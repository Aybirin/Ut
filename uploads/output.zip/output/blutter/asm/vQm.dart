// lib: , url: vQm

// class id: 1049184, size: 0x8
class :: {
}

// class id: 3032, size: 0x64, field offset: 0x54
//   transformed mixin,
abstract class _gma extends Fla
     with Iea<X0 bound Xha, X1 bound Yha> {
}

// class id: 3033, size: 0x64, field offset: 0x64
class hma extends _gma {
}
