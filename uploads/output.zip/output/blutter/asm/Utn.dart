// lib: , url: Utn

// class id: 1050501, size: 0x8
class :: {
}

// class id: 569, size: 0x8, field offset: 0x8
abstract class Xyb extends Object {

  static late final Tz<int> Exj; // offset: 0x1a20

  [closure] static String <anonymous closure>(dynamic) {
    // ** addr: 0x7a38d8, size: -0x1
  }
  [closure] static jKb <anonymous closure>(dynamic, iva) {
    // ** addr: 0x7a38cc, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, String, Map<String, dynamic>) {
    // ** addr: 0x7a3268, size: -0x1
  }
  [closure] static Null <anonymous closure>(dynamic, Gv, Fv) {
    // ** addr: 0x7a3218, size: -0x1
  }
  [closure] static Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x7a3180, size: -0x1
  }
  [closure] static Null <anonymous closure>(dynamic, Object) {
    // ** addr: 0x7a3124, size: -0x1
  }
  [closure] static String? Fxj(dynamic, String) {
    // ** addr: 0x7878e0, size: -0x1
  }
}
