// lib: , url: Zgn

// class id: 1049911, size: 0x8
class :: {
}

// class id: 7492, size: 0x2c, field offset: 0x24
class Ggb extends ugb {

  int length(Ggb) {
    // ** addr: 0xbab254, size: 0x2c
    // 0xbab254: ldr             x1, [SP]
    // 0xbab258: LoadField: r2 = r1->field_23
    //     0xbab258: ldur            w2, [x1, #0x23]
    // 0xbab25c: DecompressPointer r2
    //     0xbab25c: add             x2, x2, HEAP, lsl #32
    // 0xbab260: LoadField: r0 = r2->field_13
    //     0xbab260: ldur            w0, [x2, #0x13]
    // 0xbab264: ret
    //     0xbab264: ret             
  }
}
