// lib: , url: Jgn

// class id: 1049895, size: 0x8
class :: {
}

// class id: 1423, size: 0x48, field offset: 0x8
class ngb extends Object
    implements Cdb {
}

// class id: 1424, size: 0x48, field offset: 0x48
class ogb extends ngb {
}

// class id: 7086, size: 0x14, field offset: 0x14
enum mgb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
