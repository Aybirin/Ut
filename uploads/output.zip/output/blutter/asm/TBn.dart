// lib: , url: TBn

// class id: 1050899, size: 0x8
class :: {
}

// class id: 192, size: 0x14, field offset: 0x8
class qPb extends gPb {
}
