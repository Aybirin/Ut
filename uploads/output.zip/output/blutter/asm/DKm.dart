// lib: kh, url: DKm

// class id: 1048899, size: 0x8
class :: {
}

// class id: 5372, size: 0xc, field offset: 0x8
class aL extends Object {

  static late final S _ydc; // offset: 0xc00

  int dyn:get:length(aL) {
    // ** addr: 0xb36260, size: 0x2c
    // 0xb36260: ldr             x1, [SP]
    // 0xb36264: LoadField: r2 = r1->field_7
    //     0xb36264: ldur            w2, [x1, #7]
    // 0xb36268: DecompressPointer r2
    //     0xb36268: add             x2, x2, HEAP, lsl #32
    // 0xb3626c: LoadField: r0 = r2->field_13
    //     0xb3626c: ldur            w0, [x2, #0x13]
    // 0xb36270: ret
    //     0xb36270: ret             
  }
}

// class id: 5373, size: 0xc, field offset: 0x8
class ZK extends Object {
}

// class id: 5374, size: 0xc, field offset: 0x8
class WK extends Object {

  [closure] String <anonymous closure>(dynamic, int) {
    // ** addr: 0x6b0f54, size: -0x1
  }
}

// class id: 5375, size: 0xc, field offset: 0xc
class YK extends WK {

  int dyn:get:length(YK) {
    // ** addr: 0xb36db8, size: 0x60
    // 0xb36db8: EnterFrame
    //     0xb36db8: stp             fp, lr, [SP, #-0x10]!
    //     0xb36dbc: mov             fp, SP
    // 0xb36dc0: CheckStackOverflow
    //     0xb36dc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb36dc4: cmp             SP, x16
    //     0xb36dc8: b.ls            #0xb36df8
    // 0xb36dcc: ldr             x1, [fp, #0x10]
    // 0xb36dd0: r0 = call 0x428678
    //     0xb36dd0: bl              #0x428678
    // 0xb36dd4: mov             x2, x0
    // 0xb36dd8: r0 = BoxInt64Instr(r2)
    //     0xb36dd8: sbfiz           x0, x2, #1, #0x1f
    //     0xb36ddc: cmp             x2, x0, asr #1
    //     0xb36de0: b.eq            #0xb36dec
    //     0xb36de4: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb36de8: stur            x2, [x0, #7]
    // 0xb36dec: LeaveFrame
    //     0xb36dec: mov             SP, fp
    //     0xb36df0: ldp             fp, lr, [SP], #0x10
    // 0xb36df4: ret
    //     0xb36df4: ret             
    // 0xb36df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb36df8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb36dfc: b               #0xb36dcc
  }
}

// class id: 5376, size: 0xc, field offset: 0xc
class XK extends WK {
}

// class id: 5377, size: 0x1c, field offset: 0x8
class UK extends Object
    implements TK {

  late final ilb _dfg; // offset: 0x14
}

// class id: 5378, size: 0x8, field offset: 0x8
abstract class TK extends Object {
}

// class id: 7341, size: 0x14, field offset: 0x14
enum VK extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
