// lib: , url: YJm

// class id: 1048925, size: 0x8
class :: {

  static late final vha _Jpf; // offset: 0x9cc
}

// class id: 5256, size: 0x38, field offset: 0xc
class _DM extends CM {
}

// class id: 5257, size: 0x28, field offset: 0xc
class _BM extends CM {
}

// class id: 5294, size: 0xc, field offset: 0xc
//   const constructor, transformed mixin,
abstract class _uM extends oM<dynamic>
     with vM {
}

// class id: 5295, size: 0x10, field offset: 0xc
//   transformed mixin,
abstract class _wM extends _uM
     with xM {
}

// class id: 5296, size: 0x14, field offset: 0x10
//   transformed mixin,
abstract class _yM extends _wM
     with zM {
}

// class id: 5298, size: 0x4c, field offset: 0x14
class AM extends _yM {

  late double _Cdc; // offset: 0x38
  late nM _gIc; // offset: 0x44

  double dyn:get:value(AM) {
    // ** addr: 0xb90db0, size: 0x44
    // 0xb90db0: ldr             x1, [SP]
    // 0xb90db4: LoadField: r0 = r1->field_37
    //     0xb90db4: ldur            w0, [x1, #0x37]
    // 0xb90db8: DecompressPointer r0
    //     0xb90db8: add             x0, x0, HEAP, lsl #32
    // 0xb90dbc: r16 = Sentinel
    //     0xb90dbc: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xb90dc0: cmp             w0, w16
    // 0xb90dc4: b.eq            #0xb90dcc
    // 0xb90dc8: ret
    //     0xb90dc8: ret             
    // 0xb90dcc: EnterFrame
    //     0xb90dcc: stp             fp, lr, [SP, #-0x10]!
    //     0xb90dd0: mov             fp, SP
    // 0xb90dd4: r9 = _Cdc
    //     0xb90dd4: ldr             x9, [PP, #0x4bc8]  ; [pp+0x4bc8] Field <AM._Cdc@490066280>: late (offset: 0x38)
    // 0xb90dd8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb90dd8: bl              #0xc56180  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _qgc(dynamic, Ea) {
    // ** addr: 0x494fa0, size: -0x1
  }
  [closure] lna AUd(dynamic, {double? from}) {
    // ** addr: 0x662fc4, size: -0x1
  }
  [closure] void _wpf(dynamic, _sM) {
    // ** addr: 0x5d88cc, size: -0x1
  }
}

// class id: 7337, size: 0x14, field offset: 0x14
enum tM extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7338, size: 0x14, field offset: 0x14
enum _sM extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
