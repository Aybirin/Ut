// lib: , url: Lbn

// class id: 1049637, size: 0x8
class :: {
}

// class id: 1787, size: 0x8, field offset: 0x8
abstract class hWa extends Object {

  [closure] static bool <anonymous closure>(dynamic, Ra<int, int>) {
    // ** addr: 0x44a348, size: -0x1
  }
  [closure] static int <anonymous closure>(dynamic, Ra<int, int>, Ra<int, int>) {
    // ** addr: 0x44a2cc, size: -0x1
  }
  [closure] static String <anonymous closure>(dynamic, Ra<int, int>) {
    // ** addr: 0x44a258, size: -0x1
  }
}

// class id: 1788, size: 0x20, field offset: 0x8
//   const constructor, 
class gWa extends Object {
}

// class id: 7136, size: 0x14, field offset: 0x14
enum fWa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7137, size: 0x1c, field offset: 0x14
enum eWa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
  _Mint field_14;
}
