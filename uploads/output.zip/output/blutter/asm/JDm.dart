// lib: , url: JDm

// class id: 1048597, size: 0x8
class :: {
}

// class id: 6241, size: 0x1c, field offset: 0x8
class iu extends Object
    implements gu {

  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xbe7d74, size: 0xb8
    // 0xbe7d74: EnterFrame
    //     0xbe7d74: stp             fp, lr, [SP, #-0x10]!
    //     0xbe7d78: mov             fp, SP
    // 0xbe7d7c: AllocStack(0x20)
    //     0xbe7d7c: sub             SP, SP, #0x20
    // 0xbe7d80: SetupParameters(iu this /* r1 */)
    //     0xbe7d80: stur            NULL, [fp, #-8]
    //     0xbe7d84: movz            x0, #0
    //     0xbe7d88: add             x1, fp, w0, sxtw #2
    //     0xbe7d8c: ldr             x1, [x1, #0x10]
    //     0xbe7d90: ldur            w2, [x1, #0x17]
    //     0xbe7d94: add             x2, x2, HEAP, lsl #32
    //     0xbe7d98: stur            x2, [fp, #-0x10]
    // 0xbe7d9c: CheckStackOverflow
    //     0xbe7d9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe7da0: cmp             SP, x16
    //     0xbe7da4: b.ls            #0xbe7e24
    // 0xbe7da8: InitAsync() -> Future<void?>
    //     0xbe7da8: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xbe7dac: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbe7db0: ldur            x0, [fp, #-0x10]
    // 0xbe7db4: LoadField: r1 = r0->field_13
    //     0xbe7db4: ldur            w1, [x0, #0x13]
    // 0xbe7db8: DecompressPointer r1
    //     0xbe7db8: add             x1, x1, HEAP, lsl #32
    // 0xbe7dbc: r16 = Sentinel
    //     0xbe7dbc: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xbe7dc0: cmp             w1, w16
    // 0xbe7dc4: b.ne            #0xbe7dd8
    // 0xbe7dc8: r16 = "Ojc"
    //     0xbe7dc8: add             x16, PP, #0xc, lsl #12  ; [pp+0xc390] "Ojc"
    //     0xbe7dcc: ldr             x16, [x16, #0x390]
    // 0xbe7dd0: str             x16, [SP]
    // 0xbe7dd4: r0 = _throwLocalNotInitialized()
    //     0xbe7dd4: bl              #0x39a7f8  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xbe7dd8: ldur            x2, [fp, #-0x10]
    // 0xbe7ddc: LoadField: r1 = r2->field_13
    //     0xbe7ddc: ldur            w1, [x2, #0x13]
    // 0xbe7de0: DecompressPointer r1
    //     0xbe7de0: add             x1, x1, HEAP, lsl #32
    // 0xbe7de4: r0 = LoadClassIdInstr(r1)
    //     0xbe7de4: ldur            x0, [x1, #-1]
    //     0xbe7de8: ubfx            x0, x0, #0xc, #0x14
    // 0xbe7dec: r0 = GDT[cid_x0 + -0x166]()
    //     0xbe7dec: sub             lr, x0, #0x166
    //     0xbe7df0: ldr             lr, [x21, lr, lsl #3]
    //     0xbe7df4: blr             lr
    // 0xbe7df8: mov             x1, x0
    // 0xbe7dfc: stur            x1, [fp, #-0x18]
    // 0xbe7e00: r0 = Await()
    //     0xbe7e00: bl              #0xb0c534  ; AwaitStub
    // 0xbe7e04: r0 = Eb()
    //     0xbe7e04: bl              #0xb0b3e8  ; AllocateEbStub -> Eb (size=0x10)
    // 0xbe7e08: mov             x1, x0
    // 0xbe7e0c: r0 = "HTTP response body timed out"
    //     0xbe7e0c: add             x0, PP, #0x26, lsl #12  ; [pp+0x26518] "HTTP response body timed out"
    //     0xbe7e10: ldr             x0, [x0, #0x518]
    // 0xbe7e14: StoreField: r1->field_7 = r0
    //     0xbe7e14: stur            w0, [x1, #7]
    // 0xbe7e18: mov             x0, x1
    // 0xbe7e1c: r0 = Throw()
    //     0xbe7e1c: bl              #0xc53a04  ; ThrowStub
    // 0xbe7e20: brk             #0
    // 0xbe7e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe7e24: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe7e28: b               #0xbe7da8
  }
  [closure] void <anonymous closure>(dynamic, String, String) {
    // ** addr: 0x73a804, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x73a064, size: -0x1
  }
}

// class id: 6242, size: 0xc, field offset: 0x8
//   const constructor, 
class hu extends Object
    implements Ja {
}

// class id: 6243, size: 0x8, field offset: 0x8
abstract class gu extends Object {
}
