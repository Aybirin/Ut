// lib: , url: MVm

// class id: 1049443, size: 0x8
class :: {
}

// class id: 2420, size: 0xc, field offset: 0x8
class bJa extends Object {
}
