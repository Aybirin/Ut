// lib: , url: wvn

// class id: 1050576, size: 0x8
class :: {

  static late final Nab BEj; // offset: 0x1b20

  [closure] static mHb <anonymous closure>(dynamic, iva, abb) {
    // ** addr: 0x6d17a8, size: -0x1
  }
  [closure] static RHb <anonymous closure>(dynamic, iva, abb) {
    // ** addr: 0x6d172c, size: -0x1
  }
  [closure] static UHb <anonymous closure>(dynamic, iva, abb) {
    // ** addr: 0x6d1714, size: -0x1
  }
  static Nab BEj() {
    // ** addr: 0x6d1540, size: -0x1
  }
}
