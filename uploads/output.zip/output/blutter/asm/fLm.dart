// lib: , url: fLm

// class id: 1048918, size: 0x8
class :: {
}

// class id: 5352, size: 0x8, field offset: 0x8
abstract class File extends Object
    implements uq, File {
}
