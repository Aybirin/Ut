// lib: , url: iTm

// class id: 1049329, size: 0x8
class :: {
}

// class id: 2533, size: 0x20, field offset: 0x8
class IBa extends Object {

  late Er _nFe; // offset: 0x18
}

// class id: 2534, size: 0x18, field offset: 0x8
//   const constructor, 
class HBa extends Object {
}

// class id: 3679, size: 0x10, field offset: 0x8
//   const constructor, 
class LBa extends Fqa {

  Efa field_8;
  JBa field_c;
}

// class id: 3767, size: 0x14, field offset: 0x14
class MBa extends Hqa<dynamic> {
}

// class id: 7187, size: 0x14, field offset: 0x14
enum JBa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
