// lib: BCn, url: Imn

// class id: 1050153, size: 0x8
class :: {
}

// class id: 1044, size: 0x8, field offset: 0x8
class qmb extends imb {

  static late final fqb GEg; // offset: 0xed8

  [closure] static qmb <anonymous closure>(dynamic) {
    // ** addr: 0x41ec08, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x41ebb0, size: -0x1
  }
}
