// lib: , url: tHm

// class id: 1048774, size: 0x8
class :: {

  [closure] static NB <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x4acda8, size: -0x1
  }
}
