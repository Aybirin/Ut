// lib: , url: bwn

// class id: 1050607, size: 0x8
class :: {
}

// class id: 438, size: 0x18, field offset: 0x8
class OBb extends Object {
}
