// lib: , url: gKm

// class id: 1048891, size: 0x8
class :: {

  [closure] static void <anonymous closure>(dynamic, Qb<Y1>) {
    // ** addr: 0x6b8b4c, size: -0x1
  }
  [closure] static void ffc(dynamic, Y0) {
    // ** addr: 0x6b8e4c, size: -0x1
  }
  [closure] static FutureOr<Y1> <anonymous closure>(dynamic) {
    // ** addr: 0x6b907c, size: -0x1
  }
}
