// lib: , url: CNm

// class id: 1049037, size: 0x8
class :: {
}

// class id: 3328, size: 0x18, field offset: 0x8
//   const constructor, 
class _DX extends Object {

  _Mint field_8;
  _Mint field_10;
}
