// lib: , url: fzn

// class id: 1050769, size: 0x8
class :: {
}

// class id: 4677, size: 0x14, field offset: 0xc
//   const constructor, 
class JJb extends Zu {

  [closure] VJb <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x874d18, size: -0x1
  }
}
