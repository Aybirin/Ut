// lib: cDn, url: don

// class id: 1050229, size: 0x8
class :: {
}

// class id: 955, size: 0x14, field offset: 0x8
class rpb extends Object
    implements nlb {

  static late final fqb GEg; // offset: 0xf58

  [closure] static (dynamic) => rpb <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x401908, size: -0x1
  }
  [closure] static rpb <anonymous closure>(dynamic) {
    // ** addr: 0x40195c, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x401870, size: -0x1
  }
}
