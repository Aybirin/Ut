// lib: , url: gHm

// class id: 1048761, size: 0x8
class :: {
}

// class id: 5857, size: 0x20, field offset: 0x8
class Xz extends Object {

  [closure] Vz <anonymous closure>(dynamic, NB) {
    // ** addr: 0x4664c4, size: -0x1
  }
}

// class id: 5858, size: 0xc, field offset: 0x8
class Wz extends Object {
}

// class id: 5859, size: 0x14, field offset: 0x8
class Vz extends Object {
}
