// lib: , url: jsn

// class id: 1050414, size: 0x8
class :: {

  static late final Vvb mXb; // offset: 0x19a0
}

// class id: 724, size: 0x10, field offset: 0x8
class Vvb extends Object {
}

// class id: 7049, size: 0x14, field offset: 0x14
enum Uvb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
