// lib: , url: zBn

// class id: 1050880, size: 0x8
class :: {

  static late ROb VWf; // offset: 0xba0
  static late final RegExp _WWf; // offset: 0xba4
  static late final RegExp _XWf; // offset: 0xba8
  static late final RegExp _YWf; // offset: 0xbac

  [closure] static String _ZWf(dynamic, wa) {
    // ** addr: 0xaf200c, size: -0x1
  }
  [closure] static String <anonymous closure>(dynamic, int) {
    // ** addr: 0xaf188c, size: -0x1
  }
  [closure] static String _aXf(dynamic, wa) {
    // ** addr: 0xaf199c, size: -0x1
  }
  [closure] static String _bXf(dynamic, wa) {
    // ** addr: 0xaf1708, size: -0x1
  }
}

// class id: 210, size: 0xc, field offset: 0x8
//   const constructor, 
class QOb extends ROb {

  _ConstMap<String, String> field_8;
}
