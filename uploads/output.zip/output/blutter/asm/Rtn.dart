// lib: , url: Rtn

// class id: 1050498, size: 0x8
class :: {
}

// class id: 573, size: 0x1c, field offset: 0x8
class Tyb extends Object {
}
