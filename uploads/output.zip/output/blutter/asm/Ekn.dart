// lib: , url: Ekn

// class id: 1050067, size: 0x8
class :: {
}

// class id: 1153, size: 0x10, field offset: 0x8
class xjb extends sjb {
}
