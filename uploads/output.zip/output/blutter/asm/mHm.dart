// lib: , url: mHm

// class id: 1048767, size: 0x8
class :: {
}

// class id: 4352, size: 0x20, field offset: 0x14
class _uB extends Xu<dynamic> {

  late Future<int> eQg; // offset: 0x18
  late Npa mMg; // offset: 0x14
  late Ib<Npa> fQg; // offset: 0x1c

  [closure] void sJc(dynamic) {
    // ** addr: 0x812cdc, size: -0x1
  }
  [closure] xL <anonymous closure>(dynamic, iva, rra<int>) {
    // ** addr: 0x654750, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Npa) {
    // ** addr: 0x7c8250, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7c82f4, size: -0x1
  }
}

// class id: 5233, size: 0x34, field offset: 0xc
//   const constructor, 
class tB extends Vu {
}
