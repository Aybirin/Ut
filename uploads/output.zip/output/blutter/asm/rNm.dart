// lib: , url: rNm

// class id: 1049026, size: 0x8
class :: {
}

// class id: 4847, size: 0x14, field offset: 0xc
//   const constructor, 
class FW extends Zu {
}
