// lib: , url: Kfn

// class id: 1049840, size: 0x8
class :: {
}

// class id: 1498, size: 0xc, field offset: 0x8
class ueb extends Object {
}
