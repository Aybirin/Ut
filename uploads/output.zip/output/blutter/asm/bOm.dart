// lib: , url: bOm

// class id: 1049063, size: 0x8
class :: {
}

// class id: 3792, size: 0x3c, field offset: 0x8
//   const constructor, 
class jba extends _FM {
}
