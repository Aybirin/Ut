// lib: , url: Vgn

// class id: 1049907, size: 0x8
class :: {
}

// class id: 7496, size: 0x2c, field offset: 0x24
class Cgb extends ugb {

  int length(Cgb) {
    // ** addr: 0xbab10c, size: 0x58
    // 0xbab10c: EnterFrame
    //     0xbab10c: stp             fp, lr, [SP, #-0x10]!
    //     0xbab110: mov             fp, SP
    // 0xbab114: ldr             x2, [fp, #0x10]
    // 0xbab118: LoadField: r3 = r2->field_23
    //     0xbab118: ldur            w3, [x2, #0x23]
    // 0xbab11c: DecompressPointer r3
    //     0xbab11c: add             x3, x3, HEAP, lsl #32
    // 0xbab120: LoadField: r2 = r3->field_13
    //     0xbab120: ldur            w2, [x3, #0x13]
    // 0xbab124: r3 = LoadInt32Instr(r2)
    //     0xbab124: sbfx            x3, x2, #1, #0x1f
    // 0xbab128: lsl             x2, x3, #1
    // 0xbab12c: r0 = BoxInt64Instr(r2)
    //     0xbab12c: sbfiz           x0, x2, #1, #0x1f
    //     0xbab130: cmp             x2, x0, asr #1
    //     0xbab134: b.eq            #0xbab140
    //     0xbab138: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbab13c: stur            x2, [x0, #7]
    // 0xbab140: LeaveFrame
    //     0xbab140: mov             SP, fp
    //     0xbab144: ldp             fp, lr, [SP], #0x10
    // 0xbab148: ret
    //     0xbab148: ret             
  }
}
