// lib: , url: vtn

// class id: 1050476, size: 0x8
class :: {
}

// class id: 617, size: 0x48, field offset: 0x8
class byb extends Object {

  [closure] static kyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xaf0660, size: -0x1
  }
  [closure] static String <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xaf05e0, size: -0x1
  }
}

// class id: 618, size: 0x10, field offset: 0x8
class ayb extends Object {
}

// class id: 619, size: 0x1c, field offset: 0x8
class Zxb extends Object {

  [closure] static ayb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x833cf0, size: -0x1
  }
}
