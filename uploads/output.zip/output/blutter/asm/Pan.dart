// lib: , url: Pan

// class id: 1049624, size: 0x8
class :: {
}

// class id: 1854, size: 0x10, field offset: 0x8
class uUa extends Object {

  [closure] static bool <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x793c50, size: -0x1
  }
}

// class id: 1855, size: 0x28, field offset: 0x8
//   const constructor, 
class tUa extends Object {

  Map<String, dynamic> Gxc(tUa) {
    // ** addr: 0xbf7b60, size: 0x48
    // 0xbf7b60: EnterFrame
    //     0xbf7b60: stp             fp, lr, [SP, #-0x10]!
    //     0xbf7b64: mov             fp, SP
    // 0xbf7b68: CheckStackOverflow
    //     0xbf7b68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf7b6c: cmp             SP, x16
    //     0xbf7b70: b.ls            #0xbf7b88
    // 0xbf7b74: ldr             x1, [fp, #0x10]
    // 0xbf7b78: r0 = call 0x78abb8
    //     0xbf7b78: bl              #0x78abb8
    // 0xbf7b7c: LeaveFrame
    //     0xbf7b7c: mov             SP, fp
    //     0xbf7b80: ldp             fp, lr, [SP], #0x10
    // 0xbf7b84: ret
    //     0xbf7b84: ret             
    // 0xbf7b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf7b88: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf7b8c: b               #0xbf7b74
  }
}

// class id: 1856, size: 0x10, field offset: 0x8
//   const constructor, 
class sUa extends Object {

  Map<String, dynamic> Gxc(sUa) {
    // ** addr: 0xb37d30, size: 0x48
    // 0xb37d30: EnterFrame
    //     0xb37d30: stp             fp, lr, [SP, #-0x10]!
    //     0xb37d34: mov             fp, SP
    // 0xb37d38: CheckStackOverflow
    //     0xb37d38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb37d3c: cmp             SP, x16
    //     0xb37d40: b.ls            #0xb37d58
    // 0xb37d44: ldr             x1, [fp, #0x10]
    // 0xb37d48: r0 = call 0x429f38
    //     0xb37d48: bl              #0x429f38
    // 0xb37d4c: LeaveFrame
    //     0xb37d4c: mov             SP, fp
    //     0xb37d50: ldp             fp, lr, [SP], #0x10
    // 0xb37d54: ret
    //     0xb37d54: ret             
    // 0xb37d58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37d58: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37d5c: b               #0xb37d44
  }
}

// class id: 1857, size: 0x18, field offset: 0x8
//   const constructor, 
class rUa extends Object {

  Map<String, dynamic> Gxc(rUa) {
    // ** addr: 0xb37d90, size: 0x48
    // 0xb37d90: EnterFrame
    //     0xb37d90: stp             fp, lr, [SP, #-0x10]!
    //     0xb37d94: mov             fp, SP
    // 0xb37d98: CheckStackOverflow
    //     0xb37d98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb37d9c: cmp             SP, x16
    //     0xb37da0: b.ls            #0xb37db8
    // 0xb37da4: ldr             x1, [fp, #0x10]
    // 0xb37da8: r0 = call 0x42af3c
    //     0xb37da8: bl              #0x42af3c
    // 0xb37dac: LeaveFrame
    //     0xb37dac: mov             SP, fp
    //     0xb37db0: ldp             fp, lr, [SP], #0x10
    // 0xb37db4: ret
    //     0xb37db4: ret             
    // 0xb37db8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb37db8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb37dbc: b               #0xb37da4
  }
}

// class id: 1858, size: 0x14, field offset: 0x8
class qUa extends Object {

  Map<String, dynamic> Gxc(qUa) {
    // ** addr: 0xbfb76c, size: 0x48
    // 0xbfb76c: EnterFrame
    //     0xbfb76c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfb770: mov             fp, SP
    // 0xbfb774: CheckStackOverflow
    //     0xbfb774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfb778: cmp             SP, x16
    //     0xbfb77c: b.ls            #0xbfb794
    // 0xbfb780: ldr             x1, [fp, #0x10]
    // 0xbfb784: r0 = call 0x78adf8
    //     0xbfb784: bl              #0x78adf8
    // 0xbfb788: LeaveFrame
    //     0xbfb788: mov             SP, fp
    //     0xbfb78c: ldp             fp, lr, [SP], #0x10
    // 0xbfb790: ret
    //     0xbfb790: ret             
    // 0xbfb794: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfb794: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfb798: b               #0xbfb780
  }
}
