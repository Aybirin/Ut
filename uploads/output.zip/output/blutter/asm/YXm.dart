// lib: , url: YXm

// class id: 1049522, size: 0x8
class :: {
}

// class id: 2337, size: 0x8, field offset: 0x8
abstract class BKa extends Object {
}
