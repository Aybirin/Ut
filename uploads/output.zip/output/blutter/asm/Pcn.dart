// lib: , url: Pcn

// class id: 1049697, size: 0x8
class :: {
}

// class id: 4131, size: 0x18, field offset: 0x14
class _MYa extends Xu<dynamic> {

  late SM _aDf; // offset: 0x14

  [closure] void sJc(dynamic) {
    // ** addr: 0x814e48, size: -0x1
  }
}

// class id: 5062, size: 0x14, field offset: 0xc
//   const constructor, 
class LYa extends Vu {
}
