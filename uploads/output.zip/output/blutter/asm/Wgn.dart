// lib: , url: Wgn

// class id: 1049908, size: 0x8
class :: {
}

// class id: 7495, size: 0x38, field offset: 0x24
class Dgb extends ugb {

  late final Uint8List data; // offset: 0x24

  int length(Dgb) {
    // ** addr: 0xbab164, size: 0x4c
    // 0xbab164: ldr             x1, [SP]
    // 0xbab168: LoadField: r2 = r1->field_23
    //     0xbab168: ldur            w2, [x1, #0x23]
    // 0xbab16c: DecompressPointer r2
    //     0xbab16c: add             x2, x2, HEAP, lsl #32
    // 0xbab170: r16 = Sentinel
    //     0xbab170: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xbab174: cmp             w2, w16
    // 0xbab178: b.eq            #0xbab184
    // 0xbab17c: LoadField: r0 = r2->field_13
    //     0xbab17c: ldur            w0, [x2, #0x13]
    // 0xbab180: ret
    //     0xbab180: ret             
    // 0xbab184: EnterFrame
    //     0xbab184: stp             fp, lr, [SP, #-0x10]!
    //     0xbab188: mov             fp, SP
    // 0xbab18c: r9 = data
    //     0xbab18c: add             x9, PP, #0x32, lsl #12  ; [pp+0x32f18] Field <Dgb.data>: late final (offset: 0x24)
    //     0xbab190: ldr             x9, [x9, #0xf18]
    // 0xbab194: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbab194: bl              #0xc56180  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}
