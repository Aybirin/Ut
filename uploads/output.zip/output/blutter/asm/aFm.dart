// lib: , url: aFm

// class id: 1048662, size: 0x8
class :: {
}

// class id: 6055, size: 0x8, field offset: 0x8
abstract class Jx extends Object {

  static late int xtg; // offset: 0xd2c
  static late int Xsg; // offset: 0xcc0
  static late int Ysg; // offset: 0xcc4
  static late bool ltg; // offset: 0xcfc
  static late int stg; // offset: 0xd18
  static late Ea ttg; // offset: 0xd1c
  static late int ptg; // offset: 0xd0c
  static late int Zsg; // offset: 0xcc8
  static late int utg; // offset: 0xd20
  static late int qtg; // offset: 0xd10
  static late Ea yzc; // offset: 0xcdc
  static late Ea etg; // offset: 0xce0
  static late int gtg; // offset: 0xce8
  static late Ea htg; // offset: 0xcec
  static late Ea itg; // offset: 0xcf0
  static late int atg; // offset: 0xccc
  static late int vtg; // offset: 0xd24
  static late Ea ctg; // offset: 0xcd4
  static late int wtg; // offset: 0xd28
  static late Ea btg; // offset: 0xcd0
  static late int otg; // offset: 0xd08
  static late String jtg; // offset: 0xcf4
  static late String ktg; // offset: 0xcf8
  static late String rtg; // offset: 0xd14
  static late String mtg; // offset: 0xd00
  static late String ntg; // offset: 0xd04
  static late Ea ftg; // offset: 0xce4
  static late Ea dtg; // offset: 0xcd8
}
