// lib: , url: atn

// class id: 1050457, size: 0x8
class :: {
}

// class id: 666, size: 0x14, field offset: 0x8
class exb extends Object {
}
