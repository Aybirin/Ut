// lib: pCn, url: ymn

// class id: 1050143, size: 0x8
class :: {
}

// class id: 1088, size: 0xc, field offset: 0x8
class Ulb extends blb {

  static late final fqb GEg; // offset: 0xe94

  [closure] static (dynamic) => Ulb <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x420e58, size: -0x1
  }
  [closure] static Ulb <anonymous closure>(dynamic) {
    // ** addr: 0x420eac, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x420df4, size: -0x1
  }
}
