// lib: , url: aun

// class id: 1050507, size: 0x8
class :: {
}

// class id: 562, size: 0x8, field offset: 0x8
abstract class ezb extends Object {

  static late final List<bzb> Crj; // offset: 0x1a7c
  static late final List<bzb> Drj; // offset: 0x1a80
}
