// lib: , url: Tun

// class id: 1050551, size: 0x8
class :: {
}

// class id: 497, size: 0x8, field offset: 0x8
class uAb extends rAb {
}
