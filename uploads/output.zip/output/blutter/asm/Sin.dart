// lib: , url: Sin

// class id: 1050002, size: 0x8
class :: {
}

// class id: 1346, size: 0x8, field offset: 0x8
abstract class Hib extends Object {

  static late final List<double> _Gbj; // offset: 0x1888
  static late final List<List<double>> _Dbj; // offset: 0x187c
  static late final List<double> _Fbj; // offset: 0x1884
  static late final List<List<double>> _Ebj; // offset: 0x1880
}
