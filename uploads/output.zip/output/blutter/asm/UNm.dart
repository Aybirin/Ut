// lib: , url: UNm

// class id: 1049053, size: 0x8
class :: {
}

// class id: 3249, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class RZ extends SZ {
}

// class id: 3250, size: 0x18, field offset: 0xc
//   const constructor, 
class VZ extends RZ {
}

// class id: 3251, size: 0x10, field offset: 0xc
//   const constructor, 
class UZ extends RZ {

  Mfa field_8;
  Jfa field_c;
}

// class id: 3252, size: 0xc, field offset: 0xc
//   const constructor, 
class _TZ extends RZ {

  Mfa field_8;
}
