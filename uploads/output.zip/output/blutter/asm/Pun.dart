// lib: , url: Pun

// class id: 1050547, size: 0x8
class :: {
}

// class id: 500, size: 0x20, field offset: 0x8
class _pAb extends Object {
}

// class id: 501, size: 0x60, field offset: 0x8
class _oAb extends Object {

  late final lAb _ICj; // offset: 0x38
  static late final NF _Npj; // offset: 0x1ad4
}

// class id: 502, size: 0x8, field offset: 0x8
abstract class nAb extends Object {

  static late final NF _Npj; // offset: 0x1ad8

  [closure] static void <anonymous closure>(dynamic, int, int) {
    // ** addr: 0x6e0f38, size: -0x1
  }
}
