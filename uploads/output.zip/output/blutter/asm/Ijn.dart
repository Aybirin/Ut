// lib: , url: Ijn

// class id: 1050040, size: 0x8
class :: {
}

// class id: 1210, size: 0xc, field offset: 0x8
abstract class oI<X0> extends Object {
}

// class id: 1211, size: 0x8, field offset: 0x8
abstract class nI extends Object {
}

// class id: 1282, size: 0x18, field offset: 0x8
class PG extends Object {
}
