// lib: xCn, url: Hmn

// class id: 1050152, size: 0x8
class :: {
}

// class id: 1047, size: 0x18, field offset: 0x18
class nmb extends omb {

  static late final fqb GEg; // offset: 0xebc
  static late final RegExp _dHg; // offset: 0xeb8

  [closure] static (dynamic) => nmb <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x41e078, size: -0x1
  }
  [closure] static nmb <anonymous closure>(dynamic) {
    // ** addr: 0x41e0cc, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x41dfec, size: -0x1
  }
}
