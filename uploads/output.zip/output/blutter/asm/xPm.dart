// lib: , url: xPm

// class id: 1049130, size: 0x8
class :: {
}

// class id: 3174, size: 0x18, field offset: 0x8
class _hga extends Object
    implements ega {
}

// class id: 3175, size: 0x18, field offset: 0x8
//   const constructor, 
class _gga extends Object
    implements dga {
}

// class id: 3176, size: 0x18, field offset: 0x8
class _fga extends Object
    implements ega {

  [closure] void _Skf(dynamic, Jga, bool) {
    // ** addr: 0xa22a54, size: -0x1
  }
}

// class id: 3177, size: 0x8, field offset: 0x8
abstract class ega extends Object {
}

// class id: 3178, size: 0x44, field offset: 0x8
//   const constructor, 
class dga extends Object {
}

// class id: 7270, size: 0x14, field offset: 0x14
enum cga extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
