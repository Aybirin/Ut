// lib: , url: cUm

// class id: 1049363, size: 0x8
class :: {
}

// class id: 2943, size: 0x6c, field offset: 0x5c
class _MFa extends _cka {

  [closure] void <anonymous closure>(dynamic, xja, Dr) {
    // ** addr: 0x526120, size: -0x1
  }
  [closure] double hJd(dynamic, double) {
    // ** addr: 0x56a210, size: -0x1
  }
  [closure] double eJd(dynamic, double) {
    // ** addr: 0x501a8c, size: -0x1
  }
  [closure] double fJd(dynamic, double) {
    // ** addr: 0x50c9f0, size: -0x1
  }
  [closure] double gJd(dynamic, double) {
    // ** addr: 0x5088d8, size: -0x1
  }
}

// class id: 4381, size: 0x18, field offset: 0x14
//   const constructor, 
class aua extends Vga {

  Ot field_c;
  Nva field_14;

  Bfa Rn(aua, Rga) {
    // ** addr: 0xbbeae4, size: 0x8c
    // 0xbbeae4: EnterFrame
    //     0xbbeae4: stp             fp, lr, [SP, #-0x10]!
    //     0xbbeae8: mov             fp, SP
    // 0xbbeaec: CheckStackOverflow
    //     0xbbeaec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbbeaf0: cmp             SP, x16
    //     0xbbeaf4: b.ls            #0xbbeb50
    // 0xbbeaf8: ldr             x0, [fp, #0x10]
    // 0xbbeafc: r2 = Null
    //     0xbbeafc: mov             x2, NULL
    // 0xbbeb00: r1 = Null
    //     0xbbeb00: mov             x1, NULL
    // 0xbbeb04: r4 = 60
    //     0xbbeb04: movz            x4, #0x3c
    // 0xbbeb08: branchIfSmi(r0, 0xbbeb14)
    //     0xbbeb08: tbz             w0, #0, #0xbbeb14
    // 0xbbeb0c: r4 = LoadClassIdInstr(r0)
    //     0xbbeb0c: ldur            x4, [x0, #-1]
    //     0xbbeb10: ubfx            x4, x4, #0xc, #0x14
    // 0xbbeb14: r17 = -4379
    //     0xbbeb14: movn            x17, #0x111a
    // 0xbbeb18: add             x4, x4, x17
    // 0xbbeb1c: cmp             x4, #3
    // 0xbbeb20: b.ls            #0xbbeb38
    // 0xbbeb24: r8 = Rga
    //     0xbbeb24: add             x8, PP, #0x35, lsl #12  ; [pp+0x354b8] Type: Rga
    //     0xbbeb28: ldr             x8, [x8, #0x4b8]
    // 0xbbeb2c: r3 = Null
    //     0xbbeb2c: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fde0] Null
    //     0xbbeb30: ldr             x3, [x3, #0xde0]
    // 0xbbeb34: r0 = Rga()
    //     0xbbeb34: bl              #0xb9e728  ; IsType_Rga_Stub
    // 0xbbeb38: ldr             x1, [fp, #0x18]
    // 0xbbeb3c: ldr             x2, [fp, #0x10]
    // 0xbbeb40: r0 = call 0x99a47c
    //     0xbbeb40: bl              #0x99a47c
    // 0xbbeb44: LeaveFrame
    //     0xbbeb44: mov             SP, fp
    //     0xbbeb48: ldp             fp, lr, [SP], #0x10
    // 0xbbeb4c: ret
    //     0xbbeb4c: ret             
    // 0xbbeb50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbeb50: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbeb54: b               #0xbbeaf8
  }
  [closure] static bool xjk(dynamic, Rga) {
    // ** addr: 0x68aae4, size: -0x1
  }
}

// class id: 4493, size: 0x1c, field offset: 0x10
//   const constructor, 
class _LFa extends xL {
}

// class id: 4578, size: 0x18, field offset: 0x14
//   const constructor, 
class _KFa extends bsa<dynamic> {
}
