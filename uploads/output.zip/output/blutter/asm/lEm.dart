// lib: , url: lEm

// class id: 1048625, size: 0x8
class :: {
}

// class id: 6109, size: 0x8, field offset: 0x8
abstract class ew extends Object {
}
