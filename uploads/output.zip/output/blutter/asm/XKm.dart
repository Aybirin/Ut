// lib: , url: XKm

// class id: 1048908, size: 0x8
class :: {
}

// class id: 5343, size: 0x14, field offset: 0x14
//   transformed mixin,
abstract class _bM extends WL<dynamic, dynamic>
     with cM {

  dynamic length(dynamic) {
    // ** addr: 0xc203f0, size: 0x3c
    // 0xc203f0: EnterFrame
    //     0xc203f0: stp             fp, lr, [SP, #-0x10]!
    //     0xc203f4: mov             fp, SP
    // 0xc203f8: ldr             x2, [fp, #0x10]
    // 0xc203fc: r1 = Function 'length':.
    //     0xc203fc: add             x1, PP, #0x4e, lsl #12  ; [pp+0x4e048] AnonymousClosure: (0x8b41c4), of [XKm] _bM
    //     0xc20400: ldr             x1, [x1, #0x48]
    // 0xc20404: r0 = AllocateClosure()
    //     0xc20404: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xc20408: LeaveFrame
    //     0xc20408: mov             SP, fp
    //     0xc2040c: ldp             fp, lr, [SP], #0x10
    // 0xc20410: ret
    //     0xc20410: ret             
  }
  [closure] Future<int> length(dynamic) {
    // ** addr: 0x8b41c4, size: -0x1
  }
}

// class id: 5344, size: 0x14, field offset: 0x14
class dM extends _bM {
}
