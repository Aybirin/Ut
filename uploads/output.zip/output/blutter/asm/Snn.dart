// lib: TCn, url: Snn

// class id: 1050218, size: 0x8
class :: {
}

// class id: 968, size: 0xc, field offset: 0x8
class Wob extends Sob {

  static late final fqb GEg; // offset: 0xf28
  static late final Map<String, int> _JIg; // offset: 0xf2c

  [closure] static (dynamic) => Wob <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x40310c, size: -0x1
  }
  [closure] static Wob <anonymous closure>(dynamic) {
    // ** addr: 0x4031f8, size: -0x1
  }
  [closure] static bool <anonymous closure>(dynamic, Ra<String, int>) {
    // ** addr: 0x403614, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x4030a8, size: -0x1
  }
}
