// lib: , url: jdn

// class id: 1049716, size: 0x8
class :: {
}

// class id: 4880, size: 0x74, field offset: 0x50
//   const constructor, 
class uZa extends tBa {
}
