// lib: , url: Izn

// class id: 1050798, size: 0x8
class :: {
}

// class id: 4327, size: 0x1c, field offset: 0x1c
abstract class RL<X0 bound Vu> extends XKb<X0 bound Vu> {

  [closure] void Zph(dynamic, jR) {
    // ** addr: 0x7e4278, size: -0x1
  }
}
