// lib: , url: Bwn

// class id: 1050635, size: 0x8
class :: {
}

// class id: 422, size: 0x8, field offset: 0x8
abstract class KCb extends Object {

  [closure] static void <anonymous closure>(dynamic, BTa) {
    // ** addr: 0x796bd8, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x79690c, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, int) {
    // ** addr: 0x7968b4, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, ZVa, qWa?) {
    // ** addr: 0x79683c, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, ZVa, qWa?) {
    // ** addr: 0x796754, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, yWa) {
    // ** addr: 0x79668c, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x796638, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x7965e0, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x796588, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, int) {
    // ** addr: 0x796530, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, int) {
    // ** addr: 0x7964d8, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x79641c, size: -0x1
  }
  [closure] static void _wRj(dynamic, qWa) {
    // ** addr: 0x794c04, size: -0x1
  }
}
