// lib: , url: xHm

// class id: 1048778, size: 0x8
class :: {
}

// class id: 5776, size: 0x2c, field offset: 0x8
//   const constructor, 
class PB extends Object {
}

// class id: 5777, size: 0x10, field offset: 0x8
//   const constructor, 
class OB extends Object {
}

// class id: 5778, size: 0x20, field offset: 0x8
//   const constructor, 
class NB extends Object {
}
