// lib: , url: YQm

// class id: 1049211, size: 0x8
class :: {
}

// class id: 2741, size: 0x20, field offset: 0x8
class goa extends Object {

  [closure] bool Ald(dynamic, Jr) {
    // ** addr: 0x475098, size: -0x1
  }
  [closure] Future<Map<String, dynamic>> Dld(dynamic, dynamic) {
    // ** addr: 0x4712bc, size: -0x1
  }
  [closure] void _Gld(dynamic, tpa) {
    // ** addr: 0x4747ac, size: -0x1
  }
}

// class id: 2742, size: 0xc, field offset: 0x8
//   const constructor, 
class xoa extends Object {
}

// class id: 2743, size: 0x18, field offset: 0x8
class foa extends Object {
}

// class id: 3710, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class soa extends _FM {
}

// class id: 3711, size: 0x10, field offset: 0x10
//   const constructor, 
class voa extends soa {
}

// class id: 3712, size: 0x10, field offset: 0x10
//   const constructor, 
class uoa extends soa {
}

// class id: 3713, size: 0x10, field offset: 0x10
//   const constructor, 
class toa extends soa {
}

// class id: 7236, size: 0x14, field offset: 0x14
enum woa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7237, size: 0x18, field offset: 0x14
enum roa extends _Enum {

  static late final Map<int, roa> _Lld; // offset: 0x6c4
  _Mint field_8;
  _OneByteString field_10;
  poa field_14;
}
