// lib: , url: aAn

// class id: 1050816, size: 0x8
class :: {
}

// class id: 373, size: 0x8, field offset: 0x8
abstract class uLb extends Object {

  static late wLb QZj; // offset: 0x1c54
}

// class id: 374, size: 0x8, field offset: 0x8
abstract class tLb extends Object {

  static late List<int>? POc; // offset: 0x1c3c
  static late wLb QZj; // offset: 0x1c4c
}
