// lib: , url: OBn

// class id: 1050910, size: 0x8
class :: {
}

// class id: 196, size: 0x8, field offset: 0x8
abstract class iPb extends Object {
}
