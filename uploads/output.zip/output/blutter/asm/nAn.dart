// lib: , url: nAn

// class id: 1050829, size: 0x8
class :: {
}

// class id: 348, size: 0x14, field offset: 0x8
class _eMb extends Object {
}

// class id: 349, size: 0x58, field offset: 0x8
class dMb extends Object {

  static late final Uint8List _Ljd; // offset: 0x1c6c
  late Uint8List _Kjd; // offset: 0x14
}

// class id: 350, size: 0x8, field offset: 0x8
//   const constructor, 
class bMb extends Object {
}

// class id: 351, size: 0x10, field offset: 0x8
//   const constructor, 
class aMb extends Object {

  bool field_8;
}

// class id: 359, size: 0x8, field offset: 0x8
abstract class JLb extends Object {
}

// class id: 7024, size: 0x14, field offset: 0x14
enum _cMb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
