// lib: , url: eYm

// class id: 1049525, size: 0x8
class :: {
}

// class id: 2334, size: 0x10, field offset: 0x8
//   const constructor, 
class EKa extends Object {

  _OneByteString field_8;
  _OneByteString field_c;
}
