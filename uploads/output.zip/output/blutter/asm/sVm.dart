// lib: , url: sVm

// class id: 1049426, size: 0x8
class :: {
}

// class id: 2435, size: 0xc, field offset: 0x8
class YHa extends Object {
}
