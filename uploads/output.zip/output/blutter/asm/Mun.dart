// lib: , url: Mun

// class id: 1050544, size: 0x8
class :: {
}

// class id: 505, size: 0xc, field offset: 0x8
class kAb extends Object
    implements lAb {

  dynamic length(dynamic) {
    // ** addr: 0xbd1c20, size: 0x3c
    // 0xbd1c20: EnterFrame
    //     0xbd1c20: stp             fp, lr, [SP, #-0x10]!
    //     0xbd1c24: mov             fp, SP
    // 0xbd1c28: ldr             x2, [fp, #0x10]
    // 0xbd1c2c: r1 = Function 'length':.
    //     0xbd1c2c: add             x1, PP, #0x30, lsl #12  ; [pp+0x30d00] AnonymousClosure: (0x6e0910), of [Mun] kAb
    //     0xbd1c30: ldr             x1, [x1, #0xd00]
    // 0xbd1c34: r0 = AllocateClosure()
    //     0xbd1c34: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xbd1c38: LeaveFrame
    //     0xbd1c38: mov             SP, fp
    //     0xbd1c3c: ldp             fp, lr, [SP], #0x10
    // 0xbd1c40: ret
    //     0xbd1c40: ret             
  }
  [closure] Future<int> length(dynamic) {
    // ** addr: 0x6e0910, size: -0x1
  }
}
