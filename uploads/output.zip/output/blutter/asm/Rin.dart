// lib: , url: Rin

// class id: 1050001, size: 0x8
class :: {
}

// class id: 1347, size: 0x18, field offset: 0x8
class Gib extends Object {

  late int _Nrh; // offset: 0x14
  late double _Krh; // offset: 0x8
  late double _Lrh; // offset: 0xc
  late double _Mrh; // offset: 0x10

  int toInt(Gib) {
    // ** addr: 0xb9a0c0, size: 0x48
    // 0xb9a0c0: ldr             x1, [SP]
    // 0xb9a0c4: LoadField: r0 = r1->field_13
    //     0xb9a0c4: ldur            w0, [x1, #0x13]
    // 0xb9a0c8: DecompressPointer r0
    //     0xb9a0c8: add             x0, x0, HEAP, lsl #32
    // 0xb9a0cc: r16 = Sentinel
    //     0xb9a0cc: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xb9a0d0: cmp             w0, w16
    // 0xb9a0d4: b.eq            #0xb9a0dc
    // 0xb9a0d8: ret
    //     0xb9a0d8: ret             
    // 0xb9a0dc: EnterFrame
    //     0xb9a0dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb9a0e0: mov             fp, SP
    // 0xb9a0e4: r9 = _Nrh
    //     0xb9a0e4: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d788] Field <Gib._Nrh@1211004467>: late (offset: 0x14)
    //     0xb9a0e8: ldr             x9, [x9, #0x788]
    // 0xb9a0ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb9a0ec: bl              #0xc56180  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}
