// lib: , url: Zhn

// class id: 1049959, size: 0x8
class :: {
}

// class id: 7078, size: 0x14, field offset: 0x14
enum Ehb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
