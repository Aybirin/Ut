// lib: , url: Ccn

// class id: 1049684, size: 0x8
class :: {
}

// class id: 1704, size: 0x2c, field offset: 0x8
class pYa extends Object {
}
