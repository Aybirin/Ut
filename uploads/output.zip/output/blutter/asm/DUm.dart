// lib: , url: DUm

// class id: 1049390, size: 0x8
class :: {
}

// class id: 2480, size: 0x8, field offset: 0x8
//   const constructor, 
class JGa extends KGa {
}
