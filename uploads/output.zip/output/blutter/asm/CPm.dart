// lib: , url: CPm

// class id: 1049135, size: 0x8
class :: {
}

// class id: 3155, size: 0xc, field offset: 0x8
class Hga extends Object
    implements Ja {
}

// class id: 3157, size: 0x18, field offset: 0x8
//   const constructor, 
class yga extends Object {
}

// class id: 3158, size: 0x20, field offset: 0x8
//   const constructor, 
class wga extends Object {
}

// class id: 3933, size: 0x34, field offset: 0x34
class _Gga extends Nz {
}

// class id: 5863, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class Lz<X0> extends Object {

  [closure] Null <anonymous closure>(dynamic, X0) {
    // ** addr: 0xbb0b6c, size: 0xc0
    // 0xbb0b6c: EnterFrame
    //     0xbb0b6c: stp             fp, lr, [SP, #-0x10]!
    //     0xbb0b70: mov             fp, SP
    // 0xbb0b74: AllocStack(0x60)
    //     0xbb0b74: sub             SP, SP, #0x60
    // 0xbb0b78: SetupParameters([dynamic _ /* r0 */])
    //     0xbb0b78: ldr             x0, [fp, #0x18]
    //     0xbb0b7c: ldur            w1, [x0, #0x17]
    //     0xbb0b80: add             x1, x1, HEAP, lsl #32
    //     0xbb0b84: stur            x1, [fp, #-0x48]
    // 0xbb0b88: CheckStackOverflow
    //     0xbb0b88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbb0b8c: cmp             SP, x16
    //     0xbb0b90: b.ls            #0xbb0c24
    // 0xbb0b94: ldr             x0, [fp, #0x10]
    // 0xbb0b98: StoreField: r1->field_1b = r0
    //     0xbb0b98: stur            w0, [x1, #0x1b]
    //     0xbb0b9c: tbz             w0, #0, #0xbb0bb8
    //     0xbb0ba0: ldurb           w16, [x1, #-1]
    //     0xbb0ba4: ldurb           w17, [x0, #-1]
    //     0xbb0ba8: and             x16, x17, x16, lsr #2
    //     0xbb0bac: tst             x16, HEAP, lsr #32
    //     0xbb0bb0: b.eq            #0xbb0bb8
    //     0xbb0bb4: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xbb0bb8: LoadField: r2 = r1->field_13
    //     0xbb0bb8: ldur            w2, [x1, #0x13]
    // 0xbb0bbc: DecompressPointer r2
    //     0xbb0bbc: add             x2, x2, HEAP, lsl #32
    // 0xbb0bc0: stur            x2, [fp, #-0x40]
    // 0xbb0bc4: LoadField: r0 = r1->field_23
    //     0xbb0bc4: ldur            w0, [x1, #0x23]
    // 0xbb0bc8: DecompressPointer r0
    //     0xbb0bc8: add             x0, x0, HEAP, lsl #32
    // 0xbb0bcc: ldr             x16, [fp, #0x10]
    // 0xbb0bd0: stp             x16, x2, [SP, #8]
    // 0xbb0bd4: str             x0, [SP]
    // 0xbb0bd8: mov             x0, x2
    // 0xbb0bdc: ClosureCall
    //     0xbb0bdc: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xbb0be0: ldur            x2, [x0, #0x1f]
    //     0xbb0be4: blr             x2
    // 0xbb0be8: b               #0xbb0c14
    // 0xbb0bec: sub             SP, fp, #0x60
    // 0xbb0bf0: ldur            x2, [fp, #-0x10]
    // 0xbb0bf4: LoadField: r3 = r2->field_23
    //     0xbb0bf4: ldur            w3, [x2, #0x23]
    // 0xbb0bf8: DecompressPointer r3
    //     0xbb0bf8: add             x3, x3, HEAP, lsl #32
    // 0xbb0bfc: stp             x0, x3, [SP, #8]
    // 0xbb0c00: str             x1, [SP]
    // 0xbb0c04: mov             x0, x3
    // 0xbb0c08: ClosureCall
    //     0xbb0c08: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xbb0c0c: ldur            x2, [x0, #0x1f]
    //     0xbb0c10: blr             x2
    // 0xbb0c14: r0 = Null
    //     0xbb0c14: mov             x0, NULL
    // 0xbb0c18: LeaveFrame
    //     0xbb0c18: mov             SP, fp
    //     0xbb0c1c: ldp             fp, lr, [SP], #0x10
    // 0xbb0c20: ret
    //     0xbb0c20: ret             
    // 0xbb0c24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb0c24: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb0c28: b               #0xbb0b94
  }
  [closure] Future<void> ZPb(dynamic, Object, ua?) async {
    // ** addr: 0xbb0c2c, size: 0xb4
    // 0xbb0c2c: EnterFrame
    //     0xbb0c2c: stp             fp, lr, [SP, #-0x10]!
    //     0xbb0c30: mov             fp, SP
    // 0xbb0c34: AllocStack(0x40)
    //     0xbb0c34: sub             SP, SP, #0x40
    // 0xbb0c38: SetupParameters(Lz<X0> this /* r1 */, dynamic _ /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */)
    //     0xbb0c38: stur            NULL, [fp, #-8]
    //     0xbb0c3c: movz            x0, #0
    //     0xbb0c40: add             x1, fp, w0, sxtw #2
    //     0xbb0c44: ldr             x1, [x1, #0x20]
    //     0xbb0c48: add             x2, fp, w0, sxtw #2
    //     0xbb0c4c: ldr             x2, [x2, #0x18]
    //     0xbb0c50: stur            x2, [fp, #-0x20]
    //     0xbb0c54: add             x3, fp, w0, sxtw #2
    //     0xbb0c58: ldr             x3, [x3, #0x10]
    //     0xbb0c5c: stur            x3, [fp, #-0x18]
    //     0xbb0c60: ldur            w4, [x1, #0x17]
    //     0xbb0c64: add             x4, x4, HEAP, lsl #32
    //     0xbb0c68: stur            x4, [fp, #-0x10]
    // 0xbb0c6c: CheckStackOverflow
    //     0xbb0c6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbb0c70: cmp             SP, x16
    //     0xbb0c74: b.ls            #0xbb0cd8
    // 0xbb0c78: InitAsync() -> Future<void?>
    //     0xbb0c78: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xbb0c7c: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbb0c80: ldur            x0, [fp, #-0x10]
    // 0xbb0c84: LoadField: r1 = r0->field_1f
    //     0xbb0c84: ldur            w1, [x0, #0x1f]
    // 0xbb0c88: DecompressPointer r1
    //     0xbb0c88: add             x1, x1, HEAP, lsl #32
    // 0xbb0c8c: tbnz            w1, #4, #0xbb0c98
    // 0xbb0c90: r0 = Null
    //     0xbb0c90: mov             x0, NULL
    // 0xbb0c94: r0 = ReturnAsyncNotFuture()
    //     0xbb0c94: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbb0c98: r1 = true
    //     0xbb0c98: add             x1, NULL, #0x20  ; true
    // 0xbb0c9c: StoreField: r0->field_1f = r1
    //     0xbb0c9c: stur            w1, [x0, #0x1f]
    // 0xbb0ca0: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xbb0ca0: ldur            w1, [x0, #0x17]
    // 0xbb0ca4: DecompressPointer r1
    //     0xbb0ca4: add             x1, x1, HEAP, lsl #32
    // 0xbb0ca8: LoadField: r2 = r0->field_1b
    //     0xbb0ca8: ldur            w2, [x0, #0x1b]
    // 0xbb0cac: DecompressPointer r2
    //     0xbb0cac: add             x2, x2, HEAP, lsl #32
    // 0xbb0cb0: stp             x2, x1, [SP, #0x10]
    // 0xbb0cb4: ldur            x16, [fp, #-0x20]
    // 0xbb0cb8: ldur            lr, [fp, #-0x18]
    // 0xbb0cbc: stp             lr, x16, [SP]
    // 0xbb0cc0: mov             x0, x1
    // 0xbb0cc4: ClosureCall
    //     0xbb0cc4: ldr             x4, [PP, #0xa28]  ; [pp+0xa28] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xbb0cc8: ldur            x2, [x0, #0x1f]
    //     0xbb0ccc: blr             x2
    // 0xbb0cd0: r0 = Null
    //     0xbb0cd0: mov             x0, NULL
    // 0xbb0cd4: r0 = ReturnAsyncNotFuture()
    //     0xbb0cd4: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbb0cd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb0cd8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb0cdc: b               #0xbb0c78
  }
  [closure] Future<void> <anonymous closure>(dynamic, X0?, Object, ua?) async {
    // ** addr: 0xbb0cec, size: 0x100
    // 0xbb0cec: EnterFrame
    //     0xbb0cec: stp             fp, lr, [SP, #-0x10]!
    //     0xbb0cf0: mov             fp, SP
    // 0xbb0cf4: AllocStack(0x30)
    //     0xbb0cf4: sub             SP, SP, #0x30
    // 0xbb0cf8: SetupParameters(Lz<X0> this /* r1 */, dynamic _ /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */)
    //     0xbb0cf8: stur            NULL, [fp, #-8]
    //     0xbb0cfc: movz            x0, #0
    //     0xbb0d00: add             x1, fp, w0, sxtw #2
    //     0xbb0d04: ldr             x1, [x1, #0x28]
    //     0xbb0d08: add             x2, fp, w0, sxtw #2
    //     0xbb0d0c: ldr             x2, [x2, #0x18]
    //     0xbb0d10: stur            x2, [fp, #-0x20]
    //     0xbb0d14: add             x3, fp, w0, sxtw #2
    //     0xbb0d18: ldr             x3, [x3, #0x10]
    //     0xbb0d1c: stur            x3, [fp, #-0x18]
    //     0xbb0d20: ldur            w4, [x1, #0x17]
    //     0xbb0d24: add             x4, x4, HEAP, lsl #32
    //     0xbb0d28: stur            x4, [fp, #-0x10]
    // 0xbb0d2c: CheckStackOverflow
    //     0xbb0d2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbb0d30: cmp             SP, x16
    //     0xbb0d34: b.ls            #0xbb0de0
    // 0xbb0d38: InitAsync() -> Future<void?>
    //     0xbb0d38: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xbb0d3c: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbb0d40: r0 = Null
    //     0xbb0d40: mov             x0, NULL
    // 0xbb0d44: r0 = Await()
    //     0xbb0d44: bl              #0xb0c534  ; AwaitStub
    // 0xbb0d48: ldur            x0, [fp, #-0x10]
    // 0xbb0d4c: LoadField: r1 = r0->field_13
    //     0xbb0d4c: ldur            w1, [x0, #0x13]
    // 0xbb0d50: DecompressPointer r1
    //     0xbb0d50: add             x1, x1, HEAP, lsl #32
    // 0xbb0d54: stur            x1, [fp, #-0x28]
    // 0xbb0d58: LoadField: r0 = r1->field_7
    //     0xbb0d58: ldur            w0, [x1, #7]
    // 0xbb0d5c: DecompressPointer r0
    //     0xbb0d5c: add             x0, x0, HEAP, lsl #32
    // 0xbb0d60: cmp             w0, NULL
    // 0xbb0d64: b.ne            #0xbb0d84
    // 0xbb0d68: r0 = _Gga()
    //     0xbb0d68: bl              #0xbb1210  ; Allocate_GgaStub -> _Gga (size=0x34)
    // 0xbb0d6c: mov             x1, x0
    // 0xbb0d70: stur            x0, [fp, #-0x10]
    // 0xbb0d74: r0 = call 0x5f0960
    //     0xbb0d74: bl              #0x5f0960
    // 0xbb0d78: ldur            x1, [fp, #-0x28]
    // 0xbb0d7c: ldur            x2, [fp, #-0x10]
    // 0xbb0d80: r0 = call 0x5f06f0
    //     0xbb0d80: bl              #0x5f06f0
    // 0xbb0d84: ldur            x0, [fp, #-0x28]
    // 0xbb0d88: LoadField: r2 = r0->field_7
    //     0xbb0d88: ldur            w2, [x0, #7]
    // 0xbb0d8c: DecompressPointer r2
    //     0xbb0d8c: add             x2, x2, HEAP, lsl #32
    // 0xbb0d90: stur            x2, [fp, #-0x10]
    // 0xbb0d94: cmp             w2, NULL
    // 0xbb0d98: b.eq            #0xbb0de8
    // 0xbb0d9c: r1 = <List<Object>>
    //     0xbb0d9c: ldr             x1, [PP, #0x8b8]  ; [pp+0x8b8] TypeArguments: <List<Object>>
    // 0xbb0da0: r0 = LP()
    //     0xbb0da0: bl              #0xb12c64  ; AllocateLPStub -> LP (size=0x2c)
    // 0xbb0da4: mov             x1, x0
    // 0xbb0da8: r2 = "while resolving an image"
    //     0xbb0da8: add             x2, PP, #0x36, lsl #12  ; [pp+0x36f48] "while resolving an image"
    //     0xbb0dac: ldr             x2, [x2, #0xf48]
    // 0xbb0db0: r3 = Instance_DP
    //     0xbb0db0: ldr             x3, [PP, #0x8c0]  ; [pp+0x8c0] Obj!DP@69e151
    // 0xbb0db4: r0 = call 0x39dba8
    //     0xbb0db4: bl              #0x39dba8
    // 0xbb0db8: r16 = true
    //     0xbb0db8: add             x16, NULL, #0x20  ; true
    // 0xbb0dbc: str             x16, [SP]
    // 0xbb0dc0: ldur            x1, [fp, #-0x10]
    // 0xbb0dc4: ldur            x2, [fp, #-0x20]
    // 0xbb0dc8: ldur            x3, [fp, #-0x18]
    // 0xbb0dcc: r4 = const [0, 0x4, 0x1, 0x3, yhd, 0x3, null]
    //     0xbb0dcc: add             x4, PP, #0x36, lsl #12  ; [pp+0x36e50] List(7) [0, 0x4, 0x1, 0x3, "yhd", 0x3, Null]
    //     0xbb0dd0: ldr             x4, [x4, #0xe50]
    // 0xbb0dd4: r0 = __unknown_function__()
    //     0xbb0dd4: bl              #0xbb0dec  ; [] ::__unknown_function__
    // 0xbb0dd8: r0 = Null
    //     0xbb0dd8: mov             x0, NULL
    // 0xbb0ddc: r0 = ReturnAsyncNotFuture()
    //     0xbb0ddc: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbb0de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb0de0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb0de4: b               #0xbb0d38
    // 0xbb0de8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbb0de8: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, X0, (dynamic, Object, ua?) => void) {
    // ** addr: 0x5f0a38, size: -0x1
  }
  [closure] Nz <anonymous closure>(dynamic) {
    // ** addr: 0x97c854, size: -0x1
  }
  [closure] Nz <anonymous closure>(dynamic) {
    // ** addr: 0x97c744, size: -0x1
  }
}

// class id: 5866, size: 0x18, field offset: 0xc
//   const constructor, 
class Ega extends Lz<dynamic> {
}

// class id: 5867, size: 0x18, field offset: 0xc
//   const constructor, 
class Dga extends Lz<dynamic> {

  [closure] List<FP> <anonymous closure>(dynamic) {
    // ** addr: 0x8b73cc, size: -0x1
  }
}

// class id: 5869, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class zga extends Lz<dynamic> {
}

// class id: 5873, size: 0xc, field offset: 0xc
abstract class ufa extends Lz<dynamic> {
}
