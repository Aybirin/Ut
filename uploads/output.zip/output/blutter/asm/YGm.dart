// lib: , url: YGm

// class id: 1048816, size: 0x8
class :: {
}

// class id: 6720, size: 0xc, field offset: 0xc
//   const constructor, 
class VC extends Ze<dynamic, dynamic> {
}
