// lib: IEn, url: pon

// class id: 1050241, size: 0x8
class :: {
}

// class id: 942, size: 0x8, field offset: 0x8
abstract class Opb extends Object
    implements dlb {
}
