// lib: bDn, url: Znn

// class id: 1050225, size: 0x8
class :: {
}

// class id: 960, size: 0x28, field offset: 0x8
class ipb extends jpb {

  static late final fqb GEg; // offset: 0xf54
  late int _AGg; // offset: 0x10
  late Uint8List _ZIg; // offset: 0xc
  late Uint8List _OIg; // offset: 0x8

  [closure] static (dynamic) => ipb <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x401e98, size: -0x1
  }
  [closure] static ipb <anonymous closure>(dynamic) {
    // ** addr: 0x401eec, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x401e00, size: -0x1
  }
}
