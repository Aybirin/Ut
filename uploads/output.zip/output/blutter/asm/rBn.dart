// lib: , url: rBn

// class id: 1050872, size: 0x8
class :: {
}

// class id: 222, size: 0x14, field offset: 0x8
class DOb extends Object {

  static late final DOb _UMc; // offset: 0x1080

  [closure] double <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x7ac598, size: -0x1
  }
  [closure] double <anonymous closure>(dynamic, double?) {
    // ** addr: 0x3ac824, size: -0x1
  }
}
