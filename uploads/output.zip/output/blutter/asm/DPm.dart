// lib: , url: DPm

// class id: 1049136, size: 0x8
class :: {
}

// class id: 5870, size: 0x18, field offset: 0xc
//   const constructor, 
class Iga extends zga {

  [closure] Null <anonymous closure>(dynamic, Sna) {
    // ** addr: 0x9661f4, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic, Object, ua) {
    // ** addr: 0x96618c, size: -0x1
  }
}
