// lib: , url: Gtn

// class id: 1050487, size: 0x8
class :: {
}

// class id: 594, size: 0x10, field offset: 0x8
class yyb extends Object {
}
