// lib: , url: rqn

// class id: 1050324, size: 0x8
class :: {
}

// class id: 837, size: 0x10, field offset: 0x8
class Dsb extends Object {
}
