// lib: , url: SPm

// class id: 1049149, size: 0x8
class :: {
}

// class id: 4379, size: 0x30, field offset: 0xc
//   const constructor, 
class qha extends Rga
    implements YQ, rha {

  _TwoByteString field_c;
  _Moa field_18;
  Dt field_8;

  Bfa Rn(qha, Rga) {
    // ** addr: 0xba6180, size: 0x8c
    // 0xba6180: EnterFrame
    //     0xba6180: stp             fp, lr, [SP, #-0x10]!
    //     0xba6184: mov             fp, SP
    // 0xba6188: CheckStackOverflow
    //     0xba6188: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xba618c: cmp             SP, x16
    //     0xba6190: b.ls            #0xba61ec
    // 0xba6194: ldr             x0, [fp, #0x10]
    // 0xba6198: r2 = Null
    //     0xba6198: mov             x2, NULL
    // 0xba619c: r1 = Null
    //     0xba619c: mov             x1, NULL
    // 0xba61a0: r4 = 60
    //     0xba61a0: movz            x4, #0x3c
    // 0xba61a4: branchIfSmi(r0, 0xba61b0)
    //     0xba61a4: tbz             w0, #0, #0xba61b0
    // 0xba61a8: r4 = LoadClassIdInstr(r0)
    //     0xba61a8: ldur            x4, [x0, #-1]
    //     0xba61ac: ubfx            x4, x4, #0xc, #0x14
    // 0xba61b0: r17 = -4379
    //     0xba61b0: movn            x17, #0x111a
    // 0xba61b4: add             x4, x4, x17
    // 0xba61b8: cmp             x4, #3
    // 0xba61bc: b.ls            #0xba61d4
    // 0xba61c0: r8 = Rga
    //     0xba61c0: add             x8, PP, #0x35, lsl #12  ; [pp+0x354b8] Type: Rga
    //     0xba61c4: ldr             x8, [x8, #0x4b8]
    // 0xba61c8: r3 = Null
    //     0xba61c8: add             x3, PP, #0x35, lsl #12  ; [pp+0x354c0] Null
    //     0xba61cc: ldr             x3, [x3, #0x4c0]
    // 0xba61d0: r0 = Rga()
    //     0xba61d0: bl              #0xb9e728  ; IsType_Rga_Stub
    // 0xba61d4: ldr             x1, [fp, #0x18]
    // 0xba61d8: ldr             x2, [fp, #0x10]
    // 0xba61dc: r0 = call 0x99ea8c
    //     0xba61dc: bl              #0x99ea8c
    // 0xba61e0: LeaveFrame
    //     0xba61e0: mov             SP, fp
    //     0xba61e4: ldp             fp, lr, [SP], #0x10
    // 0xba61e8: ret
    //     0xba61e8: ret             
    // 0xba61ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba61ec: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba61f0: b               #0xba6194
  }
}
