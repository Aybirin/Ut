// lib: , url: Acn

// class id: 1049682, size: 0x8
class :: {
}

// class id: 1705, size: 0x8, field offset: 0x8
abstract class oYa extends Object {
}
