// lib: , url: wUm

// class id: 1049383, size: 0x8
class :: {
}

// class id: 2487, size: 0x10, field offset: 0x8
class yGa extends Object
    implements fM {
}
