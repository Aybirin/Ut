// lib: , url: kfn

// class id: 1049814, size: 0x8
class :: {
}

// class id: 1547, size: 0x8, field offset: 0x8
abstract class Cdb extends Object {
}
