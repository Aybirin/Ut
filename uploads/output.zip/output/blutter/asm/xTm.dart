// lib: , url: xTm

// class id: 1049345, size: 0x8
class :: {
}

// class id: 2521, size: 0x1c, field offset: 0x8
//   const constructor, 
class MDa extends Object {

  bool field_18;
}
