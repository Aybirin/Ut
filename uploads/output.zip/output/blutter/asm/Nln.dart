// lib: , url: Nln

// class id: 1050128, size: 0x8
class :: {
}

// class id: 1096, size: 0x8, field offset: 0x8
//   const constructor, 
class Ykb extends Oq {
}
