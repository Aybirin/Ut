// lib: , url: nUm

// class id: 1049374, size: 0x8
class :: {
}

// class id: 2497, size: 0x14, field offset: 0x8
//   const constructor, 
class oGa extends pGa {
}
