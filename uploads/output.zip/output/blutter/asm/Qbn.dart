// lib: , url: Qbn

// class id: 1049642, size: 0x8
class :: {
}

// class id: 1777, size: 0x8, field offset: 0x8
//   const constructor, 
class yWa extends Object {
}

// class id: 7130, size: 0x14, field offset: 0x14
enum xWa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
