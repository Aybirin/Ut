// lib: , url: ZLm

// class id: 1048963, size: 0x8
class :: {
}

// class id: 3476, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class AQ extends Object {
}

// class id: 3477, size: 0x8, field offset: 0x8
//   const constructor, 
class BQ extends AQ {
}
