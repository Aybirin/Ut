// lib: , url: lln

// class id: 1050097, size: 0x8
class :: {
}

// class id: 1100, size: 0x1c, field offset: 0x8
class qkb extends Object
    implements okb {
}
