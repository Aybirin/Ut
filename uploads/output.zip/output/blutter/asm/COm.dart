// lib: , url: COm

// class id: 1049086, size: 0x8
class :: {
}

// class id: 3215, size: 0x2c, field offset: 0x28
class _bda extends cda {

  [closure] void pMe(dynamic, ZT) {
    // ** addr: 0x6813e4, size: -0x1
  }
}
