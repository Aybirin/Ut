// lib: , url: OSm

// class id: 1049307, size: 0x8
class :: {
}

// class id: 3555, size: 0x8, field offset: 0x8
abstract class rO extends Object
    implements Mca {
}
