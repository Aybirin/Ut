// lib: , url: gFm

// class id: 1048668, size: 0x8
class :: {
}

// class id: 6049, size: 0x10, field offset: 0x8
//   const constructor, 
class Qx extends Object {
}
