// lib: , url: Mvn

// class id: 1050592, size: 0x8
class :: {
}

// class id: 449, size: 0x8, field offset: 0x8
class yBb extends Object {
}
