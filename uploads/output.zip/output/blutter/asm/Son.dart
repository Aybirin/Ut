// lib: , url: Son

// class id: 1050275, size: 0x8
class :: {
}

// class id: 907, size: 0xc, field offset: 0x8
abstract class Fqb<X0> extends Object {
}
