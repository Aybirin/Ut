// lib: vCn, url: Bmn

// class id: 1050146, size: 0x8
class :: {
}

// class id: 1086, size: 0x20, field offset: 0x8
class amb extends blb {

  static late final fqb GEg; // offset: 0xeac
  late bool _RFg; // offset: 0x1c
  late Uint8List _XGg; // offset: 0x18
  late Uint8List _WGg; // offset: 0x14
  late Uint8List _UGg; // offset: 0xc
  late Uint8List _VGg; // offset: 0x10

  [closure] static (dynamic) => amb <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x41fcd4, size: -0x1
  }
  [closure] static amb <anonymous closure>(dynamic) {
    // ** addr: 0x41fd28, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x41fc70, size: -0x1
  }
}
