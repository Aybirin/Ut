// lib: , url: IIm

// class id: 1048846, size: 0x8
class :: {
}

// class id: 5594, size: 0xc, field offset: 0x8
class bG extends Object {

  dynamic value(dynamic) {
    // ** addr: 0xb32998, size: 0x3c
    // 0xb32998: EnterFrame
    //     0xb32998: stp             fp, lr, [SP, #-0x10]!
    //     0xb3299c: mov             fp, SP
    // 0xb329a0: ldr             x2, [fp, #0x10]
    // 0xb329a4: r1 = Function 'value':.
    //     0xb329a4: add             x1, PP, #0x34, lsl #12  ; [pp+0x347f8] AnonymousClosure: (0x3f5b48), of [IIm] bG
    //     0xb329a8: ldr             x1, [x1, #0x7f8]
    // 0xb329ac: r0 = AllocateClosure()
    //     0xb329ac: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb329b0: LeaveFrame
    //     0xb329b0: mov             SP, fp
    //     0xb329b4: ldp             fp, lr, [SP], #0x10
    // 0xb329b8: ret
    //     0xb329b8: ret             
  }
  void gk(bG, (dynamic, String, List<String>) => void) {
    // ** addr: 0xb32860, size: 0x6c
    // 0xb32860: EnterFrame
    //     0xb32860: stp             fp, lr, [SP, #-0x10]!
    //     0xb32864: mov             fp, SP
    // 0xb32868: CheckStackOverflow
    //     0xb32868: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb3286c: cmp             SP, x16
    //     0xb32870: b.ls            #0xb328ac
    // 0xb32874: ldr             x0, [fp, #0x10]
    // 0xb32878: r2 = Null
    //     0xb32878: mov             x2, NULL
    // 0xb3287c: r1 = Null
    //     0xb3287c: mov             x1, NULL
    // 0xb32880: r8 = (dynamic this, String, List<String>) => void?
    //     0xb32880: add             x8, PP, #0x34, lsl #12  ; [pp+0x347d0] FunctionType: (dynamic this, String, List<String>) => void?
    //     0xb32884: ldr             x8, [x8, #0x7d0]
    // 0xb32888: r3 = Null
    //     0xb32888: add             x3, PP, #0x34, lsl #12  ; [pp+0x347d8] Null
    //     0xb3288c: ldr             x3, [x3, #0x7d8]
    // 0xb32890: r0 = DefaultTypeTest()
    //     0xb32890: bl              #0xc5360c  ; DefaultTypeTestStub
    // 0xb32894: ldr             x1, [fp, #0x18]
    // 0xb32898: ldr             x2, [fp, #0x10]
    // 0xb3289c: r0 = call 0x3f594c
    //     0xb3289c: bl              #0x3f594c
    // 0xb328a0: LeaveFrame
    //     0xb328a0: mov             SP, fp
    //     0xb328a4: ldp             fp, lr, [SP], #0x10
    // 0xb328a8: ret
    //     0xb328a8: ret             
    // 0xb328ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb328ac: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb328b0: b               #0xb32874
  }
  bool dyn:get:isEmpty(bG) {
    // ** addr: 0xb328cc, size: 0x48
    // 0xb328cc: EnterFrame
    //     0xb328cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb328d0: mov             fp, SP
    // 0xb328d4: CheckStackOverflow
    //     0xb328d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb328d8: cmp             SP, x16
    //     0xb328dc: b.ls            #0xb328f4
    // 0xb328e0: ldr             x1, [fp, #0x10]
    // 0xb328e4: r0 = call 0x3f5a90
    //     0xb328e4: bl              #0x3f5a90
    // 0xb328e8: LeaveFrame
    //     0xb328e8: mov             SP, fp
    //     0xb328ec: ldp             fp, lr, [SP], #0x10
    // 0xb328f0: ret
    //     0xb328f0: ret             
    // 0xb328f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb328f4: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb328f8: b               #0xb328e0
  }
  List<String>? [](bG, String) {
    // ** addr: 0xb32914, size: 0x84
    // 0xb32914: EnterFrame
    //     0xb32914: stp             fp, lr, [SP, #-0x10]!
    //     0xb32918: mov             fp, SP
    // 0xb3291c: CheckStackOverflow
    //     0xb3291c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb32920: cmp             SP, x16
    //     0xb32924: b.ls            #0xb32978
    // 0xb32928: ldr             x0, [fp, #0x10]
    // 0xb3292c: r2 = Null
    //     0xb3292c: mov             x2, NULL
    // 0xb32930: r1 = Null
    //     0xb32930: mov             x1, NULL
    // 0xb32934: r4 = 60
    //     0xb32934: movz            x4, #0x3c
    // 0xb32938: branchIfSmi(r0, 0xb32944)
    //     0xb32938: tbz             w0, #0, #0xb32944
    // 0xb3293c: r4 = LoadClassIdInstr(r0)
    //     0xb3293c: ldur            x4, [x0, #-1]
    //     0xb32940: ubfx            x4, x4, #0xc, #0x14
    // 0xb32944: sub             x4, x4, #0x5e
    // 0xb32948: cmp             x4, #1
    // 0xb3294c: b.ls            #0xb32960
    // 0xb32950: r8 = String
    //     0xb32950: ldr             x8, [PP, #0x9c8]  ; [pp+0x9c8] Type: String
    // 0xb32954: r3 = Null
    //     0xb32954: add             x3, PP, #0x14, lsl #12  ; [pp+0x14300] Null
    //     0xb32958: ldr             x3, [x3, #0x300]
    // 0xb3295c: r0 = String()
    //     0xb3295c: bl              #0xc5a588  ; IsType_String_Stub
    // 0xb32960: ldr             x1, [fp, #0x18]
    // 0xb32964: ldr             x2, [fp, #0x10]
    // 0xb32968: r0 = call 0x3f5ae0
    //     0xb32968: bl              #0x3f5ae0
    // 0xb3296c: LeaveFrame
    //     0xb3296c: mov             SP, fp
    //     0xb32970: ldp             fp, lr, [SP], #0x10
    // 0xb32974: ret
    //     0xb32974: ret             
    // 0xb32978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb32978: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb3297c: b               #0xb32928
  }
  [closure] Ra<String, List<String>> <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x3f58f8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x8f9764, size: -0x1
  }
  [closure] String? value(dynamic, String) {
    // ** addr: 0x3f5b48, size: -0x1
  }
}
