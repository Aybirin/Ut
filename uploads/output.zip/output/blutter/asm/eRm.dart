// lib: , url: eRm

// class id: 1049218, size: 0x8
class :: {
}

// class id: 3731, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class rha extends _FM {
}
