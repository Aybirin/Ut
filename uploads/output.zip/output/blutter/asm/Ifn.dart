// lib: , url: Ifn

// class id: 1049838, size: 0x8
class :: {
}

// class id: 1499, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class reb extends Object {
}

// class id: 1500, size: 0x10, field offset: 0x8
//   const constructor, 
class teb extends reb {
}

// class id: 1501, size: 0xc, field offset: 0x8
//   const constructor, 
class seb extends reb {
}
