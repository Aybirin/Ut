// lib: , url: Tzn

// class id: 1050809, size: 0x8
class :: {
}

// class id: 7027, size: 0x14, field offset: 0x14
enum dLb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
