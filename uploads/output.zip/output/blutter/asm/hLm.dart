// lib: , url: hLm

// class id: 1048920, size: 0x8
class :: {
}

// class id: 5348, size: 0x8, field offset: 0x8
abstract class uq extends Object
    implements uq {
}
