// lib: , url: Hun

// class id: 1050539, size: 0x8
class :: {
}

// class id: 5563, size: 0x8, field offset: 0x8
abstract class Szb extends EG {
}
