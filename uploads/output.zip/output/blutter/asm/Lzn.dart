// lib: , url: Lzn

// class id: 1050801, size: 0x8
class :: {
}

// class id: 390, size: 0xc, field offset: 0x8
class ZKb extends Object
    implements WJ {

  [closure] void Wjc(dynamic) {
    // ** addr: 0x3af1a4, size: -0x1
  }
}
