// lib: , url: KQm

// class id: 1049199, size: 0x8
class :: {
}

// class id: 2777, size: 0xc, field offset: 0x8
class nna extends Object {
}

// class id: 3534, size: 0x10, field offset: 0x10
abstract class Hha extends dQ {
}
