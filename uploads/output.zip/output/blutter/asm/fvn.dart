// lib: , url: fvn

// class id: 1050563, size: 0x8
class :: {
}

// class id: 484, size: 0x10, field offset: 0x8
class JAb extends Object {

  static late final JAb get; // offset: 0x1ab8
  late final Ttb<Pea> hAj; // offset: 0xc

  [closure] Pea <anonymous closure>(dynamic) {
    // ** addr: 0x6d8890, size: -0x1
  }
  [closure] Nva <anonymous closure>(dynamic, iva) {
    // ** addr: 0x6db398, size: -0x1
  }
  Ttb<Pea> hAj(JAb) {
    // ** addr: 0x6d8588, size: -0x1
  }
}
