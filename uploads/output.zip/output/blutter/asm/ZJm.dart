// lib: WDn, url: ZJm

// class id: 1050201, size: 0x8
class :: {
}

// class id: 992, size: 0xc, field offset: 0xc
class nob extends hnb {

  static late final fqb GEg; // offset: 0x1030

  [closure] static nob <anonymous closure>(dynamic) {
    // ** addr: 0x40d998, size: -0x1
  }
  [closure] static nob _VJg(dynamic, String, enb, dnb, za, za, List<int>) {
    // ** addr: 0x40dab0, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40d940, size: -0x1
  }
}
