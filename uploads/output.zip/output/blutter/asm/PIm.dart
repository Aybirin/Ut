// lib: , url: PIm

// class id: 1048853, size: 0x8
class :: {
}

// class id: 5584, size: 0x8, field offset: 0x8
abstract class oG extends Object {

  [closure] static String <anonymous closure>(dynamic, String, Object?) {
    // ** addr: 0x3fab00, size: -0x1
  }
}
