// lib: , url: Mxn

// class id: 1050697, size: 0x8
class :: {
}

// class id: 4719, size: 0x10, field offset: 0xc
//   const constructor, 
class vGb extends Zu
    implements rO {

  [closure] Mca <anonymous closure>(dynamic, iva) {
    // ** addr: 0x864128, size: -0x1
  }
}
