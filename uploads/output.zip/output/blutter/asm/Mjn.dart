// lib: , url: Mjn

// class id: 1050044, size: 0x8
class :: {

  [closure] static Future<void> _beh(dynamic, WI, int, int) {
    // ** addr: 0xac2500, size: -0x1
  }
}

// class id: 1168, size: 0x10, field offset: 0x8
class _IJ extends Object {

  [closure] static bool <anonymous closure>(dynamic, cJ<dynamic, dynamic>) {
    // ** addr: 0x4549c8, size: -0x1
  }
}

// class id: 1169, size: 0x10, field offset: 0x10
class _djb extends _IJ {

  BJ Lk(_djb, tH, Map<String, Object?>) {
    // ** addr: 0xb71ecc, size: 0x6c
    // 0xb71ecc: EnterFrame
    //     0xb71ecc: stp             fp, lr, [SP, #-0x10]!
    //     0xb71ed0: mov             fp, SP
    // 0xb71ed4: CheckStackOverflow
    //     0xb71ed4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb71ed8: cmp             SP, x16
    //     0xb71edc: b.ls            #0xb71f18
    // 0xb71ee0: ldr             x0, [fp, #0x10]
    // 0xb71ee4: r2 = Null
    //     0xb71ee4: mov             x2, NULL
    // 0xb71ee8: r1 = Null
    //     0xb71ee8: mov             x1, NULL
    // 0xb71eec: r8 = Map<String, Object?>
    //     0xb71eec: ldr             x8, [PP, #0x75e0]  ; [pp+0x75e0] Type: Map<String, Object?>
    // 0xb71ef0: r3 = Null
    //     0xb71ef0: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b4d0] Null
    //     0xb71ef4: ldr             x3, [x3, #0x4d0]
    // 0xb71ef8: r0 = Map<String, Object?>()
    //     0xb71ef8: bl              #0xb11208  ; IsType_Map<String, Object?>_Stub
    // 0xb71efc: ldr             x1, [fp, #0x20]
    // 0xb71f00: ldr             x2, [fp, #0x18]
    // 0xb71f04: ldr             x3, [fp, #0x10]
    // 0xb71f08: r0 = call 0x454604
    //     0xb71f08: bl              #0x454604
    // 0xb71f0c: LeaveFrame
    //     0xb71f0c: mov             SP, fp
    //     0xb71f10: ldp             fp, lr, [SP], #0x10
    // 0xb71f14: ret
    //     0xb71f14: ret             
    // 0xb71f18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb71f18: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb71f1c: b               #0xb71ee0
  }
}

// class id: 1170, size: 0xc, field offset: 0x8
class BJ extends Object {
}

// class id: 1171, size: 0x10, field offset: 0x8
class uJ extends Object {
}

// class id: 1172, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class _bjb extends Object
     with rJ<X0> {

  rJ<Y0> Lk<Y0>(_bjb, (dynamic, uJ) => Y0) {
    // ** addr: 0xb2ad08, size: 0x84
    // 0xb2ad08: EnterFrame
    //     0xb2ad08: stp             fp, lr, [SP, #-0x10]!
    //     0xb2ad0c: mov             fp, SP
    // 0xb2ad10: AllocStack(0x8)
    //     0xb2ad10: sub             SP, SP, #8
    // 0xb2ad14: SetupParameters()
    //     0xb2ad14: ldur            w0, [x4, #0xf]
    //     0xb2ad18: cbnz            w0, #0xb2ad24
    //     0xb2ad1c: mov             x3, NULL
    //     0xb2ad20: b               #0xb2ad34
    //     0xb2ad24: ldur            w0, [x4, #0x17]
    //     0xb2ad28: add             x1, fp, w0, sxtw #2
    //     0xb2ad2c: ldr             x1, [x1, #0x10]
    //     0xb2ad30: mov             x3, x1
    // 0xb2ad34: ldr             x0, [fp, #0x10]
    // 0xb2ad38: mov             x1, x3
    // 0xb2ad3c: stur            x3, [fp, #-8]
    // 0xb2ad40: r2 = Null
    //     0xb2ad40: mov             x2, NULL
    // 0xb2ad44: r8 = (dynamic this, uJ) => Y0
    //     0xb2ad44: add             x8, PP, #0x3b, lsl #12  ; [pp+0x3b4e0] FunctionType: (dynamic this, uJ) => Y0
    //     0xb2ad48: ldr             x8, [x8, #0x4e0]
    // 0xb2ad4c: LoadField: r9 = r8->field_7
    //     0xb2ad4c: ldur            x9, [x8, #7]
    // 0xb2ad50: r3 = Null
    //     0xb2ad50: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b4e8] Null
    //     0xb2ad54: ldr             x3, [x3, #0x4e8]
    // 0xb2ad58: blr             x9
    // 0xb2ad5c: ldur            x1, [fp, #-8]
    // 0xb2ad60: r2 = Null
    //     0xb2ad60: mov             x2, NULL
    // 0xb2ad64: r3 = <Y0, uJ, Y0>
    //     0xb2ad64: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b4f8] TypeArguments: <Y0, uJ, Y0>
    //     0xb2ad68: ldr             x3, [x3, #0x4f8]
    // 0xb2ad6c: r30 = InstantiateTypeArgumentsStub
    //     0xb2ad6c: ldr             lr, [PP, #0x1f8]  ; [pp+0x1f8] Stub: InstantiateTypeArguments (0x340f10)
    // 0xb2ad70: LoadField: r30 = r30->field_7
    //     0xb2ad70: ldur            lr, [lr, #7]
    // 0xb2ad74: blr             lr
    // 0xb2ad78: mov             x1, x0
    // 0xb2ad7c: r0 = _sJ()
    //     0xb2ad7c: bl              #0xb29eac  ; Allocate_sJStub -> _sJ<C1X0, C1X1> (size=0xc)
    // 0xb2ad80: LeaveFrame
    //     0xb2ad80: mov             SP, fp
    //     0xb2ad84: ldp             fp, lr, [SP], #0x10
    // 0xb2ad88: ret
    //     0xb2ad88: ret             
  }
}

// class id: 1173, size: 0x14, field offset: 0x8
class cjb extends _bjb {

  [closure] List<uJ> _Qxi(dynamic, List<Map<String, Object?>>) {
    // ** addr: 0x3e1904, size: -0x1
  }
  [closure] uJ <anonymous closure>(dynamic, Map<String, Object?>) {
    // ** addr: 0x3e19f8, size: -0x1
  }
  [closure] Future<List<Map<String, Object?>>> <anonymous closure>(dynamic, JG) {
    // ** addr: 0x3e1640, size: -0x1
  }
  [closure] dynamic <anonymous closure>(dynamic, TI<Object>) {
    // ** addr: 0x3e174c, size: -0x1
  }
}

// class id: 1174, size: 0xc, field offset: 0x8
abstract class rJ<X0> extends Object
    implements oJ<X0>, pJ<X0>, qJ<X0> {

  rJ<Y0> Lk<Y0>(rJ<X0>, (dynamic, X0) => Y0) {
    // ** addr: 0xb29eb8, size: 0x98
    // 0xb29eb8: EnterFrame
    //     0xb29eb8: stp             fp, lr, [SP, #-0x10]!
    //     0xb29ebc: mov             fp, SP
    // 0xb29ec0: AllocStack(0x20)
    //     0xb29ec0: sub             SP, SP, #0x20
    // 0xb29ec4: SetupParameters([dynamic _, dynamic _ /* r3 */])
    //     0xb29ec4: ldur            w0, [x4, #0xf]
    //     0xb29ec8: cbnz            w0, #0xb29ed4
    //     0xb29ecc: mov             x4, NULL
    //     0xb29ed0: b               #0xb29ee4
    //     0xb29ed4: ldur            w0, [x4, #0x17]
    //     0xb29ed8: add             x1, fp, w0, sxtw #2
    //     0xb29edc: ldr             x1, [x1, #0x10]
    //     0xb29ee0: mov             x4, x1
    //     0xb29ee4: ldr             x3, [fp, #0x18]
    //     0xb29ee8: stur            x4, [fp, #-8]
    // 0xb29eec: CheckStackOverflow
    //     0xb29eec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb29ef0: cmp             SP, x16
    //     0xb29ef4: b.ls            #0xb29f48
    // 0xb29ef8: LoadField: r2 = r3->field_7
    //     0xb29ef8: ldur            w2, [x3, #7]
    // 0xb29efc: DecompressPointer r2
    //     0xb29efc: add             x2, x2, HEAP, lsl #32
    // 0xb29f00: ldr             x0, [fp, #0x10]
    // 0xb29f04: mov             x1, x4
    // 0xb29f08: r8 = (dynamic this, X0) => Y0
    //     0xb29f08: add             x8, PP, #0x43, lsl #12  ; [pp+0x43760] FunctionType: (dynamic this, X0) => Y0
    //     0xb29f0c: ldr             x8, [x8, #0x760]
    // 0xb29f10: LoadField: r9 = r8->field_7
    //     0xb29f10: ldur            x9, [x8, #7]
    // 0xb29f14: r3 = Null
    //     0xb29f14: add             x3, PP, #0x43, lsl #12  ; [pp+0x43768] Null
    //     0xb29f18: ldr             x3, [x3, #0x768]
    // 0xb29f1c: blr             x9
    // 0xb29f20: ldur            x16, [fp, #-8]
    // 0xb29f24: ldr             lr, [fp, #0x18]
    // 0xb29f28: stp             lr, x16, [SP, #8]
    // 0xb29f2c: ldr             x16, [fp, #0x10]
    // 0xb29f30: str             x16, [SP]
    // 0xb29f34: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb29f34: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb29f38: r0 = call 0x3df954
    //     0xb29f38: bl              #0x3df954
    // 0xb29f3c: LeaveFrame
    //     0xb29f3c: mov             SP, fp
    //     0xb29f40: ldp             fp, lr, [SP], #0x10
    // 0xb29f44: ret
    //     0xb29f44: ret             
    // 0xb29f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29f48: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29f4c: b               #0xb29ef8
  }
}

// class id: 1175, size: 0xc, field offset: 0xc
class _sJ<C1X0, C1X1> extends rJ<C1X0> {
}

// class id: 1176, size: 0xc, field offset: 0x8
abstract class qJ<X0> extends Object {
}

// class id: 1177, size: 0xc, field offset: 0x8
abstract class pJ<X0> extends Object {
}

// class id: 1178, size: 0xc, field offset: 0x8
abstract class oJ<X0> extends Object {
}

// class id: 1179, size: 0xc, field offset: 0x8
abstract class mJ<X0 bound EG, X1> extends Object {
}

// class id: 1180, size: 0x14, field offset: 0x8
class kJ<X0 bound EG, X1> extends Object {

  [closure] Future<int> <anonymous closure>(dynamic, JG) async {
    // ** addr: 0xb3922c, size: 0x1bc
    // 0xb3922c: EnterFrame
    //     0xb3922c: stp             fp, lr, [SP, #-0x10]!
    //     0xb39230: mov             fp, SP
    // 0xb39234: AllocStack(0x38)
    //     0xb39234: sub             SP, SP, #0x38
    // 0xb39238: SetupParameters(kJ<X0 bound EG, X1> this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xb39238: stur            NULL, [fp, #-8]
    //     0xb3923c: movz            x0, #0
    //     0xb39240: add             x1, fp, w0, sxtw #2
    //     0xb39244: ldr             x1, [x1, #0x18]
    //     0xb39248: add             x2, fp, w0, sxtw #2
    //     0xb3924c: ldr             x2, [x2, #0x10]
    //     0xb39250: stur            x2, [fp, #-0x18]
    //     0xb39254: ldur            w3, [x1, #0x17]
    //     0xb39258: add             x3, x3, HEAP, lsl #32
    //     0xb3925c: stur            x3, [fp, #-0x10]
    // 0xb39260: CheckStackOverflow
    //     0xb39260: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb39264: cmp             SP, x16
    //     0xb39268: b.ls            #0xb393e0
    // 0xb3926c: InitAsync() -> Future<int>
    //     0xb3926c: ldr             x0, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    //     0xb39270: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb39274: ldur            x0, [fp, #-0x10]
    // 0xb39278: LoadField: r1 = r0->field_13
    //     0xb39278: ldur            w1, [x0, #0x13]
    // 0xb3927c: DecompressPointer r1
    //     0xb3927c: add             x1, x1, HEAP, lsl #32
    // 0xb39280: stur            x1, [fp, #-0x20]
    // 0xb39284: LoadField: r2 = r1->field_2b
    //     0xb39284: ldur            w2, [x1, #0x2b]
    // 0xb39288: DecompressPointer r2
    //     0xb39288: add             x2, x2, HEAP, lsl #32
    // 0xb3928c: str             x2, [SP]
    // 0xb39290: r0 = call 0x8d76dc
    //     0xb39290: bl              #0x8d76dc
    // 0xb39294: mov             x1, x0
    // 0xb39298: ldur            x0, [fp, #-0x20]
    // 0xb3929c: LoadField: r3 = r0->field_23
    //     0xb3929c: ldur            w3, [x0, #0x23]
    // 0xb392a0: DecompressPointer r3
    //     0xb392a0: add             x3, x3, HEAP, lsl #32
    // 0xb392a4: ldur            x0, [fp, #-0x18]
    // 0xb392a8: r2 = LoadClassIdInstr(r0)
    //     0xb392a8: ldur            x2, [x0, #-1]
    //     0xb392ac: ubfx            x2, x2, #0xc, #0x14
    // 0xb392b0: mov             x16, x1
    // 0xb392b4: mov             x1, x2
    // 0xb392b8: mov             x2, x16
    // 0xb392bc: mov             x16, x0
    // 0xb392c0: mov             x0, x1
    // 0xb392c4: mov             x1, x16
    // 0xb392c8: r0 = GDT[cid_x0 + -0xe50]()
    //     0xb392c8: sub             lr, x0, #0xe50
    //     0xb392cc: ldr             lr, [x21, lr, lsl #3]
    //     0xb392d0: blr             lr
    // 0xb392d4: mov             x1, x0
    // 0xb392d8: stur            x1, [fp, #-0x18]
    // 0xb392dc: r0 = Await()
    //     0xb392dc: bl              #0xb0c534  ; AwaitStub
    // 0xb392e0: mov             x1, x0
    // 0xb392e4: ldur            x0, [fp, #-0x10]
    // 0xb392e8: stur            x1, [fp, #-0x20]
    // 0xb392ec: LoadField: r2 = r0->field_f
    //     0xb392ec: ldur            w2, [x0, #0xf]
    // 0xb392f0: DecompressPointer r2
    //     0xb392f0: add             x2, x2, HEAP, lsl #32
    // 0xb392f4: LoadField: r3 = r2->field_b
    //     0xb392f4: ldur            w3, [x2, #0xb]
    // 0xb392f8: DecompressPointer r3
    //     0xb392f8: add             x3, x3, HEAP, lsl #32
    // 0xb392fc: stur            x3, [fp, #-0x18]
    // 0xb39300: r0 = InitLateStaticField(0x3c4) // [dart:_compact_hash] ::_Dhc
    //     0xb39300: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb39304: ldr             x0, [x0, #0x788]
    //     0xb39308: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb3930c: cmp             w0, w16
    //     0xb39310: b.ne            #0xb3931c
    //     0xb39314: ldr             x2, [PP, #0x18d8]  ; [pp+0x18d8] Field <::._Dhc@3099033>: static late final (offset: 0x3c4)
    //     0xb39318: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb3931c: r1 = <yH>
    //     0xb3931c: add             x1, PP, #0x29, lsl #12  ; [pp+0x294d0] TypeArguments: <yH>
    //     0xb39320: ldr             x1, [x1, #0x4d0]
    // 0xb39324: stur            x0, [fp, #-0x28]
    // 0xb39328: r0 = _Set()
    //     0xb39328: bl              #0xb14d6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xb3932c: mov             x1, x0
    // 0xb39330: ldur            x0, [fp, #-0x28]
    // 0xb39334: stur            x1, [fp, #-0x30]
    // 0xb39338: StoreField: r1->field_1b = r0
    //     0xb39338: stur            w0, [x1, #0x1b]
    // 0xb3933c: StoreField: r1->field_b = rZR
    //     0xb3933c: stur            wzr, [x1, #0xb]
    // 0xb39340: r0 = InitLateStaticField(0x3c8) // [dart:_compact_hash] ::_Ehc
    //     0xb39340: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb39344: ldr             x0, [x0, #0x790]
    //     0xb39348: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb3934c: cmp             w0, w16
    //     0xb39350: b.ne            #0xb3935c
    //     0xb39354: ldr             x2, [PP, #0x18e8]  ; [pp+0x18e8] Field <::._Ehc@3099033>: static late final (offset: 0x3c8)
    //     0xb39358: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb3935c: ldur            x2, [fp, #-0x30]
    // 0xb39360: StoreField: r2->field_f = r0
    //     0xb39360: stur            w0, [x2, #0xf]
    // 0xb39364: StoreField: r2->field_13 = rZR
    //     0xb39364: stur            wzr, [x2, #0x13]
    // 0xb39368: ArrayStore: r2[0] = rZR  ; List_4
    //     0xb39368: stur            wzr, [x2, #0x17]
    // 0xb3936c: ldur            x0, [fp, #-0x10]
    // 0xb39370: LoadField: r1 = r0->field_f
    //     0xb39370: ldur            w1, [x0, #0xf]
    // 0xb39374: DecompressPointer r1
    //     0xb39374: add             x1, x1, HEAP, lsl #32
    // 0xb39378: LoadField: r0 = r1->field_f
    //     0xb39378: ldur            w0, [x1, #0xf]
    // 0xb3937c: DecompressPointer r0
    //     0xb3937c: add             x0, x0, HEAP, lsl #32
    // 0xb39380: r1 = LoadClassIdInstr(r0)
    //     0xb39380: ldur            x1, [x0, #-1]
    //     0xb39384: ubfx            x1, x1, #0xc, #0x14
    // 0xb39388: mov             x16, x0
    // 0xb3938c: mov             x0, x1
    // 0xb39390: mov             x1, x16
    // 0xb39394: r0 = GDT[cid_x0 + -0xd80]()
    //     0xb39394: sub             lr, x0, #0xd80
    //     0xb39398: ldr             lr, [x21, lr, lsl #3]
    //     0xb3939c: blr             lr
    // 0xb393a0: stur            x0, [fp, #-0x10]
    // 0xb393a4: r0 = yH()
    //     0xb393a4: bl              #0xb38be8  ; AllocateyHStub -> yH (size=0x10)
    // 0xb393a8: mov             x1, x0
    // 0xb393ac: ldur            x0, [fp, #-0x10]
    // 0xb393b0: StoreField: r1->field_b = r0
    //     0xb393b0: stur            w0, [x1, #0xb]
    // 0xb393b4: r0 = Instance_xH
    //     0xb393b4: add             x0, PP, #0x29, lsl #12  ; [pp+0x294b8] Obj!xH@6973a1
    //     0xb393b8: ldr             x0, [x0, #0x4b8]
    // 0xb393bc: StoreField: r1->field_7 = r0
    //     0xb393bc: stur            w0, [x1, #7]
    // 0xb393c0: mov             x2, x1
    // 0xb393c4: ldur            x1, [fp, #-0x30]
    // 0xb393c8: r0 = call 0xa181a4
    //     0xb393c8: bl              #0xa181a4
    // 0xb393cc: ldur            x1, [fp, #-0x18]
    // 0xb393d0: ldur            x2, [fp, #-0x30]
    // 0xb393d4: r0 = call 0x42cc84
    //     0xb393d4: bl              #0x42cc84
    // 0xb393d8: ldur            x0, [fp, #-0x20]
    // 0xb393dc: r0 = ReturnAsync()
    //     0xb393dc: b               #0xb13694  ; ReturnAsyncStub
    // 0xb393e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb393e0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb393e4: b               #0xb3926c
  }
}

// class id: 1181, size: 0x8, field offset: 0x8
abstract class aJ extends Object {
}

// class id: 1182, size: 0xc, field offset: 0x8
abstract class cJ<X0, X1> extends aJ {
}

// class id: 1184, size: 0x14, field offset: 0x8
//   const constructor, 
class XI extends Object {
}

// class id: 1185, size: 0x10, field offset: 0x8
class WI extends Object {
}

// class id: 1186, size: 0x14, field offset: 0x8
class VI extends Object {
}

// class id: 1187, size: 0x30, field offset: 0x8
class UI extends Object {

  [closure] String sIc(dynamic, String) {
    // ** addr: 0x42dcb8, size: -0x1
  }
}

// class id: 1188, size: 0x8, field offset: 0x8
abstract class LI extends Object
    implements xI {
}

// class id: 1189, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class xI extends Object {
}

// class id: 1190, size: 0xc, field offset: 0x8
//   const constructor, transformed mixin,
abstract class _vJ<X0> extends xI
     with rJ<X0> {
}

// class id: 1191, size: 0xc, field offset: 0xc
abstract class wJ<X0> extends _vJ<X0> {
}

// class id: 1192, size: 0x28, field offset: 0x8
abstract class iJ<X0 bound DG, X1> extends xI {
}

// class id: 1193, size: 0x28, field offset: 0x28
//   transformed mixin,
abstract class _CJ<X0 bound DG, X1> extends iJ<X0 bound DG, X1>
     with tJ<X0 bound DG, X1> {
}

// class id: 1194, size: 0x28, field offset: 0x28
//   transformed mixin,
abstract class _FJ<X0 bound DG, X1> extends _CJ<X0 bound DG, X1>
     with rJ<X0> {

  rJ<Y0> Lk<Y0>(_FJ<X0, X1>, (dynamic, BJ) => Y0) {
    // ** addr: 0xb727cc, size: 0x84
    // 0xb727cc: EnterFrame
    //     0xb727cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb727d0: mov             fp, SP
    // 0xb727d4: AllocStack(0x8)
    //     0xb727d4: sub             SP, SP, #8
    // 0xb727d8: SetupParameters()
    //     0xb727d8: ldur            w0, [x4, #0xf]
    //     0xb727dc: cbnz            w0, #0xb727e8
    //     0xb727e0: mov             x3, NULL
    //     0xb727e4: b               #0xb727f8
    //     0xb727e8: ldur            w0, [x4, #0x17]
    //     0xb727ec: add             x1, fp, w0, sxtw #2
    //     0xb727f0: ldr             x1, [x1, #0x10]
    //     0xb727f4: mov             x3, x1
    // 0xb727f8: ldr             x0, [fp, #0x10]
    // 0xb727fc: mov             x1, x3
    // 0xb72800: stur            x3, [fp, #-8]
    // 0xb72804: r2 = Null
    //     0xb72804: mov             x2, NULL
    // 0xb72808: r8 = (dynamic this, BJ) => Y0
    //     0xb72808: add             x8, PP, #0x3b, lsl #12  ; [pp+0x3b4b0] FunctionType: (dynamic this, BJ) => Y0
    //     0xb7280c: ldr             x8, [x8, #0x4b0]
    // 0xb72810: LoadField: r9 = r8->field_7
    //     0xb72810: ldur            x9, [x8, #7]
    // 0xb72814: r3 = Null
    //     0xb72814: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b4b8] Null
    //     0xb72818: ldr             x3, [x3, #0x4b8]
    // 0xb7281c: blr             x9
    // 0xb72820: ldur            x1, [fp, #-8]
    // 0xb72824: r2 = Null
    //     0xb72824: mov             x2, NULL
    // 0xb72828: r3 = <Y0, BJ, Y0>
    //     0xb72828: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b4c8] TypeArguments: <Y0, BJ, Y0>
    //     0xb7282c: ldr             x3, [x3, #0x4c8]
    // 0xb72830: r30 = InstantiateTypeArgumentsStub
    //     0xb72830: ldr             lr, [PP, #0x1f8]  ; [pp+0x1f8] Stub: InstantiateTypeArguments (0x340f10)
    // 0xb72834: LoadField: r30 = r30->field_7
    //     0xb72834: ldur            lr, [lr, #7]
    // 0xb72838: blr             lr
    // 0xb7283c: mov             x1, x0
    // 0xb72840: r0 = _sJ()
    //     0xb72840: bl              #0xb29eac  ; Allocate_sJStub -> _sJ<C1X0, C1X1> (size=0xc)
    // 0xb72844: LeaveFrame
    //     0xb72844: mov             SP, fp
    //     0xb72848: ldp             fp, lr, [SP], #0x10
    // 0xb7284c: ret
    //     0xb7284c: ret             
  }
}

// class id: 1195, size: 0x40, field offset: 0x28
class GJ<X0 bound DG, X1> extends _FJ<X0 bound DG, X1>
    implements wJ<X0> {

  [closure] Future<List<Map<String, Object?>>> <anonymous closure>(dynamic, JG) async {
    // ** addr: 0xb728e8, size: 0x2ec
    // 0xb728e8: EnterFrame
    //     0xb728e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb728ec: mov             fp, SP
    // 0xb728f0: AllocStack(0xa8)
    //     0xb728f0: sub             SP, SP, #0xa8
    // 0xb728f4: SetupParameters(GJ<X0 bound DG, X1> this /* r1, fp-0x80 */, dynamic _ /* r2, fp-0x78 */)
    //     0xb728f4: stur            NULL, [fp, #-8]
    //     0xb728f8: movz            x0, #0
    //     0xb728fc: add             x1, fp, w0, sxtw #2
    //     0xb72900: ldr             x1, [x1, #0x18]
    //     0xb72904: stur            x1, [fp, #-0x80]
    //     0xb72908: add             x2, fp, w0, sxtw #2
    //     0xb7290c: ldr             x2, [x2, #0x10]
    //     0xb72910: stur            x2, [fp, #-0x78]
    //     0xb72914: ldur            w3, [x1, #0x17]
    //     0xb72918: add             x3, x3, HEAP, lsl #32
    //     0xb7291c: stur            x3, [fp, #-0x70]
    // 0xb72920: CheckStackOverflow
    //     0xb72920: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb72924: cmp             SP, x16
    //     0xb72928: b.ls            #0xb72bc4
    // 0xb7292c: InitAsync() -> Future<List<Map<String, Object?>>>
    //     0xb7292c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd658] TypeArguments: <List<Map<String, Object?>>>
    //     0xb72930: ldr             x0, [x0, #0x658]
    //     0xb72934: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb72938: ldur            x1, [fp, #-0x78]
    // 0xb7293c: ldur            x0, [fp, #-0x70]
    // 0xb72940: LoadField: r2 = r0->field_13
    //     0xb72940: ldur            w2, [x0, #0x13]
    // 0xb72944: DecompressPointer r2
    //     0xb72944: add             x2, x2, HEAP, lsl #32
    // 0xb72948: stur            x2, [fp, #-0x80]
    // 0xb7294c: LoadField: r3 = r2->field_2b
    //     0xb7294c: ldur            w3, [x2, #0x2b]
    // 0xb72950: DecompressPointer r3
    //     0xb72950: add             x3, x3, HEAP, lsl #32
    // 0xb72954: str             x3, [SP]
    // 0xb72958: r0 = call 0x8d76dc
    //     0xb72958: bl              #0x8d76dc
    // 0xb7295c: ldur            x4, [fp, #-0x70]
    // 0xb72960: LoadField: r1 = r4->field_13
    //     0xb72960: ldur            w1, [x4, #0x13]
    // 0xb72964: DecompressPointer r1
    //     0xb72964: add             x1, x1, HEAP, lsl #32
    // 0xb72968: LoadField: r3 = r1->field_23
    //     0xb72968: ldur            w3, [x1, #0x23]
    // 0xb7296c: DecompressPointer r3
    //     0xb7296c: add             x3, x3, HEAP, lsl #32
    // 0xb72970: ldur            x1, [fp, #-0x78]
    // 0xb72974: r2 = LoadClassIdInstr(r1)
    //     0xb72974: ldur            x2, [x1, #-1]
    //     0xb72978: ubfx            x2, x2, #0xc, #0x14
    // 0xb7297c: mov             x16, x0
    // 0xb72980: mov             x0, x2
    // 0xb72984: mov             x2, x16
    // 0xb72988: r0 = GDT[cid_x0 + -0xfb4]()
    //     0xb72988: sub             lr, x0, #0xfb4
    //     0xb7298c: ldr             lr, [x21, lr, lsl #3]
    //     0xb72990: blr             lr
    // 0xb72994: mov             x1, x0
    // 0xb72998: stur            x1, [fp, #-0x78]
    // 0xb7299c: r0 = Await()
    //     0xb7299c: bl              #0xb0c534  ; AwaitStub
    // 0xb729a0: r0 = ReturnAsync()
    //     0xb729a0: b               #0xb13694  ; ReturnAsyncStub
    // 0xb729a4: sub             SP, fp, #0xa8
    // 0xb729a8: stur            x0, [fp, #-0x70]
    // 0xb729ac: stur            x1, [fp, #-0x78]
    // 0xb729b0: r0 = InitLateStaticField(0x3c4) // [dart:_compact_hash] ::_Dhc
    //     0xb729b0: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb729b4: ldr             x0, [x0, #0x788]
    //     0xb729b8: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb729bc: cmp             w0, w16
    //     0xb729c0: b.ne            #0xb729cc
    //     0xb729c4: ldr             x2, [PP, #0x18d8]  ; [pp+0x18d8] Field <::._Dhc@3099033>: static late final (offset: 0x3c4)
    //     0xb729c8: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb729cc: r1 = <String>
    //     0xb729cc: ldr             x1, [PP, #0x928]  ; [pp+0x928] TypeArguments: <String>
    // 0xb729d0: stur            x0, [fp, #-0x80]
    // 0xb729d4: r0 = _Set()
    //     0xb729d4: bl              #0xb14d6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xb729d8: mov             x1, x0
    // 0xb729dc: ldur            x0, [fp, #-0x80]
    // 0xb729e0: stur            x1, [fp, #-0x88]
    // 0xb729e4: StoreField: r1->field_1b = r0
    //     0xb729e4: stur            w0, [x1, #0x1b]
    // 0xb729e8: StoreField: r1->field_b = rZR
    //     0xb729e8: stur            wzr, [x1, #0xb]
    // 0xb729ec: r0 = InitLateStaticField(0x3c8) // [dart:_compact_hash] ::_Ehc
    //     0xb729ec: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb729f0: ldr             x0, [x0, #0x790]
    //     0xb729f4: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb729f8: cmp             w0, w16
    //     0xb729fc: b.ne            #0xb72a08
    //     0xb72a00: ldr             x2, [PP, #0x18e8]  ; [pp+0x18e8] Field <::._Ehc@3099033>: static late final (offset: 0x3c8)
    //     0xb72a04: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb72a08: mov             x1, x0
    // 0xb72a0c: ldur            x0, [fp, #-0x88]
    // 0xb72a10: StoreField: r0->field_f = r1
    //     0xb72a10: stur            w1, [x0, #0xf]
    // 0xb72a14: StoreField: r0->field_13 = rZR
    //     0xb72a14: stur            wzr, [x0, #0x13]
    // 0xb72a18: ArrayStore: r0[0] = rZR  ; List_4
    //     0xb72a18: stur            wzr, [x0, #0x17]
    // 0xb72a1c: ldur            x1, [fp, #-0x28]
    // 0xb72a20: LoadField: r2 = r1->field_f
    //     0xb72a20: ldur            w2, [x1, #0xf]
    // 0xb72a24: DecompressPointer r2
    //     0xb72a24: add             x2, x2, HEAP, lsl #32
    // 0xb72a28: mov             x1, x2
    // 0xb72a2c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb72a2c: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb72a30: r0 = __unknown_function__()
    //     0xb72a30: bl              #0xb71fb0  ; [] ::__unknown_function__
    // 0xb72a34: mov             x1, x0
    // 0xb72a38: r0 = call 0x5b4318
    //     0xb72a38: bl              #0x5b4318
    // 0xb72a3c: stur            x0, [fp, #-0x90]
    // 0xb72a40: LoadField: r2 = r0->field_7
    //     0xb72a40: ldur            w2, [x0, #7]
    // 0xb72a44: DecompressPointer r2
    //     0xb72a44: add             x2, x2, HEAP, lsl #32
    // 0xb72a48: stur            x2, [fp, #-0x80]
    // 0xb72a4c: CheckStackOverflow
    //     0xb72a4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb72a50: cmp             SP, x16
    //     0xb72a54: b.ls            #0xb72bcc
    // 0xb72a58: mov             x1, x0
    // 0xb72a5c: r0 = __unknown_function__()
    //     0xb72a5c: bl              #0xb119c8  ; [] ::__unknown_function__
    // 0xb72a60: tbnz            w0, #4, #0xb72bb0
    // 0xb72a64: ldur            x3, [fp, #-0x90]
    // 0xb72a68: ArrayLoad: r4 = r3[0]  ; List_4
    //     0xb72a68: ldur            w4, [x3, #0x17]
    // 0xb72a6c: DecompressPointer r4
    //     0xb72a6c: add             x4, x4, HEAP, lsl #32
    // 0xb72a70: stur            x4, [fp, #-0x98]
    // 0xb72a74: cmp             w4, NULL
    // 0xb72a78: b.ne            #0xb72aac
    // 0xb72a7c: mov             x0, x4
    // 0xb72a80: ldur            x2, [fp, #-0x80]
    // 0xb72a84: r1 = Null
    //     0xb72a84: mov             x1, NULL
    // 0xb72a88: cmp             w2, NULL
    // 0xb72a8c: b.eq            #0xb72aac
    // 0xb72a90: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb72a90: ldur            w4, [x2, #0x17]
    // 0xb72a94: DecompressPointer r4
    //     0xb72a94: add             x4, x4, HEAP, lsl #32
    // 0xb72a98: r8 = X0
    //     0xb72a98: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xb72a9c: LoadField: r9 = r4->field_7
    //     0xb72a9c: ldur            x9, [x4, #7]
    // 0xb72aa0: r3 = Null
    //     0xb72aa0: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2ceb0] Null
    //     0xb72aa4: ldr             x3, [x3, #0xeb0]
    // 0xb72aa8: blr             x9
    // 0xb72aac: ldur            x2, [fp, #-0x98]
    // 0xb72ab0: r0 = LoadClassIdInstr(r2)
    //     0xb72ab0: ldur            x0, [x2, #-1]
    //     0xb72ab4: ubfx            x0, x0, #0xc, #0x14
    // 0xb72ab8: mov             x1, x2
    // 0xb72abc: r0 = GDT[cid_x0 + -0x1000]()
    //     0xb72abc: sub             lr, x0, #1, lsl #12
    //     0xb72ac0: ldr             lr, [x21, lr, lsl #3]
    //     0xb72ac4: blr             lr
    // 0xb72ac8: stur            x0, [fp, #-0xa0]
    // 0xb72acc: str             x0, [SP]
    // 0xb72ad0: r0 = hashCode()
    //     0xb72ad0: bl              #0xc24070  ; [dart:core] _OneByteString::hashCode
    // 0xb72ad4: r3 = LoadInt32Instr(r0)
    //     0xb72ad4: sbfx            x3, x0, #1, #0x1f
    //     0xb72ad8: tbz             w0, #0, #0xb72ae0
    //     0xb72adc: ldur            x3, [x0, #7]
    // 0xb72ae0: ldur            x1, [fp, #-0x88]
    // 0xb72ae4: ldur            x2, [fp, #-0xa0]
    // 0xb72ae8: r0 = call 0x42e4b4
    //     0xb72ae8: bl              #0x42e4b4
    // 0xb72aec: tbnz            w0, #4, #0xb72afc
    // 0xb72af0: ldur            x0, [fp, #-0x90]
    // 0xb72af4: ldur            x2, [fp, #-0x80]
    // 0xb72af8: b               #0xb72a4c
    // 0xb72afc: ldur            x4, [fp, #-0x70]
    // 0xb72b00: ldur            x3, [fp, #-0x78]
    // 0xb72b04: ldur            x0, [fp, #-0x98]
    // 0xb72b08: r1 = Null
    //     0xb72b08: mov             x1, NULL
    // 0xb72b0c: r2 = 6
    //     0xb72b0c: movz            x2, #0x6
    // 0xb72b10: r0 = AllocateArray()
    //     0xb72b10: bl              #0xc55848  ; AllocateArrayStub
    // 0xb72b14: mov             x2, x0
    // 0xb72b18: stur            x2, [fp, #-0x80]
    // 0xb72b1c: r16 = "This query contained the table "
    //     0xb72b1c: add             x16, PP, #0xd, lsl #12  ; [pp+0xde30] "This query contained the table "
    //     0xb72b20: ldr             x16, [x16, #0xe30]
    // 0xb72b24: StoreField: r2->field_f = r16
    //     0xb72b24: stur            w16, [x2, #0xf]
    // 0xb72b28: ldur            x1, [fp, #-0x98]
    // 0xb72b2c: r0 = LoadClassIdInstr(r1)
    //     0xb72b2c: ldur            x0, [x1, #-1]
    //     0xb72b30: ubfx            x0, x0, #0xc, #0x14
    // 0xb72b34: r0 = GDT[cid_x0 + -0xfd9]()
    //     0xb72b34: sub             lr, x0, #0xfd9
    //     0xb72b38: ldr             lr, [x21, lr, lsl #3]
    //     0xb72b3c: blr             lr
    // 0xb72b40: ldur            x1, [fp, #-0x80]
    // 0xb72b44: ArrayStore: r1[1] = r0  ; List_4
    //     0xb72b44: add             x25, x1, #0x13
    //     0xb72b48: str             w0, [x25]
    //     0xb72b4c: tbz             w0, #0, #0xb72b68
    //     0xb72b50: ldurb           w16, [x1, #-1]
    //     0xb72b54: ldurb           w17, [x0, #-1]
    //     0xb72b58: and             x16, x17, x16, lsr #2
    //     0xb72b5c: tst             x16, HEAP, lsr #32
    //     0xb72b60: b.eq            #0xb72b68
    //     0xb72b64: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xb72b68: ldur            x0, [fp, #-0x80]
    // 0xb72b6c: r16 = " more than once. Is this a typo\? \nIf you need a join that includes the same table more than once, you need to alias() at least one table. See https://drift.simonbinder.eu/queries/joins#aliases for an example."
    //     0xb72b6c: add             x16, PP, #0xd, lsl #12  ; [pp+0xde38] " more than once. Is this a typo\? \nIf you need a join that includes the same table more than once, you need to alias() at least one table. See https://drift.simonbinder.eu/queries/joins#aliases for an example."
    //     0xb72b70: ldr             x16, [x16, #0xe38]
    // 0xb72b74: ArrayStore: r0[0] = r16  ; List_4
    //     0xb72b74: stur            w16, [x0, #0x17]
    // 0xb72b78: str             x0, [SP]
    // 0xb72b7c: r0 = _interpolate()
    //     0xb72b7c: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xb72b80: stur            x0, [fp, #-0x80]
    // 0xb72b84: r0 = NH()
    //     0xb72b84: bl              #0xb72bd4  ; AllocateNHStub -> NH (size=0x14)
    // 0xb72b88: mov             x1, x0
    // 0xb72b8c: ldur            x0, [fp, #-0x80]
    // 0xb72b90: StoreField: r1->field_7 = r0
    //     0xb72b90: stur            w0, [x1, #7]
    // 0xb72b94: ldur            x0, [fp, #-0x70]
    // 0xb72b98: StoreField: r1->field_b = r0
    //     0xb72b98: stur            w0, [x1, #0xb]
    // 0xb72b9c: ldur            x2, [fp, #-0x78]
    // 0xb72ba0: StoreField: r1->field_f = r2
    //     0xb72ba0: stur            w2, [x1, #0xf]
    // 0xb72ba4: mov             x0, x1
    // 0xb72ba8: r0 = Throw()
    //     0xb72ba8: bl              #0xc53a04  ; ThrowStub
    // 0xb72bac: brk             #0
    // 0xb72bb0: ldur            x0, [fp, #-0x70]
    // 0xb72bb4: ldur            x2, [fp, #-0x78]
    // 0xb72bb8: mov             x1, x2
    // 0xb72bbc: r0 = ReThrow()
    //     0xb72bbc: bl              #0xc539d8  ; ReThrowStub
    // 0xb72bc0: brk             #0
    // 0xb72bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb72bc4: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb72bc8: b               #0xb7292c
    // 0xb72bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb72bcc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb72bd0: b               #0xb72a58
  }
  [closure] List<BJ> <anonymous closure>(dynamic) {
    // ** addr: 0x454aec, size: -0x1
  }
  [closure] Future<BJ> <anonymous closure>(dynamic, Map<String, Object?>) {
    // ** addr: 0x454a90, size: -0x1
  }
  [closure] String <anonymous closure>(dynamic) {
    // ** addr: 0x454f68, size: -0x1
  }
}

// class id: 1196, size: 0x28, field offset: 0x28
//   transformed mixin,
abstract class _xJ<X0 bound DG, X1> extends iJ<X0 bound DG, X1>
     with jJ<X0 bound DG, X1> {
}

// class id: 1197, size: 0x28, field offset: 0x28
//   transformed mixin,
abstract class _yJ<X0 bound DG, X1> extends _xJ<X0 bound DG, X1>
     with tJ<X0 bound DG, X1> {
}

// class id: 1198, size: 0x28, field offset: 0x28
//   transformed mixin,
abstract class _zJ<X0 bound DG, X1> extends _yJ<X0 bound DG, X1>
     with rJ<X0> {

  rJ<Y0> Lk<Y0>(_zJ<X0, X1>, (dynamic, X1) => Y0) {
    // ** addr: 0xb29e14, size: 0x98
    // 0xb29e14: EnterFrame
    //     0xb29e14: stp             fp, lr, [SP, #-0x10]!
    //     0xb29e18: mov             fp, SP
    // 0xb29e1c: AllocStack(0x20)
    //     0xb29e1c: sub             SP, SP, #0x20
    // 0xb29e20: SetupParameters([dynamic _, dynamic _ /* r3 */])
    //     0xb29e20: ldur            w0, [x4, #0xf]
    //     0xb29e24: cbnz            w0, #0xb29e30
    //     0xb29e28: mov             x4, NULL
    //     0xb29e2c: b               #0xb29e40
    //     0xb29e30: ldur            w0, [x4, #0x17]
    //     0xb29e34: add             x1, fp, w0, sxtw #2
    //     0xb29e38: ldr             x1, [x1, #0x10]
    //     0xb29e3c: mov             x4, x1
    //     0xb29e40: ldr             x3, [fp, #0x18]
    //     0xb29e44: stur            x4, [fp, #-8]
    // 0xb29e48: CheckStackOverflow
    //     0xb29e48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb29e4c: cmp             SP, x16
    //     0xb29e50: b.ls            #0xb29ea4
    // 0xb29e54: LoadField: r2 = r3->field_7
    //     0xb29e54: ldur            w2, [x3, #7]
    // 0xb29e58: DecompressPointer r2
    //     0xb29e58: add             x2, x2, HEAP, lsl #32
    // 0xb29e5c: ldr             x0, [fp, #0x10]
    // 0xb29e60: mov             x1, x4
    // 0xb29e64: r8 = (dynamic this, X1) => Y0
    //     0xb29e64: add             x8, PP, #0x3b, lsl #12  ; [pp+0x3b488] FunctionType: (dynamic this, X1) => Y0
    //     0xb29e68: ldr             x8, [x8, #0x488]
    // 0xb29e6c: LoadField: r9 = r8->field_7
    //     0xb29e6c: ldur            x9, [x8, #7]
    // 0xb29e70: r3 = Null
    //     0xb29e70: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b490] Null
    //     0xb29e74: ldr             x3, [x3, #0x490]
    // 0xb29e78: blr             x9
    // 0xb29e7c: ldur            x16, [fp, #-8]
    // 0xb29e80: ldr             lr, [fp, #0x18]
    // 0xb29e84: stp             lr, x16, [SP, #8]
    // 0xb29e88: ldr             x16, [fp, #0x10]
    // 0xb29e8c: str             x16, [SP]
    // 0xb29e90: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb29e90: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb29e94: r0 = call 0x3df8e8
    //     0xb29e94: bl              #0x3df8e8
    // 0xb29e98: LeaveFrame
    //     0xb29e98: mov             SP, fp
    //     0xb29e9c: ldp             fp, lr, [SP], #0x10
    // 0xb29ea0: ret
    //     0xb29ea0: ret             
    // 0xb29ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb29ea4: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb29ea8: b               #0xb29e54
  }
}

// class id: 1199, size: 0x2c, field offset: 0x28
class AJ<X0 bound DG, X1> extends _zJ<X0 bound DG, X1>
    implements wJ<X0> {

  [closure] FutureOr<List<X1>> _xch(dynamic, List<Map<String, Object?>>) {
    // ** addr: 0x3e06f4, size: -0x1
  }
  [closure] Future<List<Map<String, Object?>>> <anonymous closure>(dynamic, JG) {
    // ** addr: 0x3df84c, size: -0x1
  }
}

// class id: 1200, size: 0x28, field offset: 0x28
abstract class tJ<X0 bound DG, X1> extends iJ<X0 bound DG, X1> {
}

// class id: 1201, size: 0x28, field offset: 0x28
//   transformed mixin,
abstract class _hJ<X0 bound EG, X1> extends iJ<X0 bound EG, X1>
     with jJ<X0 bound DG, X1> {
}

// class id: 1202, size: 0x2c, field offset: 0x28
class KJ<X0 bound EG, X1> extends _hJ<X0 bound EG, X1> {

  late Map<String, xE<Object>> _Ich; // offset: 0x28

  [closure] Future<int> <anonymous closure>(dynamic, JG) async {
    // ** addr: 0xb39b10, size: 0xc0
    // 0xb39b10: EnterFrame
    //     0xb39b10: stp             fp, lr, [SP, #-0x10]!
    //     0xb39b14: mov             fp, SP
    // 0xb39b18: AllocStack(0x28)
    //     0xb39b18: sub             SP, SP, #0x28
    // 0xb39b1c: SetupParameters(KJ<X0 bound EG, X1> this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xb39b1c: stur            NULL, [fp, #-8]
    //     0xb39b20: movz            x0, #0
    //     0xb39b24: add             x1, fp, w0, sxtw #2
    //     0xb39b28: ldr             x1, [x1, #0x18]
    //     0xb39b2c: add             x2, fp, w0, sxtw #2
    //     0xb39b30: ldr             x2, [x2, #0x10]
    //     0xb39b34: stur            x2, [fp, #-0x18]
    //     0xb39b38: ldur            w3, [x1, #0x17]
    //     0xb39b3c: add             x3, x3, HEAP, lsl #32
    //     0xb39b40: stur            x3, [fp, #-0x10]
    // 0xb39b44: CheckStackOverflow
    //     0xb39b44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb39b48: cmp             SP, x16
    //     0xb39b4c: b.ls            #0xb39bc8
    // 0xb39b50: InitAsync() -> Future<int>
    //     0xb39b50: ldr             x0, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    //     0xb39b54: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb39b58: ldur            x0, [fp, #-0x10]
    // 0xb39b5c: LoadField: r1 = r0->field_f
    //     0xb39b5c: ldur            w1, [x0, #0xf]
    // 0xb39b60: DecompressPointer r1
    //     0xb39b60: add             x1, x1, HEAP, lsl #32
    // 0xb39b64: stur            x1, [fp, #-0x20]
    // 0xb39b68: LoadField: r2 = r1->field_2b
    //     0xb39b68: ldur            w2, [x1, #0x2b]
    // 0xb39b6c: DecompressPointer r2
    //     0xb39b6c: add             x2, x2, HEAP, lsl #32
    // 0xb39b70: str             x2, [SP]
    // 0xb39b74: r0 = call 0x8d76dc
    //     0xb39b74: bl              #0x8d76dc
    // 0xb39b78: mov             x1, x0
    // 0xb39b7c: ldur            x0, [fp, #-0x20]
    // 0xb39b80: LoadField: r3 = r0->field_23
    //     0xb39b80: ldur            w3, [x0, #0x23]
    // 0xb39b84: DecompressPointer r3
    //     0xb39b84: add             x3, x3, HEAP, lsl #32
    // 0xb39b88: ldur            x0, [fp, #-0x18]
    // 0xb39b8c: r2 = LoadClassIdInstr(r0)
    //     0xb39b8c: ldur            x2, [x0, #-1]
    //     0xb39b90: ubfx            x2, x2, #0xc, #0x14
    // 0xb39b94: mov             x16, x1
    // 0xb39b98: mov             x1, x2
    // 0xb39b9c: mov             x2, x16
    // 0xb39ba0: mov             x16, x0
    // 0xb39ba4: mov             x0, x1
    // 0xb39ba8: mov             x1, x16
    // 0xb39bac: r0 = GDT[cid_x0 + -0xe27]()
    //     0xb39bac: sub             lr, x0, #0xe27
    //     0xb39bb0: ldr             lr, [x21, lr, lsl #3]
    //     0xb39bb4: blr             lr
    // 0xb39bb8: mov             x1, x0
    // 0xb39bbc: stur            x1, [fp, #-0x18]
    // 0xb39bc0: r0 = Await()
    //     0xb39bc0: bl              #0xb0c534  ; AwaitStub
    // 0xb39bc4: r0 = ReturnAsync()
    //     0xb39bc4: b               #0xb13694  ; ReturnAsyncStub
    // 0xb39bc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb39bc8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb39bcc: b               #0xb39b50
  }
  [closure] void <anonymous closure>(dynamic, String, xE<Object>) {
    // ** addr: 0x3e0338, size: -0x1
  }
}

// class id: 1203, size: 0x28, field offset: 0x28
abstract class jJ<X0 bound DG, X1> extends iJ<X0 bound DG, X1> {
}

// class id: 1204, size: 0xc, field offset: 0x8
class HI extends xI {
}

// class id: 1208, size: 0xc, field offset: 0x8
abstract class BI<X0 bound DG, X1> extends xI {
}

// class id: 1319, size: 0xc, field offset: 0x8
abstract class fJ<X0 bound EG, X1> extends EG
    implements aJ, cJ<X0, X1> {
}

// class id: 1323, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class xE<X0> extends Object
    implements LI {

  xE<Y0> Zk<Y0 extends Object>(xE<X0>, [NJ<Y0>?]) {
    // ** addr: 0xb29f50, size: 0x100
    // 0xb29f50: EnterFrame
    //     0xb29f50: stp             fp, lr, [SP, #-0x10]!
    //     0xb29f54: mov             fp, SP
    // 0xb29f58: AllocStack(0x30)
    //     0xb29f58: sub             SP, SP, #0x30
    // 0xb29f5c: SetupParameters(xE<X0> this /* r5, fp-0x18 */, [dynamic _ = Null /* r6, fp-0x10 */])
    //     0xb29f5c: ldur            w0, [x4, #0x13]
    //     0xb29f60: sub             x1, x0, #2
    //     0xb29f64: add             x5, fp, w1, sxtw #2
    //     0xb29f68: ldr             x5, [x5, #0x10]
    //     0xb29f6c: stur            x5, [fp, #-0x18]
    //     0xb29f70: cmp             w1, #2
    //     0xb29f74: b.lt            #0xb29f88
    //     0xb29f78: add             x0, fp, w1, sxtw #2
    //     0xb29f7c: ldr             x0, [x0, #8]
    //     0xb29f80: mov             x6, x0
    //     0xb29f84: b               #0xb29f8c
    //     0xb29f88: mov             x6, NULL
    //     0xb29f8c: stur            x6, [fp, #-0x10]
    //     0xb29f90: ldur            w0, [x4, #0xf]
    //     0xb29f94: cbnz            w0, #0xb29fa0
    //     0xb29f98: mov             x1, NULL
    //     0xb29f9c: b               #0xb29fb0
    //     0xb29fa0: ldur            w1, [x4, #0x17]
    //     0xb29fa4: add             x2, fp, w1, sxtw #2
    //     0xb29fa8: ldr             x2, [x2, #0x10]
    //     0xb29fac: mov             x1, x2
    // 0xb29fb0: CheckStackOverflow
    //     0xb29fb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb29fb4: cmp             SP, x16
    //     0xb29fb8: b.ls            #0xb2a048
    // 0xb29fbc: cbnz            w0, #0xb29fc8
    // 0xb29fc0: r4 = <Object>
    //     0xb29fc0: ldr             x4, [PP, #0x770]  ; [pp+0x770] TypeArguments: <Object>
    // 0xb29fc4: b               #0xb29fcc
    // 0xb29fc8: mov             x4, x1
    // 0xb29fcc: stur            x4, [fp, #-8]
    // 0xb29fd0: LoadField: r2 = r5->field_7
    //     0xb29fd0: ldur            w2, [x5, #7]
    // 0xb29fd4: DecompressPointer r2
    //     0xb29fd4: add             x2, x2, HEAP, lsl #32
    // 0xb29fd8: mov             x1, x4
    // 0xb29fdc: r0 = Y0
    //     0xb29fdc: add             x0, PP, #0x31, lsl #12  ; [pp+0x31a10] TypeParameter: Y0
    //     0xb29fe0: ldr             x0, [x0, #0xa10]
    // 0xb29fe4: r8 = Object
    //     0xb29fe4: ldr             x8, [PP, #0xf0]  ; [pp+0xf0] Type: Object
    // 0xb29fe8: r3 = "RI"
    //     0xb29fe8: add             x3, PP, #0x13, lsl #12  ; [pp+0x13ea8] "RI"
    //     0xb29fec: ldr             x3, [x3, #0xea8]
    // 0xb29ff0: r30 = AssertSubtypeStub
    //     0xb29ff0: ldr             lr, [PP, #0x73d8]  ; [pp+0x73d8] Stub: AssertSubtype (0x353218)
    // 0xb29ff4: LoadField: r30 = r30->field_7
    //     0xb29ff4: ldur            lr, [lr, #7]
    // 0xb29ff8: blr             lr
    // 0xb29ffc: ldur            x0, [fp, #-0x10]
    // 0xb2a000: ldur            x1, [fp, #-8]
    // 0xb2a004: r2 = Null
    //     0xb2a004: mov             x2, NULL
    // 0xb2a008: r8 = NJ<Y0>?
    //     0xb2a008: add             x8, PP, #0x31, lsl #12  ; [pp+0x31a18] Type: NJ<Y0>?
    //     0xb2a00c: ldr             x8, [x8, #0xa18]
    // 0xb2a010: LoadField: r9 = r8->field_7
    //     0xb2a010: ldur            x9, [x8, #7]
    // 0xb2a014: r3 = Null
    //     0xb2a014: add             x3, PP, #0x31, lsl #12  ; [pp+0x31a20] Null
    //     0xb2a018: ldr             x3, [x3, #0xa20]
    // 0xb2a01c: blr             x9
    // 0xb2a020: ldur            x16, [fp, #-8]
    // 0xb2a024: ldur            lr, [fp, #-0x18]
    // 0xb2a028: stp             lr, x16, [SP, #8]
    // 0xb2a02c: ldur            x16, [fp, #-0x10]
    // 0xb2a030: str             x16, [SP]
    // 0xb2a034: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb2a034: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb2a038: r0 = call 0x3dff90
    //     0xb2a038: bl              #0x3dff90
    // 0xb2a03c: LeaveFrame
    //     0xb2a03c: mov             SP, fp
    //     0xb2a040: ldp             fp, lr, [SP], #0x10
    // 0xb2a044: ret
    //     0xb2a044: ret             
    // 0xb2a048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2a048: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2a04c: b               #0xb29fbc
  }
}

// class id: 1324, size: 0x14, field offset: 0xc
//   const constructor, 
class TI<X0> extends xE<X0> {

  [closure] static TI<String> Sxi(dynamic, String) {
    // ** addr: 0x4489dc, size: -0x1
  }
}

// class id: 1325, size: 0x14, field offset: 0xc
abstract class _Zib extends xE<dynamic> {
}

// class id: 1326, size: 0x18, field offset: 0x14
class _ajb<C1X0> extends _Zib {
}

// class id: 1328, size: 0x14, field offset: 0xc
//   const constructor, 
class _PI<C1X0, C1X1> extends xE<C1X0> {
}

// class id: 1329, size: 0x14, field offset: 0xc
//   const constructor, 
class KI<X0> extends xE<X0> {

  _OneByteString field_c;
}

// class id: 1333, size: 0x18, field offset: 0xc
class _OI extends vI<dynamic> {
}

// class id: 1336, size: 0x40, field offset: 0x10
class YI<X0> extends CG<X0> {

  [closure] static void <anonymous closure>(dynamic, UI) {
    // ** addr: 0xac2de8, size: -0x1
  }
}

// class id: 6804, size: 0x18, field offset: 0xc
class _HJ extends E<dynamic, dynamic> {

  Object? [](_HJ, Object?) {
    // ** addr: 0xb71f50, size: 0x4c
    // 0xb71f50: EnterFrame
    //     0xb71f50: stp             fp, lr, [SP, #-0x10]!
    //     0xb71f54: mov             fp, SP
    // 0xb71f58: CheckStackOverflow
    //     0xb71f58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb71f5c: cmp             SP, x16
    //     0xb71f60: b.ls            #0xb71f7c
    // 0xb71f64: ldr             x1, [fp, #0x18]
    // 0xb71f68: ldr             x2, [fp, #0x10]
    // 0xb71f6c: r0 = call 0x9a59c4
    //     0xb71f6c: bl              #0x9a59c4
    // 0xb71f70: LeaveFrame
    //     0xb71f70: mov             SP, fp
    //     0xb71f74: ldp             fp, lr, [SP], #0x10
    // 0xb71f78: ret
    //     0xb71f78: ret             
    // 0xb71f7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb71f7c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb71f80: b               #0xb71f64
  }
  [closure] Object? <anonymous closure>(dynamic) {
    // ** addr: 0x9a5a8c, size: -0x1
  }
}

// class id: 7064, size: 0x14, field offset: 0x14
abstract class _JJ extends _Enum {
}

// class id: 7065, size: 0x14, field offset: 0x14
enum lJ extends _Enum
    implements xI {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7066, size: 0x18, field offset: 0x14
enum _NI extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
  _OneByteString field_14;
}

// class id: 7067, size: 0x1c, field offset: 0x14
enum MI extends _Enum
    implements Ca<X0> {

  _Mint field_8;
  _OneByteString field_10;
  _Mint field_14;

  int Rn(MI, MI) {
    // ** addr: 0xb110e0, size: 0x64
    // 0xb110e0: EnterFrame
    //     0xb110e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb110e4: mov             fp, SP
    // 0xb110e8: CheckStackOverflow
    //     0xb110e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb110ec: cmp             SP, x16
    //     0xb110f0: b.ls            #0xb11124
    // 0xb110f4: ldr             x1, [fp, #0x18]
    // 0xb110f8: ldr             x2, [fp, #0x10]
    // 0xb110fc: r0 = call 0x38e23c
    //     0xb110fc: bl              #0x38e23c
    // 0xb11100: mov             x2, x0
    // 0xb11104: r0 = BoxInt64Instr(r2)
    //     0xb11104: sbfiz           x0, x2, #1, #0x1f
    //     0xb11108: cmp             x2, x0, asr #1
    //     0xb1110c: b.eq            #0xb11118
    //     0xb11110: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb11114: stur            x2, [x0, #7]
    // 0xb11118: LeaveFrame
    //     0xb11118: mov             SP, fp
    //     0xb1111c: ldp             fp, lr, [SP], #0x10
    // 0xb11120: ret
    //     0xb11120: ret             
    // 0xb11124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb11124: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb11128: b               #0xb110f4
  }
}

// class id: 7068, size: 0x30, field offset: 0x14
enum yI extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
  _OneByteString field_14;
  _OneByteString field_18;
  _OneByteString field_1c;
  _OneByteString field_20;
  _OneByteString field_24;
  _OneByteString field_28;
  bool field_2c;
}
