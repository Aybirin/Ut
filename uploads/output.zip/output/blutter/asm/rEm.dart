// lib: , url: rEm

// class id: 1048631, size: 0x8
class :: {
}

// class id: 6096, size: 0x8, field offset: 0x8
//   const constructor, 
class qw extends Object
    implements pw {
}

// class id: 6097, size: 0x8, field offset: 0x8
abstract class pw extends Object {
}
