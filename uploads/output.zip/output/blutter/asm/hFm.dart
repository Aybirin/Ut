// lib: , url: hFm

// class id: 1048669, size: 0x8
class :: {
}

// class id: 6048, size: 0x20, field offset: 0x8
class Rx extends Object {

  late final String Smc; // offset: 0xc
  late final Map<String, dynamic> _Atg; // offset: 0x1c

  Map<String, dynamic> Gxc(Rx) {
    // ** addr: 0xc075d8, size: 0x48
    // 0xc075d8: EnterFrame
    //     0xc075d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc075dc: mov             fp, SP
    // 0xc075e0: CheckStackOverflow
    //     0xc075e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc075e4: cmp             SP, x16
    //     0xc075e8: b.ls            #0xc07600
    // 0xc075ec: ldr             x1, [fp, #0x10]
    // 0xc075f0: r0 = call 0x7a4268
    //     0xc075f0: bl              #0x7a4268
    // 0xc075f4: LeaveFrame
    //     0xc075f4: mov             SP, fp
    //     0xc075f8: ldp             fp, lr, [SP], #0x10
    // 0xc075fc: ret
    //     0xc075fc: ret             
    // 0xc07600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc07600: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc07604: b               #0xc075ec
  }
}
