// lib: , url: ZBn

// class id: 1050904, size: 0x8
class :: {
}

// class id: 7474, size: 0x28, field offset: 0xc
class yPb extends Iterable<dynamic> {
}
