// lib: , url: vsn

// class id: 1050426, size: 0x8
class :: {
}

// class id: 705, size: 0xc, field offset: 0x8
//   const constructor, 
class qwb extends Object
    implements pwb {
}

// class id: 706, size: 0x8, field offset: 0x8
abstract class pwb extends Object {
}

// class id: 747, size: 0x8, field offset: 0x8
abstract class nvb extends Object {
}
