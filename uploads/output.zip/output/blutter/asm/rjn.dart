// lib: , url: rjn

// class id: 1050028, size: 0x8
class :: {

  static late rH Yah; // offset: 0x16a0
}

// class id: 1242, size: 0x10, field offset: 0x8
//   const constructor, 
class yH extends Object {
}

// class id: 1243, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class wH extends Object {
}

// class id: 1244, size: 0xc, field offset: 0x8
//   const constructor, 
class vH extends Object {

  _ImmutableList<wH> field_8;
}

// class id: 1245, size: 0x10, field offset: 0x8
abstract class tH extends Object {

  late final LJ Dah; // offset: 0xc

  [closure] Future<Y0> <anonymous closure>(dynamic) async {
    // ** addr: 0xb42b58, size: 0x26c
    // 0xb42b58: EnterFrame
    //     0xb42b58: stp             fp, lr, [SP, #-0x10]!
    //     0xb42b5c: mov             fp, SP
    // 0xb42b60: AllocStack(0xa8)
    //     0xb42b60: sub             SP, SP, #0xa8
    // 0xb42b64: SetupParameters(tH this /* r1, fp-0x90 */)
    //     0xb42b64: stur            NULL, [fp, #-8]
    //     0xb42b68: movz            x0, #0
    //     0xb42b6c: add             x1, fp, w0, sxtw #2
    //     0xb42b70: ldr             x1, [x1, #0x10]
    //     0xb42b74: stur            x1, [fp, #-0x90]
    //     0xb42b78: ldur            w2, [x1, #0x17]
    //     0xb42b7c: add             x2, x2, HEAP, lsl #32
    //     0xb42b80: stur            x2, [fp, #-0x88]
    // 0xb42b84: CheckStackOverflow
    //     0xb42b84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb42b88: cmp             SP, x16
    //     0xb42b8c: b.ls            #0xb42dbc
    // 0xb42b90: LoadField: r3 = r1->field_b
    //     0xb42b90: ldur            w3, [x1, #0xb]
    // 0xb42b94: DecompressPointer r3
    //     0xb42b94: add             x3, x3, HEAP, lsl #32
    // 0xb42b98: mov             x0, x3
    // 0xb42b9c: stur            x3, [fp, #-0x80]
    // 0xb42ba0: r0 = InitAsync()
    //     0xb42ba0: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb42ba4: ldur            x3, [fp, #-0x88]
    // 0xb42ba8: LoadField: r1 = r3->field_f
    //     0xb42ba8: ldur            w1, [x3, #0xf]
    // 0xb42bac: DecompressPointer r1
    //     0xb42bac: add             x1, x1, HEAP, lsl #32
    // 0xb42bb0: LoadField: r4 = r3->field_b
    //     0xb42bb0: ldur            w4, [x3, #0xb]
    // 0xb42bb4: DecompressPointer r4
    //     0xb42bb4: add             x4, x4, HEAP, lsl #32
    // 0xb42bb8: stur            x4, [fp, #-0x98]
    // 0xb42bbc: LoadField: r2 = r4->field_f
    //     0xb42bbc: ldur            w2, [x4, #0xf]
    // 0xb42bc0: DecompressPointer r2
    //     0xb42bc0: add             x2, x2, HEAP, lsl #32
    // 0xb42bc4: r0 = LoadClassIdInstr(r1)
    //     0xb42bc4: ldur            x0, [x1, #-1]
    //     0xb42bc8: ubfx            x0, x0, #0xc, #0x14
    // 0xb42bcc: r0 = GDT[cid_x0 + -0xfc9]()
    //     0xb42bcc: sub             lr, x0, #0xfc9
    //     0xb42bd0: ldr             lr, [x21, lr, lsl #3]
    //     0xb42bd4: blr             lr
    // 0xb42bd8: mov             x1, x0
    // 0xb42bdc: stur            x1, [fp, #-0xa0]
    // 0xb42be0: r0 = Await()
    //     0xb42be0: bl              #0xb0c534  ; AwaitStub
    // 0xb42be4: ldur            x0, [fp, #-0x98]
    // 0xb42be8: LoadField: r1 = r0->field_13
    //     0xb42be8: ldur            w1, [x0, #0x13]
    // 0xb42bec: DecompressPointer r1
    //     0xb42bec: add             x1, x1, HEAP, lsl #32
    // 0xb42bf0: stur            x1, [fp, #-0x80]
    // 0xb42bf4: str             x1, [SP]
    // 0xb42bf8: mov             x0, x1
    // 0xb42bfc: ClosureCall
    //     0xb42bfc: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xb42c00: ldur            x2, [x0, #0x1f]
    //     0xb42c04: blr             x2
    // 0xb42c08: mov             x1, x0
    // 0xb42c0c: stur            x1, [fp, #-0x80]
    // 0xb42c10: r0 = Await()
    //     0xb42c10: bl              #0xb0c534  ; AwaitStub
    // 0xb42c14: stur            x0, [fp, #-0x90]
    // 0xb42c18: ldur            x2, [fp, #-0x88]
    // 0xb42c1c: LoadField: r3 = r2->field_13
    //     0xb42c1c: ldur            w3, [x2, #0x13]
    // 0xb42c20: DecompressPointer r3
    //     0xb42c20: add             x3, x3, HEAP, lsl #32
    // 0xb42c24: mov             x1, x3
    // 0xb42c28: stur            x3, [fp, #-0x80]
    // 0xb42c2c: r0 = __unknown_function__()
    //     0xb42c2c: bl              #0xb42fe8  ; [] ::__unknown_function__
    // 0xb42c30: mov             x1, x0
    // 0xb42c34: stur            x1, [fp, #-0x98]
    // 0xb42c38: r0 = Await()
    //     0xb42c38: bl              #0xb0c534  ; AwaitStub
    // 0xb42c3c: ldur            x1, [fp, #-0x80]
    // 0xb42c40: r0 = __unknown_function__()
    //     0xb42c40: bl              #0xb42e68  ; [] ::__unknown_function__
    // 0xb42c44: mov             x1, x0
    // 0xb42c48: stur            x1, [fp, #-0x80]
    // 0xb42c4c: r0 = Await()
    //     0xb42c4c: bl              #0xb0c534  ; AwaitStub
    // 0xb42c50: ldur            x0, [fp, #-0x90]
    // 0xb42c54: r0 = ReturnAsync()
    //     0xb42c54: b               #0xb13694  ; ReturnAsyncStub
    // 0xb42c58: sub             SP, fp, #0xa8
    // 0xb42c5c: ldur            x5, [fp, #-0x28]
    // 0xb42c60: mov             x4, x0
    // 0xb42c64: stur            x0, [fp, #-0x80]
    // 0xb42c68: mov             x0, x1
    // 0xb42c6c: stur            x1, [fp, #-0x88]
    // 0xb42c70: LoadField: r1 = r5->field_f
    //     0xb42c70: ldur            w1, [x5, #0xf]
    // 0xb42c74: DecompressPointer r1
    //     0xb42c74: add             x1, x1, HEAP, lsl #32
    // 0xb42c78: mov             x2, x4
    // 0xb42c7c: mov             x3, x0
    // 0xb42c80: r0 = __unknown_function__()
    //     0xb42c80: bl              #0xb42dc4  ; [] ::__unknown_function__
    // 0xb42c84: mov             x1, x0
    // 0xb42c88: stur            x1, [fp, #-0x90]
    // 0xb42c8c: r0 = Await()
    //     0xb42c8c: bl              #0xb0c534  ; AwaitStub
    // 0xb42c90: ldur            x0, [fp, #-0x80]
    // 0xb42c94: ldur            x1, [fp, #-0x88]
    // 0xb42c98: r0 = ReThrow()
    //     0xb42c98: bl              #0xc539d8  ; ReThrowStub
    // 0xb42c9c: brk             #0
    // 0xb42ca0: sub             SP, fp, #0xa8
    // 0xb42ca4: mov             x4, x0
    // 0xb42ca8: stur            x0, [fp, #-0x80]
    // 0xb42cac: mov             x0, x1
    // 0xb42cb0: stur            x1, [fp, #-0x88]
    // 0xb42cb4: ldur            x1, [fp, #-0x30]
    // 0xb42cb8: LoadField: r2 = r1->field_f
    //     0xb42cb8: ldur            w2, [x1, #0xf]
    // 0xb42cbc: DecompressPointer r2
    //     0xb42cbc: add             x2, x2, HEAP, lsl #32
    // 0xb42cc0: mov             x1, x2
    // 0xb42cc4: mov             x2, x4
    // 0xb42cc8: mov             x3, x0
    // 0xb42ccc: r0 = __unknown_function__()
    //     0xb42ccc: bl              #0xb42dc4  ; [] ::__unknown_function__
    // 0xb42cd0: mov             x1, x0
    // 0xb42cd4: stur            x1, [fp, #-0x90]
    // 0xb42cd8: r0 = Await()
    //     0xb42cd8: bl              #0xb0c534  ; AwaitStub
    // 0xb42cdc: ldur            x0, [fp, #-0x80]
    // 0xb42ce0: ldur            x1, [fp, #-0x88]
    // 0xb42ce4: r0 = ReThrow()
    //     0xb42ce4: bl              #0xc539d8  ; ReThrowStub
    // 0xb42ce8: brk             #0
    // 0xb42cec: sub             SP, fp, #0xa8
    // 0xb42cf0: ldur            x5, [fp, #-0x28]
    // 0xb42cf4: mov             x4, x0
    // 0xb42cf8: stur            x0, [fp, #-0x80]
    // 0xb42cfc: mov             x0, x1
    // 0xb42d00: stur            x1, [fp, #-0x88]
    // 0xb42d04: LoadField: r1 = r5->field_f
    //     0xb42d04: ldur            w1, [x5, #0xf]
    // 0xb42d08: DecompressPointer r1
    //     0xb42d08: add             x1, x1, HEAP, lsl #32
    // 0xb42d0c: mov             x2, x4
    // 0xb42d10: mov             x3, x0
    // 0xb42d14: r0 = __unknown_function__()
    //     0xb42d14: bl              #0xb42dc4  ; [] ::__unknown_function__
    // 0xb42d18: mov             x1, x0
    // 0xb42d1c: stur            x1, [fp, #-0x90]
    // 0xb42d20: r0 = Await()
    //     0xb42d20: bl              #0xb0c534  ; AwaitStub
    // 0xb42d24: ldur            x0, [fp, #-0x80]
    // 0xb42d28: ldur            x1, [fp, #-0x88]
    // 0xb42d2c: r0 = ReThrow()
    //     0xb42d2c: bl              #0xc539d8  ; ReThrowStub
    // 0xb42d30: brk             #0
    // 0xb42d34: sub             SP, fp, #0xa8
    // 0xb42d38: ldur            x3, [fp, #-0x28]
    // 0xb42d3c: mov             x2, x0
    // 0xb42d40: stur            x0, [fp, #-0x80]
    // 0xb42d44: mov             x0, x1
    // 0xb42d48: stur            x1, [fp, #-0x88]
    // 0xb42d4c: LoadField: r1 = r3->field_13
    //     0xb42d4c: ldur            w1, [x3, #0x13]
    // 0xb42d50: DecompressPointer r1
    //     0xb42d50: add             x1, x1, HEAP, lsl #32
    // 0xb42d54: r0 = __unknown_function__()
    //     0xb42d54: bl              #0xb42e68  ; [] ::__unknown_function__
    // 0xb42d58: mov             x1, x0
    // 0xb42d5c: stur            x1, [fp, #-0x90]
    // 0xb42d60: r0 = Await()
    //     0xb42d60: bl              #0xb0c534  ; AwaitStub
    // 0xb42d64: ldur            x0, [fp, #-0x80]
    // 0xb42d68: ldur            x1, [fp, #-0x88]
    // 0xb42d6c: r0 = ReThrow()
    //     0xb42d6c: bl              #0xc539d8  ; ReThrowStub
    // 0xb42d70: brk             #0
    // 0xb42d74: sub             SP, fp, #0xa8
    // 0xb42d78: ldur            x5, [fp, #-0x28]
    // 0xb42d7c: mov             x4, x0
    // 0xb42d80: stur            x0, [fp, #-0x80]
    // 0xb42d84: mov             x0, x1
    // 0xb42d88: stur            x1, [fp, #-0x88]
    // 0xb42d8c: LoadField: r1 = r5->field_f
    //     0xb42d8c: ldur            w1, [x5, #0xf]
    // 0xb42d90: DecompressPointer r1
    //     0xb42d90: add             x1, x1, HEAP, lsl #32
    // 0xb42d94: mov             x2, x4
    // 0xb42d98: mov             x3, x0
    // 0xb42d9c: r0 = __unknown_function__()
    //     0xb42d9c: bl              #0xb42dc4  ; [] ::__unknown_function__
    // 0xb42da0: mov             x1, x0
    // 0xb42da4: stur            x1, [fp, #-0x90]
    // 0xb42da8: r0 = Await()
    //     0xb42da8: bl              #0xb0c534  ; AwaitStub
    // 0xb42dac: ldur            x0, [fp, #-0x80]
    // 0xb42db0: ldur            x1, [fp, #-0x88]
    // 0xb42db4: r0 = ReThrow()
    //     0xb42db4: bl              #0xc539d8  ; ReThrowStub
    // 0xb42db8: brk             #0
    // 0xb42dbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb42dbc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb42dc0: b               #0xb42b90
  }
  [closure] FutureOr<Y0> <anonymous closure>(dynamic, bool) {
    // ** addr: 0x3df688, size: -0x1
  }
  [closure] Future<void> <anonymous closure>(dynamic, JG) {
    // ** addr: 0x3e14bc, size: -0x1
  }
  [closure] Future<int> <anonymous closure>(dynamic, JG, String, List<dynamic>) {
    // ** addr: 0x43af88, size: -0x1
  }
  [closure] dynamic <anonymous closure>(dynamic, TI<Object>) {
    // ** addr: 0x43af44, size: -0x1
  }
  [closure] Future<Y0> <anonymous closure>(dynamic, JG) {
    // ** addr: 0x43aedc, size: -0x1
  }
  [closure] Future<int> <anonymous closure>(dynamic, JG, String, List<dynamic>) {
    // ** addr: 0x43b20c, size: -0x1
  }
  [closure] Future<Y0> <anonymous closure>(dynamic, JG) {
    // ** addr: 0x43f9b4, size: -0x1
  }
}

// class id: 1248, size: 0x14, field offset: 0x10
abstract class uH extends tH
    implements pH {

  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xc4b84c, size: 0x1a8
    // 0xc4b84c: EnterFrame
    //     0xc4b84c: stp             fp, lr, [SP, #-0x10]!
    //     0xc4b850: mov             fp, SP
    // 0xc4b854: AllocStack(0x38)
    //     0xc4b854: sub             SP, SP, #0x38
    // 0xc4b858: SetupParameters(uH this /* r1 */)
    //     0xc4b858: stur            NULL, [fp, #-8]
    //     0xc4b85c: movz            x0, #0
    //     0xc4b860: add             x1, fp, w0, sxtw #2
    //     0xc4b864: ldr             x1, [x1, #0x10]
    //     0xc4b868: ldur            w2, [x1, #0x17]
    //     0xc4b86c: add             x2, x2, HEAP, lsl #32
    //     0xc4b870: stur            x2, [fp, #-0x10]
    // 0xc4b874: CheckStackOverflow
    //     0xc4b874: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4b878: cmp             SP, x16
    //     0xc4b87c: b.ls            #0xc4b9e4
    // 0xc4b880: InitAsync() -> Future<void?>
    //     0xc4b880: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xc4b884: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc4b888: ldur            x0, [fp, #-0x10]
    // 0xc4b88c: LoadField: r1 = r0->field_f
    //     0xc4b88c: ldur            w1, [x0, #0xf]
    // 0xc4b890: DecompressPointer r1
    //     0xc4b890: add             x1, x1, HEAP, lsl #32
    // 0xc4b894: LoadField: r2 = r0->field_13
    //     0xc4b894: ldur            w2, [x0, #0x13]
    // 0xc4b898: DecompressPointer r2
    //     0xc4b898: add             x2, x2, HEAP, lsl #32
    // 0xc4b89c: LoadField: r3 = r2->field_7
    //     0xc4b89c: ldur            w3, [x2, #7]
    // 0xc4b8a0: DecompressPointer r3
    //     0xc4b8a0: add             x3, x3, HEAP, lsl #32
    // 0xc4b8a4: cmp             w3, NULL
    // 0xc4b8a8: b.ne            #0xc4b8f8
    // 0xc4b8ac: r0 = call 0xac3694
    //     0xc4b8ac: bl              #0xac3694
    // 0xc4b8b0: mov             x2, x0
    // 0xc4b8b4: ldur            x0, [fp, #-0x10]
    // 0xc4b8b8: stur            x2, [fp, #-0x18]
    // 0xc4b8bc: LoadField: r1 = r0->field_f
    //     0xc4b8bc: ldur            w1, [x0, #0xf]
    // 0xc4b8c0: DecompressPointer r1
    //     0xc4b8c0: add             x1, x1, HEAP, lsl #32
    // 0xc4b8c4: r0 = call 0xac23b0
    //     0xc4b8c4: bl              #0xac23b0
    // 0xc4b8c8: LoadField: r1 = r0->field_7
    //     0xc4b8c8: ldur            w1, [x0, #7]
    // 0xc4b8cc: DecompressPointer r1
    //     0xc4b8cc: add             x1, x1, HEAP, lsl #32
    // 0xc4b8d0: ldur            x16, [fp, #-0x18]
    // 0xc4b8d4: stp             x16, x1, [SP]
    // 0xc4b8d8: mov             x0, x1
    // 0xc4b8dc: ClosureCall
    //     0xc4b8dc: ldr             x4, [PP, #0x158]  ; [pp+0x158] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc4b8e0: ldur            x2, [x0, #0x1f]
    //     0xc4b8e4: blr             x2
    // 0xc4b8e8: mov             x1, x0
    // 0xc4b8ec: stur            x1, [fp, #-0x18]
    // 0xc4b8f0: r0 = Await()
    //     0xc4b8f0: bl              #0xb0c534  ; AwaitStub
    // 0xc4b8f4: b               #0xc4b990
    // 0xc4b8f8: mov             x1, x2
    // 0xc4b8fc: r0 = call 0x9ccb54
    //     0xc4b8fc: bl              #0x9ccb54
    // 0xc4b900: tbnz            w0, #4, #0xc4b990
    // 0xc4b904: ldur            x0, [fp, #-0x10]
    // 0xc4b908: LoadField: r1 = r0->field_f
    //     0xc4b908: ldur            w1, [x0, #0xf]
    // 0xc4b90c: DecompressPointer r1
    //     0xc4b90c: add             x1, x1, HEAP, lsl #32
    // 0xc4b910: r0 = call 0xac3694
    //     0xc4b910: bl              #0xac3694
    // 0xc4b914: mov             x2, x0
    // 0xc4b918: ldur            x0, [fp, #-0x10]
    // 0xc4b91c: stur            x2, [fp, #-0x18]
    // 0xc4b920: LoadField: r1 = r0->field_f
    //     0xc4b920: ldur            w1, [x0, #0xf]
    // 0xc4b924: DecompressPointer r1
    //     0xc4b924: add             x1, x1, HEAP, lsl #32
    // 0xc4b928: r0 = call 0xac23b0
    //     0xc4b928: bl              #0xac23b0
    // 0xc4b92c: ldur            x2, [fp, #-0x10]
    // 0xc4b930: LoadField: r1 = r2->field_13
    //     0xc4b930: ldur            w1, [x2, #0x13]
    // 0xc4b934: DecompressPointer r1
    //     0xc4b934: add             x1, x1, HEAP, lsl #32
    // 0xc4b938: LoadField: r3 = r1->field_7
    //     0xc4b938: ldur            w3, [x1, #7]
    // 0xc4b93c: DecompressPointer r3
    //     0xc4b93c: add             x3, x3, HEAP, lsl #32
    // 0xc4b940: cmp             w3, NULL
    // 0xc4b944: b.eq            #0xc4b9ec
    // 0xc4b948: LoadField: r4 = r1->field_b
    //     0xc4b948: ldur            x4, [x1, #0xb]
    // 0xc4b94c: LoadField: r5 = r0->field_b
    //     0xc4b94c: ldur            w5, [x0, #0xb]
    // 0xc4b950: DecompressPointer r5
    //     0xc4b950: add             x5, x5, HEAP, lsl #32
    // 0xc4b954: r0 = BoxInt64Instr(r4)
    //     0xc4b954: sbfiz           x0, x4, #1, #0x1f
    //     0xc4b958: cmp             x4, x0, asr #1
    //     0xc4b95c: b.eq            #0xc4b968
    //     0xc4b960: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc4b964: stur            x4, [x0, #7]
    // 0xc4b968: ldur            x16, [fp, #-0x18]
    // 0xc4b96c: stp             x16, x5, [SP, #0x10]
    // 0xc4b970: stp             x0, x3, [SP]
    // 0xc4b974: mov             x0, x5
    // 0xc4b978: ClosureCall
    //     0xc4b978: ldr             x4, [PP, #0xa28]  ; [pp+0xa28] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xc4b97c: ldur            x2, [x0, #0x1f]
    //     0xc4b980: blr             x2
    // 0xc4b984: mov             x1, x0
    // 0xc4b988: stur            x1, [fp, #-0x18]
    // 0xc4b98c: r0 = Await()
    //     0xc4b98c: bl              #0xb0c534  ; AwaitStub
    // 0xc4b990: ldur            x0, [fp, #-0x10]
    // 0xc4b994: LoadField: r1 = r0->field_f
    //     0xc4b994: ldur            w1, [x0, #0xf]
    // 0xc4b998: DecompressPointer r1
    //     0xc4b998: add             x1, x1, HEAP, lsl #32
    // 0xc4b99c: r0 = call 0xac23b0
    //     0xc4b99c: bl              #0xac23b0
    // 0xc4b9a0: LoadField: r1 = r0->field_f
    //     0xc4b9a0: ldur            w1, [x0, #0xf]
    // 0xc4b9a4: DecompressPointer r1
    //     0xc4b9a4: add             x1, x1, HEAP, lsl #32
    // 0xc4b9a8: ldur            x2, [fp, #-0x10]
    // 0xc4b9ac: LoadField: r0 = r2->field_13
    //     0xc4b9ac: ldur            w0, [x2, #0x13]
    // 0xc4b9b0: DecompressPointer r0
    //     0xc4b9b0: add             x0, x0, HEAP, lsl #32
    // 0xc4b9b4: cmp             w1, NULL
    // 0xc4b9b8: b.eq            #0xc4b9f0
    // 0xc4b9bc: stp             x0, x1, [SP]
    // 0xc4b9c0: mov             x0, x1
    // 0xc4b9c4: ClosureCall
    //     0xc4b9c4: ldr             x4, [PP, #0x158]  ; [pp+0x158] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc4b9c8: ldur            x2, [x0, #0x1f]
    //     0xc4b9cc: blr             x2
    // 0xc4b9d0: mov             x1, x0
    // 0xc4b9d4: stur            x1, [fp, #-0x18]
    // 0xc4b9d8: r0 = Await()
    //     0xc4b9d8: bl              #0xb0c534  ; AwaitStub
    // 0xc4b9dc: r0 = Null
    //     0xc4b9dc: mov             x0, NULL
    // 0xc4b9e0: r0 = ReturnAsyncNotFuture()
    //     0xc4b9e0: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc4b9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4b9e4: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4b9e8: b               #0xc4b880
    // 0xc4b9ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc4b9ec: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc4b9f0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc4b9f0: bl              #0xc560a8  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 1252, size: 0x14, field offset: 0x8
class sH extends Object
    implements JG {

  [closure] static Future<JG> <anonymous closure>(dynamic) async {
    // ** addr: 0xbf9804, size: 0x70
    // 0xbf9804: EnterFrame
    //     0xbf9804: stp             fp, lr, [SP, #-0x10]!
    //     0xbf9808: mov             fp, SP
    // 0xbf980c: AllocStack(0x18)
    //     0xbf980c: sub             SP, SP, #0x18
    // 0xbf9810: SetupParameters(dynamic _ /* r1 */)
    //     0xbf9810: stur            NULL, [fp, #-8]
    //     0xbf9814: movz            x0, #0
    //     0xbf9818: add             x1, fp, w0, sxtw #2
    //     0xbf981c: ldr             x1, [x1, #0x10]
    //     0xbf9820: ldur            w2, [x1, #0x17]
    //     0xbf9824: add             x2, x2, HEAP, lsl #32
    //     0xbf9828: stur            x2, [fp, #-0x10]
    // 0xbf982c: CheckStackOverflow
    //     0xbf982c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf9830: cmp             SP, x16
    //     0xbf9834: b.ls            #0xbf986c
    // 0xbf9838: InitAsync() -> Future<JG>
    //     0xbf9838: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2a030] TypeArguments: <JG>
    //     0xbf983c: ldr             x0, [x0, #0x30]
    //     0xbf9840: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbf9844: ldur            x1, [fp, #-0x10]
    // 0xbf9848: LoadField: r2 = r1->field_f
    //     0xbf9848: ldur            w2, [x1, #0xf]
    // 0xbf984c: DecompressPointer r2
    //     0xbf984c: add             x2, x2, HEAP, lsl #32
    // 0xbf9850: mov             x0, x2
    // 0xbf9854: stur            x2, [fp, #-0x18]
    // 0xbf9858: r0 = Await()
    //     0xbf9858: bl              #0xb0c534  ; AwaitStub
    // 0xbf985c: LoadField: r1 = r0->field_7
    //     0xbf985c: ldur            w1, [x0, #7]
    // 0xbf9860: DecompressPointer r1
    //     0xbf9860: add             x1, x1, HEAP, lsl #32
    // 0xbf9864: mov             x0, x1
    // 0xbf9868: r0 = ReturnAsyncNotFuture()
    //     0xbf9868: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf986c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf986c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9870: b               #0xbf9838
  }
}

// class id: 1253, size: 0x20, field offset: 0x8
class Xib extends Object {

  [closure] int <anonymous closure>(dynamic) {
    // ** addr: 0x42d1e4, size: -0x1
  }
}

// class id: 1254, size: 0xc, field offset: 0x8
class rH extends Object {
}

// class id: 7069, size: 0x14, field offset: 0x14
enum xH extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
