// lib: , url: Lfn

// class id: 1049841, size: 0x8
class :: {
}

// class id: 1497, size: 0x3c, field offset: 0x8
class veb extends Object {

  late int hHh; // offset: 0x24
  late int iHh; // offset: 0x28
  late List<List<Int32List>> jHh; // offset: 0x2c
  late List<reb?> kHh; // offset: 0x30
  late int mHh; // offset: 0x38
  late List<reb?> lHh; // offset: 0x34
}
