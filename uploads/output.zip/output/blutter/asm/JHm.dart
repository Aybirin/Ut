// lib: , url: JHm

// class id: 1048789, size: 0x8
class :: {
}

// class id: 5771, size: 0x2c, field offset: 0x8
class iC extends Object {
}
