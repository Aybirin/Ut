// lib: , url: fpn

// class id: 1050281, size: 0x8
class :: {
}

// class id: 7475, size: 0x14, field offset: 0xc
//   const constructor, 
class drb extends Iterable<dynamic> {

  int length(drb) {
    // ** addr: 0xc16ca4, size: 0x2c
    // 0xc16ca4: ldr             x1, [SP]
    // 0xc16ca8: LoadField: r2 = r1->field_f
    //     0xc16ca8: ldur            w2, [x1, #0xf]
    // 0xc16cac: DecompressPointer r2
    //     0xc16cac: add             x2, x2, HEAP, lsl #32
    // 0xc16cb0: LoadField: r0 = r2->field_b
    //     0xc16cb0: ldur            w0, [x2, #0xb]
    // 0xc16cb4: ret
    //     0xc16cb4: ret             
  }
  [closure] static erb <anonymous closure>(dynamic, int) {
    // ** addr: 0x5384a0, size: -0x1
  }
}

// class id: 7476, size: 0x20, field offset: 0x14
class _frb extends drb {

  [closure] erb <anonymous closure>(dynamic, erb) {
    // ** addr: 0x535f5c, size: -0x1
  }
}
