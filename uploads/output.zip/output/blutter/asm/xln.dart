// lib: , url: xln

// class id: 1050109, size: 0x8
class :: {

  [closure] static Y5 <anonymous closure>(dynamic, (Y0, Y1, Y2, Y3, Y4)) {
    // ** addr: 0x5b94f0, size: -0x1
  }
}

// class id: 1117, size: 0x20, field offset: 0xc
class Ekb<C1X0, C1X1, C1X2, C1X3, C1X4> extends ckb<C1X0>
    implements zkb {
}
