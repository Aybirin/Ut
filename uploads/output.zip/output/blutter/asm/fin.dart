// lib: mEn, url: fin

// class id: 1049965, size: 0x8
class :: {

  static late final Lhb wEh; // offset: 0x1440
}

// class id: 1388, size: 0x54, field offset: 0x8
class Lhb extends Object {
}
