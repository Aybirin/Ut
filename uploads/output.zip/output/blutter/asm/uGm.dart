// lib: , url: uGm

// class id: 1048732, size: 0x8
class :: {
}

// class id: 5981, size: 0x8, field offset: 0x8
//   const constructor, 
class _hz extends iz {
}
