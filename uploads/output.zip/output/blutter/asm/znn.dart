// lib: RDn, url: znn

// class id: 1050196, size: 0x8
class :: {
}

// class id: 997, size: 0xc, field offset: 0xc
class dob extends hnb {

  static late final fqb GEg; // offset: 0x101c

  [closure] static dob <anonymous closure>(dynamic) {
    // ** addr: 0x40e168, size: -0x1
  }
  [closure] static dob _VJg(dynamic, String, enb, dnb, za, za, List<int>) {
    // ** addr: 0x40e280, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40e110, size: -0x1
  }
}
