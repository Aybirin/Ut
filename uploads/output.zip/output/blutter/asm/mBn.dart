// lib: , url: mBn

// class id: 1050867, size: 0x8
class :: {
}

// class id: 4661, size: 0x14, field offset: 0xc
//   const constructor, 
class sOb extends Zu {

  [closure] zza <anonymous closure>(dynamic, iva, fpa) {
    // ** addr: 0x87ab50, size: -0x1
  }
  [closure] gpa <anonymous closure>(dynamic, vza) {
    // ** addr: 0x87a7f4, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x87aaf4, size: -0x1
  }
}
