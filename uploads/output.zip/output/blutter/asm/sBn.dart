// lib: , url: sBn

// class id: 1050873, size: 0x8
class :: {
}

// class id: 221, size: 0x10, field offset: 0x8
class EOb extends Object
    implements lp {

  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x3ed93c, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic, Object, ua) {
    // ** addr: 0x3ed824, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x3ed75c, size: -0x1
  }
}
