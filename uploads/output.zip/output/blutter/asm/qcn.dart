// lib: , url: qcn

// class id: 1049672, size: 0x8
class :: {
}

// class id: 1718, size: 0x3c, field offset: 0x8
class cYa extends Object {
}
