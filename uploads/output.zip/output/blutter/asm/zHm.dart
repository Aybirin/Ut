// lib: , url: zHm

// class id: 1048780, size: 0x8
class :: {
}

// class id: 7371, size: 0x14, field offset: 0x14
enum RB extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
