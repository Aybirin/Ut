// lib: , url: IWm

// class id: 1049473, size: 0x8
class :: {
}

// class id: 2388, size: 0x10, field offset: 0x8
//   const constructor, 
class CJa extends Object {

  _OneByteString field_8;
  _OneByteString field_c;
}
