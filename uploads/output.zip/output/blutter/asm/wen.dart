// lib: , url: wen

// class id: 1049766, size: 0x8
class :: {
}

// class id: 1587, size: 0x24, field offset: 0x8
class vcb extends Object {

  late lbb JKi; // offset: 0xc
}

// class id: 7593, size: 0x10, field offset: 0x10
class ucb extends rbb<dynamic> {

  [closure] void add(dynamic, Object?) {
    // ** addr: 0x390280, size: -0x1
  }
}
