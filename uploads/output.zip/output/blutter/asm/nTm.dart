// lib: , url: nTm

// class id: 1049334, size: 0x8
class :: {
}

// class id: 4157, size: 0x18, field offset: 0x14
class _pCa extends Xu<dynamic> {

  late Map<Object, Object?> data; // offset: 0x14
}

// class id: 4607, size: 0x18, field offset: 0x14
class _qCa extends vwa<dynamic> {
}

// class id: 5083, size: 0x10, field offset: 0xc
//   const constructor, 
class oCa extends Vu {
}
