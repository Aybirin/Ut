// lib: , url: Qqn

// class id: 1050349, size: 0x8
class :: {
}

// class id: 821, size: 0x24, field offset: 0x8
class stb extends Object {
}
