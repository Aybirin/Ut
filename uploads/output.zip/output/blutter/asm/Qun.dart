// lib: , url: Qun

// class id: 1050548, size: 0x8
class :: {
}

// class id: 499, size: 0x18, field offset: 0x8
class qAb extends Object {
}
