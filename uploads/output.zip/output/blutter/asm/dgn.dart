// lib: , url: dgn

// class id: 1049859, size: 0x8
class :: {
}

// class id: 1479, size: 0xc, field offset: 0xc
class afb extends Veb {
}
