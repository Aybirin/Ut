// lib: , url: Ztn

// class id: 1050506, size: 0x8
class :: {
}

// class id: 563, size: 0x8, field offset: 0x8
abstract class dzb extends Object {

  [closure] static void <anonymous closure>(dynamic, PP) {
    // ** addr: 0xb07034, size: -0x1
  }
  [closure] static bool <anonymous closure>(dynamic, Object, ua) {
    // ** addr: 0xb06ffc, size: -0x1
  }
  [closure] static String iGk(dynamic, dynamic, int) {
    // ** addr: 0xb06ecc, size: -0x1
  }
}
