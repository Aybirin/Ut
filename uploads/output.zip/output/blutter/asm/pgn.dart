// lib: , url: pgn

// class id: 1049871, size: 0x8
class :: {
}

// class id: 1463, size: 0x20, field offset: 0x8
class rfb extends Object
    implements Cdb {
}

// class id: 1464, size: 0x2c, field offset: 0x8
class qfb extends Object
    implements Cdb {
}

// class id: 1465, size: 0x40, field offset: 0x8
class pfb extends Object
    implements Cdb {
}
