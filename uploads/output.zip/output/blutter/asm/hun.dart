// lib: , url: hun

// class id: 1050514, size: 0x8
class :: {
}

// class id: 4767, size: 0x20, field offset: 0xc
//   const constructor, 
class lzb extends Zu {
}
