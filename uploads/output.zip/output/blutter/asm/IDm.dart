// lib: , url: IDm

// class id: 1048596, size: 0x8
class :: {
}

// class id: 6244, size: 0x8, field offset: 0x8
abstract class fu extends Object {
}

// class id: 6245, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class cu<X0> extends Object {
}

// class id: 6246, size: 0x10, field offset: 0xc
//   const constructor, 
class eu<X0> extends cu<X0> {
}

// class id: 6247, size: 0x10, field offset: 0xc
//   const constructor, 
class du<X0> extends cu<X0> {
}
