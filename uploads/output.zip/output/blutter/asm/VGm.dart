// lib: kEn, url: VGm

// class id: 1048759, size: 0x8
class :: {
}

// class id: 5875, size: 0x8, field offset: 0x8
abstract class Hz extends Object {
}

// class id: 7386, size: 0x14, field offset: 0x14
enum Jz extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
