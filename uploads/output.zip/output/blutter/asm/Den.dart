// lib: , url: Den

// class id: 1049773, size: 0x8
class :: {
}

// class id: 1581, size: 0x8, field offset: 0x8
abstract class zcb extends Object {
}
