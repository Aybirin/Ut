// lib: , url: bAn

// class id: 1050817, size: 0x8
class :: {
}

// class id: 372, size: 0x8, field offset: 0x8
abstract class vLb extends Object {

  static late final List<String> _TZj; // offset: 0x1c5c
}
