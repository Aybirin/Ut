// lib: , url: ljn

// class id: 1050022, size: 0x8
class :: {

  [closure] static void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x790678, size: -0x1
  }
}

// class id: 1302, size: 0x34, field offset: 0x8
class GG extends Object {

  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x790f68, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x7920e0, size: -0x1
  }
}

// class id: 1303, size: 0x10, field offset: 0x8
class Wib extends Object {
}
