// lib: , url: TLm

// class id: 1048956, size: 0x8
class :: {
}

// class id: 3525, size: 0x10, field offset: 0x8
abstract class dQ extends Object {

  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0xbb1d54, size: 0xb8
    // 0xbb1d54: EnterFrame
    //     0xbb1d54: stp             fp, lr, [SP, #-0x10]!
    //     0xbb1d58: mov             fp, SP
    // 0xbb1d5c: AllocStack(0x50)
    //     0xbb1d5c: sub             SP, SP, #0x50
    // 0xbb1d60: SetupParameters([dynamic _ /* r0 */])
    //     0xbb1d60: ldr             x0, [fp, #0x10]
    //     0xbb1d64: ldur            w1, [x0, #0x17]
    //     0xbb1d68: add             x1, x1, HEAP, lsl #32
    // 0xbb1d6c: CheckStackOverflow
    //     0xbb1d6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbb1d70: cmp             SP, x16
    //     0xbb1d74: b.ls            #0xbb1e04
    // 0xbb1d78: LoadField: r0 = r1->field_f
    //     0xbb1d78: ldur            w0, [x1, #0xf]
    // 0xbb1d7c: DecompressPointer r0
    //     0xbb1d7c: add             x0, x0, HEAP, lsl #32
    // 0xbb1d80: LoadField: r1 = r0->field_7
    //     0xbb1d80: ldur            x1, [x0, #7]
    // 0xbb1d84: sub             x2, x1, #1
    // 0xbb1d88: StoreField: r0->field_7 = r2
    //     0xbb1d88: stur            x2, [x0, #7]
    // 0xbb1d8c: cmp             x2, #0
    // 0xbb1d90: b.gt            #0xbb1df4
    // 0xbb1d94: mov             x1, x0
    // 0xbb1d98: r0 = call 0x5f3598
    //     0xbb1d98: bl              #0x5f3598
    // 0xbb1d9c: b               #0xbb1df4
    // 0xbb1da0: sub             SP, fp, #0x50
    // 0xbb1da4: mov             x2, x0
    // 0xbb1da8: stur            x0, [fp, #-0x48]
    // 0xbb1dac: mov             x0, x1
    // 0xbb1db0: stur            x1, [fp, #-0x50]
    // 0xbb1db4: r1 = <List<Object>>
    //     0xbb1db4: ldr             x1, [PP, #0x8b8]  ; [pp+0x8b8] TypeArguments: <List<Object>>
    // 0xbb1db8: r0 = LP()
    //     0xbb1db8: bl              #0xb12c64  ; AllocateLPStub -> LP (size=0x2c)
    // 0xbb1dbc: mov             x1, x0
    // 0xbb1dc0: r2 = "while handling pending events"
    //     0xbb1dc0: add             x2, PP, #8, lsl #12  ; [pp+0x81f0] "while handling pending events"
    //     0xbb1dc4: ldr             x2, [x2, #0x1f0]
    // 0xbb1dc8: r3 = Instance_DP
    //     0xbb1dc8: ldr             x3, [PP, #0x8c0]  ; [pp+0x8c0] Obj!DP@69e151
    // 0xbb1dcc: r0 = call 0x39dba8
    //     0xbb1dcc: bl              #0x39dba8
    // 0xbb1dd0: r0 = PP()
    //     0xbb1dd0: bl              #0xb12c58  ; AllocatePPStub -> PP (size=0x14)
    // 0xbb1dd4: mov             x1, x0
    // 0xbb1dd8: ldur            x0, [fp, #-0x48]
    // 0xbb1ddc: StoreField: r1->field_7 = r0
    //     0xbb1ddc: stur            w0, [x1, #7]
    // 0xbb1de0: ldur            x0, [fp, #-0x50]
    // 0xbb1de4: StoreField: r1->field_b = r0
    //     0xbb1de4: stur            w0, [x1, #0xb]
    // 0xbb1de8: r0 = false
    //     0xbb1de8: add             x0, NULL, #0x30  ; false
    // 0xbb1dec: StoreField: r1->field_f = r0
    //     0xbb1dec: stur            w0, [x1, #0xf]
    // 0xbb1df0: r0 = call 0x3993e4
    //     0xbb1df0: bl              #0x3993e4
    // 0xbb1df4: r0 = Null
    //     0xbb1df4: mov             x0, NULL
    // 0xbb1df8: LeaveFrame
    //     0xbb1df8: mov             SP, fp
    //     0xbb1dfc: ldp             fp, lr, [SP], #0x10
    // 0xbb1e00: ret
    //     0xbb1e00: ret             
    // 0xbb1e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbb1e04: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbb1e08: b               #0xbb1d78
  }
}
