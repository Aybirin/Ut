// lib: ODn, url: wnn

// class id: 1050193, size: 0x8
class :: {
}

// class id: 1000, size: 0xc, field offset: 0xc
class Xnb extends hnb {

  static late final fqb GEg; // offset: 0x1010

  [closure] static Xnb <anonymous closure>(dynamic) {
    // ** addr: 0x40e618, size: -0x1
  }
  [closure] static Xnb _VJg(dynamic, String, enb, dnb, za, za, List<int>) {
    // ** addr: 0x40e730, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40e5c0, size: -0x1
  }
}
