// lib: , url: uln

// class id: 1050106, size: 0x8
class :: {

  [closure] static Y2 <anonymous closure>(dynamic, (Y0, Y1)) {
    // ** addr: 0x5b9d30, size: -0x1
  }
}

// class id: 1120, size: 0x14, field offset: 0xc
class wkb<C1X0, C1X1> extends ckb<C1X0>
    implements zkb {
}
