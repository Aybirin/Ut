// lib: , url: kkn

// class id: 1050047, size: 0x8
class :: {
}

// class id: 1161, size: 0x8, field offset: 0x8
class UJ extends Object {
}
