// lib: , url: Nyn

// class id: 1050751, size: 0x8
class :: {
}

// class id: 4697, size: 0x34, field offset: 0xc
//   const constructor, 
class hJb extends Zu
    implements rO {

  [closure] Mca <anonymous closure>(dynamic, iva, Mca?) {
    // ** addr: 0x86d0c8, size: -0x1
  }
}
