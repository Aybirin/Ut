// lib: , url: qzn

// class id: 1050780, size: 0x8
class :: {
}

// class id: 403, size: 0x8, field offset: 0x8
//   const constructor, 
class dKb extends Object
    implements cKb {
}

// class id: 404, size: 0x8, field offset: 0x8
abstract class cKb extends Object {
}
