// lib: , url: Tin

// class id: 1050118, size: 0x8
class :: {
}

// class id: 1111, size: 0x1c, field offset: 0xc
class Qkb extends ckb<dynamic> {
}
