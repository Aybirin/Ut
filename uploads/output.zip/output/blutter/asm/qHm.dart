// lib: , url: qHm

// class id: 1048771, size: 0x8
class :: {
}

// class id: 5784, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class zB extends Object {
}

// class id: 5785, size: 0x18, field offset: 0x10
//   const constructor, 
class EB extends zB {

  Map<String, dynamic> Gxc(EB) {
    // ** addr: 0xc30504, size: 0x48
    // 0xc30504: EnterFrame
    //     0xc30504: stp             fp, lr, [SP, #-0x10]!
    //     0xc30508: mov             fp, SP
    // 0xc3050c: CheckStackOverflow
    //     0xc3050c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc30510: cmp             SP, x16
    //     0xc30514: b.ls            #0xc3052c
    // 0xc30518: ldr             x1, [fp, #0x10]
    // 0xc3051c: r0 = call 0x9c0fec
    //     0xc3051c: bl              #0x9c0fec
    // 0xc30520: LeaveFrame
    //     0xc30520: mov             SP, fp
    //     0xc30524: ldp             fp, lr, [SP], #0x10
    // 0xc30528: ret
    //     0xc30528: ret             
    // 0xc3052c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3052c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc30530: b               #0xc30518
  }
}

// class id: 5786, size: 0x14, field offset: 0x10
//   const constructor, 
class DB extends zB {

  Map<String, dynamic> Gxc(DB) {
    // ** addr: 0xb96804, size: 0x48
    // 0xb96804: EnterFrame
    //     0xb96804: stp             fp, lr, [SP, #-0x10]!
    //     0xb96808: mov             fp, SP
    // 0xb9680c: CheckStackOverflow
    //     0xb9680c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb96810: cmp             SP, x16
    //     0xb96814: b.ls            #0xb9682c
    // 0xb96818: ldr             x1, [fp, #0x10]
    // 0xb9681c: r0 = call 0x4ac1e0
    //     0xb9681c: bl              #0x4ac1e0
    // 0xb96820: LeaveFrame
    //     0xb96820: mov             SP, fp
    //     0xb96824: ldp             fp, lr, [SP], #0x10
    // 0xb96828: ret
    //     0xb96828: ret             
    // 0xb9682c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9682c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb96830: b               #0xb96818
  }
}

// class id: 5787, size: 0x10, field offset: 0x10
//   const constructor, 
class CB extends zB {

  Map<String, dynamic> Gxc(CB) {
    // ** addr: 0xb96858, size: 0x48
    // 0xb96858: EnterFrame
    //     0xb96858: stp             fp, lr, [SP, #-0x10]!
    //     0xb9685c: mov             fp, SP
    // 0xb96860: CheckStackOverflow
    //     0xb96860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb96864: cmp             SP, x16
    //     0xb96868: b.ls            #0xb96880
    // 0xb9686c: ldr             x1, [fp, #0x10]
    // 0xb96870: r0 = call 0x4ac278
    //     0xb96870: bl              #0x4ac278
    // 0xb96874: LeaveFrame
    //     0xb96874: mov             SP, fp
    //     0xb96878: ldp             fp, lr, [SP], #0x10
    // 0xb9687c: ret
    //     0xb9687c: ret             
    // 0xb96880: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb96880: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb96884: b               #0xb9686c
  }
}

// class id: 5788, size: 0x20, field offset: 0x10
//   const constructor, 
class BB extends zB {

  Map<String, dynamic> Gxc(BB) {
    // ** addr: 0xc304bc, size: 0x48
    // 0xc304bc: EnterFrame
    //     0xc304bc: stp             fp, lr, [SP, #-0x10]!
    //     0xc304c0: mov             fp, SP
    // 0xc304c4: CheckStackOverflow
    //     0xc304c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc304c8: cmp             SP, x16
    //     0xc304cc: b.ls            #0xc304e4
    // 0xc304d0: ldr             x1, [fp, #0x10]
    // 0xc304d4: r0 = call 0x9c0b80
    //     0xc304d4: bl              #0x9c0b80
    // 0xc304d8: LeaveFrame
    //     0xc304d8: mov             SP, fp
    //     0xc304dc: ldp             fp, lr, [SP], #0x10
    // 0xc304e0: ret
    //     0xc304e0: ret             
    // 0xc304e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc304e4: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc304e8: b               #0xc304d0
  }
}

// class id: 5789, size: 0x30, field offset: 0x10
//   const constructor, 
class AB extends zB {

  Map<String, dynamic> Gxc(AB) {
    // ** addr: 0xb98d94, size: 0x48
    // 0xb98d94: EnterFrame
    //     0xb98d94: stp             fp, lr, [SP, #-0x10]!
    //     0xb98d98: mov             fp, SP
    // 0xb98d9c: CheckStackOverflow
    //     0xb98d9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb98da0: cmp             SP, x16
    //     0xb98da4: b.ls            #0xb98dbc
    // 0xb98da8: ldr             x1, [fp, #0x10]
    // 0xb98dac: r0 = call 0x4ae020
    //     0xb98dac: bl              #0x4ae020
    // 0xb98db0: LeaveFrame
    //     0xb98db0: mov             SP, fp
    //     0xb98db4: ldp             fp, lr, [SP], #0x10
    // 0xb98db8: ret
    //     0xb98db8: ret             
    // 0xb98dbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb98dbc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb98dc0: b               #0xb98da8
  }
}
