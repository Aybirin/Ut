// lib: , url: iYm

// class id: 1049527, size: 0x8
class :: {
}

// class id: 2331, size: 0x18, field offset: 0x8
//   const constructor, 
class HKa extends Object {

  _Mint field_8;
  _Mint field_10;
}
