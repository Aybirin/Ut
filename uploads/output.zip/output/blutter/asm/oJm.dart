// lib: , url: oJm

// class id: 1048871, size: 0x8
class :: {
}

// class id: 5478, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class HH extends Object {
}

// class id: 5479, size: 0xc, field offset: 0x8
//   const constructor, 
class _IH extends HH {

  bool field_8;

  dynamic Gxc<Y0>(_IH, Y0) {
    // ** addr: 0xbc63a4, size: 0x64
    // 0xbc63a4: EnterFrame
    //     0xbc63a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbc63a8: mov             fp, SP
    // 0xbc63ac: LoadField: r0 = r4->field_f
    //     0xbc63ac: ldur            w0, [x4, #0xf]
    // 0xbc63b0: cbnz            w0, #0xbc63bc
    // 0xbc63b4: r1 = Null
    //     0xbc63b4: mov             x1, NULL
    // 0xbc63b8: b               #0xbc63c8
    // 0xbc63bc: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xbc63bc: ldur            w0, [x4, #0x17]
    // 0xbc63c0: add             x1, fp, w0, sxtw #2
    // 0xbc63c4: ldr             x1, [x1, #0x10]
    // 0xbc63c8: ldr             x0, [fp, #0x10]
    // 0xbc63cc: r2 = Null
    //     0xbc63cc: mov             x2, NULL
    // 0xbc63d0: cmp             w1, NULL
    // 0xbc63d4: b.eq            #0xbc63f8
    // 0xbc63d8: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xbc63d8: ldur            w4, [x1, #0x17]
    // 0xbc63dc: DecompressPointer r4
    //     0xbc63dc: add             x4, x4, HEAP, lsl #32
    // 0xbc63e0: r8 = Y0
    //     0xbc63e0: add             x8, PP, #0x1c, lsl #12  ; [pp+0x1ca50] TypeParameter: Y0
    //     0xbc63e4: ldr             x8, [x8, #0xa50]
    // 0xbc63e8: LoadField: r9 = r4->field_7
    //     0xbc63e8: ldur            x9, [x4, #7]
    // 0xbc63ec: r3 = Null
    //     0xbc63ec: add             x3, PP, #0x1c, lsl #12  ; [pp+0x1ca58] Null
    //     0xbc63f0: ldr             x3, [x3, #0xa58]
    // 0xbc63f4: blr             x9
    // 0xbc63f8: ldr             x0, [fp, #0x10]
    // 0xbc63fc: LeaveFrame
    //     0xbc63fc: mov             SP, fp
    //     0xbc6400: ldp             fp, lr, [SP], #0x10
    // 0xbc6404: ret
    //     0xbc6404: ret             
  }
}

// class id: 5480, size: 0x14, field offset: 0x8
//   const constructor, 
class GH<X0> extends Object {

  bool field_c;

  X0 dyn:get:value(GH<X0>) {
    // ** addr: 0xbc5a94, size: 0x80
    // 0xbc5a94: EnterFrame
    //     0xbc5a94: stp             fp, lr, [SP, #-0x10]!
    //     0xbc5a98: mov             fp, SP
    // 0xbc5a9c: AllocStack(0x8)
    //     0xbc5a9c: sub             SP, SP, #8
    // 0xbc5aa0: ldr             x0, [fp, #0x10]
    // 0xbc5aa4: LoadField: r3 = r0->field_f
    //     0xbc5aa4: ldur            w3, [x0, #0xf]
    // 0xbc5aa8: DecompressPointer r3
    //     0xbc5aa8: add             x3, x3, HEAP, lsl #32
    // 0xbc5aac: stur            x3, [fp, #-8]
    // 0xbc5ab0: cmp             w3, NULL
    // 0xbc5ab4: b.ne            #0xbc5aec
    // 0xbc5ab8: LoadField: r2 = r0->field_7
    //     0xbc5ab8: ldur            w2, [x0, #7]
    // 0xbc5abc: DecompressPointer r2
    //     0xbc5abc: add             x2, x2, HEAP, lsl #32
    // 0xbc5ac0: mov             x0, x3
    // 0xbc5ac4: r1 = Null
    //     0xbc5ac4: mov             x1, NULL
    // 0xbc5ac8: cmp             w2, NULL
    // 0xbc5acc: b.eq            #0xbc5aec
    // 0xbc5ad0: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xbc5ad0: ldur            w4, [x2, #0x17]
    // 0xbc5ad4: DecompressPointer r4
    //     0xbc5ad4: add             x4, x4, HEAP, lsl #32
    // 0xbc5ad8: r8 = X0
    //     0xbc5ad8: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xbc5adc: LoadField: r9 = r4->field_7
    //     0xbc5adc: ldur            x9, [x4, #7]
    // 0xbc5ae0: r3 = Null
    //     0xbc5ae0: add             x3, PP, #0x34, lsl #12  ; [pp+0x347b8] Null
    //     0xbc5ae4: ldr             x3, [x3, #0x7b8]
    // 0xbc5ae8: blr             x9
    // 0xbc5aec: ldur            x0, [fp, #-8]
    // 0xbc5af0: LeaveFrame
    //     0xbc5af0: mov             SP, fp
    //     0xbc5af4: ldp             fp, lr, [SP], #0x10
    // 0xbc5af8: ret
    //     0xbc5af8: ret             
  }
}

// class id: 5481, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class FH<X0> extends Object
    implements CH<X0> {
}

// class id: 5485, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class EH extends Object {
}

// class id: 5489, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class CH<X0> extends Object {
}
