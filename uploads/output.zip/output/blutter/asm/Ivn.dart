// lib: , url: Ivn

// class id: 1050588, size: 0x8
class :: {
}

// class id: 454, size: 0x8, field offset: 0x8
abstract class tBb extends Object {

  static late final Tz<double> _CDj; // offset: 0x1b04
}
