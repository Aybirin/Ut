// lib: yDn, url: gnn

// class id: 1050177, size: 0x8
class :: {
}

// class id: 1016, size: 0xc, field offset: 0xc
class rnb extends hnb {

  static late final fqb GEg; // offset: 0xfd0

  [closure] static rnb <anonymous closure>(dynamic) {
    // ** addr: 0x40fe14, size: -0x1
  }
  [closure] static rnb _VJg(dynamic, String, enb, dnb, za, za?, List<int>?) {
    // ** addr: 0x40ff18, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40fdbc, size: -0x1
  }
}
