// lib: , url: cPm

// class id: 1049112, size: 0x8
class :: {
}

// class id: 3730, size: 0x40, field offset: 0x8
//   const constructor, 
class nfa extends _FM {
}

// class id: 4636, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ofa extends uP {
}

// class id: 7279, size: 0x14, field offset: 0x14
enum pfa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
