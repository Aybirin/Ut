// lib: , url: HZm

// class id: 1049574, size: 0x8
class :: {
}

// class id: 2266, size: 0xc, field offset: 0x8
//   const constructor, 
class VLa extends Object {
}
