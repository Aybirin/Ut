// lib: , url: stn

// class id: 1050473, size: 0x8
class :: {
}

// class id: 622, size: 0x10, field offset: 0x8
class Wxb extends Object {
}
