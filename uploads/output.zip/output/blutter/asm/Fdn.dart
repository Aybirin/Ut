// lib: , url: Fdn

// class id: 1049789, size: 0x8
class :: {
}

// class id: 7520, size: 0x10, field offset: 0xc
class Ocb extends Iterable<dynamic>
    implements Lr {

  int length(Ocb) {
    // ** addr: 0xbaaf8c, size: 0x2c
    // 0xbaaf8c: ldr             x1, [SP]
    // 0xbaaf90: LoadField: r2 = r1->field_b
    //     0xbaaf90: ldur            w2, [x1, #0xb]
    // 0xbaaf94: DecompressPointer r2
    //     0xbaaf94: add             x2, x2, HEAP, lsl #32
    // 0xbaaf98: LoadField: r0 = r2->field_13
    //     0xbaaf98: ldur            w0, [x2, #0x13]
    // 0xbaaf9c: ret
    //     0xbaaf9c: ret             
  }
  num [](Ocb, int) {
    // ** addr: 0xbdbaa8, size: 0x80
    // 0xbdbaa8: EnterFrame
    //     0xbdbaa8: stp             fp, lr, [SP, #-0x10]!
    //     0xbdbaac: mov             fp, SP
    // 0xbdbab0: CheckStackOverflow
    //     0xbdbab0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbdbab4: cmp             SP, x16
    //     0xbdbab8: b.ls            #0xbdbb08
    // 0xbdbabc: ldr             x0, [fp, #0x10]
    // 0xbdbac0: r2 = Null
    //     0xbdbac0: mov             x2, NULL
    // 0xbdbac4: r1 = Null
    //     0xbdbac4: mov             x1, NULL
    // 0xbdbac8: branchIfSmi(r0, 0xbdbaf0)
    //     0xbdbac8: tbz             w0, #0, #0xbdbaf0
    // 0xbdbacc: r4 = LoadClassIdInstr(r0)
    //     0xbdbacc: ldur            x4, [x0, #-1]
    //     0xbdbad0: ubfx            x4, x4, #0xc, #0x14
    // 0xbdbad4: sub             x4, x4, #0x3c
    // 0xbdbad8: cmp             x4, #1
    // 0xbdbadc: b.ls            #0xbdbaf0
    // 0xbdbae0: r8 = int
    //     0xbdbae0: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xbdbae4: r3 = Null
    //     0xbdbae4: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3be50] Null
    //     0xbdbae8: ldr             x3, [x3, #0xe50]
    // 0xbdbaec: r0 = int()
    //     0xbdbaec: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xbdbaf0: ldr             x1, [fp, #0x18]
    // 0xbdbaf4: ldr             x2, [fp, #0x10]
    // 0xbdbaf8: r0 = call 0x968a54
    //     0xbdbaf8: bl              #0x968a54
    // 0xbdbafc: LeaveFrame
    //     0xbdbafc: mov             SP, fp
    //     0xbdbb00: ldp             fp, lr, [SP], #0x10
    // 0xbdbb04: ret
    //     0xbdbb04: ret             
    // 0xbdbb08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbdbb08: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbdbb0c: b               #0xbdbabc
  }
}
