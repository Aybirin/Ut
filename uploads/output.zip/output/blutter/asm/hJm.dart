// lib: , url: hJm

// class id: 1048868, size: 0x8
class :: {
}

// class id: 5506, size: 0x10, field offset: 0x8
//   const constructor, 
class qH extends Object {

  LJ field_8;
  bool field_c;
}
