// lib: , url: gun

// class id: 1050513, size: 0x8
class :: {
}

// class id: 517, size: 0x8, field offset: 0x8
abstract class kzb extends Object {
}
