// lib: , url: LYm

// class id: 1049602, size: 0x8
class :: {
}

// class id: 2130, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class LMa extends Object
    implements VN {
}

// class id: 3566, size: 0xc, field offset: 0xc
//   const constructor, 
class _MMa extends XN<dynamic> {

  static late final Map<Ws, Future<VN>> _bgg; // offset: 0xc10

  [closure] OQ<VN> <anonymous closure>(dynamic) {
    // ** addr: 0x8daa00, size: -0x1
  }
  [closure] void Qwm(dynamic, String?) {
    // ** addr: 0x8e2494, size: -0x1
  }
}
