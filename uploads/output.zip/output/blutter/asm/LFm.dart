// lib: , url: LFm

// class id: 1048697, size: 0x8
class :: {
}

// class id: 6022, size: 0x8, field offset: 0x8
abstract class sy extends Object {

  static late String _iug; // offset: 0xd38
  static late String _tug; // offset: 0xd6c
  static late Map<String, dynamic> _uug; // offset: 0xd70

  [closure] static bool <anonymous closure>(dynamic, String, dynamic) {
    // ** addr: 0x3cdb94, size: -0x1
  }
}
