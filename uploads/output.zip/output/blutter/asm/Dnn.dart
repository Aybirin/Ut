// lib: VDn, url: Dnn

// class id: 1050200, size: 0x8
class :: {
}

// class id: 993, size: 0xc, field offset: 0xc
class lob extends hnb {

  static late final fqb GEg; // offset: 0x102c

  [closure] static lob <anonymous closure>(dynamic) {
    // ** addr: 0x40db28, size: -0x1
  }
  [closure] static lob _VJg(dynamic, String, enb, dnb, za, za, List<int>) {
    // ** addr: 0x40dc40, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40dad0, size: -0x1
  }
}
