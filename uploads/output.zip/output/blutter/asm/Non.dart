// lib: mDn, url: Non

// class id: 1050265, size: 0x8
class :: {
}

// class id: 936, size: 0x28, field offset: 0x8
class Aqb extends Wpb {

  static late final fqb GEg; // offset: 0xf88
  static late final Uint8List _iZc; // offset: 0xf8c
  static late final Uint8List _CJg; // offset: 0xf90
  late Uint8List _EJg; // offset: 0xc

  [closure] static Aqb <anonymous closure>(dynamic) {
    // ** addr: 0x4001ac, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x400154, size: -0x1
  }
}
