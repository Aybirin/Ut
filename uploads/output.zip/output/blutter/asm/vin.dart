// lib: , url: vin

// class id: 1049979, size: 0x8
class :: {
}

// class id: 1373, size: 0x14, field offset: 0x8
class iib extends Object {
}
