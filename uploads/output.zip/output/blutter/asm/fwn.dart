// lib: , url: fwn

// class id: 1050611, size: 0x8
class :: {
}

// class id: 432, size: 0xc, field offset: 0x8
class UBb extends Object {
}

// class id: 433, size: 0x1c, field offset: 0x8
class TBb extends Object {
}

// class id: 435, size: 0x8, field offset: 0x8
abstract class RBb extends Object {
}
