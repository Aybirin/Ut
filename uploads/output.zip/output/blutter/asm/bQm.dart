// lib: , url: bQm

// class id: 1049158, size: 0x8
class :: {
}

// class id: 2877, size: 0x58, field offset: 0x50
abstract class jP extends Xha {

  [closure] Pg _wJd(dynamic, wca) {
    // ** addr: 0x50a394, size: -0x1
  }
  [closure] double? <anonymous closure>(dynamic, (wca, yt)) {
    // ** addr: 0x4f814c, size: -0x1
  }
  [closure] double? _zJd(dynamic, (wca, yt)) {
    // ** addr: 0x503550, size: -0x1
  }
  [closure] void HJd(dynamic) {
    // ** addr: 0x5899f0, size: -0x1
  }
}

// class id: 3085, size: 0x18, field offset: 0x8
class _gia extends Object {
}

// class id: 3086, size: 0x8, field offset: 0x8
//   const constructor, 
class _eia extends Object
    implements _aia<X0, X1> {

  [closure] double? Hl(dynamic) {
    // ** addr: 0x9e613c, size: -0x1
  }
}

// class id: 3087, size: 0x8, field offset: 0x8
//   const constructor, 
class _dia extends Object
    implements _aia<X0, X1> {

  [closure] Pg <anonymous closure>(dynamic) {
    // ** addr: 0xa261c4, size: -0x1
  }
}

// class id: 3088, size: 0xc, field offset: 0x8
abstract class _aia<X0, X1> extends Object {
}

// class id: 3105, size: 0xc, field offset: 0x8
class Tha extends Uha {
}

// class id: 3106, size: 0x18, field offset: 0xc
//   transformed mixin,
abstract class _Vha<X0 bound Xha> extends Tha
     with Yha<X0 bound Xha> {
}

// class id: 3107, size: 0x18, field offset: 0x18
abstract class Zha<X0 bound Xha> extends _Vha<X0 bound Xha> {
}

// class id: 3119, size: 0x28, field offset: 0x8
//   const constructor, 
class wca extends Qha {

  _Mint field_8;
  _Double field_10;
  _Mint field_18;
  _Double field_20;
}

// class id: 3378, size: 0x14, field offset: 0x14
class Rha extends XQ {
}

// class id: 3384, size: 0x14, field offset: 0x14
class Sha extends WQ<dynamic> {
}

// class id: 3547, size: 0xc, field offset: 0x8
abstract class iP<X0 bound jP, X1 bound Zha> extends Object
    implements Iea<X0 bound Xha, X1 bound Yha> {
}

// class id: 7264, size: 0x14, field offset: 0x14
enum _fia extends _Enum
    implements _aia<X0, X1> {

  _Mint field_8;
  _OneByteString field_10;
}
