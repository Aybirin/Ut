// lib: , url: Lkn

// class id: 1050074, size: 0x8
class :: {
}

// class id: 5894, size: 0x8, field offset: 0x8
abstract class Pjb extends Ez {

  static late final Object _Hcd; // offset: 0x610
  static late Pjb _UMc; // offset: 0x614
}
