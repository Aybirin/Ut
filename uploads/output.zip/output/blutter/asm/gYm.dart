// lib: , url: gYm

// class id: 1049526, size: 0x8
class :: {
}

// class id: 2332, size: 0x18, field offset: 0x8
class GKa extends Object {

  Map<String, dynamic> Gxc(GKa) {
    // ** addr: 0xbc0d80, size: 0x48
    // 0xbc0d80: EnterFrame
    //     0xbc0d80: stp             fp, lr, [SP, #-0x10]!
    //     0xbc0d84: mov             fp, SP
    // 0xbc0d88: CheckStackOverflow
    //     0xbc0d88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbc0d8c: cmp             SP, x16
    //     0xbc0d90: b.ls            #0xbc0da8
    // 0xbc0d94: ldr             x1, [fp, #0x10]
    // 0xbc0d98: r0 = call 0x6a46c4
    //     0xbc0d98: bl              #0x6a46c4
    // 0xbc0d9c: LeaveFrame
    //     0xbc0d9c: mov             SP, fp
    //     0xbc0da0: ldp             fp, lr, [SP], #0x10
    // 0xbc0da4: ret
    //     0xbc0da4: ret             
    // 0xbc0da8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc0da8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc0dac: b               #0xbc0d94
  }
}

// class id: 2333, size: 0x18, field offset: 0x8
class FKa extends Object {

  Map<String, dynamic> Gxc(FKa) {
    // ** addr: 0xbc0cd8, size: 0x48
    // 0xbc0cd8: EnterFrame
    //     0xbc0cd8: stp             fp, lr, [SP, #-0x10]!
    //     0xbc0cdc: mov             fp, SP
    // 0xbc0ce0: CheckStackOverflow
    //     0xbc0ce0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbc0ce4: cmp             SP, x16
    //     0xbc0ce8: b.ls            #0xbc0d00
    // 0xbc0cec: ldr             x1, [fp, #0x10]
    // 0xbc0cf0: r0 = call 0x6a46c4
    //     0xbc0cf0: bl              #0x6a46c4
    // 0xbc0cf4: LeaveFrame
    //     0xbc0cf4: mov             SP, fp
    //     0xbc0cf8: ldp             fp, lr, [SP], #0x10
    // 0xbc0cfc: ret
    //     0xbc0cfc: ret             
    // 0xbc0d00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc0d00: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc0d04: b               #0xbc0cec
  }
}
