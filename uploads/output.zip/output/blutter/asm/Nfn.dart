// lib: , url: Nfn

// class id: 1049843, size: 0x8
class :: {
}

// class id: 1494, size: 0x38, field offset: 0x8
class yeb extends Object {

  late int SHh; // offset: 0x2c
  late int RHh; // offset: 0x28
}
