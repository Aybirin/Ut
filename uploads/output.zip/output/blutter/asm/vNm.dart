// lib: , url: vNm

// class id: 1049030, size: 0x8
class :: {
}

// class id: 3813, size: 0x1c, field offset: 0x8
//   const constructor, 
class SW extends _FM {
}

// class id: 4647, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class UW extends uP {
}
