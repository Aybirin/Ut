// lib: , url: Nun

// class id: 1050545, size: 0x8
class :: {
}

// class id: 504, size: 0x8, field offset: 0x8
abstract class lAb extends Object {
}
