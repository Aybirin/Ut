// lib: jEn, url: Fon

// class id: 1050257, size: 0x8
class :: {

  static late final List<int> _nKg; // offset: 0x1060
}

// class id: 926, size: 0xc, field offset: 0x8
class lqb extends Object {

  int dyn:get:length(lqb) {
    // ** addr: 0xb36b34, size: 0x2c
    // 0xb36b34: ldr             x1, [SP]
    // 0xb36b38: LoadField: r2 = r1->field_7
    //     0xb36b38: ldur            w2, [x1, #7]
    // 0xb36b3c: DecompressPointer r2
    //     0xb36b3c: add             x2, x2, HEAP, lsl #32
    // 0xb36b40: LoadField: r0 = r2->field_b
    //     0xb36b40: ldur            w0, [x2, #0xb]
    // 0xb36b44: ret
    //     0xb36b44: ret             
  }
  kqb [](lqb, int) {
    // ** addr: 0xb36b60, size: 0xa8
    // 0xb36b60: EnterFrame
    //     0xb36b60: stp             fp, lr, [SP, #-0x10]!
    //     0xb36b64: mov             fp, SP
    // 0xb36b68: ldr             x0, [fp, #0x10]
    // 0xb36b6c: r2 = Null
    //     0xb36b6c: mov             x2, NULL
    // 0xb36b70: r1 = Null
    //     0xb36b70: mov             x1, NULL
    // 0xb36b74: branchIfSmi(r0, 0xb36b9c)
    //     0xb36b74: tbz             w0, #0, #0xb36b9c
    // 0xb36b78: r4 = LoadClassIdInstr(r0)
    //     0xb36b78: ldur            x4, [x0, #-1]
    //     0xb36b7c: ubfx            x4, x4, #0xc, #0x14
    // 0xb36b80: sub             x4, x4, #0x3c
    // 0xb36b84: cmp             x4, #1
    // 0xb36b88: b.ls            #0xb36b9c
    // 0xb36b8c: r8 = int
    //     0xb36b8c: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xb36b90: r3 = Null
    //     0xb36b90: add             x3, PP, #0x14, lsl #12  ; [pp+0x14520] Null
    //     0xb36b94: ldr             x3, [x3, #0x520]
    // 0xb36b98: r0 = int()
    //     0xb36b98: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xb36b9c: ldr             x2, [fp, #0x18]
    // 0xb36ba0: LoadField: r3 = r2->field_7
    //     0xb36ba0: ldur            w3, [x2, #7]
    // 0xb36ba4: DecompressPointer r3
    //     0xb36ba4: add             x3, x3, HEAP, lsl #32
    // 0xb36ba8: LoadField: r2 = r3->field_b
    //     0xb36ba8: ldur            w2, [x3, #0xb]
    // 0xb36bac: ldr             x4, [fp, #0x10]
    // 0xb36bb0: r5 = LoadInt32Instr(r4)
    //     0xb36bb0: sbfx            x5, x4, #1, #0x1f
    //     0xb36bb4: tbz             w4, #0, #0xb36bbc
    //     0xb36bb8: ldur            x5, [x4, #7]
    // 0xb36bbc: r0 = LoadInt32Instr(r2)
    //     0xb36bbc: sbfx            x0, x2, #1, #0x1f
    // 0xb36bc0: mov             x1, x5
    // 0xb36bc4: cmp             x1, x0
    // 0xb36bc8: b.hs            #0xb36bec
    // 0xb36bcc: LoadField: r1 = r3->field_f
    //     0xb36bcc: ldur            w1, [x3, #0xf]
    // 0xb36bd0: DecompressPointer r1
    //     0xb36bd0: add             x1, x1, HEAP, lsl #32
    // 0xb36bd4: ArrayLoad: r0 = r1[r5]  ; Unknown_4
    //     0xb36bd4: add             x16, x1, x5, lsl #2
    //     0xb36bd8: ldur            w0, [x16, #0xf]
    // 0xb36bdc: DecompressPointer r0
    //     0xb36bdc: add             x0, x0, HEAP, lsl #32
    // 0xb36be0: LeaveFrame
    //     0xb36be0: mov             SP, fp
    //     0xb36be4: ldp             fp, lr, [SP], #0x10
    // 0xb36be8: ret
    //     0xb36be8: ret             
    // 0xb36bec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb36bec: bl              #0xc55d98  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 927, size: 0x10, field offset: 0x8
class kqb extends Object {

  late int _YJg; // offset: 0x8
  late int _ZJg; // offset: 0xc

  int dyn:get:_YJg(kqb) {
    // ** addr: 0xb36a48, size: 0x48
    // 0xb36a48: ldr             x1, [SP]
    // 0xb36a4c: LoadField: r0 = r1->field_7
    //     0xb36a4c: ldur            w0, [x1, #7]
    // 0xb36a50: DecompressPointer r0
    //     0xb36a50: add             x0, x0, HEAP, lsl #32
    // 0xb36a54: r16 = Sentinel
    //     0xb36a54: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xb36a58: cmp             w0, w16
    // 0xb36a5c: b.eq            #0xb36a64
    // 0xb36a60: ret
    //     0xb36a60: ret             
    // 0xb36a64: EnterFrame
    //     0xb36a64: stp             fp, lr, [SP, #-0x10]!
    //     0xb36a68: mov             fp, SP
    // 0xb36a6c: r9 = _YJg
    //     0xb36a6c: add             x9, PP, #9, lsl #12  ; [pp+0x9f00] Field <kqb._YJg@1029143242>: late (offset: 0x8)
    //     0xb36a70: ldr             x9, [x9, #0xf00]
    // 0xb36a74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb36a74: bl              #0xc56180  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  int dyn:get:_ZJg(kqb) {
    // ** addr: 0xb36a90, size: 0x48
    // 0xb36a90: ldr             x1, [SP]
    // 0xb36a94: LoadField: r0 = r1->field_b
    //     0xb36a94: ldur            w0, [x1, #0xb]
    // 0xb36a98: DecompressPointer r0
    //     0xb36a98: add             x0, x0, HEAP, lsl #32
    // 0xb36a9c: r16 = Sentinel
    //     0xb36a9c: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xb36aa0: cmp             w0, w16
    // 0xb36aa4: b.eq            #0xb36aac
    // 0xb36aa8: ret
    //     0xb36aa8: ret             
    // 0xb36aac: EnterFrame
    //     0xb36aac: stp             fp, lr, [SP, #-0x10]!
    //     0xb36ab0: mov             fp, SP
    // 0xb36ab4: r9 = _ZJg
    //     0xb36ab4: add             x9, PP, #9, lsl #12  ; [pp+0x9f08] Field <kqb._ZJg@1029143242>: late (offset: 0xc)
    //     0xb36ab8: ldr             x9, [x9, #0xf08]
    // 0xb36abc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xb36abc: bl              #0xc56180  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}
