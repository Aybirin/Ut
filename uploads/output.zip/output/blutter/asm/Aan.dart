// lib: , url: Aan

// class id: 1049615, size: 0x8
class :: {
}

// class id: 1876, size: 0x20, field offset: 0x8
class VTa extends Object {

  static late final VTa _UMc; // offset: 0x1658

  [closure] Future<void> _Qpi(dynamic) {
    // ** addr: 0x3f2074, size: -0x1
  }
  [closure] zWa <anonymous closure>(dynamic, Map<dynamic, dynamic>) {
    // ** addr: 0x42bff0, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, int) {
    // ** addr: 0x42cae4, size: -0x1
  }
}
