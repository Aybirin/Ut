// lib: , url: MGm

// class id: 1048750, size: 0x8
class :: {
}

// class id: 5960, size: 0x8, field offset: 0x8
class Cz extends Object {
}
