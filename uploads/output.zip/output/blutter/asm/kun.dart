// lib: , url: kun

// class id: 1050517, size: 0x8
class :: {
}

// class id: 4765, size: 0x40, field offset: 0xc
//   const constructor, 
class uzb extends Zu {

  [closure] Mca <anonymous closure>(dynamic, iva, wca) {
    // ** addr: 0x85508c, size: -0x1
  }
  [closure] Mca <anonymous closure>(dynamic, iva, Mca, int?, bool) {
    // ** addr: 0x854820, size: -0x1
  }
  [closure] Mca <anonymous closure>(dynamic, iva, Object, ua?) {
    // ** addr: 0x8547dc, size: -0x1
  }
  [closure] Hra <anonymous closure>(dynamic, iva, double, Mca?) {
    // ** addr: 0x854910, size: -0x1
  }
}
