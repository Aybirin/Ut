// lib: , url: SIm

// class id: 1048856, size: 0x8
class :: {
}

// class id: 5583, size: 0x10, field offset: 0x8
class _rG extends Object
    implements Jb<X0> {

  static late final Uint8List _UZg; // offset: 0x112c

  [closure] void add(dynamic, Object?) {
    // ** addr: 0x38e798, size: -0x1
  }
}

// class id: 6901, size: 0xc, field offset: 0xc
//   const constructor, 
class qG extends Ob<dynamic, dynamic> {

  [closure] _rG <anonymous closure>(dynamic, Jb<Uint8List>) {
    // ** addr: 0x935b7c, size: -0x1
  }
}
