// lib: , url: qrn

// class id: 1050369, size: 0x8
class :: {
}

// class id: 4769, size: 0x14, field offset: 0xc
//   const constructor, 
class Ztb extends aub {
}
