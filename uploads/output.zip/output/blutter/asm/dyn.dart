// lib: , url: dyn

// class id: 1050714, size: 0x8
class :: {
}

// class id: 4711, size: 0x10, field offset: 0xc
//   const constructor, 
class uHb extends Zu {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x86786c, size: -0x1
  }
}
