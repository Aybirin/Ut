// lib: , url: sEm

// class id: 1048632, size: 0x8
class :: {

  [closure] static String <anonymous closure>(dynamic, wa) {
    // ** addr: 0x463c20, size: -0x1
  }
}
