// lib: , url: VIm

// class id: 1048859, size: 0x8
class :: {
}

// class id: 5581, size: 0x10, field offset: 0x8
class uG extends Object {
}
