// lib: JEn, url: won

// class id: 1050248, size: 0x8
class :: {
}

// class id: 935, size: 0x8, field offset: 0x8
abstract class Wpb extends Object
    implements ulb {
}
