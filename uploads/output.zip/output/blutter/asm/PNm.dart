// lib: , url: PNm

// class id: 1049049, size: 0x8
class :: {
}

// class id: 3258, size: 0x8, field offset: 0x8
//   const constructor, 
class _BZ extends CZ {
}

// class id: 3264, size: 0x4c, field offset: 0x1c
class DZ extends zZ {

  late AM _tGf; // offset: 0x40
  late AM _vGf; // offset: 0x48
  late AM _rGf; // offset: 0x38
  static late final mM<double> _wGf; // offset: 0xaa4
  static late final mM<double> _xGf; // offset: 0xaa8
  late oM<int> _sGf; // offset: 0x3c
  late oM<int> _uGf; // offset: 0x44
  late oM<double> _HHd; // offset: 0x34

  [closure] void _iGf(dynamic, nM) {
    // ** addr: 0xa12624, size: -0x1
  }
}
