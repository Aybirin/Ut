// lib: , url: qsn

// class id: 1050421, size: 0x8
class :: {
}

// class id: 727, size: 0xc, field offset: 0x8
abstract class Pvb extends Object
    implements lvb {
}
