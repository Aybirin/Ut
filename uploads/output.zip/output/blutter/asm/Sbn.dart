// lib: , url: Sbn

// class id: 1049644, size: 0x8
class :: {
}

// class id: 1774, size: 0x38, field offset: 0x8
class DWa extends Object {
}

// class id: 1775, size: 0x8, field offset: 0x8
//   const constructor, 
class CWa extends Object {
}
