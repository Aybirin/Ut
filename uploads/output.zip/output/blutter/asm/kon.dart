// lib: kDn, url: kon

// class id: 1050236, size: 0x8
class :: {
}

// class id: 946, size: 0x8, field offset: 0x8
class Hpb extends Object
    implements tlb {

  static late final fqb GEg; // offset: 0xf7c

  [closure] static (dynamic) => Hpb <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x400b14, size: -0x1
  }
  [closure] static Hpb <anonymous closure>(dynamic) {
    // ** addr: 0x400bb0, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x400ab0, size: -0x1
  }
}
