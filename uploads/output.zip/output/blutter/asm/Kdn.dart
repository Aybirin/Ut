// lib: , url: Kdn

// class id: 1049876, size: 0x8
class :: {
}

// class id: 1460, size: 0x1c, field offset: 0x8
class xfb extends Object {
}
