// lib: FEn, url: uon

// class id: 1050246, size: 0x8
class :: {
}

// class id: 956, size: 0x8, field offset: 0x8
abstract class jpb extends Object
    implements mlb {
}
