// lib: , url: qbn

// class id: 1049631, size: 0x8
class :: {
}

// class id: 1251, size: 0x18, field offset: 0x14
class lVa extends uH {

  static late final lVa ZLc; // offset: 0x165c

  [closure] Future<void> <anonymous closure>(dynamic, XI) async {
    // ** addr: 0xc4ba00, size: 0x84
    // 0xc4ba00: EnterFrame
    //     0xc4ba00: stp             fp, lr, [SP, #-0x10]!
    //     0xc4ba04: mov             fp, SP
    // 0xc4ba08: AllocStack(0x18)
    //     0xc4ba08: sub             SP, SP, #0x18
    // 0xc4ba0c: SetupParameters(lVa this /* r1 */)
    //     0xc4ba0c: stur            NULL, [fp, #-8]
    //     0xc4ba10: movz            x0, #0
    //     0xc4ba14: add             x1, fp, w0, sxtw #2
    //     0xc4ba18: ldr             x1, [x1, #0x18]
    //     0xc4ba1c: ldur            w2, [x1, #0x17]
    //     0xc4ba20: add             x2, x2, HEAP, lsl #32
    //     0xc4ba24: stur            x2, [fp, #-0x10]
    // 0xc4ba28: CheckStackOverflow
    //     0xc4ba28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4ba2c: cmp             SP, x16
    //     0xc4ba30: b.ls            #0xc4ba7c
    // 0xc4ba34: InitAsync() -> Future<void?>
    //     0xc4ba34: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xc4ba38: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc4ba3c: ldur            x0, [fp, #-0x10]
    // 0xc4ba40: LoadField: r1 = r0->field_f
    //     0xc4ba40: ldur            w1, [x0, #0xf]
    // 0xc4ba44: DecompressPointer r1
    //     0xc4ba44: add             x1, x1, HEAP, lsl #32
    // 0xc4ba48: r0 = __unknown_function__()
    //     0xc4ba48: bl              #0xb2ab64  ; [] ::__unknown_function__
    // 0xc4ba4c: mov             x1, x0
    // 0xc4ba50: stur            x1, [fp, #-0x18]
    // 0xc4ba54: r0 = Await()
    //     0xc4ba54: bl              #0xb0c534  ; AwaitStub
    // 0xc4ba58: ldur            x0, [fp, #-0x10]
    // 0xc4ba5c: LoadField: r1 = r0->field_f
    //     0xc4ba5c: ldur            w1, [x0, #0xf]
    // 0xc4ba60: DecompressPointer r1
    //     0xc4ba60: add             x1, x1, HEAP, lsl #32
    // 0xc4ba64: r0 = __unknown_function__()
    //     0xc4ba64: bl              #0xc4ba84  ; [] ::__unknown_function__
    // 0xc4ba68: mov             x1, x0
    // 0xc4ba6c: stur            x1, [fp, #-0x18]
    // 0xc4ba70: r0 = Await()
    //     0xc4ba70: bl              #0xb0c534  ; AwaitStub
    // 0xc4ba74: r0 = Null
    //     0xc4ba74: mov             x0, NULL
    // 0xc4ba78: r0 = ReturnAsyncNotFuture()
    //     0xc4ba78: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc4ba7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4ba7c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4ba80: b               #0xc4ba34
  }
  [closure] bool <anonymous closure>(dynamic, uJ) {
    // ** addr: 0x3e1ac0, size: -0x1
  }
  [closure] Future<void> <anonymous closure>(dynamic, WI) {
    // ** addr: 0xac2538, size: -0x1
  }
  [closure] Future<void> _eqi(dynamic) {
    // ** addr: 0xac25a4, size: -0x1
  }
}

// class id: 1816, size: 0x14, field offset: 0x8
//   const constructor, 
class mVa extends Object {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 1817, size: 0x28, field offset: 0x8
//   const constructor, 
class kVa extends Object {
}
