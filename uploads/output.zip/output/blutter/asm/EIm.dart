// lib: , url: EIm

// class id: 1048843, size: 0x8
class :: {
}

// class id: 5604, size: 0x1c, field offset: 0x8
//   transformed mixin,
abstract class _OF extends Object
     with PF {

  late iG options; // offset: 0x8
  late FF lZg; // offset: 0x10

  [closure] Future<UF<dynamic>> ZPb(dynamic) async {
    // ** addr: 0xb329e0, size: 0x174
    // 0xb329e0: EnterFrame
    //     0xb329e0: stp             fp, lr, [SP, #-0x10]!
    //     0xb329e4: mov             fp, SP
    // 0xb329e8: AllocStack(0x48)
    //     0xb329e8: sub             SP, SP, #0x48
    // 0xb329ec: SetupParameters(_OF this /* r1 */)
    //     0xb329ec: stur            NULL, [fp, #-8]
    //     0xb329f0: movz            x0, #0
    //     0xb329f4: add             x1, fp, w0, sxtw #2
    //     0xb329f8: ldr             x1, [x1, #0x10]
    //     0xb329fc: ldur            w2, [x1, #0x17]
    //     0xb32a00: add             x2, x2, HEAP, lsl #32
    //     0xb32a04: stur            x2, [fp, #-0x18]
    // 0xb32a08: CheckStackOverflow
    //     0xb32a08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb32a0c: cmp             SP, x16
    //     0xb32a10: b.ls            #0xb32b4c
    // 0xb32a14: LoadField: r3 = r1->field_b
    //     0xb32a14: ldur            w3, [x1, #0xb]
    // 0xb32a18: DecompressPointer r3
    //     0xb32a18: add             x3, x3, HEAP, lsl #32
    // 0xb32a1c: stur            x3, [fp, #-0x10]
    // 0xb32a20: InitAsync() -> Future<UF>
    //     0xb32a20: add             x0, PP, #0xf, lsl #12  ; [pp+0xf068] TypeArguments: <UF>
    //     0xb32a24: ldr             x0, [x0, #0x68]
    //     0xb32a28: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb32a2c: r1 = 1
    //     0xb32a2c: movz            x1, #0x1
    // 0xb32a30: r0 = AllocateContext()
    //     0xb32a30: bl              #0xc547b8  ; AllocateContextStub
    // 0xb32a34: mov             x1, x0
    // 0xb32a38: ldur            x0, [fp, #-0x18]
    // 0xb32a3c: stur            x1, [fp, #-0x20]
    // 0xb32a40: StoreField: r1->field_b = r0
    //     0xb32a40: stur            w0, [x1, #0xb]
    // 0xb32a44: r0 = YF()
    //     0xb32a44: bl              #0xb32b54  ; AllocateYFStub -> YF (size=0x10)
    // 0xb32a48: mov             x1, x0
    // 0xb32a4c: stur            x0, [fp, #-0x28]
    // 0xb32a50: r0 = call 0x3f66f4
    //     0xb32a50: bl              #0x3f66f4
    // 0xb32a54: ldur            x0, [fp, #-0x28]
    // 0xb32a58: ldur            x3, [fp, #-0x20]
    // 0xb32a5c: StoreField: r3->field_f = r0
    //     0xb32a5c: stur            w0, [x3, #0xf]
    //     0xb32a60: ldurb           w16, [x3, #-1]
    //     0xb32a64: ldurb           w17, [x0, #-1]
    //     0xb32a68: and             x16, x17, x16, lsr #2
    //     0xb32a6c: tst             x16, HEAP, lsr #32
    //     0xb32a70: b.eq            #0xb32a78
    //     0xb32a74: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb32a78: ldur            x0, [fp, #-0x18]
    // 0xb32a7c: LoadField: r1 = r0->field_b
    //     0xb32a7c: ldur            w1, [x0, #0xb]
    // 0xb32a80: DecompressPointer r1
    //     0xb32a80: add             x1, x1, HEAP, lsl #32
    // 0xb32a84: LoadField: r4 = r1->field_f
    //     0xb32a84: ldur            w4, [x1, #0xf]
    // 0xb32a88: DecompressPointer r4
    //     0xb32a88: add             x4, x4, HEAP, lsl #32
    // 0xb32a8c: stur            x4, [fp, #-0x30]
    // 0xb32a90: LoadField: r1 = r0->field_f
    //     0xb32a90: ldur            w1, [x0, #0xf]
    // 0xb32a94: DecompressPointer r1
    //     0xb32a94: add             x1, x1, HEAP, lsl #32
    // 0xb32a98: LoadField: r5 = r1->field_b
    //     0xb32a98: ldur            w5, [x1, #0xb]
    // 0xb32a9c: DecompressPointer r5
    //     0xb32a9c: add             x5, x5, HEAP, lsl #32
    // 0xb32aa0: mov             x0, x5
    // 0xb32aa4: stur            x5, [fp, #-0x18]
    // 0xb32aa8: r2 = Null
    //     0xb32aa8: mov             x2, NULL
    // 0xb32aac: r1 = Null
    //     0xb32aac: mov             x1, NULL
    // 0xb32ab0: r4 = 60
    //     0xb32ab0: movz            x4, #0x3c
    // 0xb32ab4: branchIfSmi(r0, 0xb32ac0)
    //     0xb32ab4: tbz             w0, #0, #0xb32ac0
    // 0xb32ab8: r4 = LoadClassIdInstr(r0)
    //     0xb32ab8: ldur            x4, [x0, #-1]
    //     0xb32abc: ubfx            x4, x4, #0xc, #0x14
    // 0xb32ac0: r17 = 5602
    //     0xb32ac0: movz            x17, #0x15e2
    // 0xb32ac4: cmp             x4, x17
    // 0xb32ac8: b.eq            #0xb32ae0
    // 0xb32acc: r8 = SF
    //     0xb32acc: add             x8, PP, #0xf, lsl #12  ; [pp+0xf070] Type: SF
    //     0xb32ad0: ldr             x8, [x8, #0x70]
    // 0xb32ad4: r3 = Null
    //     0xb32ad4: add             x3, PP, #0xf, lsl #12  ; [pp+0xf078] Null
    //     0xb32ad8: ldr             x3, [x3, #0x78]
    // 0xb32adc: r0 = SF()
    //     0xb32adc: bl              #0xb31db8  ; IsType_SF_Stub
    // 0xb32ae0: ldur            x16, [fp, #-0x30]
    // 0xb32ae4: ldur            lr, [fp, #-0x18]
    // 0xb32ae8: stp             lr, x16, [SP, #8]
    // 0xb32aec: ldur            x16, [fp, #-0x28]
    // 0xb32af0: str             x16, [SP]
    // 0xb32af4: ldur            x0, [fp, #-0x30]
    // 0xb32af8: ClosureCall
    //     0xb32af8: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb32afc: ldur            x2, [x0, #0x1f]
    //     0xb32b00: blr             x2
    // 0xb32b04: ldur            x2, [fp, #-0x20]
    // 0xb32b08: r1 = Function '<anonymous closure>':.
    //     0xb32b08: add             x1, PP, #0xf, lsl #12  ; [pp+0xf088] AnonymousClosure: (0x3f679c), in [EIm] _OF::mMk (0x3fc4c0)
    //     0xb32b0c: ldr             x1, [x1, #0x88]
    // 0xb32b10: stur            x0, [fp, #-0x18]
    // 0xb32b14: r0 = AllocateClosure()
    //     0xb32b14: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb32b18: mov             x1, x0
    // 0xb32b1c: ldur            x0, [fp, #-0x10]
    // 0xb32b20: StoreField: r1->field_b = r0
    //     0xb32b20: stur            w0, [x1, #0xb]
    // 0xb32b24: mov             x3, x1
    // 0xb32b28: ldur            x1, [fp, #-0x18]
    // 0xb32b2c: ldur            x2, [fp, #-0x28]
    // 0xb32b30: r0 = call 0x3f6464
    //     0xb32b30: bl              #0x3f6464
    // 0xb32b34: ldur            x1, [fp, #-0x28]
    // 0xb32b38: LoadField: r2 = r1->field_7
    //     0xb32b38: ldur            w2, [x1, #7]
    // 0xb32b3c: DecompressPointer r2
    //     0xb32b3c: add             x2, x2, HEAP, lsl #32
    // 0xb32b40: LoadField: r0 = r2->field_b
    //     0xb32b40: ldur            w0, [x2, #0xb]
    // 0xb32b44: DecompressPointer r0
    //     0xb32b44: add             x0, x0, HEAP, lsl #32
    // 0xb32b48: r0 = ReturnAsync()
    //     0xb32b48: b               #0xb13694  ; ReturnAsyncStub
    // 0xb32b4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb32b4c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb32b50: b               #0xb32a14
  }
  [closure] Future<UF<dynamic>> <anonymous closure>(dynamic) async {
    // ** addr: 0xb32b84, size: 0x174
    // 0xb32b84: EnterFrame
    //     0xb32b84: stp             fp, lr, [SP, #-0x10]!
    //     0xb32b88: mov             fp, SP
    // 0xb32b8c: AllocStack(0x48)
    //     0xb32b8c: sub             SP, SP, #0x48
    // 0xb32b90: SetupParameters(_OF this /* r1 */)
    //     0xb32b90: stur            NULL, [fp, #-8]
    //     0xb32b94: movz            x0, #0
    //     0xb32b98: add             x1, fp, w0, sxtw #2
    //     0xb32b9c: ldr             x1, [x1, #0x10]
    //     0xb32ba0: ldur            w2, [x1, #0x17]
    //     0xb32ba4: add             x2, x2, HEAP, lsl #32
    //     0xb32ba8: stur            x2, [fp, #-0x18]
    // 0xb32bac: CheckStackOverflow
    //     0xb32bac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb32bb0: cmp             SP, x16
    //     0xb32bb4: b.ls            #0xb32cf0
    // 0xb32bb8: LoadField: r3 = r1->field_b
    //     0xb32bb8: ldur            w3, [x1, #0xb]
    // 0xb32bbc: DecompressPointer r3
    //     0xb32bbc: add             x3, x3, HEAP, lsl #32
    // 0xb32bc0: stur            x3, [fp, #-0x10]
    // 0xb32bc4: InitAsync() -> Future<UF>
    //     0xb32bc4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf068] TypeArguments: <UF>
    //     0xb32bc8: ldr             x0, [x0, #0x68]
    //     0xb32bcc: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb32bd0: r1 = 1
    //     0xb32bd0: movz            x1, #0x1
    // 0xb32bd4: r0 = AllocateContext()
    //     0xb32bd4: bl              #0xc547b8  ; AllocateContextStub
    // 0xb32bd8: mov             x1, x0
    // 0xb32bdc: ldur            x0, [fp, #-0x18]
    // 0xb32be0: stur            x1, [fp, #-0x20]
    // 0xb32be4: StoreField: r1->field_b = r0
    //     0xb32be4: stur            w0, [x1, #0xb]
    // 0xb32be8: r0 = XF()
    //     0xb32be8: bl              #0xb32cf8  ; AllocateXFStub -> XF (size=0x10)
    // 0xb32bec: mov             x1, x0
    // 0xb32bf0: stur            x0, [fp, #-0x28]
    // 0xb32bf4: r0 = call 0x3f66f4
    //     0xb32bf4: bl              #0x3f66f4
    // 0xb32bf8: ldur            x0, [fp, #-0x28]
    // 0xb32bfc: ldur            x3, [fp, #-0x20]
    // 0xb32c00: StoreField: r3->field_f = r0
    //     0xb32c00: stur            w0, [x3, #0xf]
    //     0xb32c04: ldurb           w16, [x3, #-1]
    //     0xb32c08: ldurb           w17, [x0, #-1]
    //     0xb32c0c: and             x16, x17, x16, lsr #2
    //     0xb32c10: tst             x16, HEAP, lsr #32
    //     0xb32c14: b.eq            #0xb32c1c
    //     0xb32c18: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb32c1c: ldur            x0, [fp, #-0x18]
    // 0xb32c20: LoadField: r1 = r0->field_b
    //     0xb32c20: ldur            w1, [x0, #0xb]
    // 0xb32c24: DecompressPointer r1
    //     0xb32c24: add             x1, x1, HEAP, lsl #32
    // 0xb32c28: LoadField: r4 = r1->field_f
    //     0xb32c28: ldur            w4, [x1, #0xf]
    // 0xb32c2c: DecompressPointer r4
    //     0xb32c2c: add             x4, x4, HEAP, lsl #32
    // 0xb32c30: stur            x4, [fp, #-0x30]
    // 0xb32c34: LoadField: r1 = r0->field_f
    //     0xb32c34: ldur            w1, [x0, #0xf]
    // 0xb32c38: DecompressPointer r1
    //     0xb32c38: add             x1, x1, HEAP, lsl #32
    // 0xb32c3c: LoadField: r5 = r1->field_b
    //     0xb32c3c: ldur            w5, [x1, #0xb]
    // 0xb32c40: DecompressPointer r5
    //     0xb32c40: add             x5, x5, HEAP, lsl #32
    // 0xb32c44: mov             x0, x5
    // 0xb32c48: stur            x5, [fp, #-0x18]
    // 0xb32c4c: r2 = Null
    //     0xb32c4c: mov             x2, NULL
    // 0xb32c50: r1 = Null
    //     0xb32c50: mov             x1, NULL
    // 0xb32c54: r4 = 60
    //     0xb32c54: movz            x4, #0x3c
    // 0xb32c58: branchIfSmi(r0, 0xb32c64)
    //     0xb32c58: tbz             w0, #0, #0xb32c64
    // 0xb32c5c: r4 = LoadClassIdInstr(r0)
    //     0xb32c5c: ldur            x4, [x0, #-1]
    //     0xb32c60: ubfx            x4, x4, #0xc, #0x14
    // 0xb32c64: r17 = 5586
    //     0xb32c64: movz            x17, #0x15d2
    // 0xb32c68: cmp             x4, x17
    // 0xb32c6c: b.eq            #0xb32c84
    // 0xb32c70: r8 = nG
    //     0xb32c70: add             x8, PP, #0xf, lsl #12  ; [pp+0xf130] Type: nG
    //     0xb32c74: ldr             x8, [x8, #0x130]
    // 0xb32c78: r3 = Null
    //     0xb32c78: add             x3, PP, #0xf, lsl #12  ; [pp+0xf138] Null
    //     0xb32c7c: ldr             x3, [x3, #0x138]
    // 0xb32c80: r0 = nG()
    //     0xb32c80: bl              #0xb32d04  ; IsType_nG_Stub
    // 0xb32c84: ldur            x16, [fp, #-0x30]
    // 0xb32c88: ldur            lr, [fp, #-0x18]
    // 0xb32c8c: stp             lr, x16, [SP, #8]
    // 0xb32c90: ldur            x16, [fp, #-0x28]
    // 0xb32c94: str             x16, [SP]
    // 0xb32c98: ldur            x0, [fp, #-0x30]
    // 0xb32c9c: ClosureCall
    //     0xb32c9c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb32ca0: ldur            x2, [x0, #0x1f]
    //     0xb32ca4: blr             x2
    // 0xb32ca8: ldur            x2, [fp, #-0x20]
    // 0xb32cac: r1 = Function '<anonymous closure>':.
    //     0xb32cac: add             x1, PP, #0xf, lsl #12  ; [pp+0xf148] AnonymousClosure: (0x3f6b2c), in [EIm] _OF::lMk (0x3fc52c)
    //     0xb32cb0: ldr             x1, [x1, #0x148]
    // 0xb32cb4: stur            x0, [fp, #-0x18]
    // 0xb32cb8: r0 = AllocateClosure()
    //     0xb32cb8: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb32cbc: mov             x1, x0
    // 0xb32cc0: ldur            x0, [fp, #-0x10]
    // 0xb32cc4: StoreField: r1->field_b = r0
    //     0xb32cc4: stur            w0, [x1, #0xb]
    // 0xb32cc8: mov             x3, x1
    // 0xb32ccc: ldur            x1, [fp, #-0x18]
    // 0xb32cd0: ldur            x2, [fp, #-0x28]
    // 0xb32cd4: r0 = call 0x3f6464
    //     0xb32cd4: bl              #0x3f6464
    // 0xb32cd8: ldur            x1, [fp, #-0x28]
    // 0xb32cdc: LoadField: r2 = r1->field_7
    //     0xb32cdc: ldur            w2, [x1, #7]
    // 0xb32ce0: DecompressPointer r2
    //     0xb32ce0: add             x2, x2, HEAP, lsl #32
    // 0xb32ce4: LoadField: r0 = r2->field_b
    //     0xb32ce4: ldur            w0, [x2, #0xb]
    // 0xb32ce8: DecompressPointer r0
    //     0xb32ce8: add             x0, x0, HEAP, lsl #32
    // 0xb32cec: r0 = ReturnAsync()
    //     0xb32cec: b               #0xb13694  ; ReturnAsyncStub
    // 0xb32cf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb32cf0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb32cf4: b               #0xb32bb8
  }
  [closure] Future<Null> <anonymous closure>(dynamic, kG, WF) async {
    // ** addr: 0xb32d28, size: 0x10c
    // 0xb32d28: EnterFrame
    //     0xb32d28: stp             fp, lr, [SP, #-0x10]!
    //     0xb32d2c: mov             fp, SP
    // 0xb32d30: AllocStack(0x98)
    //     0xb32d30: sub             SP, SP, #0x98
    // 0xb32d34: SetupParameters(_OF this /* r1, fp-0x80 */, dynamic _ /* r2, fp-0x78 */, dynamic _ /* r3, fp-0x70 */)
    //     0xb32d34: stur            NULL, [fp, #-8]
    //     0xb32d38: movz            x0, #0
    //     0xb32d3c: add             x1, fp, w0, sxtw #2
    //     0xb32d40: ldr             x1, [x1, #0x20]
    //     0xb32d44: stur            x1, [fp, #-0x80]
    //     0xb32d48: add             x2, fp, w0, sxtw #2
    //     0xb32d4c: ldr             x2, [x2, #0x18]
    //     0xb32d50: stur            x2, [fp, #-0x78]
    //     0xb32d54: add             x3, fp, w0, sxtw #2
    //     0xb32d58: ldr             x3, [x3, #0x10]
    //     0xb32d5c: stur            x3, [fp, #-0x70]
    //     0xb32d60: ldur            w4, [x1, #0x17]
    //     0xb32d64: add             x4, x4, HEAP, lsl #32
    //     0xb32d68: stur            x4, [fp, #-0x68]
    // 0xb32d6c: CheckStackOverflow
    //     0xb32d6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb32d70: cmp             SP, x16
    //     0xb32d74: b.ls            #0xb32e2c
    // 0xb32d78: LoadField: r5 = r1->field_b
    //     0xb32d78: ldur            w5, [x1, #0xb]
    // 0xb32d7c: DecompressPointer r5
    //     0xb32d7c: add             x5, x5, HEAP, lsl #32
    // 0xb32d80: stur            x5, [fp, #-0x60]
    // 0xb32d84: InitAsync() -> Future<Null?>
    //     0xb32d84: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xb32d88: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb32d8c: ldur            x0, [fp, #-0x78]
    // 0xb32d90: ldur            x1, [fp, #-0x68]
    // 0xb32d94: StoreField: r1->field_13 = r0
    //     0xb32d94: stur            w0, [x1, #0x13]
    //     0xb32d98: ldurb           w16, [x1, #-1]
    //     0xb32d9c: ldurb           w17, [x0, #-1]
    //     0xb32da0: and             x16, x17, x16, lsr #2
    //     0xb32da4: tst             x16, HEAP, lsr #32
    //     0xb32da8: b.eq            #0xb32db0
    //     0xb32dac: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xb32db0: LoadField: r0 = r1->field_f
    //     0xb32db0: ldur            w0, [x1, #0xf]
    // 0xb32db4: DecompressPointer r0
    //     0xb32db4: add             x0, x0, HEAP, lsl #32
    // 0xb32db8: ldur            x16, [fp, #-0x60]
    // 0xb32dbc: stp             x0, x16, [SP, #8]
    // 0xb32dc0: ldur            x16, [fp, #-0x78]
    // 0xb32dc4: str             x16, [SP]
    // 0xb32dc8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb32dc8: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb32dcc: r0 = __unknown_function__()
    //     0xb32dcc: bl              #0xb32e34  ; [] ::__unknown_function__
    // 0xb32dd0: mov             x1, x0
    // 0xb32dd4: stur            x1, [fp, #-0x60]
    // 0xb32dd8: r0 = Await()
    //     0xb32dd8: bl              #0xb0c534  ; AwaitStub
    // 0xb32ddc: ldur            x1, [fp, #-0x70]
    // 0xb32de0: mov             x2, x0
    // 0xb32de4: r0 = call 0x3f6db8
    //     0xb32de4: bl              #0x3f6db8
    // 0xb32de8: b               #0xb32e18
    // 0xb32dec: sub             SP, fp, #0x98
    // 0xb32df0: mov             x2, x0
    // 0xb32df4: r0 = 60
    //     0xb32df4: movz            x0, #0x3c
    // 0xb32df8: branchIfSmi(r2, 0xb32e04)
    //     0xb32df8: tbz             w2, #0, #0xb32e04
    // 0xb32dfc: r0 = LoadClassIdInstr(r2)
    //     0xb32dfc: ldur            x0, [x2, #-1]
    //     0xb32e00: ubfx            x0, x0, #0xc, #0x14
    // 0xb32e04: r17 = 5602
    //     0xb32e04: movz            x17, #0x15e2
    // 0xb32e08: cmp             x0, x17
    // 0xb32e0c: b.ne            #0xb32e20
    // 0xb32e10: ldur            x1, [fp, #-0x20]
    // 0xb32e14: r0 = call 0x3f6bb8
    //     0xb32e14: bl              #0x3f6bb8
    // 0xb32e18: r0 = Null
    //     0xb32e18: mov             x0, NULL
    // 0xb32e1c: r0 = ReturnAsyncNotFuture()
    //     0xb32e1c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb32e20: mov             x0, x2
    // 0xb32e24: r0 = ReThrow()
    //     0xb32e24: bl              #0xc539d8  ; ReThrowStub
    // 0xb32e28: brk             #0
    // 0xb32e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb32e2c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb32e30: b               #0xb32d78
  }
  [closure] Future<UF<dynamic>> <anonymous closure>(dynamic) async {
    // ** addr: 0xb36074, size: 0x174
    // 0xb36074: EnterFrame
    //     0xb36074: stp             fp, lr, [SP, #-0x10]!
    //     0xb36078: mov             fp, SP
    // 0xb3607c: AllocStack(0x48)
    //     0xb3607c: sub             SP, SP, #0x48
    // 0xb36080: SetupParameters(_OF this /* r1 */)
    //     0xb36080: stur            NULL, [fp, #-8]
    //     0xb36084: movz            x0, #0
    //     0xb36088: add             x1, fp, w0, sxtw #2
    //     0xb3608c: ldr             x1, [x1, #0x10]
    //     0xb36090: ldur            w2, [x1, #0x17]
    //     0xb36094: add             x2, x2, HEAP, lsl #32
    //     0xb36098: stur            x2, [fp, #-0x18]
    // 0xb3609c: CheckStackOverflow
    //     0xb3609c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb360a0: cmp             SP, x16
    //     0xb360a4: b.ls            #0xb361e0
    // 0xb360a8: LoadField: r3 = r1->field_b
    //     0xb360a8: ldur            w3, [x1, #0xb]
    // 0xb360ac: DecompressPointer r3
    //     0xb360ac: add             x3, x3, HEAP, lsl #32
    // 0xb360b0: stur            x3, [fp, #-0x10]
    // 0xb360b4: InitAsync() -> Future<UF>
    //     0xb360b4: add             x0, PP, #0xf, lsl #12  ; [pp+0xf068] TypeArguments: <UF>
    //     0xb360b8: ldr             x0, [x0, #0x68]
    //     0xb360bc: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb360c0: r1 = 1
    //     0xb360c0: movz            x1, #0x1
    // 0xb360c4: r0 = AllocateContext()
    //     0xb360c4: bl              #0xc547b8  ; AllocateContextStub
    // 0xb360c8: mov             x1, x0
    // 0xb360cc: ldur            x0, [fp, #-0x18]
    // 0xb360d0: stur            x1, [fp, #-0x20]
    // 0xb360d4: StoreField: r1->field_b = r0
    //     0xb360d4: stur            w0, [x1, #0xb]
    // 0xb360d8: r0 = WF()
    //     0xb360d8: bl              #0xb361e8  ; AllocateWFStub -> WF (size=0x10)
    // 0xb360dc: mov             x1, x0
    // 0xb360e0: stur            x0, [fp, #-0x28]
    // 0xb360e4: r0 = call 0x3fc07c
    //     0xb360e4: bl              #0x3fc07c
    // 0xb360e8: ldur            x0, [fp, #-0x28]
    // 0xb360ec: ldur            x3, [fp, #-0x20]
    // 0xb360f0: StoreField: r3->field_f = r0
    //     0xb360f0: stur            w0, [x3, #0xf]
    //     0xb360f4: ldurb           w16, [x3, #-1]
    //     0xb360f8: ldurb           w17, [x0, #-1]
    //     0xb360fc: and             x16, x17, x16, lsr #2
    //     0xb36100: tst             x16, HEAP, lsr #32
    //     0xb36104: b.eq            #0xb3610c
    //     0xb36108: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb3610c: ldur            x0, [fp, #-0x18]
    // 0xb36110: LoadField: r1 = r0->field_b
    //     0xb36110: ldur            w1, [x0, #0xb]
    // 0xb36114: DecompressPointer r1
    //     0xb36114: add             x1, x1, HEAP, lsl #32
    // 0xb36118: LoadField: r4 = r1->field_f
    //     0xb36118: ldur            w4, [x1, #0xf]
    // 0xb3611c: DecompressPointer r4
    //     0xb3611c: add             x4, x4, HEAP, lsl #32
    // 0xb36120: stur            x4, [fp, #-0x30]
    // 0xb36124: LoadField: r1 = r0->field_f
    //     0xb36124: ldur            w1, [x0, #0xf]
    // 0xb36128: DecompressPointer r1
    //     0xb36128: add             x1, x1, HEAP, lsl #32
    // 0xb3612c: LoadField: r5 = r1->field_b
    //     0xb3612c: ldur            w5, [x1, #0xb]
    // 0xb36130: DecompressPointer r5
    //     0xb36130: add             x5, x5, HEAP, lsl #32
    // 0xb36134: mov             x0, x5
    // 0xb36138: stur            x5, [fp, #-0x18]
    // 0xb3613c: r2 = Null
    //     0xb3613c: mov             x2, NULL
    // 0xb36140: r1 = Null
    //     0xb36140: mov             x1, NULL
    // 0xb36144: r4 = 60
    //     0xb36144: movz            x4, #0x3c
    // 0xb36148: branchIfSmi(r0, 0xb36154)
    //     0xb36148: tbz             w0, #0, #0xb36154
    // 0xb3614c: r4 = LoadClassIdInstr(r0)
    //     0xb3614c: ldur            x4, [x0, #-1]
    //     0xb36150: ubfx            x4, x4, #0xc, #0x14
    // 0xb36154: r17 = 5591
    //     0xb36154: movz            x17, #0x15d7
    // 0xb36158: cmp             x4, x17
    // 0xb3615c: b.eq            #0xb36174
    // 0xb36160: r8 = kG
    //     0xb36160: add             x8, PP, #0xf, lsl #12  ; [pp+0xfb08] Type: kG
    //     0xb36164: ldr             x8, [x8, #0xb08]
    // 0xb36168: r3 = Null
    //     0xb36168: add             x3, PP, #0xf, lsl #12  ; [pp+0xfb10] Null
    //     0xb3616c: ldr             x3, [x3, #0xb10]
    // 0xb36170: r0 = kG()
    //     0xb36170: bl              #0xb31de8  ; IsType_kG_Stub
    // 0xb36174: ldur            x16, [fp, #-0x30]
    // 0xb36178: ldur            lr, [fp, #-0x18]
    // 0xb3617c: stp             lr, x16, [SP, #8]
    // 0xb36180: ldur            x16, [fp, #-0x28]
    // 0xb36184: str             x16, [SP]
    // 0xb36188: ldur            x0, [fp, #-0x30]
    // 0xb3618c: ClosureCall
    //     0xb3618c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xb36190: ldur            x2, [x0, #0x1f]
    //     0xb36194: blr             x2
    // 0xb36198: ldur            x2, [fp, #-0x20]
    // 0xb3619c: r1 = Function '<anonymous closure>':.
    //     0xb3619c: add             x1, PP, #0xf, lsl #12  ; [pp+0xfb20] AnonymousClosure: (0x3fc0ac), in [EIm] _OF::iMk (0x3fc598)
    //     0xb361a0: ldr             x1, [x1, #0xb20]
    // 0xb361a4: stur            x0, [fp, #-0x18]
    // 0xb361a8: r0 = AllocateClosure()
    //     0xb361a8: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb361ac: mov             x1, x0
    // 0xb361b0: ldur            x0, [fp, #-0x10]
    // 0xb361b4: StoreField: r1->field_b = r0
    //     0xb361b4: stur            w0, [x1, #0xb]
    // 0xb361b8: mov             x3, x1
    // 0xb361bc: ldur            x1, [fp, #-0x18]
    // 0xb361c0: ldur            x2, [fp, #-0x28]
    // 0xb361c4: r0 = call 0x3f6464
    //     0xb361c4: bl              #0x3f6464
    // 0xb361c8: ldur            x1, [fp, #-0x28]
    // 0xb361cc: LoadField: r2 = r1->field_7
    //     0xb361cc: ldur            w2, [x1, #7]
    // 0xb361d0: DecompressPointer r2
    //     0xb361d0: add             x2, x2, HEAP, lsl #32
    // 0xb361d4: LoadField: r0 = r2->field_b
    //     0xb361d4: ldur            w0, [x2, #0xb]
    // 0xb361d8: DecompressPointer r0
    //     0xb361d8: add             x0, x0, HEAP, lsl #32
    // 0xb361dc: r0 = ReturnAsync()
    //     0xb361dc: b               #0xb13694  ; ReturnAsyncStub
    // 0xb361e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb361e0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb361e4: b               #0xb360a8
  }
  [closure] (dynamic, dynamic) => dynamic iMk(dynamic, (dynamic, kG, WF) => Object?) {
    // ** addr: 0x3fc598, size: -0x1
  }
  [closure] (dynamic, dynamic) => dynamic lMk(dynamic, (dynamic, nG<dynamic>, XF) => Object?) {
    // ** addr: 0x3fc52c, size: -0x1
  }
  [closure] (dynamic, Object) => dynamic mMk(dynamic, (dynamic, SF, YF) => Object?) {
    // ** addr: 0x3fc4c0, size: -0x1
  }
  [closure] UF<kG> <anonymous closure>(dynamic) {
    // ** addr: 0x3fc470, size: -0x1
  }
  [closure] Object <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x3fbf54, size: -0x1
  }
  [closure] Object <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x3f69f4, size: -0x1
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x3f60b8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Object, ua) {
    // ** addr: 0x3f679c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Object, ua) {
    // ** addr: 0x3f6b2c, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic) {
    // ** addr: 0x3fbe04, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x3fbcb8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Object, ua) {
    // ** addr: 0x3fc0ac, size: -0x1
  }
}

// class id: 5605, size: 0x1c, field offset: 0x1c
class QF extends _OF
    implements NF {

  [closure] Future<Null> <anonymous closure>(dynamic, dynamic) async {
    // ** addr: 0xc1c47c, size: 0x190
    // 0xc1c47c: EnterFrame
    //     0xc1c47c: stp             fp, lr, [SP, #-0x10]!
    //     0xc1c480: mov             fp, SP
    // 0xc1c484: AllocStack(0x70)
    //     0xc1c484: sub             SP, SP, #0x70
    // 0xc1c488: SetupParameters(QF this /* r1, fp-0x68 */, dynamic _ /* r2, fp-0x60 */)
    //     0xc1c488: stur            NULL, [fp, #-8]
    //     0xc1c48c: movz            x0, #0
    //     0xc1c490: add             x1, fp, w0, sxtw #2
    //     0xc1c494: ldr             x1, [x1, #0x18]
    //     0xc1c498: stur            x1, [fp, #-0x68]
    //     0xc1c49c: add             x2, fp, w0, sxtw #2
    //     0xc1c4a0: ldr             x2, [x2, #0x10]
    //     0xc1c4a4: stur            x2, [fp, #-0x60]
    //     0xc1c4a8: ldur            w3, [x1, #0x17]
    //     0xc1c4ac: add             x3, x3, HEAP, lsl #32
    //     0xc1c4b0: stur            x3, [fp, #-0x58]
    // 0xc1c4b4: CheckStackOverflow
    //     0xc1c4b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc1c4b8: cmp             SP, x16
    //     0xc1c4bc: b.ls            #0xc1c604
    // 0xc1c4c0: InitAsync() -> Future<Null?>
    //     0xc1c4c0: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xc1c4c4: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc1c4c8: ldur            x1, [fp, #-0x58]
    // 0xc1c4cc: LoadField: r2 = r1->field_33
    //     0xc1c4cc: ldur            w2, [x1, #0x33]
    // 0xc1c4d0: DecompressPointer r2
    //     0xc1c4d0: add             x2, x2, HEAP, lsl #32
    // 0xc1c4d4: stur            x2, [fp, #-0x68]
    // 0xc1c4d8: str             x2, [SP]
    // 0xc1c4dc: mov             x0, x2
    // 0xc1c4e0: ClosureCall
    //     0xc1c4e0: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc1c4e4: ldur            x2, [x0, #0x1f]
    //     0xc1c4e8: blr             x2
    // 0xc1c4ec: mov             x1, x0
    // 0xc1c4f0: stur            x1, [fp, #-0x68]
    // 0xc1c4f4: r0 = Await()
    //     0xc1c4f4: bl              #0xb0c534  ; AwaitStub
    // 0xc1c4f8: ldur            x4, [fp, #-0x60]
    // 0xc1c4fc: ldur            x3, [fp, #-0x58]
    // 0xc1c500: LoadField: r5 = r3->field_1f
    //     0xc1c500: ldur            w5, [x3, #0x1f]
    // 0xc1c504: DecompressPointer r5
    //     0xc1c504: add             x5, x5, HEAP, lsl #32
    // 0xc1c508: stur            x5, [fp, #-0x68]
    // 0xc1c50c: cmp             w4, NULL
    // 0xc1c510: b.ne            #0xc1c538
    // 0xc1c514: mov             x0, x4
    // 0xc1c518: r2 = Null
    //     0xc1c518: mov             x2, NULL
    // 0xc1c51c: r1 = Null
    //     0xc1c51c: mov             x1, NULL
    // 0xc1c520: cmp             w0, NULL
    // 0xc1c524: b.ne            #0xc1c538
    // 0xc1c528: r8 = Object
    //     0xc1c528: ldr             x8, [PP, #0xf0]  ; [pp+0xf0] Type: Object
    // 0xc1c52c: r3 = Null
    //     0xc1c52c: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f7e0] Null
    //     0xc1c530: ldr             x3, [x3, #0x7e0]
    // 0xc1c534: r0 = Object()
    //     0xc1c534: bl              #0xc5c050  ; IsType_Object_Stub
    // 0xc1c538: ldur            x0, [fp, #-0x58]
    // 0xc1c53c: LoadField: r1 = r0->field_13
    //     0xc1c53c: ldur            w1, [x0, #0x13]
    // 0xc1c540: DecompressPointer r1
    //     0xc1c540: add             x1, x1, HEAP, lsl #32
    // 0xc1c544: LoadField: r2 = r1->field_f
    //     0xc1c544: ldur            w2, [x1, #0xf]
    // 0xc1c548: DecompressPointer r2
    //     0xc1c548: add             x2, x2, HEAP, lsl #32
    // 0xc1c54c: ldur            x1, [fp, #-0x60]
    // 0xc1c550: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c550: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c554: r0 = call 0x3f54c8
    //     0xc1c554: bl              #0x3f54c8
    // 0xc1c558: ldur            x1, [fp, #-0x68]
    // 0xc1c55c: mov             x2, x0
    // 0xc1c560: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c560: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c564: r0 = call 0x36878c
    //     0xc1c564: bl              #0x36878c
    // 0xc1c568: r0 = Null
    //     0xc1c568: mov             x0, NULL
    // 0xc1c56c: r0 = ReturnAsyncNotFuture()
    //     0xc1c56c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc1c570: sub             SP, fp, #0x70
    // 0xc1c574: ldur            x5, [fp, #-0x28]
    // 0xc1c578: mov             x4, x0
    // 0xc1c57c: mov             x3, x1
    // 0xc1c580: stur            x0, [fp, #-0x60]
    // 0xc1c584: stur            x1, [fp, #-0x68]
    // 0xc1c588: LoadField: r6 = r5->field_1f
    //     0xc1c588: ldur            w6, [x5, #0x1f]
    // 0xc1c58c: DecompressPointer r6
    //     0xc1c58c: add             x6, x6, HEAP, lsl #32
    // 0xc1c590: ldur            x7, [fp, #-0x18]
    // 0xc1c594: stur            x6, [fp, #-0x58]
    // 0xc1c598: cmp             w7, NULL
    // 0xc1c59c: b.ne            #0xc1c5c4
    // 0xc1c5a0: mov             x0, x7
    // 0xc1c5a4: r2 = Null
    //     0xc1c5a4: mov             x2, NULL
    // 0xc1c5a8: r1 = Null
    //     0xc1c5a8: mov             x1, NULL
    // 0xc1c5ac: cmp             w0, NULL
    // 0xc1c5b0: b.ne            #0xc1c5c4
    // 0xc1c5b4: r8 = Object
    //     0xc1c5b4: ldr             x8, [PP, #0xf0]  ; [pp+0xf0] Type: Object
    // 0xc1c5b8: r3 = Null
    //     0xc1c5b8: add             x3, PP, #0x2f, lsl #12  ; [pp+0x2f7f0] Null
    //     0xc1c5bc: ldr             x3, [x3, #0x7f0]
    // 0xc1c5c0: r0 = Object()
    //     0xc1c5c0: bl              #0xc5c050  ; IsType_Object_Stub
    // 0xc1c5c4: ldur            x0, [fp, #-0x28]
    // 0xc1c5c8: LoadField: r1 = r0->field_13
    //     0xc1c5c8: ldur            w1, [x0, #0x13]
    // 0xc1c5cc: DecompressPointer r1
    //     0xc1c5cc: add             x1, x1, HEAP, lsl #32
    // 0xc1c5d0: LoadField: r2 = r1->field_f
    //     0xc1c5d0: ldur            w2, [x1, #0xf]
    // 0xc1c5d4: DecompressPointer r2
    //     0xc1c5d4: add             x2, x2, HEAP, lsl #32
    // 0xc1c5d8: ldur            x1, [fp, #-0x18]
    // 0xc1c5dc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c5dc: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c5e0: r0 = call 0x3f54c8
    //     0xc1c5e0: bl              #0x3f54c8
    // 0xc1c5e4: ldur            x1, [fp, #-0x58]
    // 0xc1c5e8: mov             x2, x0
    // 0xc1c5ec: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c5ec: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c5f0: r0 = call 0x36878c
    //     0xc1c5f0: bl              #0x36878c
    // 0xc1c5f4: ldur            x0, [fp, #-0x60]
    // 0xc1c5f8: ldur            x1, [fp, #-0x68]
    // 0xc1c5fc: r0 = ReThrow()
    //     0xc1c5fc: bl              #0xc539d8  ; ReThrowStub
    // 0xc1c600: brk             #0
    // 0xc1c604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1c604: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1c608: b               #0xc1c4c0
  }
  [closure] Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xc1c60c, size: 0x118
    // 0xc1c60c: EnterFrame
    //     0xc1c60c: stp             fp, lr, [SP, #-0x10]!
    //     0xc1c610: mov             fp, SP
    // 0xc1c614: AllocStack(0x58)
    //     0xc1c614: sub             SP, SP, #0x58
    // 0xc1c618: SetupParameters(QF this /* r1, fp-0x50 */)
    //     0xc1c618: stur            NULL, [fp, #-8]
    //     0xc1c61c: movz            x0, #0
    //     0xc1c620: add             x1, fp, w0, sxtw #2
    //     0xc1c624: ldr             x1, [x1, #0x10]
    //     0xc1c628: stur            x1, [fp, #-0x50]
    //     0xc1c62c: ldur            w2, [x1, #0x17]
    //     0xc1c630: add             x2, x2, HEAP, lsl #32
    //     0xc1c634: stur            x2, [fp, #-0x48]
    // 0xc1c638: CheckStackOverflow
    //     0xc1c638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc1c63c: cmp             SP, x16
    //     0xc1c640: b.ls            #0xc1c71c
    // 0xc1c644: InitAsync() -> Future<void?>
    //     0xc1c644: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xc1c648: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc1c64c: ldur            x2, [fp, #-0x48]
    // 0xc1c650: LoadField: r1 = r2->field_2b
    //     0xc1c650: ldur            w1, [x2, #0x2b]
    // 0xc1c654: DecompressPointer r1
    //     0xc1c654: add             x1, x1, HEAP, lsl #32
    // 0xc1c658: mov             x0, x1
    // 0xc1c65c: stur            x1, [fp, #-0x50]
    // 0xc1c660: r0 = Await()
    //     0xc1c660: bl              #0xb0c534  ; AwaitStub
    // 0xc1c664: ldur            x2, [fp, #-0x48]
    // 0xc1c668: r0 = true
    //     0xc1c668: add             x0, NULL, #0x20  ; true
    // 0xc1c66c: StoreField: r2->field_2f = r0
    //     0xc1c66c: stur            w0, [x2, #0x2f]
    // 0xc1c670: LoadField: r1 = r2->field_1b
    //     0xc1c670: ldur            w1, [x2, #0x1b]
    // 0xc1c674: DecompressPointer r1
    //     0xc1c674: add             x1, x1, HEAP, lsl #32
    // 0xc1c678: r0 = call 0x389420
    //     0xc1c678: bl              #0x389420
    // 0xc1c67c: ldur            x2, [fp, #-0x48]
    // 0xc1c680: r1 = Function '<anonymous closure>':.
    //     0xc1c680: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f800] AnonymousClosure: (0x869448), in [EIm] QF::<anonymous closure> (0xc1c60c)
    //     0xc1c684: ldr             x1, [x1, #0x800]
    // 0xc1c688: stur            x0, [fp, #-0x50]
    // 0xc1c68c: r0 = AllocateClosure()
    //     0xc1c68c: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xc1c690: ldur            x1, [fp, #-0x50]
    // 0xc1c694: mov             x2, x0
    // 0xc1c698: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c698: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c69c: r0 = call 0x9ecd04
    //     0xc1c69c: bl              #0x9ecd04
    // 0xc1c6a0: mov             x1, x0
    // 0xc1c6a4: stur            x1, [fp, #-0x50]
    // 0xc1c6a8: r0 = Await()
    //     0xc1c6a8: bl              #0xb0c534  ; AwaitStub
    // 0xc1c6ac: ldur            x0, [fp, #-0x48]
    // 0xc1c6b0: LoadField: r1 = r0->field_1f
    //     0xc1c6b0: ldur            w1, [x0, #0x1f]
    // 0xc1c6b4: DecompressPointer r1
    //     0xc1c6b4: add             x1, x1, HEAP, lsl #32
    // 0xc1c6b8: LoadField: r2 = r0->field_13
    //     0xc1c6b8: ldur            w2, [x0, #0x13]
    // 0xc1c6bc: DecompressPointer r2
    //     0xc1c6bc: add             x2, x2, HEAP, lsl #32
    // 0xc1c6c0: str             x2, [SP]
    // 0xc1c6c4: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xc1c6c4: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xc1c6c8: r0 = call 0x9eda78
    //     0xc1c6c8: bl              #0x9eda78
    // 0xc1c6cc: b               #0xc1c714
    // 0xc1c6d0: sub             SP, fp, #0x58
    // 0xc1c6d4: mov             x1, x0
    // 0xc1c6d8: ldur            x0, [fp, #-0x20]
    // 0xc1c6dc: LoadField: r3 = r0->field_1f
    //     0xc1c6dc: ldur            w3, [x0, #0x1f]
    // 0xc1c6e0: DecompressPointer r3
    //     0xc1c6e0: add             x3, x3, HEAP, lsl #32
    // 0xc1c6e4: stur            x3, [fp, #-0x48]
    // 0xc1c6e8: LoadField: r2 = r0->field_13
    //     0xc1c6e8: ldur            w2, [x0, #0x13]
    // 0xc1c6ec: DecompressPointer r2
    //     0xc1c6ec: add             x2, x2, HEAP, lsl #32
    // 0xc1c6f0: LoadField: r0 = r2->field_f
    //     0xc1c6f0: ldur            w0, [x2, #0xf]
    // 0xc1c6f4: DecompressPointer r0
    //     0xc1c6f4: add             x0, x0, HEAP, lsl #32
    // 0xc1c6f8: mov             x2, x0
    // 0xc1c6fc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c6fc: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c700: r0 = call 0x3f54c8
    //     0xc1c700: bl              #0x3f54c8
    // 0xc1c704: ldur            x1, [fp, #-0x48]
    // 0xc1c708: mov             x2, x0
    // 0xc1c70c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c70c: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c710: r0 = call 0x36878c
    //     0xc1c710: bl              #0x36878c
    // 0xc1c714: r0 = Null
    //     0xc1c714: mov             x0, NULL
    // 0xc1c718: r0 = ReturnAsyncNotFuture()
    //     0xc1c718: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc1c71c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1c71c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1c720: b               #0xc1c644
  }
  [closure] Future<Null> <anonymous closure>(dynamic, Object) async {
    // ** addr: 0xc1c724, size: 0x23c
    // 0xc1c724: EnterFrame
    //     0xc1c724: stp             fp, lr, [SP, #-0x10]!
    //     0xc1c728: mov             fp, SP
    // 0xc1c72c: AllocStack(0x70)
    //     0xc1c72c: sub             SP, SP, #0x70
    // 0xc1c730: SetupParameters(QF this /* r1, fp-0x60 */, dynamic _ /* r2, fp-0x58 */)
    //     0xc1c730: stur            NULL, [fp, #-8]
    //     0xc1c734: movz            x0, #0
    //     0xc1c738: add             x1, fp, w0, sxtw #2
    //     0xc1c73c: ldr             x1, [x1, #0x18]
    //     0xc1c740: stur            x1, [fp, #-0x60]
    //     0xc1c744: add             x2, fp, w0, sxtw #2
    //     0xc1c748: ldr             x2, [x2, #0x10]
    //     0xc1c74c: stur            x2, [fp, #-0x58]
    //     0xc1c750: ldur            w3, [x1, #0x17]
    //     0xc1c754: add             x3, x3, HEAP, lsl #32
    //     0xc1c758: stur            x3, [fp, #-0x50]
    // 0xc1c75c: CheckStackOverflow
    //     0xc1c75c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc1c760: cmp             SP, x16
    //     0xc1c764: b.ls            #0xc1c958
    // 0xc1c768: InitAsync() -> Future<Null?>
    //     0xc1c768: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xc1c76c: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc1c770: ldur            x2, [fp, #-0x50]
    // 0xc1c774: LoadField: r0 = r2->field_b
    //     0xc1c774: ldur            w0, [x2, #0xb]
    // 0xc1c778: DecompressPointer r0
    //     0xc1c778: add             x0, x0, HEAP, lsl #32
    // 0xc1c77c: stur            x0, [fp, #-0x60]
    // 0xc1c780: LoadField: r1 = r0->field_37
    //     0xc1c780: ldur            w1, [x0, #0x37]
    // 0xc1c784: DecompressPointer r1
    //     0xc1c784: add             x1, x1, HEAP, lsl #32
    // 0xc1c788: r16 = Sentinel
    //     0xc1c788: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xc1c78c: cmp             w1, w16
    // 0xc1c790: b.ne            #0xc1c7a4
    // 0xc1c794: r16 = "Ojc"
    //     0xc1c794: add             x16, PP, #0xc, lsl #12  ; [pp+0xc390] "Ojc"
    //     0xc1c798: ldr             x16, [x16, #0x390]
    // 0xc1c79c: str             x16, [SP]
    // 0xc1c7a0: r0 = _throwLocalNotInitialized()
    //     0xc1c7a0: bl              #0x39a7f8  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xc1c7a4: ldur            x2, [fp, #-0x60]
    // 0xc1c7a8: LoadField: r1 = r2->field_37
    //     0xc1c7a8: ldur            w1, [x2, #0x37]
    // 0xc1c7ac: DecompressPointer r1
    //     0xc1c7ac: add             x1, x1, HEAP, lsl #32
    // 0xc1c7b0: r0 = LoadClassIdInstr(r1)
    //     0xc1c7b0: ldur            x0, [x1, #-1]
    //     0xc1c7b4: ubfx            x0, x0, #0xc, #0x14
    // 0xc1c7b8: r0 = GDT[cid_x0 + -0x166]()
    //     0xc1c7b8: sub             lr, x0, #0x166
    //     0xc1c7bc: ldr             lr, [x21, lr, lsl #3]
    //     0xc1c7c0: blr             lr
    // 0xc1c7c4: r1 = Function '<anonymous closure>':.
    //     0xc1c7c4: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f818] Function: [dart:ui] Shader::Shader._ (0xafb534)
    //     0xc1c7c8: ldr             x1, [x1, #0x818]
    // 0xc1c7cc: r2 = Null
    //     0xc1c7cc: mov             x2, NULL
    // 0xc1c7d0: stur            x0, [fp, #-0x68]
    // 0xc1c7d4: r0 = AllocateClosure()
    //     0xc1c7d4: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xc1c7d8: ldur            x1, [fp, #-0x68]
    // 0xc1c7dc: r2 = LoadClassIdInstr(r1)
    //     0xc1c7dc: ldur            x2, [x1, #-1]
    //     0xc1c7e0: ubfx            x2, x2, #0xc, #0x14
    // 0xc1c7e4: mov             x16, x0
    // 0xc1c7e8: mov             x0, x2
    // 0xc1c7ec: mov             x2, x16
    // 0xc1c7f0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c7f0: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c7f4: r0 = GDT[cid_x0 + -0xfce]()
    //     0xc1c7f4: sub             lr, x0, #0xfce
    //     0xc1c7f8: ldr             lr, [x21, lr, lsl #3]
    //     0xc1c7fc: blr             lr
    // 0xc1c800: mov             x1, x0
    // 0xc1c804: stur            x1, [fp, #-0x68]
    // 0xc1c808: r0 = Await()
    //     0xc1c808: bl              #0xb0c534  ; AwaitStub
    // 0xc1c80c: ldur            x0, [fp, #-0x60]
    // 0xc1c810: r1 = true
    //     0xc1c810: add             x1, NULL, #0x20  ; true
    // 0xc1c814: StoreField: r0->field_2f = r1
    //     0xc1c814: stur            w1, [x0, #0x2f]
    // 0xc1c818: LoadField: r1 = r0->field_1b
    //     0xc1c818: ldur            w1, [x0, #0x1b]
    // 0xc1c81c: DecompressPointer r1
    //     0xc1c81c: add             x1, x1, HEAP, lsl #32
    // 0xc1c820: r0 = call 0x389420
    //     0xc1c820: bl              #0x389420
    // 0xc1c824: ldur            x2, [fp, #-0x50]
    // 0xc1c828: r1 = Function '<anonymous closure>':.
    //     0xc1c828: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f820] AnonymousClosure: (0x8695bc), in [EIm] QF::<anonymous closure> (0x869460)
    //     0xc1c82c: ldr             x1, [x1, #0x820]
    // 0xc1c830: stur            x0, [fp, #-0x68]
    // 0xc1c834: r0 = AllocateClosure()
    //     0xc1c834: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xc1c838: ldur            x1, [fp, #-0x68]
    // 0xc1c83c: mov             x2, x0
    // 0xc1c840: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c840: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c844: r0 = call 0x9ecd04
    //     0xc1c844: bl              #0x9ecd04
    // 0xc1c848: mov             x1, x0
    // 0xc1c84c: stur            x1, [fp, #-0x68]
    // 0xc1c850: r0 = Await()
    //     0xc1c850: bl              #0xb0c534  ; AwaitStub
    // 0xc1c854: ldur            x0, [fp, #-0x60]
    // 0xc1c858: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xc1c858: ldur            w2, [x0, #0x17]
    // 0xc1c85c: DecompressPointer r2
    //     0xc1c85c: add             x2, x2, HEAP, lsl #32
    // 0xc1c860: mov             x1, x2
    // 0xc1c864: stur            x2, [fp, #-0x68]
    // 0xc1c868: r0 = call 0x700270
    //     0xc1c868: bl              #0x700270
    // 0xc1c86c: tbnz            w0, #4, #0xc1c8ac
    // 0xc1c870: ldur            x1, [fp, #-0x68]
    // 0xc1c874: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc1c874: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc1c878: r0 = call 0x9706ac
    //     0xc1c878: bl              #0x9706ac
    // 0xc1c87c: ldur            x2, [fp, #-0x50]
    // 0xc1c880: r1 = Function '<anonymous closure>':.
    //     0xc1c880: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f828] AnonymousClosure: (0x86959c), in [EIm] QF::<anonymous closure> (0x869460)
    //     0xc1c884: ldr             x1, [x1, #0x828]
    // 0xc1c888: stur            x0, [fp, #-0x68]
    // 0xc1c88c: r0 = AllocateClosure()
    //     0xc1c88c: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xc1c890: ldur            x1, [fp, #-0x68]
    // 0xc1c894: mov             x2, x0
    // 0xc1c898: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c898: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c89c: r0 = call 0x9ecd04
    //     0xc1c89c: bl              #0x9ecd04
    // 0xc1c8a0: mov             x1, x0
    // 0xc1c8a4: stur            x1, [fp, #-0x68]
    // 0xc1c8a8: r0 = Await()
    //     0xc1c8a8: bl              #0xb0c534  ; AwaitStub
    // 0xc1c8ac: ldur            x0, [fp, #-0x60]
    // 0xc1c8b0: LoadField: r3 = r0->field_1f
    //     0xc1c8b0: ldur            w3, [x0, #0x1f]
    // 0xc1c8b4: DecompressPointer r3
    //     0xc1c8b4: add             x3, x3, HEAP, lsl #32
    // 0xc1c8b8: stur            x3, [fp, #-0x50]
    // 0xc1c8bc: LoadField: r1 = r0->field_13
    //     0xc1c8bc: ldur            w1, [x0, #0x13]
    // 0xc1c8c0: DecompressPointer r1
    //     0xc1c8c0: add             x1, x1, HEAP, lsl #32
    // 0xc1c8c4: LoadField: r2 = r1->field_f
    //     0xc1c8c4: ldur            w2, [x1, #0xf]
    // 0xc1c8c8: DecompressPointer r2
    //     0xc1c8c8: add             x2, x2, HEAP, lsl #32
    // 0xc1c8cc: ldur            x1, [fp, #-0x58]
    // 0xc1c8d0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c8d0: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c8d4: r0 = call 0x3f54c8
    //     0xc1c8d4: bl              #0x3f54c8
    // 0xc1c8d8: ldur            x1, [fp, #-0x50]
    // 0xc1c8dc: mov             x2, x0
    // 0xc1c8e0: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c8e0: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c8e4: r0 = call 0x36878c
    //     0xc1c8e4: bl              #0x36878c
    // 0xc1c8e8: r0 = Null
    //     0xc1c8e8: mov             x0, NULL
    // 0xc1c8ec: r0 = ReturnAsyncNotFuture()
    //     0xc1c8ec: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc1c8f0: sub             SP, fp, #0x70
    // 0xc1c8f4: mov             x3, x0
    // 0xc1c8f8: stur            x0, [fp, #-0x58]
    // 0xc1c8fc: mov             x0, x1
    // 0xc1c900: stur            x1, [fp, #-0x60]
    // 0xc1c904: ldur            x1, [fp, #-0x28]
    // 0xc1c908: LoadField: r2 = r1->field_b
    //     0xc1c908: ldur            w2, [x1, #0xb]
    // 0xc1c90c: DecompressPointer r2
    //     0xc1c90c: add             x2, x2, HEAP, lsl #32
    // 0xc1c910: LoadField: r4 = r2->field_1f
    //     0xc1c910: ldur            w4, [x2, #0x1f]
    // 0xc1c914: DecompressPointer r4
    //     0xc1c914: add             x4, x4, HEAP, lsl #32
    // 0xc1c918: stur            x4, [fp, #-0x50]
    // 0xc1c91c: LoadField: r1 = r2->field_13
    //     0xc1c91c: ldur            w1, [x2, #0x13]
    // 0xc1c920: DecompressPointer r1
    //     0xc1c920: add             x1, x1, HEAP, lsl #32
    // 0xc1c924: LoadField: r2 = r1->field_f
    //     0xc1c924: ldur            w2, [x1, #0xf]
    // 0xc1c928: DecompressPointer r2
    //     0xc1c928: add             x2, x2, HEAP, lsl #32
    // 0xc1c92c: ldur            x1, [fp, #-0x18]
    // 0xc1c930: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c930: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c934: r0 = call 0x3f54c8
    //     0xc1c934: bl              #0x3f54c8
    // 0xc1c938: ldur            x1, [fp, #-0x50]
    // 0xc1c93c: mov             x2, x0
    // 0xc1c940: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c940: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c944: r0 = call 0x36878c
    //     0xc1c944: bl              #0x36878c
    // 0xc1c948: ldur            x0, [fp, #-0x58]
    // 0xc1c94c: ldur            x1, [fp, #-0x60]
    // 0xc1c950: r0 = ReThrow()
    //     0xc1c950: bl              #0xc539d8  ; ReThrowStub
    // 0xc1c954: brk             #0
    // 0xc1c958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1c958: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1c95c: b               #0xc1c768
  }
  [closure] Future<void> Ntl(dynamic) async {
    // ** addr: 0xc1c960, size: 0x110
    // 0xc1c960: EnterFrame
    //     0xc1c960: stp             fp, lr, [SP, #-0x10]!
    //     0xc1c964: mov             fp, SP
    // 0xc1c968: AllocStack(0x18)
    //     0xc1c968: sub             SP, SP, #0x18
    // 0xc1c96c: SetupParameters(QF this /* r1 */)
    //     0xc1c96c: stur            NULL, [fp, #-8]
    //     0xc1c970: movz            x0, #0
    //     0xc1c974: add             x1, fp, w0, sxtw #2
    //     0xc1c978: ldr             x1, [x1, #0x10]
    //     0xc1c97c: ldur            w2, [x1, #0x17]
    //     0xc1c980: add             x2, x2, HEAP, lsl #32
    //     0xc1c984: stur            x2, [fp, #-0x10]
    // 0xc1c988: CheckStackOverflow
    //     0xc1c988: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc1c98c: cmp             SP, x16
    //     0xc1c990: b.ls            #0xc1ca68
    // 0xc1c994: InitAsync() -> Future<void?>
    //     0xc1c994: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xc1c998: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc1c99c: ldur            x2, [fp, #-0x10]
    // 0xc1c9a0: LoadField: r0 = r2->field_2f
    //     0xc1c9a0: ldur            w0, [x2, #0x2f]
    // 0xc1c9a4: DecompressPointer r0
    //     0xc1c9a4: add             x0, x0, HEAP, lsl #32
    // 0xc1c9a8: tbz             w0, #4, #0xc1ca60
    // 0xc1c9ac: r0 = true
    //     0xc1c9ac: add             x0, NULL, #0x20  ; true
    // 0xc1c9b0: StoreField: r2->field_2f = r0
    //     0xc1c9b0: stur            w0, [x2, #0x2f]
    // 0xc1c9b4: LoadField: r1 = r2->field_2b
    //     0xc1c9b4: ldur            w1, [x2, #0x2b]
    // 0xc1c9b8: DecompressPointer r1
    //     0xc1c9b8: add             x1, x1, HEAP, lsl #32
    // 0xc1c9bc: mov             x0, x1
    // 0xc1c9c0: stur            x1, [fp, #-0x18]
    // 0xc1c9c4: r0 = Await()
    //     0xc1c9c4: bl              #0xb0c534  ; AwaitStub
    // 0xc1c9c8: ldur            x2, [fp, #-0x10]
    // 0xc1c9cc: LoadField: r1 = r2->field_1b
    //     0xc1c9cc: ldur            w1, [x2, #0x1b]
    // 0xc1c9d0: DecompressPointer r1
    //     0xc1c9d0: add             x1, x1, HEAP, lsl #32
    // 0xc1c9d4: r0 = call 0x389420
    //     0xc1c9d4: bl              #0x389420
    // 0xc1c9d8: ldur            x2, [fp, #-0x10]
    // 0xc1c9dc: r1 = Function '<anonymous closure>':.
    //     0xc1c9dc: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f830] AnonymousClosure: (0x869448), in [EIm] QF::<anonymous closure> (0xc1c60c)
    //     0xc1c9e0: ldr             x1, [x1, #0x830]
    // 0xc1c9e4: stur            x0, [fp, #-0x18]
    // 0xc1c9e8: r0 = AllocateClosure()
    //     0xc1c9e8: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xc1c9ec: ldur            x1, [fp, #-0x18]
    // 0xc1c9f0: mov             x2, x0
    // 0xc1c9f4: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1c9f4: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1c9f8: r0 = call 0x9ecd04
    //     0xc1c9f8: bl              #0x9ecd04
    // 0xc1c9fc: mov             x1, x0
    // 0xc1ca00: stur            x1, [fp, #-0x18]
    // 0xc1ca04: r0 = Await()
    //     0xc1ca04: bl              #0xb0c534  ; AwaitStub
    // 0xc1ca08: ldur            x2, [fp, #-0x10]
    // 0xc1ca0c: ArrayLoad: r0 = r2[0]  ; List_4
    //     0xc1ca0c: ldur            w0, [x2, #0x17]
    // 0xc1ca10: DecompressPointer r0
    //     0xc1ca10: add             x0, x0, HEAP, lsl #32
    // 0xc1ca14: mov             x1, x0
    // 0xc1ca18: stur            x0, [fp, #-0x18]
    // 0xc1ca1c: r0 = call 0x700270
    //     0xc1ca1c: bl              #0x700270
    // 0xc1ca20: tbnz            w0, #4, #0xc1ca60
    // 0xc1ca24: ldur            x1, [fp, #-0x18]
    // 0xc1ca28: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc1ca28: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc1ca2c: r0 = call 0x9706ac
    //     0xc1ca2c: bl              #0x9706ac
    // 0xc1ca30: ldur            x2, [fp, #-0x10]
    // 0xc1ca34: r1 = Function '<anonymous closure>':.
    //     0xc1ca34: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f838] AnonymousClosure: (0x869710), in [EIm] QF::Ntl (0xc1c960)
    //     0xc1ca38: ldr             x1, [x1, #0x838]
    // 0xc1ca3c: stur            x0, [fp, #-0x18]
    // 0xc1ca40: r0 = AllocateClosure()
    //     0xc1ca40: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xc1ca44: ldur            x1, [fp, #-0x18]
    // 0xc1ca48: mov             x2, x0
    // 0xc1ca4c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc1ca4c: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc1ca50: r0 = call 0x9ecd04
    //     0xc1ca50: bl              #0x9ecd04
    // 0xc1ca54: mov             x1, x0
    // 0xc1ca58: stur            x1, [fp, #-0x18]
    // 0xc1ca5c: r0 = Await()
    //     0xc1ca5c: bl              #0xb0c534  ; AwaitStub
    // 0xc1ca60: r0 = Null
    //     0xc1ca60: mov             x0, NULL
    // 0xc1ca64: r0 = ReturnAsyncNotFuture()
    //     0xc1ca64: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc1ca68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1ca68: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1ca6c: b               #0xc1c994
  }
  [closure] void <anonymous closure>(dynamic, Uint8List) {
    // ** addr: 0x869460, size: -0x1
  }
  [closure] zq <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x869448, size: -0x1
  }
  [closure] Null <anonymous closure>(dynamic, zq) {
    // ** addr: 0x8695dc, size: -0x1
  }
  [closure] zq <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8695bc, size: -0x1
  }
  [closure] File <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x86959c, size: -0x1
  }
  [closure] File <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x869710, size: -0x1
  }
}
