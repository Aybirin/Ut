// lib: , url: wOm

// class id: 1049082, size: 0x8
class :: {
}

// class id: 3749, size: 0x34, field offset: 0x8
//   const constructor, 
class Uca extends _FM {
}
