// lib: , url: jBn

// class id: 1050864, size: 0x8
class :: {
}

// class id: 237, size: 0x50, field offset: 0x8
//   const constructor, 
class dOb extends Object {

  Ea field_8;
  Ea field_c;
  XNb field_10;
  Ea field_14;
  _ImmutableList<PXa> field_18;
  bool field_1c;
  bool field_20;
  bool field_24;
  _Double field_28;
  _Double field_30;
  bool field_3c;
  Pg field_40;
  _Mint field_44;
  bool field_4c;
}

// class id: 3937, size: 0x1c, field offset: 0x14
class _hOb extends Xu<dynamic> {

  late int _ipi; // offset: 0x18
  late (dynamic) => void _hpi; // offset: 0x14

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82dfb8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x82e09c, size: -0x1
  }
}

// class id: 4662, size: 0x18, field offset: 0xc
//   const constructor, 
class _iOb extends Zu {
}

// class id: 4919, size: 0x10, field offset: 0xc
//   const constructor, 
class gOb extends Vu {
}

// class id: 6003, size: 0x10, field offset: 0x8
class _fOb extends _Iy {
}

// class id: 6195, size: 0x6c, field offset: 0x2c
class eOb extends Tz<dynamic> {

  [closure] Future<void> <anonymous closure>(dynamic, r) async {
    // ** addr: 0xb7edf8, size: 0xa4
    // 0xb7edf8: EnterFrame
    //     0xb7edf8: stp             fp, lr, [SP, #-0x10]!
    //     0xb7edfc: mov             fp, SP
    // 0xb7ee00: AllocStack(0x18)
    //     0xb7ee00: sub             SP, SP, #0x18
    // 0xb7ee04: SetupParameters(eOb this /* r1 */)
    //     0xb7ee04: stur            NULL, [fp, #-8]
    //     0xb7ee08: movz            x0, #0
    //     0xb7ee0c: add             x1, fp, w0, sxtw #2
    //     0xb7ee10: ldr             x1, [x1, #0x18]
    //     0xb7ee14: ldur            w2, [x1, #0x17]
    //     0xb7ee18: add             x2, x2, HEAP, lsl #32
    //     0xb7ee1c: stur            x2, [fp, #-0x10]
    // 0xb7ee20: CheckStackOverflow
    //     0xb7ee20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7ee24: cmp             SP, x16
    //     0xb7ee28: b.ls            #0xb7ee94
    // 0xb7ee2c: InitAsync() -> Future<void?>
    //     0xb7ee2c: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xb7ee30: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb7ee34: ldur            x0, [fp, #-0x10]
    // 0xb7ee38: LoadField: r1 = r0->field_f
    //     0xb7ee38: ldur            w1, [x0, #0xf]
    // 0xb7ee3c: DecompressPointer r1
    //     0xb7ee3c: add             x1, x1, HEAP, lsl #32
    // 0xb7ee40: LoadField: r2 = r1->field_53
    //     0xb7ee40: ldur            w2, [x1, #0x53]
    // 0xb7ee44: DecompressPointer r2
    //     0xb7ee44: add             x2, x2, HEAP, lsl #32
    // 0xb7ee48: tbnz            w2, #4, #0xb7ee54
    // 0xb7ee4c: r0 = Null
    //     0xb7ee4c: mov             x0, NULL
    // 0xb7ee50: r0 = ReturnAsyncNotFuture()
    //     0xb7ee50: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb7ee54: r0 = __unknown_function__()
    //     0xb7ee54: bl              #0xb7ee9c  ; [] ::__unknown_function__
    // 0xb7ee58: mov             x1, x0
    // 0xb7ee5c: stur            x1, [fp, #-0x18]
    // 0xb7ee60: r0 = Await()
    //     0xb7ee60: bl              #0xb0c534  ; AwaitStub
    // 0xb7ee64: cmp             w0, NULL
    // 0xb7ee68: b.ne            #0xb7ee74
    // 0xb7ee6c: r0 = Null
    //     0xb7ee6c: mov             x0, NULL
    // 0xb7ee70: r0 = ReturnAsyncNotFuture()
    //     0xb7ee70: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb7ee74: ldur            x1, [fp, #-0x10]
    // 0xb7ee78: LoadField: r2 = r1->field_f
    //     0xb7ee78: ldur            w2, [x1, #0xf]
    // 0xb7ee7c: DecompressPointer r2
    //     0xb7ee7c: add             x2, x2, HEAP, lsl #32
    // 0xb7ee80: mov             x1, x2
    // 0xb7ee84: mov             x2, x0
    // 0xb7ee88: r0 = call 0x45a518
    //     0xb7ee88: bl              #0x45a518
    // 0xb7ee8c: r0 = Null
    //     0xb7ee8c: mov             x0, NULL
    // 0xb7ee90: r0 = ReturnAsyncNotFuture()
    //     0xb7ee90: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb7ee94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7ee94: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7ee98: b               #0xb7ee2c
  }
  [closure] void dcm(dynamic, cy) {
    // ** addr: 0x7d4134, size: -0x1
  }
  [closure] void Ckg(dynamic, Object) {
    // ** addr: 0x7d3fc8, size: -0x1
  }
  [closure] Future<void> <anonymous closure>(dynamic, void) {
    // ** addr: 0x7d442c, size: -0x1
  }
  [closure] Future<void> sJc(dynamic) {
    // ** addr: 0x7bee34, size: -0x1
  }
}
