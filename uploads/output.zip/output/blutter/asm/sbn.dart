// lib: , url: sbn

// class id: 1049632, size: 0x8
class :: {
}

// class id: 1813, size: 0x28, field offset: 0x8
//   const constructor, 
class pVa extends Object {
}

// class id: 1814, size: 0x20, field offset: 0x8
//   const constructor, 
class oVa extends Object {
}

// class id: 1815, size: 0x20, field offset: 0x8
//   const constructor, 
class nVa extends Object {
}
