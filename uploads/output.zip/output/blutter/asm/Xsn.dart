// lib: , url: Xsn

// class id: 1050454, size: 0x8
class :: {
}

// class id: 670, size: 0x18, field offset: 0x8
class axb extends Object {

  [closure] static kyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x795710, size: -0x1
  }
  [closure] static kyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x7956c0, size: -0x1
  }
  [closure] static kyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x795670, size: -0x1
  }
  [closure] static kyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x795620, size: -0x1
  }
}
