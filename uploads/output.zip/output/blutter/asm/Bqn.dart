// lib: , url: Bqn

// class id: 1050334, size: 0x8
class :: {
}

// class id: 830, size: 0x20, field offset: 0x8
//   const constructor, 
class Ssb extends Object {
}

// class id: 831, size: 0x8, field offset: 0x8
abstract class Rsb extends Object {
}
