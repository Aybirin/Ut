// lib: , url: package:flutter_local_notifications/src/callback_dispatcher.dart

// class id: 1049571, size: 0x8
class :: {

  static void callbackDispatcher() {
    // ** addr: 0xb036e0, size: -0x1
  }
  [closure] static Null <anonymous closure>(dynamic, int?) {
    // ** addr: 0xb03758, size: -0x1
  }
  [closure] static Map<dynamic, dynamic> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xb03ae0, size: -0x1
  }
  [closure] static Map<String, dynamic> <anonymous closure>(dynamic, Map<dynamic, dynamic>) {
    // ** addr: 0xb03aa0, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic, Map<String, dynamic>) {
    // ** addr: 0xb038a8, size: -0x1
  }
}
