// lib: , url: wkn

// class id: 1050059, size: 0x8
class :: {

  static late final Context eBc; // offset: 0xb94
  static late final Context BZb; // offset: 0xb90
}
