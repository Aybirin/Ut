// lib: , url: eVm

// class id: 1049417, size: 0x8
class :: {
}

// class id: 2448, size: 0x28, field offset: 0x24
class JHa extends KHa {
}
