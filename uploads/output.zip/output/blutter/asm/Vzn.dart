// lib: , url: Vzn

// class id: 1050811, size: 0x8
class :: {
}

// class id: 381, size: 0x10, field offset: 0x8
class iLb extends Object {
}

// class id: 382, size: 0xc, field offset: 0x8
class hLb extends Object {
}

// class id: 383, size: 0x14, field offset: 0x8
class gLb extends Object {
}

// class id: 5793, size: 0x8, field offset: 0x8
//   const constructor, 
class _iA extends uA {
}
