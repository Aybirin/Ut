// lib: , url: yhn

// class id: 1049936, size: 0x8
class :: {
}

// class id: 7479, size: 0x28, field offset: 0xc
class ehb extends Iterable<dynamic>
    implements tgb {

  int length(ehb) {
    // ** addr: 0xbab418, size: 0xa4
    // 0xbab418: EnterFrame
    //     0xbab418: stp             fp, lr, [SP, #-0x10]!
    //     0xbab41c: mov             fp, SP
    // 0xbab420: ldr             x2, [fp, #0x10]
    // 0xbab424: LoadField: r3 = r2->field_23
    //     0xbab424: ldur            w3, [x2, #0x23]
    // 0xbab428: DecompressPointer r3
    //     0xbab428: add             x3, x3, HEAP, lsl #32
    // 0xbab42c: LoadField: r2 = r3->field_27
    //     0xbab42c: ldur            w2, [x3, #0x27]
    // 0xbab430: DecompressPointer r2
    //     0xbab430: add             x2, x2, HEAP, lsl #32
    // 0xbab434: cmp             w2, NULL
    // 0xbab438: b.ne            #0xbab444
    // 0xbab43c: r2 = Null
    //     0xbab43c: mov             x2, NULL
    // 0xbab440: b               #0xbab460
    // 0xbab444: LoadField: r4 = r2->field_f
    //     0xbab444: ldur            x4, [x2, #0xf]
    // 0xbab448: r0 = BoxInt64Instr(r4)
    //     0xbab448: sbfiz           x0, x4, #1, #0x1f
    //     0xbab44c: cmp             x4, x0, asr #1
    //     0xbab450: b.eq            #0xbab45c
    //     0xbab454: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbab458: stur            x4, [x0, #7]
    // 0xbab45c: mov             x2, x0
    // 0xbab460: cmp             w2, NULL
    // 0xbab464: b.ne            #0xbab474
    // 0xbab468: LoadField: r4 = r3->field_1b
    //     0xbab468: ldur            x4, [x3, #0x1b]
    // 0xbab46c: mov             x2, x4
    // 0xbab470: b               #0xbab484
    // 0xbab474: r3 = LoadInt32Instr(r2)
    //     0xbab474: sbfx            x3, x2, #1, #0x1f
    //     0xbab478: tbz             w2, #0, #0xbab480
    //     0xbab47c: ldur            x3, [x2, #7]
    // 0xbab480: mov             x2, x3
    // 0xbab484: r0 = BoxInt64Instr(r2)
    //     0xbab484: sbfiz           x0, x2, #1, #0x1f
    //     0xbab488: cmp             x2, x0, asr #1
    //     0xbab48c: b.eq            #0xbab498
    //     0xbab490: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbab494: stur            x2, [x0, #7]
    // 0xbab498: LeaveFrame
    //     0xbab498: mov             SP, fp
    //     0xbab49c: ldp             fp, lr, [SP], #0x10
    // 0xbab4a0: ret
    //     0xbab4a0: ret             
  }
  num [](ehb, int) {
    // ** addr: 0xbaa000, size: 0x8c
    // 0xbaa000: EnterFrame
    //     0xbaa000: stp             fp, lr, [SP, #-0x10]!
    //     0xbaa004: mov             fp, SP
    // 0xbaa008: CheckStackOverflow
    //     0xbaa008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbaa00c: cmp             SP, x16
    //     0xbaa010: b.ls            #0xbaa06c
    // 0xbaa014: ldr             x0, [fp, #0x10]
    // 0xbaa018: r2 = Null
    //     0xbaa018: mov             x2, NULL
    // 0xbaa01c: r1 = Null
    //     0xbaa01c: mov             x1, NULL
    // 0xbaa020: branchIfSmi(r0, 0xbaa048)
    //     0xbaa020: tbz             w0, #0, #0xbaa048
    // 0xbaa024: r4 = LoadClassIdInstr(r0)
    //     0xbaa024: ldur            x4, [x0, #-1]
    //     0xbaa028: ubfx            x4, x4, #0xc, #0x14
    // 0xbaa02c: sub             x4, x4, #0x3c
    // 0xbaa030: cmp             x4, #1
    // 0xbaa034: b.ls            #0xbaa048
    // 0xbaa038: r8 = int
    //     0xbaa038: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xbaa03c: r3 = Null
    //     0xbaa03c: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3ba38] Null
    //     0xbaa040: ldr             x3, [x3, #0xa38]
    // 0xbaa044: r0 = int()
    //     0xbaa044: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xbaa048: ldr             x0, [fp, #0x10]
    // 0xbaa04c: r2 = LoadInt32Instr(r0)
    //     0xbaa04c: sbfx            x2, x0, #1, #0x1f
    //     0xbaa050: tbz             w0, #0, #0xbaa058
    //     0xbaa054: ldur            x2, [x0, #7]
    // 0xbaa058: ldr             x1, [fp, #0x18]
    // 0xbaa05c: r0 = call 0x5b5ff4
    //     0xbaa05c: bl              #0x5b5ff4
    // 0xbaa060: LeaveFrame
    //     0xbaa060: mov             SP, fp
    //     0xbaa064: ldp             fp, lr, [SP], #0x10
    // 0xbaa068: ret
    //     0xbaa068: ret             
    // 0xbaa06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbaa06c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbaa070: b               #0xbaa014
  }
}
