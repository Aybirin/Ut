// lib: , url: tQm

// class id: 1049182, size: 0x8
class :: {
}

// class id: 3041, size: 0x6c, field offset: 0x6c
abstract class Sla extends Vla {
}
