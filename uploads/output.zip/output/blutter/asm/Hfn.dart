// lib: , url: Hfn

// class id: 1049837, size: 0x8
class :: {
}

// class id: 1502, size: 0x1c, field offset: 0x8
class qeb extends Object {
}
