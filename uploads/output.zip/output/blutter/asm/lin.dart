// lib: , url: lin

// class id: 1049971, size: 0x8
class :: {

  static late final int Saj; // offset: 0x186c
}
