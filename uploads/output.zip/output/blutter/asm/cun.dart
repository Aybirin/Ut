// lib: , url: cun

// class id: 1050509, size: 0x8
class :: {

  static late final Tz<bool> Mzj; // offset: 0x1a9c
}
