// lib: , url: zin

// class id: 1049983, size: 0x8
class :: {
}

// class id: 7075, size: 0x1c, field offset: 0x14
enum nib extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
  mib field_14;
  bool field_18;
}
