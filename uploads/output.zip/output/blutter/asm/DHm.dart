// lib: , url: DHm

// class id: 1048784, size: 0x8
class :: {
}

// class id: 7368, size: 0x14, field offset: 0x14
enum VB extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
