// lib: , url: CEm

// class id: 1048642, size: 0x8
class :: {

  static late final S _mkg; // offset: 0xc5c
}

// class id: 4372, size: 0x3c, field offset: 0x14
class _ww extends Xu<dynamic> {

  late String _Pjg; // offset: 0x14
  late Wv _Xjg; // offset: 0x38
  late Da _Ujg; // offset: 0x28

  [closure] Future<void> <anonymous closure>(dynamic, String) async {
    // ** addr: 0xbaec70, size: 0x1fc
    // 0xbaec70: EnterFrame
    //     0xbaec70: stp             fp, lr, [SP, #-0x10]!
    //     0xbaec74: mov             fp, SP
    // 0xbaec78: AllocStack(0x40)
    //     0xbaec78: sub             SP, SP, #0x40
    // 0xbaec7c: SetupParameters(_ww this /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xbaec7c: stur            NULL, [fp, #-8]
    //     0xbaec80: movz            x0, #0
    //     0xbaec84: add             x1, fp, w0, sxtw #2
    //     0xbaec88: ldr             x1, [x1, #0x18]
    //     0xbaec8c: add             x2, fp, w0, sxtw #2
    //     0xbaec90: ldr             x2, [x2, #0x10]
    //     0xbaec94: stur            x2, [fp, #-0x18]
    //     0xbaec98: ldur            w3, [x1, #0x17]
    //     0xbaec9c: add             x3, x3, HEAP, lsl #32
    //     0xbaeca0: stur            x3, [fp, #-0x10]
    // 0xbaeca4: CheckStackOverflow
    //     0xbaeca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbaeca8: cmp             SP, x16
    //     0xbaecac: b.ls            #0xbaee4c
    // 0xbaecb0: InitAsync() -> Future<void?>
    //     0xbaecb0: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xbaecb4: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbaecb8: ldur            x0, [fp, #-0x10]
    // 0xbaecbc: LoadField: r1 = r0->field_f
    //     0xbaecbc: ldur            w1, [x0, #0xf]
    // 0xbaecc0: DecompressPointer r1
    //     0xbaecc0: add             x1, x1, HEAP, lsl #32
    // 0xbaecc4: LoadField: r2 = r1->field_f
    //     0xbaecc4: ldur            w2, [x1, #0xf]
    // 0xbaecc8: DecompressPointer r2
    //     0xbaecc8: add             x2, x2, HEAP, lsl #32
    // 0xbaeccc: cmp             w2, NULL
    // 0xbaecd0: b.ne            #0xbaecdc
    // 0xbaecd4: r0 = Null
    //     0xbaecd4: mov             x0, NULL
    // 0xbaecd8: r0 = ReturnAsyncNotFuture()
    //     0xbaecd8: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbaecdc: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbaecdc: ldur            w2, [x1, #0x17]
    // 0xbaece0: DecompressPointer r2
    //     0xbaece0: add             x2, x2, HEAP, lsl #32
    // 0xbaece4: tbz             w2, #4, #0xbaecf4
    // 0xbaece8: LoadField: r2 = r1->field_1b
    //     0xbaece8: ldur            w2, [x1, #0x1b]
    // 0xbaecec: DecompressPointer r2
    //     0xbaecec: add             x2, x2, HEAP, lsl #32
    // 0xbaecf0: tbnz            w2, #4, #0xbaee44
    // 0xbaecf4: r1 = 1
    //     0xbaecf4: movz            x1, #0x1
    // 0xbaecf8: r0 = AllocateContext()
    //     0xbaecf8: bl              #0xc547b8  ; AllocateContextStub
    // 0xbaecfc: mov             x1, x0
    // 0xbaed00: ldur            x0, [fp, #-0x10]
    // 0xbaed04: stur            x1, [fp, #-0x20]
    // 0xbaed08: StoreField: r1->field_b = r0
    //     0xbaed08: stur            w0, [x1, #0xb]
    // 0xbaed0c: r0 = InitLateStaticField(0xc5c) // [CEm] ::_mkg
    //     0xbaed0c: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xbaed10: ldr             x0, [x0, #0x18b8]
    //     0xbaed14: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xbaed18: cmp             w0, w16
    //     0xbaed1c: b.ne            #0xbaed2c
    //     0xbaed20: add             x2, PP, #0x44, lsl #12  ; [pp+0x44070] Field <::._mkg@781497926>: static late final (offset: 0xc5c)
    //     0xbaed24: ldr             x2, [x2, #0x70]
    //     0xbaed28: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xbaed2c: mov             x1, x0
    // 0xbaed30: r2 = 500
    //     0xbaed30: movz            x2, #0x1f4
    // 0xbaed34: r0 = call 0x3d227c
    //     0xbaed34: bl              #0x3d227c
    // 0xbaed38: r16 = 1000
    //     0xbaed38: movz            x16, #0x3e8
    // 0xbaed3c: mul             x1, x0, x16
    // 0xbaed40: stur            x1, [fp, #-0x28]
    // 0xbaed44: r0 = Ea()
    //     0xbaed44: bl              #0xb0a61c  ; AllocateEaStub -> Ea (size=0x10)
    // 0xbaed48: mov             x1, x0
    // 0xbaed4c: ldur            x0, [fp, #-0x28]
    // 0xbaed50: StoreField: r1->field_7 = r0
    //     0xbaed50: stur            x0, [x1, #7]
    // 0xbaed54: mov             x2, x1
    // 0xbaed58: r1 = Null
    //     0xbaed58: mov             x1, NULL
    // 0xbaed5c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xbaed5c: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xbaed60: r0 = call 0x440e50
    //     0xbaed60: bl              #0x440e50
    // 0xbaed64: mov             x1, x0
    // 0xbaed68: stur            x1, [fp, #-0x30]
    // 0xbaed6c: r0 = Await()
    //     0xbaed6c: bl              #0xb0c534  ; AwaitStub
    // 0xbaed70: ldur            x0, [fp, #-0x10]
    // 0xbaed74: LoadField: r1 = r0->field_f
    //     0xbaed74: ldur            w1, [x0, #0xf]
    // 0xbaed78: DecompressPointer r1
    //     0xbaed78: add             x1, x1, HEAP, lsl #32
    // 0xbaed7c: LoadField: r2 = r1->field_f
    //     0xbaed7c: ldur            w2, [x1, #0xf]
    // 0xbaed80: DecompressPointer r2
    //     0xbaed80: add             x2, x2, HEAP, lsl #32
    // 0xbaed84: cmp             w2, NULL
    // 0xbaed88: b.ne            #0xbaed94
    // 0xbaed8c: r0 = Null
    //     0xbaed8c: mov             x0, NULL
    // 0xbaed90: r0 = ReturnAsyncNotFuture()
    //     0xbaed90: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbaed94: ldur            x3, [fp, #-0x20]
    // 0xbaed98: LoadField: r2 = r1->field_13
    //     0xbaed98: ldur            w2, [x1, #0x13]
    // 0xbaed9c: DecompressPointer r2
    //     0xbaed9c: add             x2, x2, HEAP, lsl #32
    // 0xbaeda0: r16 = Sentinel
    //     0xbaeda0: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xbaeda4: cmp             w2, w16
    // 0xbaeda8: b.eq            #0xbaee54
    // 0xbaedac: mov             x1, x2
    // 0xbaedb0: ldur            x2, [fp, #-0x18]
    // 0xbaedb4: r0 = call 0x5d33ec
    //     0xbaedb4: bl              #0x5d33ec
    // 0xbaedb8: mov             x1, x0
    // 0xbaedbc: ldur            x2, [fp, #-0x20]
    // 0xbaedc0: StoreField: r2->field_f = r0
    //     0xbaedc0: stur            w0, [x2, #0xf]
    //     0xbaedc4: ldurb           w16, [x2, #-1]
    //     0xbaedc8: ldurb           w17, [x0, #-1]
    //     0xbaedcc: and             x16, x17, x16, lsr #2
    //     0xbaedd0: tst             x16, HEAP, lsr #32
    //     0xbaedd4: b.eq            #0xbaeddc
    //     0xbaedd8: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xbaeddc: ldur            x3, [fp, #-0x10]
    // 0xbaede0: LoadField: r0 = r3->field_f
    //     0xbaede0: ldur            w0, [x3, #0xf]
    // 0xbaede4: DecompressPointer r0
    //     0xbaede4: add             x0, x0, HEAP, lsl #32
    // 0xbaede8: LoadField: r4 = r0->field_13
    //     0xbaede8: ldur            w4, [x0, #0x13]
    // 0xbaedec: DecompressPointer r4
    //     0xbaedec: add             x4, x4, HEAP, lsl #32
    // 0xbaedf0: r16 = Sentinel
    //     0xbaedf0: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    // 0xbaedf4: cmp             w4, w16
    // 0xbaedf8: b.eq            #0xbaee60
    // 0xbaedfc: r0 = LoadClassIdInstr(r1)
    //     0xbaedfc: ldur            x0, [x1, #-1]
    //     0xbaee00: ubfx            x0, x0, #0xc, #0x14
    // 0xbaee04: stp             x4, x1, [SP]
    // 0xbaee08: mov             lr, x0
    // 0xbaee0c: ldr             lr, [x21, lr, lsl #3]
    // 0xbaee10: blr             lr
    // 0xbaee14: tbz             w0, #4, #0xbaee44
    // 0xbaee18: ldur            x0, [fp, #-0x10]
    // 0xbaee1c: LoadField: r3 = r0->field_f
    //     0xbaee1c: ldur            w3, [x0, #0xf]
    // 0xbaee20: DecompressPointer r3
    //     0xbaee20: add             x3, x3, HEAP, lsl #32
    // 0xbaee24: ldur            x2, [fp, #-0x20]
    // 0xbaee28: stur            x3, [fp, #-0x18]
    // 0xbaee2c: r1 = Function '<anonymous closure>':.
    //     0xbaee2c: add             x1, PP, #0x44, lsl #12  ; [pp+0x44078] AnonymousClosure: (0x5d394c), in [CEm] _ww::<anonymous closure> (0xbaec70)
    //     0xbaee30: ldr             x1, [x1, #0x78]
    // 0xbaee34: r0 = AllocateClosure()
    //     0xbaee34: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xbaee38: ldur            x1, [fp, #-0x18]
    // 0xbaee3c: mov             x2, x0
    // 0xbaee40: r0 = call 0x461da4
    //     0xbaee40: bl              #0x461da4
    // 0xbaee44: r0 = Null
    //     0xbaee44: mov             x0, NULL
    // 0xbaee48: r0 = ReturnAsyncNotFuture()
    //     0xbaee48: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbaee4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbaee4c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbaee50: b               #0xbaecb0
    // 0xbaee54: r9 = _Pjg
    //     0xbaee54: add             x9, PP, #0x44, lsl #12  ; [pp+0x44020] Field <_ww@781497926._Pjg@781497926>: late (offset: 0x14)
    //     0xbaee58: ldr             x9, [x9, #0x20]
    // 0xbaee5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbaee5c: bl              #0xc56180  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbaee60: r9 = _Pjg
    //     0xbaee60: add             x9, PP, #0x44, lsl #12  ; [pp+0x44020] Field <_ww@781497926._Pjg@781497926>: late (offset: 0x14)
    //     0xbaee64: ldr             x9, [x9, #0x20]
    // 0xbaee68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbaee68: bl              #0xc56180  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Image <anonymous closure>(dynamic, iva, Lz<Object>) {
    // ** addr: 0x645e54, size: -0x1
  }
  [closure] Mca <anonymous closure>(dynamic, iva, String) {
    // ** addr: 0x645dd4, size: -0x1
  }
  [closure] dsa <anonymous closure>(dynamic, iva, String, Object) {
    // ** addr: 0x645cfc, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5d394c, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5d3d38, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Object, ua?) {
    // ** addr: 0x5d3b24, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5d3c10, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5d3e14, size: -0x1
  }
  [closure] void sJc(dynamic) {
    // ** addr: 0x812ab4, size: -0x1
  }
}

// class id: 5246, size: 0x34, field offset: 0xc
//   const constructor, 
class vw extends Vu {
}

// class id: 6092, size: 0x14, field offset: 0x8
class _xw extends Object
    implements Wv {
}
