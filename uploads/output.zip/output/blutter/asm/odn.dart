// lib: , url: odn

// class id: 1049721, size: 0x8
class :: {

  static late final HZa yZa; // offset: 0x174c
}

// class id: 1673, size: 0xc, field offset: 0x8
class HZa extends Object {
}

// class id: 4780, size: 0x44, field offset: 0xc
//   const constructor, 
class IZa extends Zu {
}
