// lib: , url: wMm

// class id: 1048986, size: 0x8
class :: {
}

// class id: 3365, size: 0x10, field offset: 0x8
class ZQ extends Object {

  [closure] void <anonymous closure>(dynamic, (dynamic, VQ) => void, oR?) {
    // ** addr: 0x4771dc, size: -0x1
  }
  [closure] Map<(dynamic, VQ) => void, oR?> <anonymous closure>(dynamic) {
    // ** addr: 0x583540, size: -0x1
  }
}
