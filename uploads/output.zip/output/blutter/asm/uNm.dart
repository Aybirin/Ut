// lib: , url: uNm

// class id: 1049029, size: 0x8
class :: {
}

// class id: 3814, size: 0x20, field offset: 0x1c
//   const constructor, 
class _TW extends SW {
}

// class id: 3815, size: 0x20, field offset: 0x1c
//   const constructor, 
class _RW extends SW {
}

// class id: 4844, size: 0x24, field offset: 0xc
//   const constructor, 
class QW extends Zu {

  _Double field_c;
  Lr field_20;
}
