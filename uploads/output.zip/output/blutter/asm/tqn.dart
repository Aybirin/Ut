// lib: , url: tqn

// class id: 1050326, size: 0x8
class :: {

  [closure] static void <anonymous closure>(dynamic, Qb<Y1>) {
    // ** addr: 0x935d84, size: -0x1
  }
  [closure] static void ikm(dynamic, [void]) {
    // ** addr: 0x936148, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x936050, size: -0x1
  }
}

// class id: 835, size: 0x10, field offset: 0x8
class _Fsb<X0> extends Object
    implements Jb<X0>, Esb<X0> {

  [closure] void add(dynamic, Object?) {
    // ** addr: 0x4cb7f8, size: -0x1
  }
}
