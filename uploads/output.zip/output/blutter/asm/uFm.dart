// lib: , url: uFm

// class id: 1048682, size: 0x8
class :: {
}

// class id: 6036, size: 0xc, field offset: 0x8
//   const constructor, 
class fy extends Object {

  _OneByteString field_8;
}
