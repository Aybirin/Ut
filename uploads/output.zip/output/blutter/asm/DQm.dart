// lib: , url: DQm

// class id: 1049192, size: 0x8
class :: {
}

// class id: 2789, size: 0x18, field offset: 0x8
//   const constructor, 
class Jma extends Object {
}

// class id: 2870, size: 0x54, field offset: 0x50
//   transformed mixin,
abstract class _Kma extends Xha
     with yja<X0 bound Xha> {
}

// class id: 2871, size: 0x68, field offset: 0x54
class Pha extends _Kma {
}
