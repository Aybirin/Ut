// lib: , url: lhn

// class id: 1049923, size: 0x8
class :: {
}

// class id: 1421, size: 0x8, field offset: 0x8
abstract class tgb extends Object
    implements ja<X0>, Lr {
}
