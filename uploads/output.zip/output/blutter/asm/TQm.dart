// lib: , url: TQm

// class id: 1049206, size: 0x8
class :: {
}

// class id: 2754, size: 0x1c, field offset: 0x8
//   const constructor, 
class Zna extends Object {

  bool field_8;
  _OneByteString field_c;
  _ImmutableList<String> field_10;
  Vna field_14;

  Map<String, dynamic>? Gxc(Zna) {
    // ** addr: 0xc3ef94, size: 0x48
    // 0xc3ef94: EnterFrame
    //     0xc3ef94: stp             fp, lr, [SP, #-0x10]!
    //     0xc3ef98: mov             fp, SP
    // 0xc3ef9c: CheckStackOverflow
    //     0xc3ef9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3efa0: cmp             SP, x16
    //     0xc3efa4: b.ls            #0xc3efbc
    // 0xc3efa8: ldr             x1, [fp, #0x10]
    // 0xc3efac: r0 = call 0x49d298
    //     0xc3efac: bl              #0x49d298
    // 0xc3efb0: LeaveFrame
    //     0xc3efb0: mov             SP, fp
    //     0xc3efb4: ldp             fp, lr, [SP], #0x10
    // 0xc3efb8: ret
    //     0xc3efb8: ret             
    // 0xc3efbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3efbc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3efc0: b               #0xc3efa8
  }
}

// class id: 3203, size: 0x8, field offset: 0x8
abstract class rea extends Object {
}
