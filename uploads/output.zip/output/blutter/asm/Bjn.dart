// lib: , url: Bjn

// class id: 1050033, size: 0x8
class :: {
}

// class id: 1231, size: 0x14, field offset: 0x8
class OH extends Object
    implements Ja {
}

// class id: 1232, size: 0x14, field offset: 0x8
class NH extends Object
    implements Ja {
}

// class id: 1233, size: 0xc, field offset: 0x8
class MH extends Object
    implements Ja {
}
