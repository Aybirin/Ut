// lib: HCn, url: Omn

// class id: 1050159, size: 0x8
class :: {
}

// class id: 1038, size: 0x38, field offset: 0x2c
class Dmb extends tmb
    implements ZC {

  static late final fqb GEg; // offset: 0xef0

  [closure] static Dmb <anonymous closure>(dynamic) {
    // ** addr: 0x41e77c, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x41e724, size: -0x1
  }
}
