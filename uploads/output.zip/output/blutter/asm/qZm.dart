// lib: , url: qZm

// class id: 1049556, size: 0x8
class :: {
}

// class id: 2294, size: 0x28, field offset: 0x8
class tLa extends Object {

  Map<String, dynamic> Gxc(tLa) {
    // ** addr: 0xbc1080, size: 0x48
    // 0xbc1080: EnterFrame
    //     0xbc1080: stp             fp, lr, [SP, #-0x10]!
    //     0xbc1084: mov             fp, SP
    // 0xbc1088: CheckStackOverflow
    //     0xbc1088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbc108c: cmp             SP, x16
    //     0xbc1090: b.ls            #0xbc10a8
    // 0xbc1094: ldr             x1, [fp, #0x10]
    // 0xbc1098: r0 = call 0x6a53d8
    //     0xbc1098: bl              #0x6a53d8
    // 0xbc109c: LeaveFrame
    //     0xbc109c: mov             SP, fp
    //     0xbc10a0: ldp             fp, lr, [SP], #0x10
    // 0xbc10a4: ret
    //     0xbc10a4: ret             
    // 0xbc10a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc10a8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc10ac: b               #0xbc1094
  }
}

// class id: 2295, size: 0x28, field offset: 0x8
class sLa extends Object {

  Map<String, dynamic> Gxc(sLa) {
    // ** addr: 0xbc102c, size: 0x48
    // 0xbc102c: EnterFrame
    //     0xbc102c: stp             fp, lr, [SP, #-0x10]!
    //     0xbc1030: mov             fp, SP
    // 0xbc1034: CheckStackOverflow
    //     0xbc1034: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbc1038: cmp             SP, x16
    //     0xbc103c: b.ls            #0xbc1054
    // 0xbc1040: ldr             x1, [fp, #0x10]
    // 0xbc1044: r0 = call 0x6a53d8
    //     0xbc1044: bl              #0x6a53d8
    // 0xbc1048: LeaveFrame
    //     0xbc1048: mov             SP, fp
    //     0xbc104c: ldp             fp, lr, [SP], #0x10
    // 0xbc1050: ret
    //     0xbc1050: ret             
    // 0xbc1054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc1054: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc1058: b               #0xbc1040
  }
}
