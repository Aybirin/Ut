// lib: , url: EBn

// class id: 1050885, size: 0x8
class :: {
}

// class id: 204, size: 0x8, field offset: 0x8
abstract class VOb extends Object
    implements FormatException {
}
