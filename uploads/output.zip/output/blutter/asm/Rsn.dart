// lib: , url: Rsn

// class id: 1050448, size: 0x8
class :: {
}

// class id: 676, size: 0x2c, field offset: 0x8
class Uwb extends Object {

  Map<String, dynamic> Gxc(Uwb) {
    // ** addr: 0xbc5c40, size: 0x48
    // 0xbc5c40: EnterFrame
    //     0xbc5c40: stp             fp, lr, [SP, #-0x10]!
    //     0xbc5c44: mov             fp, SP
    // 0xbc5c48: CheckStackOverflow
    //     0xbc5c48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbc5c4c: cmp             SP, x16
    //     0xbc5c50: b.ls            #0xbc5c68
    // 0xbc5c54: ldr             x1, [fp, #0x10]
    // 0xbc5c58: r0 = call 0x6b7670
    //     0xbc5c58: bl              #0x6b7670
    // 0xbc5c5c: LeaveFrame
    //     0xbc5c5c: mov             SP, fp
    //     0xbc5c60: ldp             fp, lr, [SP], #0x10
    // 0xbc5c64: ret
    //     0xbc5c64: ret             
    // 0xbc5c68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbc5c68: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbc5c6c: b               #0xbc5c54
  }
}
