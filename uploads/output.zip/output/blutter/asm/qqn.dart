// lib: , url: qqn

// class id: 1050323, size: 0x8
class :: {
}

// class id: 838, size: 0x8, field offset: 0x8
//   const constructor, 
class _Csb extends Object {
}
