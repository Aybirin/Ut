// lib: , url: sfn

// class id: 1049822, size: 0x8
class :: {
}

// class id: 1513, size: 0x24, field offset: 0x8
class Sdb extends Object
    implements Cdb {

  late int dQc; // offset: 0x20
}
