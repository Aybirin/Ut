// lib: , url: THm

// class id: 1048799, size: 0x8
class :: {
}

// class id: 5763, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class _sC extends Object
     with B<X0> {

  List<Y0> Zk<Y0>(_sC) {
    // ** addr: 0xba7d98, size: 0x70
    // 0xba7d98: EnterFrame
    //     0xba7d98: stp             fp, lr, [SP, #-0x10]!
    //     0xba7d9c: mov             fp, SP
    // 0xba7da0: AllocStack(0x10)
    //     0xba7da0: sub             SP, SP, #0x10
    // 0xba7da4: SetupParameters()
    //     0xba7da4: ldur            w0, [x4, #0xf]
    //     0xba7da8: cbnz            w0, #0xba7db4
    //     0xba7dac: mov             x1, NULL
    //     0xba7db0: b               #0xba7dc0
    //     0xba7db4: ldur            w0, [x4, #0x17]
    //     0xba7db8: add             x1, fp, w0, sxtw #2
    //     0xba7dbc: ldr             x1, [x1, #0x10]
    // 0xba7dc0: CheckStackOverflow
    //     0xba7dc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xba7dc4: cmp             SP, x16
    //     0xba7dc8: b.ls            #0xba7e00
    // 0xba7dcc: r2 = Null
    //     0xba7dcc: mov             x2, NULL
    // 0xba7dd0: r3 = <bool, Y0>
    //     0xba7dd0: add             x3, PP, #0x44, lsl #12  ; [pp+0x44b18] TypeArguments: <bool, Y0>
    //     0xba7dd4: ldr             x3, [x3, #0xb18]
    // 0xba7dd8: r30 = InstantiateTypeArgumentsStub
    //     0xba7dd8: ldr             lr, [PP, #0x1f8]  ; [pp+0x1f8] Stub: InstantiateTypeArguments (0x340f10)
    // 0xba7ddc: LoadField: r30 = r30->field_7
    //     0xba7ddc: ldur            lr, [lr, #7]
    // 0xba7de0: blr             lr
    // 0xba7de4: ldr             x16, [fp, #0x10]
    // 0xba7de8: stp             x16, x0, [SP]
    // 0xba7dec: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xba7dec: ldr             x4, [PP, #0x19f8]  ; [pp+0x19f8] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xba7df0: r0 = call 0x58f72c
    //     0xba7df0: bl              #0x58f72c
    // 0xba7df4: LeaveFrame
    //     0xba7df4: mov             SP, fp
    //     0xba7df8: ldp             fp, lr, [SP], #0x10
    // 0xba7dfc: ret
    //     0xba7dfc: ret             
    // 0xba7e00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba7e00: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba7e04: b               #0xba7dcc
  }
  List<bool> +(_sC, List<bool>) {
    // ** addr: 0xb7f400, size: 0x4c
    // 0xb7f400: EnterFrame
    //     0xb7f400: stp             fp, lr, [SP, #-0x10]!
    //     0xb7f404: mov             fp, SP
    // 0xb7f408: CheckStackOverflow
    //     0xb7f408: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7f40c: cmp             SP, x16
    //     0xb7f410: b.ls            #0xb7f42c
    // 0xb7f414: ldr             x1, [fp, #0x18]
    // 0xb7f418: ldr             x2, [fp, #0x10]
    // 0xb7f41c: r0 = call 0x39610c
    //     0xb7f41c: bl              #0x39610c
    // 0xb7f420: LeaveFrame
    //     0xb7f420: mov             SP, fp
    //     0xb7f424: ldp             fp, lr, [SP], #0x10
    // 0xb7f428: ret
    //     0xb7f428: ret             
    // 0xb7f42c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7f42c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7f430: b               #0xb7f414
  }
  Iterable<Y0> Lk<Y0>(_sC, (dynamic, bool) => Y0) {
    // ** addr: 0xb7f434, size: 0x90
    // 0xb7f434: EnterFrame
    //     0xb7f434: stp             fp, lr, [SP, #-0x10]!
    //     0xb7f438: mov             fp, SP
    // 0xb7f43c: AllocStack(0x20)
    //     0xb7f43c: sub             SP, SP, #0x20
    // 0xb7f440: SetupParameters()
    //     0xb7f440: ldur            w0, [x4, #0xf]
    //     0xb7f444: cbnz            w0, #0xb7f450
    //     0xb7f448: mov             x3, NULL
    //     0xb7f44c: b               #0xb7f460
    //     0xb7f450: ldur            w0, [x4, #0x17]
    //     0xb7f454: add             x1, fp, w0, sxtw #2
    //     0xb7f458: ldr             x1, [x1, #0x10]
    //     0xb7f45c: mov             x3, x1
    //     0xb7f460: stur            x3, [fp, #-8]
    // 0xb7f464: CheckStackOverflow
    //     0xb7f464: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7f468: cmp             SP, x16
    //     0xb7f46c: b.ls            #0xb7f4bc
    // 0xb7f470: ldr             x0, [fp, #0x10]
    // 0xb7f474: mov             x1, x3
    // 0xb7f478: r2 = Null
    //     0xb7f478: mov             x2, NULL
    // 0xb7f47c: r8 = (dynamic this, bool) => Y0
    //     0xb7f47c: add             x8, PP, #0x44, lsl #12  ; [pp+0x44b58] FunctionType: (dynamic this, bool) => Y0
    //     0xb7f480: ldr             x8, [x8, #0xb58]
    // 0xb7f484: LoadField: r9 = r8->field_7
    //     0xb7f484: ldur            x9, [x8, #7]
    // 0xb7f488: r3 = Null
    //     0xb7f488: add             x3, PP, #0x44, lsl #12  ; [pp+0x44b60] Null
    //     0xb7f48c: ldr             x3, [x3, #0xb60]
    // 0xb7f490: blr             x9
    // 0xb7f494: ldur            x16, [fp, #-8]
    // 0xb7f498: ldr             lr, [fp, #0x18]
    // 0xb7f49c: stp             lr, x16, [SP, #8]
    // 0xb7f4a0: ldr             x16, [fp, #0x10]
    // 0xb7f4a4: str             x16, [SP]
    // 0xb7f4a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb7f4a8: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb7f4ac: r0 = call 0x5aa180
    //     0xb7f4ac: bl              #0x5aa180
    // 0xb7f4b0: LeaveFrame
    //     0xb7f4b0: mov             SP, fp
    //     0xb7f4b4: ldp             fp, lr, [SP], #0x10
    // 0xb7f4b8: ret
    //     0xb7f4b8: ret             
    // 0xb7f4bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7f4bc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7f4c0: b               #0xb7f470
  }
  void gk(_sC, (dynamic, bool) => void) {
    // ** addr: 0xb7f4dc, size: 0x6c
    // 0xb7f4dc: EnterFrame
    //     0xb7f4dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb7f4e0: mov             fp, SP
    // 0xb7f4e4: CheckStackOverflow
    //     0xb7f4e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7f4e8: cmp             SP, x16
    //     0xb7f4ec: b.ls            #0xb7f528
    // 0xb7f4f0: ldr             x0, [fp, #0x10]
    // 0xb7f4f4: r2 = Null
    //     0xb7f4f4: mov             x2, NULL
    // 0xb7f4f8: r1 = Null
    //     0xb7f4f8: mov             x1, NULL
    // 0xb7f4fc: r8 = (dynamic this, bool) => void?
    //     0xb7f4fc: add             x8, PP, #0x44, lsl #12  ; [pp+0x44b90] FunctionType: (dynamic this, bool) => void?
    //     0xb7f500: ldr             x8, [x8, #0xb90]
    // 0xb7f504: r3 = Null
    //     0xb7f504: add             x3, PP, #0x44, lsl #12  ; [pp+0x44b98] Null
    //     0xb7f508: ldr             x3, [x3, #0xb98]
    // 0xb7f50c: r0 = DefaultTypeTest()
    //     0xb7f50c: bl              #0xc5360c  ; DefaultTypeTestStub
    // 0xb7f510: ldr             x1, [fp, #0x18]
    // 0xb7f514: ldr             x2, [fp, #0x10]
    // 0xb7f518: r0 = call 0x587e7c
    //     0xb7f518: bl              #0x587e7c
    // 0xb7f51c: LeaveFrame
    //     0xb7f51c: mov             SP, fp
    //     0xb7f520: ldp             fp, lr, [SP], #0x10
    // 0xb7f524: ret
    //     0xb7f524: ret             
    // 0xb7f528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7f528: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7f52c: b               #0xb7f4f0
  }
  [closure] bool Ck(dynamic, Object?) {
    // ** addr: 0x579580, size: -0x1
  }
  [closure] void add(dynamic, Object?) {
    // ** addr: 0x45bc5c, size: -0x1
  }
}
