// lib: , url: PLm

// class id: 1048954, size: 0x8
class :: {
}

// class id: 3518, size: 0x2c, field offset: 0x2c
abstract class _JP extends KP<dynamic> {

  List<Object> dyn:get:value(_JP) {
    // ** addr: 0xb12c88, size: 0x3c
    // 0xb12c88: ldr             x1, [SP]
    // 0xb12c8c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xb12c8c: ldur            w0, [x1, #0x17]
    // 0xb12c90: DecompressPointer r0
    //     0xb12c90: add             x0, x0, HEAP, lsl #32
    // 0xb12c94: cmp             w0, NULL
    // 0xb12c98: b.eq            #0xb12ca0
    // 0xb12c9c: ret
    //     0xb12c9c: ret             
    // 0xb12ca0: EnterFrame
    //     0xb12ca0: stp             fp, lr, [SP, #-0x10]!
    //     0xb12ca4: mov             fp, SP
    // 0xb12ca8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb12ca8: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3519, size: 0x2c, field offset: 0x2c
class NP extends _JP {
}

// class id: 3520, size: 0x2c, field offset: 0x2c
class MP extends _JP {
}

// class id: 3521, size: 0x2c, field offset: 0x2c
class LP extends _JP {
}

// class id: 3539, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class IP extends Object {
}

// class id: 3915, size: 0x14, field offset: 0x8
//   const constructor, 
class PP extends _FM {
}

// class id: 7615, size: 0xc, field offset: 0xc
//   transformed mixin,
abstract class _QP extends Error
     with RP {
}

// class id: 7616, size: 0x10, field offset: 0xc
class SP extends _QP
    implements ka {

  static late ((dynamic, PP) => void)? Ncc; // offset: 0x660
  static late (dynamic, PP) => void Jhd; // offset: 0x668
  static late (dynamic, ua) => ua Ihd; // offset: 0x664
  static late final List<IP> _Lhd; // offset: 0x670

  [closure] static void Ohd(dynamic, PP, {bool Qhd}) {
    // ** addr: 0x399498, size: -0x1
  }
  [closure] static int <anonymous closure>(dynamic, int) {
    // ** addr: 0x39dad8, size: -0x1
  }
  [closure] static ua _Nhd(dynamic, ua) {
    // ** addr: 0xaff29c, size: -0x1
  }
  [closure] static LP <anonymous closure>(dynamic, String) {
    // ** addr: 0x474300, size: -0x1
  }
}
