// lib: , url: Jjn

// class id: 1050041, size: 0x8
class :: {
}

// class id: 1246, size: 0x14, field offset: 0x10
class uI extends tH {
}

// class id: 1247, size: 0x14, field offset: 0x10
class sI extends tH {
}

// class id: 1283, size: 0x24, field offset: 0x18
class _tI extends PG {
}
