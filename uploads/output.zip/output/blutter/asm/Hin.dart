// lib: , url: Hin

// class id: 1049991, size: 0x8
class :: {
}

// class id: 1365, size: 0x1c, field offset: 0x8
class Uy extends Object {

  static late final Map<String, Uy> _bIi; // offset: 0x179c

  [closure] static Uy <anonymous closure>(dynamic) {
    // ** addr: 0x3b193c, size: -0x1
  }
}
