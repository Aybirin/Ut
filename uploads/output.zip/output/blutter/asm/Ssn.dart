// lib: , url: Ssn

// class id: 1050449, size: 0x8
class :: {
}

// class id: 675, size: 0x8, field offset: 0x8
abstract class Vwb extends Object {

  [closure] static Wwb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x778068, size: -0x1
  }
  [closure] static Wwb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xaee74c, size: -0x1
  }
}
