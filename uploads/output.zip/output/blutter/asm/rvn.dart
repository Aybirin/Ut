// lib: , url: rvn

// class id: 1050571, size: 0x8
class :: {

  static late final Nab HDj; // offset: 0x1b0c

  [closure] static gEb <anonymous closure>(dynamic, iva, abb) {
    // ** addr: 0x6d1918, size: -0x1
  }
  static Nab HDj() {
    // ** addr: 0x6d1824, size: -0x1
  }
}
