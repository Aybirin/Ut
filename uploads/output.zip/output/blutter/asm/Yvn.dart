// lib: , url: Yvn

// class id: 1050604, size: 0x8
class :: {
}

// class id: 439, size: 0x8, field offset: 0x8
abstract class JBb extends Object {

  static late final RegExp _zOj; // offset: 0x1b74
  static late final RegExp _AOj; // offset: 0x1b78
  static late final RegExp _uOj; // offset: 0x1b60
  static late final RegExp _vOj; // offset: 0x1b64
  static late final RegExp _xOj; // offset: 0x1b6c
  static late final RegExp _wOj; // offset: 0x1b68
  static late final RegExp _yOj; // offset: 0x1b70

  [closure] static String <anonymous closure>(dynamic, wa) {
    // ** addr: 0x859bec, size: -0x1
  }
  [closure] static XDa <anonymous closure>(dynamic, iva, wca) {
    // ** addr: 0x858c20, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x85941c, size: -0x1
  }
}

// class id: 440, size: 0x10, field offset: 0x8
//   const constructor, 
class _IBb extends Object {
}
