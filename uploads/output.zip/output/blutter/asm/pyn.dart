// lib: , url: pyn

// class id: 1050727, size: 0x8
class :: {
}

// class id: 3966, size: 0x18, field offset: 0x14
class _pIb extends Xu<dynamic> {

  [closure] Ava <anonymous closure>(dynamic, String) {
    // ** addr: 0x785300, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7854e0, size: -0x1
  }
  [closure] Future<void> _CXj(dynamic) {
    // ** addr: 0x785760, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x785798, size: -0x1
  }
}

// class id: 4943, size: 0x18, field offset: 0xc
//   const constructor, 
class oIb extends Vu {
}
