// lib: , url: pwn

// class id: 1050623, size: 0x8
class :: {
}

// class id: 4751, size: 0x28, field offset: 0xc
//   const constructor, 
class nCb extends Zu {

  [closure] Lra <anonymous closure>(dynamic, (dynamic) => void) {
    // ** addr: 0x85b3fc, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85b7d8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x85b748, size: -0x1
  }
}
