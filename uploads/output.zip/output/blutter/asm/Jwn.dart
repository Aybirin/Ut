// lib: , url: Jwn

// class id: 1050643, size: 0x8
class :: {
}

// class id: 4742, size: 0xc, field offset: 0xc
//   const constructor, 
class gDb extends Zu {

  [closure] vBa <anonymous closure>(dynamic, iva, List<jyb>) {
    // ** addr: 0x85e864, size: -0x1
  }
  [closure] Mca <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x85e958, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x705b70, size: -0x1
  }
}
