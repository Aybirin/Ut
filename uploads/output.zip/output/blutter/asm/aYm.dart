// lib: , url: aYm

// class id: 1049523, size: 0x8
class :: {
}

// class id: 2336, size: 0x18, field offset: 0x8
//   const constructor, 
class CKa extends Object {

  _Mint field_8;
  _Mint field_10;
}
