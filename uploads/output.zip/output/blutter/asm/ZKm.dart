// lib: , url: ZKm

// class id: 1048909, size: 0x8
class :: {
}

// class id: 5350, size: 0x8, field offset: 0x8
//   const constructor, 
class eM extends fM {
}
