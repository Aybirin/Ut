// lib: , url: CUm

// class id: 1049389, size: 0x8
class :: {
}

// class id: 3481, size: 0x14, field offset: 0xc
//   const constructor, 
class IGa extends bva<dynamic> {

  static late final Set<IGa> _MLe; // offset: 0x1300
}
