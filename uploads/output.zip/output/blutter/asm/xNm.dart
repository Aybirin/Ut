// lib: , url: xNm

// class id: 1049032, size: 0x8
class :: {
}

// class id: 3812, size: 0x2c, field offset: 0x8
//   const constructor, 
class aX extends _FM {
}
