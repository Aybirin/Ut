// lib: IDn, url: qnn

// class id: 1050187, size: 0x8
class :: {
}

// class id: 1006, size: 0xc, field offset: 0xc
class Lnb extends hnb {

  static late final fqb GEg; // offset: 0xff8

  [closure] static Lnb <anonymous closure>(dynamic) {
    // ** addr: 0x40ef3c, size: -0x1
  }
  [closure] static Lnb _VJg(dynamic, String, enb, dnb, za, za, List<int>?) {
    // ** addr: 0x40f040, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40eee4, size: -0x1
  }
}
