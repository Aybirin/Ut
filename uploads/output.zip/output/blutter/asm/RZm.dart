// lib: , url: RZm

// class id: 1049584, size: 0x8
class :: {
}

// class id: 2256, size: 0x10, field offset: 0x8
//   const constructor, 
class uMa extends Object
    implements vMa {
}
