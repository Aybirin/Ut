// lib: , url: Wen

// class id: 1049800, size: 0x8
class :: {
}

// class id: 7507, size: 0x10, field offset: 0xc
class Zcb extends Iterable<dynamic>
    implements Lr {

  int length(Zcb) {
    // ** addr: 0xbaaf8c, size: 0x2c
    // 0xbaaf8c: ldr             x1, [SP]
    // 0xbaaf90: LoadField: r2 = r1->field_b
    //     0xbaaf90: ldur            w2, [x1, #0xb]
    // 0xbaaf94: DecompressPointer r2
    //     0xbaaf94: add             x2, x2, HEAP, lsl #32
    // 0xbaaf98: LoadField: r0 = r2->field_13
    //     0xbaaf98: ldur            w0, [x2, #0x13]
    // 0xbaaf9c: ret
    //     0xbaaf9c: ret             
  }
  num [](Zcb, int) {
    // ** addr: 0xbaafb8, size: 0xb0
    // 0xbaafb8: EnterFrame
    //     0xbaafb8: stp             fp, lr, [SP, #-0x10]!
    //     0xbaafbc: mov             fp, SP
    // 0xbaafc0: ldr             x0, [fp, #0x10]
    // 0xbaafc4: r2 = Null
    //     0xbaafc4: mov             x2, NULL
    // 0xbaafc8: r1 = Null
    //     0xbaafc8: mov             x1, NULL
    // 0xbaafcc: branchIfSmi(r0, 0xbaaff4)
    //     0xbaafcc: tbz             w0, #0, #0xbaaff4
    // 0xbaafd0: r4 = LoadClassIdInstr(r0)
    //     0xbaafd0: ldur            x4, [x0, #-1]
    //     0xbaafd4: ubfx            x4, x4, #0xc, #0x14
    // 0xbaafd8: sub             x4, x4, #0x3c
    // 0xbaafdc: cmp             x4, #1
    // 0xbaafe0: b.ls            #0xbaaff4
    // 0xbaafe4: r8 = int
    //     0xbaafe4: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xbaafe8: r3 = Null
    //     0xbaafe8: add             x3, PP, #0x34, lsl #12  ; [pp+0x34640] Null
    //     0xbaafec: ldr             x3, [x3, #0x640]
    // 0xbaaff0: r0 = int()
    //     0xbaaff0: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xbaaff4: ldr             x2, [fp, #0x18]
    // 0xbaaff8: LoadField: r3 = r2->field_b
    //     0xbaaff8: ldur            w3, [x2, #0xb]
    // 0xbaaffc: DecompressPointer r3
    //     0xbaaffc: add             x3, x3, HEAP, lsl #32
    // 0xbab000: LoadField: r2 = r3->field_13
    //     0xbab000: ldur            w2, [x3, #0x13]
    // 0xbab004: ldr             x4, [fp, #0x10]
    // 0xbab008: r5 = LoadInt32Instr(r4)
    //     0xbab008: sbfx            x5, x4, #1, #0x1f
    //     0xbab00c: tbz             w4, #0, #0xbab014
    //     0xbab010: ldur            x5, [x4, #7]
    // 0xbab014: r0 = LoadInt32Instr(r2)
    //     0xbab014: sbfx            x0, x2, #1, #0x1f
    // 0xbab018: cmp             x5, x0
    // 0xbab01c: b.ge            #0xbab038
    // 0xbab020: mov             x1, x5
    // 0xbab024: cmp             x1, x0
    // 0xbab028: b.hs            #0xbab04c
    // 0xbab02c: ArrayLoad: r1 = r3[r5]  ; List_1
    //     0xbab02c: add             x16, x3, x5
    //     0xbab030: ldrb            w1, [x16, #0x17]
    // 0xbab034: b               #0xbab03c
    // 0xbab038: r1 = 0
    //     0xbab038: movz            x1, #0
    // 0xbab03c: lsl             x0, x1, #1
    // 0xbab040: LeaveFrame
    //     0xbab040: mov             SP, fp
    //     0xbab044: ldp             fp, lr, [SP], #0x10
    // 0xbab048: ret
    //     0xbab048: ret             
    // 0xbab04c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbab04c: bl              #0xc55d98  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 7508, size: 0x10, field offset: 0x10
class bdb extends Zcb {
}

// class id: 7509, size: 0x10, field offset: 0x10
class adb extends Zcb {
}
