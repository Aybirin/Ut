// lib: DCn, url: Kmn

// class id: 1050155, size: 0x8
class :: {
}

// class id: 1042, size: 0x38, field offset: 0x2c
class vmb extends tmb
    implements ZC {

  static late final fqb GEg; // offset: 0xee0

  [closure] static vmb <anonymous closure>(dynamic) {
    // ** addr: 0x41ea88, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x41ea30, size: -0x1
  }
}
