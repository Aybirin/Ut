// lib: , url: qkn

// class id: 1050053, size: 0x8
class :: {
}

// class id: 4107, size: 0x1c, field offset: 0x14
class _kjb extends Xu<dynamic> {

  late mjb _aMg; // offset: 0x18
}

// class id: 5047, size: 0x5c, field offset: 0xc
class jjb extends Vu {
}
