// lib: , url: azn

// class id: 1050764, size: 0x8
class :: {
}

// class id: 4681, size: 0x24, field offset: 0xc
//   const constructor, 
class CJb extends Zu {

  [closure] static uKb <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x72ff60, size: -0x1
  }
  [closure] uKb <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x872dec, size: -0x1
  }
}
