// lib: , url: Xyn

// class id: 1050761, size: 0x8
class :: {
}

// class id: 4684, size: 0x20, field offset: 0xc
//   const constructor, 
class zJb extends Zu {

  [closure] dsa <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x871288, size: -0x1
  }
  [closure] uKb <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x871614, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x871b10, size: -0x1
  }
}
