// lib: , url: qBn

// class id: 1050871, size: 0x8
class :: {
}

// class id: 223, size: 0xc, field offset: 0x8
class COb extends Object {

  static late final COb _UMc; // offset: 0xca4
}
