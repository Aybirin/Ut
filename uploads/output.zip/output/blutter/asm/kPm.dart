// lib: , url: kPm

// class id: 1049169, size: 0x8
class :: {
}

// class id: 2837, size: 0x8, field offset: 0x8
abstract class tja extends Object {

  [closure] static Pg rpe(dynamic, jP, wca) {
    // ** addr: 0x54d528, size: -0x1
  }
  [closure] static Pg yXe(dynamic, jP, wca) {
    // ** addr: 0x50a2e8, size: -0x1
  }
  [closure] static double? FVe(dynamic, jP, wca, yt) {
    // ** addr: 0x557b74, size: -0x1
  }
  [closure] static double? yJd(dynamic, jP, wca, yt) {
    // ** addr: 0x5034a0, size: -0x1
  }
}
