// lib: , url: Wvn

// class id: 1050602, size: 0x8
class :: {
}

// class id: 442, size: 0x8, field offset: 0x8
abstract class GBb extends Object {

  static late final HBb _Ayj; // offset: 0x1b5c
}
