// lib: , url: Skn

// class id: 1050078, size: 0x8
class :: {
}

// class id: 5893, size: 0x8, field offset: 0x8
class akb extends Zjb {
}
