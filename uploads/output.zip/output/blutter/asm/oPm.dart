// lib: , url: oPm

// class id: 1049121, size: 0x8
class :: {
}

// class id: 3238, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class Qfa extends SZ {
}

// class id: 3240, size: 0x18, field offset: 0x8
//   const constructor, 
class Rfa extends Qfa {

  Mfa field_8;
  Mfa field_c;
  Mfa field_10;
  Mfa field_14;
}

// class id: 7272, size: 0x14, field offset: 0x14
enum Pfa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
