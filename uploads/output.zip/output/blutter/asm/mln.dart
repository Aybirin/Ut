// lib: , url: mln

// class id: 1050098, size: 0x8
class :: {
}

// class id: 1102, size: 0xc, field offset: 0x8
//   const constructor, 
class rkb extends okb {
}
