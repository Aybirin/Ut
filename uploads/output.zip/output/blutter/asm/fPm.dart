// lib: , url: fPm

// class id: 1049115, size: 0x8
class :: {
}

// class id: 5872, size: 0x1c, field offset: 0xc
//   const constructor, 
class ufa extends Lz<dynamic>
    implements ufa {

  static late final no _fth; // offset: 0x12dc

  [closure] List<FP> <anonymous closure>(dynamic) {
    // ** addr: 0x8b6e68, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, int, int?) {
    // ** addr: 0x8b6dc4, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8b6d48, size: -0x1
  }
}
