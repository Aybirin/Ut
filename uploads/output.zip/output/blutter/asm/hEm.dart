// lib: , url: hEm

// class id: 1048621, size: 0x8
class :: {
}

// class id: 6115, size: 0x74, field offset: 0x8
//   const constructor, 
class Xv extends Object {
}
