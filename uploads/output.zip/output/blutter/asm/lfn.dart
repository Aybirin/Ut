// lib: , url: lfn

// class id: 1049815, size: 0x8
class :: {
}

// class id: 1533, size: 0x8, field offset: 0x8
abstract class Edb extends Object {
}
