// lib: , url: aqn

// class id: 1050307, size: 0x8
class :: {
}

// class id: 5764, size: 0x14, field offset: 0x8
class gsb extends _sC {

  int length(gsb) {
    // ** addr: 0xbae77c, size: 0x48
    // 0xbae77c: ldr             x2, [SP]
    // 0xbae780: LoadField: r3 = r2->field_b
    //     0xbae780: ldur            x3, [x2, #0xb]
    // 0xbae784: r0 = BoxInt64Instr(r3)
    //     0xbae784: sbfiz           x0, x3, #1, #0x1f
    //     0xbae788: cmp             x3, x0, asr #1
    //     0xbae78c: b.eq            #0xbae7a8
    //     0xbae790: stp             fp, lr, [SP, #-0x10]!
    //     0xbae794: mov             fp, SP
    //     0xbae798: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbae79c: mov             SP, fp
    //     0xbae7a0: ldp             fp, lr, [SP], #0x10
    //     0xbae7a4: stur            x3, [x0, #7]
    // 0xbae7a8: ret
    //     0xbae7a8: ret             
  }
  bool [](gsb, int) {
    // ** addr: 0xbae7c4, size: 0xf8
    // 0xbae7c4: EnterFrame
    //     0xbae7c4: stp             fp, lr, [SP, #-0x10]!
    //     0xbae7c8: mov             fp, SP
    // 0xbae7cc: ldr             x0, [fp, #0x10]
    // 0xbae7d0: r2 = Null
    //     0xbae7d0: mov             x2, NULL
    // 0xbae7d4: r1 = Null
    //     0xbae7d4: mov             x1, NULL
    // 0xbae7d8: branchIfSmi(r0, 0xbae800)
    //     0xbae7d8: tbz             w0, #0, #0xbae800
    // 0xbae7dc: r4 = LoadClassIdInstr(r0)
    //     0xbae7dc: ldur            x4, [x0, #-1]
    //     0xbae7e0: ubfx            x4, x4, #0xc, #0x14
    // 0xbae7e4: sub             x4, x4, #0x3c
    // 0xbae7e8: cmp             x4, #1
    // 0xbae7ec: b.ls            #0xbae800
    // 0xbae7f0: r8 = int
    //     0xbae7f0: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xbae7f4: r3 = Null
    //     0xbae7f4: add             x3, PP, #0x41, lsl #12  ; [pp+0x41c60] Null
    //     0xbae7f8: ldr             x3, [x3, #0xc60]
    // 0xbae7fc: r0 = int()
    //     0xbae7fc: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xbae800: ldr             x2, [fp, #0x10]
    // 0xbae804: r3 = LoadInt32Instr(r2)
    //     0xbae804: sbfx            x3, x2, #1, #0x1f
    //     0xbae808: tbz             w2, #0, #0xbae810
    //     0xbae80c: ldur            x3, [x2, #7]
    // 0xbae810: r2 = 8
    //     0xbae810: movz            x2, #0x8
    // 0xbae814: sdiv            x4, x3, x2
    // 0xbae818: ldr             x2, [fp, #0x18]
    // 0xbae81c: LoadField: r5 = r2->field_7
    //     0xbae81c: ldur            w5, [x2, #7]
    // 0xbae820: DecompressPointer r5
    //     0xbae820: add             x5, x5, HEAP, lsl #32
    // 0xbae824: LoadField: r2 = r5->field_b
    //     0xbae824: ldur            w2, [x5, #0xb]
    // 0xbae828: r0 = LoadInt32Instr(r2)
    //     0xbae828: sbfx            x0, x2, #1, #0x1f
    // 0xbae82c: mov             x1, x4
    // 0xbae830: cmp             x1, x0
    // 0xbae834: b.hs            #0xbae8a0
    // 0xbae838: LoadField: r1 = r5->field_f
    //     0xbae838: ldur            w1, [x5, #0xf]
    // 0xbae83c: DecompressPointer r1
    //     0xbae83c: add             x1, x1, HEAP, lsl #32
    // 0xbae840: ArrayLoad: r2 = r1[r4]  ; Unknown_4
    //     0xbae840: add             x16, x1, x4, lsl #2
    //     0xbae844: ldur            w2, [x16, #0xf]
    // 0xbae848: DecompressPointer r2
    //     0xbae848: add             x2, x2, HEAP, lsl #32
    // 0xbae84c: ubfx            x3, x3, #0, #0x20
    // 0xbae850: r1 = 7
    //     0xbae850: movz            x1, #0x7
    // 0xbae854: and             x4, x3, x1
    // 0xbae858: ubfx            x4, x4, #0, #0x20
    // 0xbae85c: r1 = 7
    //     0xbae85c: movz            x1, #0x7
    // 0xbae860: sub             x3, x1, x4
    // 0xbae864: r1 = LoadInt32Instr(r2)
    //     0xbae864: sbfx            x1, x2, #1, #0x1f
    //     0xbae868: tbz             w2, #0, #0xbae870
    //     0xbae86c: ldur            x1, [x2, #7]
    // 0xbae870: asr             x2, x1, x3
    // 0xbae874: ubfx            x2, x2, #0, #0x20
    // 0xbae878: r1 = 1
    //     0xbae878: movz            x1, #0x1
    // 0xbae87c: and             x3, x2, x1
    // 0xbae880: ubfx            x3, x3, #0, #0x20
    // 0xbae884: cmp             x3, #1
    // 0xbae888: r16 = true
    //     0xbae888: add             x16, NULL, #0x20  ; true
    // 0xbae88c: r17 = false
    //     0xbae88c: add             x17, NULL, #0x30  ; false
    // 0xbae890: csel            x0, x16, x17, eq
    // 0xbae894: LeaveFrame
    //     0xbae894: mov             SP, fp
    //     0xbae898: ldp             fp, lr, [SP], #0x10
    // 0xbae89c: ret
    //     0xbae89c: ret             
    // 0xbae8a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbae8a0: bl              #0xc55d98  ; RangeErrorSharedWithoutFPURegsStub
  }
}
