// lib: , url: aNm

// class id: 1049060, size: 0x8
class :: {
}

// class id: 4298, size: 0x14, field offset: 0x14
abstract class SV<X0 bound Vu> extends Xu<X0 bound Vu> {
}
