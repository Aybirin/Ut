// lib: , url: Xgn

// class id: 1049909, size: 0x8
class :: {
}

// class id: 7494, size: 0x28, field offset: 0x24
class Egb extends ugb {

  int length(Egb) {
    // ** addr: 0xbab1b0, size: 0x58
    // 0xbab1b0: EnterFrame
    //     0xbab1b0: stp             fp, lr, [SP, #-0x10]!
    //     0xbab1b4: mov             fp, SP
    // 0xbab1b8: ldr             x2, [fp, #0x10]
    // 0xbab1bc: LoadField: r3 = r2->field_23
    //     0xbab1bc: ldur            w3, [x2, #0x23]
    // 0xbab1c0: DecompressPointer r3
    //     0xbab1c0: add             x3, x3, HEAP, lsl #32
    // 0xbab1c4: LoadField: r2 = r3->field_13
    //     0xbab1c4: ldur            w2, [x3, #0x13]
    // 0xbab1c8: r3 = LoadInt32Instr(r2)
    //     0xbab1c8: sbfx            x3, x2, #1, #0x1f
    // 0xbab1cc: lsl             x2, x3, #2
    // 0xbab1d0: r0 = BoxInt64Instr(r2)
    //     0xbab1d0: sbfiz           x0, x2, #1, #0x1f
    //     0xbab1d4: cmp             x2, x0, asr #1
    //     0xbab1d8: b.eq            #0xbab1e4
    //     0xbab1dc: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbab1e0: stur            x2, [x0, #7]
    // 0xbab1e4: LeaveFrame
    //     0xbab1e4: mov             SP, fp
    //     0xbab1e8: ldp             fp, lr, [SP], #0x10
    // 0xbab1ec: ret
    //     0xbab1ec: ret             
  }
}
