// lib: , url: RHm

// class id: 1048797, size: 0x8
class :: {
}

// class id: 5765, size: 0xc, field offset: 0x8
//   const constructor, 
class pC extends Object {

  _Closure field_8;
}
