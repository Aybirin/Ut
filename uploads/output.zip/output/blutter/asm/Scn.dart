// lib: , url: Scn

// class id: 1049700, size: 0x8
class :: {
}

// class id: 4127, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _SYa extends Xu<dynamic>
     with eC<X0 bound Vu> {

  [closure] void sJc(dynamic) {
    // ** addr: 0x814f5c, size: -0x1
  }
}

// class id: 4128, size: 0x20, field offset: 0x1c
class _TYa extends _SYa {

  late oN<Dr> _mBi; // offset: 0x1c
}

// class id: 5059, size: 0x18, field offset: 0xc
//   const constructor, 
class RYa extends Vu {
}
