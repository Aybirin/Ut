// lib: , url: Hzn

// class id: 1050797, size: 0x8
class :: {
}

// class id: 6182, size: 0x40, field offset: 0x40
abstract class UKb extends mL
    implements WKb {
}

// class id: 6185, size: 0x60, field offset: 0x54
//   transformed mixin,
abstract class _TKb extends eza
     with UKb {

  late final YKb _jqh; // offset: 0x54

  [closure] bool <anonymous closure>(dynamic, PKb) {
    // ** addr: 0x7e4b84, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, UKb) {
    // ** addr: 0x7e5558, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, UKb) {
    // ** addr: 0x7e5510, size: -0x1
  }
}

// class id: 6186, size: 0x64, field offset: 0x60
class VKb extends _TKb {
}
