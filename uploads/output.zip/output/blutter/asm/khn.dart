// lib: , url: khn

// class id: 1049922, size: 0x8
class :: {
}

// class id: 1412, size: 0x1c, field offset: 0x18
class Rgb extends Igb {
}
