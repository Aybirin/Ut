// lib: , url: jxn

// class id: 1050668, size: 0x8
class :: {

  static late final bva<BEb> jKj; // offset: 0x1b48
}

// class id: 518, size: 0x2c, field offset: 0x8
class CEb extends kzb {

  late final eza controller; // offset: 0x18
}

// class id: 4052, size: 0x18, field offset: 0x14
class BEb extends Xu<dynamic> {

  late CEb JAj; // offset: 0x14

  [closure] void <anonymous closure>(dynamic, int) {
    // ** addr: 0x740144, size: -0x1
  }
  [closure] MEb <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x73fd44, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x73fe98, size: -0x1
  }
  [closure] void sJc(dynamic) {
    // ** addr: 0x815b94, size: -0x1
  }
}

// class id: 5000, size: 0x1c, field offset: 0xc
//   const constructor, 
class AEb extends Vu {
}
