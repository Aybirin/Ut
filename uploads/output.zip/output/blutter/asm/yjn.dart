// lib: , url: yjn

// class id: 1050030, size: 0x8
class :: {
}

// class id: 1237, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class HH extends Object {
}

// class id: 1238, size: 0xc, field offset: 0x8
//   const constructor, 
class _IH extends HH {

  bool field_8;

  dynamic Gxc<Y0>(_IH, Y0) {
    // ** addr: 0xb2a578, size: 0x64
    // 0xb2a578: EnterFrame
    //     0xb2a578: stp             fp, lr, [SP, #-0x10]!
    //     0xb2a57c: mov             fp, SP
    // 0xb2a580: LoadField: r0 = r4->field_f
    //     0xb2a580: ldur            w0, [x4, #0xf]
    // 0xb2a584: cbnz            w0, #0xb2a590
    // 0xb2a588: r1 = Null
    //     0xb2a588: mov             x1, NULL
    // 0xb2a58c: b               #0xb2a59c
    // 0xb2a590: ArrayLoad: r0 = r4[0]  ; List_4
    //     0xb2a590: ldur            w0, [x4, #0x17]
    // 0xb2a594: add             x1, fp, w0, sxtw #2
    // 0xb2a598: ldr             x1, [x1, #0x10]
    // 0xb2a59c: ldr             x0, [fp, #0x10]
    // 0xb2a5a0: r2 = Null
    //     0xb2a5a0: mov             x2, NULL
    // 0xb2a5a4: cmp             w1, NULL
    // 0xb2a5a8: b.eq            #0xb2a5cc
    // 0xb2a5ac: ArrayLoad: r4 = r1[0]  ; List_4
    //     0xb2a5ac: ldur            w4, [x1, #0x17]
    // 0xb2a5b0: DecompressPointer r4
    //     0xb2a5b0: add             x4, x4, HEAP, lsl #32
    // 0xb2a5b4: r8 = Y0
    //     0xb2a5b4: add             x8, PP, #0x43, lsl #12  ; [pp+0x43780] TypeParameter: Y0
    //     0xb2a5b8: ldr             x8, [x8, #0x780]
    // 0xb2a5bc: LoadField: r9 = r4->field_7
    //     0xb2a5bc: ldur            x9, [x4, #7]
    // 0xb2a5c0: r3 = Null
    //     0xb2a5c0: add             x3, PP, #0x43, lsl #12  ; [pp+0x43788] Null
    //     0xb2a5c4: ldr             x3, [x3, #0x788]
    // 0xb2a5c8: blr             x9
    // 0xb2a5cc: ldr             x0, [fp, #0x10]
    // 0xb2a5d0: LeaveFrame
    //     0xb2a5d0: mov             SP, fp
    //     0xb2a5d4: ldp             fp, lr, [SP], #0x10
    // 0xb2a5d8: ret
    //     0xb2a5d8: ret             
  }
}

// class id: 1239, size: 0x14, field offset: 0x8
//   const constructor, 
class GH<X0> extends Object {

  bool field_c;
  _Mint field_10;

  X0 dyn:get:value(GH<X0>) {
    // ** addr: 0xb38c24, size: 0x80
    // 0xb38c24: EnterFrame
    //     0xb38c24: stp             fp, lr, [SP, #-0x10]!
    //     0xb38c28: mov             fp, SP
    // 0xb38c2c: AllocStack(0x8)
    //     0xb38c2c: sub             SP, SP, #8
    // 0xb38c30: ldr             x0, [fp, #0x10]
    // 0xb38c34: LoadField: r3 = r0->field_f
    //     0xb38c34: ldur            w3, [x0, #0xf]
    // 0xb38c38: DecompressPointer r3
    //     0xb38c38: add             x3, x3, HEAP, lsl #32
    // 0xb38c3c: stur            x3, [fp, #-8]
    // 0xb38c40: cmp             w3, NULL
    // 0xb38c44: b.ne            #0xb38c7c
    // 0xb38c48: LoadField: r2 = r0->field_7
    //     0xb38c48: ldur            w2, [x0, #7]
    // 0xb38c4c: DecompressPointer r2
    //     0xb38c4c: add             x2, x2, HEAP, lsl #32
    // 0xb38c50: mov             x0, x3
    // 0xb38c54: r1 = Null
    //     0xb38c54: mov             x1, NULL
    // 0xb38c58: cmp             w2, NULL
    // 0xb38c5c: b.eq            #0xb38c7c
    // 0xb38c60: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb38c60: ldur            w4, [x2, #0x17]
    // 0xb38c64: DecompressPointer r4
    //     0xb38c64: add             x4, x4, HEAP, lsl #32
    // 0xb38c68: r8 = X0
    //     0xb38c68: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xb38c6c: LoadField: r9 = r4->field_7
    //     0xb38c6c: ldur            x9, [x4, #7]
    // 0xb38c70: r3 = Null
    //     0xb38c70: add             x3, PP, #0x31, lsl #12  ; [pp+0x31ae0] Null
    //     0xb38c74: ldr             x3, [x3, #0xae0]
    // 0xb38c78: blr             x9
    // 0xb38c7c: ldur            x0, [fp, #-8]
    // 0xb38c80: LeaveFrame
    //     0xb38c80: mov             SP, fp
    //     0xb38c84: ldp             fp, lr, [SP], #0x10
    // 0xb38c88: ret
    //     0xb38c88: ret             
  }
}

// class id: 1799, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class FH<X0> extends Object
    implements CH<X0> {
}

// class id: 1804, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class CH<X0> extends Object {
}

// class id: 1805, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class EH extends Object {
}
