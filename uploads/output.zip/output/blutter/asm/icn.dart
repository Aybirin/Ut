// lib: , url: icn

// class id: 1049664, size: 0x8
class :: {
}

// class id: 5902, size: 0x8, field offset: 0x8
abstract class MXa extends Ez {

  static late MXa _UMc; // offset: 0x16d4
  static late final Object _Hcd; // offset: 0x16d0
}
