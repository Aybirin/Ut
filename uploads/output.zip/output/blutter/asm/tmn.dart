// lib: , url: tmn

// class id: 1050138, size: 0x8
class :: {
}

// class id: 1055, size: 0x18, field offset: 0x8
class Jlb extends Ilb
    implements blb {

  static late final fqb GEg; // offset: 0xe44

  [closure] static Jlb <anonymous closure>(dynamic) {
    // ** addr: 0x4216ec, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x421694, size: -0x1
  }
}
