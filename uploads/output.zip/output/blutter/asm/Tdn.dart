// lib: , url: Tdn

// class id: 1049737, size: 0x8
class :: {
}

// class id: 1662, size: 0x18, field offset: 0x8
class hab extends Object {

  [closure] _iab <anonymous closure>(dynamic, _iab) {
    // ** addr: 0x6cda30, size: -0x1
  }
  [closure] FutureOr<kab> evm(dynamic, kab) {
    // ** addr: 0x601e88, size: -0x1
  }
  [closure] FutureOr<kab> hvm(dynamic, String?) {
    // ** addr: 0x6023ec, size: -0x1
  }
  [closure] FutureOr<kab> jvm(dynamic, String?) {
    // ** addr: 0x602db0, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, pab) {
    // ** addr: 0x602c80, size: -0x1
  }
  [closure] String <anonymous closure>(dynamic, kab) {
    // ** addr: 0x602c28, size: -0x1
  }
}

// class id: 7110, size: 0x18, field offset: 0x14
enum _iab extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
  _TwoByteString field_14;
}
