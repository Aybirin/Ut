// lib: , url: WEm

// class id: 1048658, size: 0x8
class :: {
}

// class id: 4891, size: 0x14, field offset: 0xc
//   const constructor, 
class xx extends Zu {

  [closure] Mca <anonymous closure>(dynamic, iva) {
    // ** addr: 0xc1a7ec, size: 0x104
    // 0xc1a7ec: EnterFrame
    //     0xc1a7ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc1a7f0: mov             fp, SP
    // 0xc1a7f4: AllocStack(0x70)
    //     0xc1a7f4: sub             SP, SP, #0x70
    // 0xc1a7f8: SetupParameters([dynamic _ /* r0 */])
    //     0xc1a7f8: ldr             x0, [fp, #0x18]
    //     0xc1a7fc: ldur            w1, [x0, #0x17]
    //     0xc1a800: add             x1, x1, HEAP, lsl #32
    //     0xc1a804: stur            x1, [fp, #-0x58]
    // 0xc1a808: CheckStackOverflow
    //     0xc1a808: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc1a80c: cmp             SP, x16
    //     0xc1a810: b.ls            #0xc1a8e8
    // 0xc1a814: LoadField: r0 = r1->field_f
    //     0xc1a814: ldur            w0, [x1, #0xf]
    // 0xc1a818: DecompressPointer r0
    //     0xc1a818: add             x0, x0, HEAP, lsl #32
    // 0xc1a81c: LoadField: r2 = r0->field_b
    //     0xc1a81c: ldur            w2, [x0, #0xb]
    // 0xc1a820: DecompressPointer r2
    //     0xc1a820: add             x2, x2, HEAP, lsl #32
    // 0xc1a824: stur            x2, [fp, #-0x50]
    // 0xc1a828: ldr             x16, [fp, #0x10]
    // 0xc1a82c: stp             x16, x2, [SP]
    // 0xc1a830: mov             x0, x2
    // 0xc1a834: ClosureCall
    //     0xc1a834: ldr             x4, [PP, #0x158]  ; [pp+0x158] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xc1a838: ldur            x2, [x0, #0x1f]
    //     0xc1a83c: blr             x2
    // 0xc1a840: LeaveFrame
    //     0xc1a840: mov             SP, fp
    //     0xc1a844: ldp             fp, lr, [SP], #0x10
    // 0xc1a848: ret
    //     0xc1a848: ret             
    // 0xc1a84c: sub             SP, fp, #0x70
    // 0xc1a850: mov             x2, x0
    // 0xc1a854: stur            x0, [fp, #-0x50]
    // 0xc1a858: ldur            x0, [fp, #-0x10]
    // 0xc1a85c: stur            x1, [fp, #-0x58]
    // 0xc1a860: LoadField: r3 = r0->field_f
    //     0xc1a860: ldur            w3, [x0, #0xf]
    // 0xc1a864: DecompressPointer r3
    //     0xc1a864: add             x3, x3, HEAP, lsl #32
    // 0xc1a868: LoadField: r0 = r3->field_f
    //     0xc1a868: ldur            w0, [x3, #0xf]
    // 0xc1a86c: DecompressPointer r0
    //     0xc1a86c: add             x0, x0, HEAP, lsl #32
    // 0xc1a870: cmp             w0, NULL
    // 0xc1a874: b.ne            #0xc1a884
    // 0xc1a878: mov             x3, x2
    // 0xc1a87c: mov             x0, x1
    // 0xc1a880: b               #0xc1a8a0
    // 0xc1a884: stp             x2, x0, [SP, #8]
    // 0xc1a888: str             x1, [SP]
    // 0xc1a88c: ClosureCall
    //     0xc1a88c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xc1a890: ldur            x2, [x0, #0x1f]
    //     0xc1a894: blr             x2
    // 0xc1a898: ldur            x3, [fp, #-0x50]
    // 0xc1a89c: ldur            x0, [fp, #-0x58]
    // 0xc1a8a0: r1 = Null
    //     0xc1a8a0: mov             x1, NULL
    // 0xc1a8a4: r2 = 8
    //     0xc1a8a4: movz            x2, #0x8
    // 0xc1a8a8: r0 = AllocateArray()
    //     0xc1a8a8: bl              #0xc55848  ; AllocateArrayStub
    // 0xc1a8ac: r16 = "SafeAdWidget: caught render error: "
    //     0xc1a8ac: add             x16, PP, #0x4e, lsl #12  ; [pp+0x4e4d0] "SafeAdWidget: caught render error: "
    //     0xc1a8b0: ldr             x16, [x16, #0x4d0]
    // 0xc1a8b4: StoreField: r0->field_f = r16
    //     0xc1a8b4: stur            w16, [x0, #0xf]
    // 0xc1a8b8: ldur            x1, [fp, #-0x50]
    // 0xc1a8bc: StoreField: r0->field_13 = r1
    //     0xc1a8bc: stur            w1, [x0, #0x13]
    // 0xc1a8c0: r16 = "\n"
    //     0xc1a8c0: ldr             x16, [PP, #0x918]  ; [pp+0x918] "\n"
    // 0xc1a8c4: ArrayStore: r0[0] = r16  ; List_4
    //     0xc1a8c4: stur            w16, [x0, #0x17]
    // 0xc1a8c8: ldur            x1, [fp, #-0x58]
    // 0xc1a8cc: StoreField: r0->field_1b = r1
    //     0xc1a8cc: stur            w1, [x0, #0x1b]
    // 0xc1a8d0: str             x0, [SP]
    // 0xc1a8d4: r0 = _interpolate()
    //     0xc1a8d4: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc1a8d8: r0 = Instance_dsa
    //     0xc1a8d8: ldr             x0, [PP, #0x4980]  ; [pp+0x4980] Obj!dsa@68ad01
    // 0xc1a8dc: LeaveFrame
    //     0xc1a8dc: mov             SP, fp
    //     0xc1a8e0: ldp             fp, lr, [SP], #0x10
    // 0xc1a8e4: ret
    //     0xc1a8e4: ret             
    // 0xc1a8e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1a8e8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1a8ec: b               #0xc1a814
  }
}
