// lib: , url: gPm

// class id: 1049116, size: 0x8
class :: {
}

// class id: 3189, size: 0x10, field offset: 0x8
//   const constructor, 
class zfa extends Object {

  _Mint field_8;
}

// class id: 3190, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class vfa extends Object {
}

// class id: 3191, size: 0x20, field offset: 0x8
//   const constructor, 
class _yfa extends vfa {
}

// class id: 3192, size: 0x18, field offset: 0x8
//   const constructor, 
class xfa extends vfa {

  _Double field_8;
  _Double field_10;

  xfa -(xfa, xfa) {
    // ** addr: 0xba5848, size: 0x84
    // 0xba5848: EnterFrame
    //     0xba5848: stp             fp, lr, [SP, #-0x10]!
    //     0xba584c: mov             fp, SP
    // 0xba5850: CheckStackOverflow
    //     0xba5850: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xba5854: cmp             SP, x16
    //     0xba5858: b.ls            #0xba58ac
    // 0xba585c: ldr             x0, [fp, #0x10]
    // 0xba5860: r2 = Null
    //     0xba5860: mov             x2, NULL
    // 0xba5864: r1 = Null
    //     0xba5864: mov             x1, NULL
    // 0xba5868: r4 = 60
    //     0xba5868: movz            x4, #0x3c
    // 0xba586c: branchIfSmi(r0, 0xba5878)
    //     0xba586c: tbz             w0, #0, #0xba5878
    // 0xba5870: r4 = LoadClassIdInstr(r0)
    //     0xba5870: ldur            x4, [x0, #-1]
    //     0xba5874: ubfx            x4, x4, #0xc, #0x14
    // 0xba5878: cmp             x4, #0xc78
    // 0xba587c: b.eq            #0xba5894
    // 0xba5880: r8 = xfa
    //     0xba5880: add             x8, PP, #0x4e, lsl #12  ; [pp+0x4ed78] Type: xfa
    //     0xba5884: ldr             x8, [x8, #0xd78]
    // 0xba5888: r3 = Null
    //     0xba5888: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4ed90] Null
    //     0xba588c: ldr             x3, [x3, #0xd90]
    // 0xba5890: r0 = DefaultTypeTest()
    //     0xba5890: bl              #0xc5360c  ; DefaultTypeTestStub
    // 0xba5894: ldr             x1, [fp, #0x18]
    // 0xba5898: ldr             x2, [fp, #0x10]
    // 0xba589c: r0 = call 0x54fbdc
    //     0xba589c: bl              #0x54fbdc
    // 0xba58a0: LeaveFrame
    //     0xba58a0: mov             SP, fp
    //     0xba58a4: ldp             fp, lr, [SP], #0x10
    // 0xba58a8: ret
    //     0xba58a8: ret             
    // 0xba58ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba58ac: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba58b0: b               #0xba585c
  }
  xfa +(xfa, xfa) {
    // ** addr: 0xba58d8, size: 0x84
    // 0xba58d8: EnterFrame
    //     0xba58d8: stp             fp, lr, [SP, #-0x10]!
    //     0xba58dc: mov             fp, SP
    // 0xba58e0: CheckStackOverflow
    //     0xba58e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xba58e4: cmp             SP, x16
    //     0xba58e8: b.ls            #0xba593c
    // 0xba58ec: ldr             x0, [fp, #0x10]
    // 0xba58f0: r2 = Null
    //     0xba58f0: mov             x2, NULL
    // 0xba58f4: r1 = Null
    //     0xba58f4: mov             x1, NULL
    // 0xba58f8: r4 = 60
    //     0xba58f8: movz            x4, #0x3c
    // 0xba58fc: branchIfSmi(r0, 0xba5908)
    //     0xba58fc: tbz             w0, #0, #0xba5908
    // 0xba5900: r4 = LoadClassIdInstr(r0)
    //     0xba5900: ldur            x4, [x0, #-1]
    //     0xba5904: ubfx            x4, x4, #0xc, #0x14
    // 0xba5908: cmp             x4, #0xc78
    // 0xba590c: b.eq            #0xba5924
    // 0xba5910: r8 = xfa
    //     0xba5910: add             x8, PP, #0x4e, lsl #12  ; [pp+0x4ed78] Type: xfa
    //     0xba5914: ldr             x8, [x8, #0xd78]
    // 0xba5918: r3 = Null
    //     0xba5918: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4ed80] Null
    //     0xba591c: ldr             x3, [x3, #0xd80]
    // 0xba5920: r0 = DefaultTypeTest()
    //     0xba5920: bl              #0xc5360c  ; DefaultTypeTestStub
    // 0xba5924: ldr             x1, [fp, #0x18]
    // 0xba5928: ldr             x2, [fp, #0x10]
    // 0xba592c: r0 = call 0x54fc28
    //     0xba592c: bl              #0x54fc28
    // 0xba5930: LeaveFrame
    //     0xba5930: mov             SP, fp
    //     0xba5934: ldp             fp, lr, [SP], #0x10
    // 0xba5938: ret
    //     0xba5938: ret             
    // 0xba593c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba593c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba5940: b               #0xba58ec
  }
  xfa *(xfa, double) {
    // ** addr: 0xba595c, size: 0x50
    // 0xba595c: EnterFrame
    //     0xba595c: stp             fp, lr, [SP, #-0x10]!
    //     0xba5960: mov             fp, SP
    // 0xba5964: CheckStackOverflow
    //     0xba5964: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xba5968: cmp             SP, x16
    //     0xba596c: b.ls            #0xba598c
    // 0xba5970: ldr             x0, [fp, #0x10]
    // 0xba5974: LoadField: d0 = r0->field_7
    //     0xba5974: ldur            d0, [x0, #7]
    // 0xba5978: ldr             x1, [fp, #0x18]
    // 0xba597c: r0 = call 0xa1b17c
    //     0xba597c: bl              #0xa1b17c
    // 0xba5980: LeaveFrame
    //     0xba5980: mov             SP, fp
    //     0xba5984: ldp             fp, lr, [SP], #0x10
    // 0xba5988: ret
    //     0xba5988: ret             
    // 0xba598c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba598c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba5990: b               #0xba5970
  }
}

// class id: 3193, size: 0x18, field offset: 0x8
//   const constructor, 
class wfa extends vfa {

  _Mint field_8;
  _Mint field_10;

  wfa -(wfa, wfa) {
    // ** addr: 0xb9bba4, size: 0x84
    // 0xb9bba4: EnterFrame
    //     0xb9bba4: stp             fp, lr, [SP, #-0x10]!
    //     0xb9bba8: mov             fp, SP
    // 0xb9bbac: CheckStackOverflow
    //     0xb9bbac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb9bbb0: cmp             SP, x16
    //     0xb9bbb4: b.ls            #0xb9bc08
    // 0xb9bbb8: ldr             x0, [fp, #0x10]
    // 0xb9bbbc: r2 = Null
    //     0xb9bbbc: mov             x2, NULL
    // 0xb9bbc0: r1 = Null
    //     0xb9bbc0: mov             x1, NULL
    // 0xb9bbc4: r4 = 60
    //     0xb9bbc4: movz            x4, #0x3c
    // 0xb9bbc8: branchIfSmi(r0, 0xb9bbd4)
    //     0xb9bbc8: tbz             w0, #0, #0xb9bbd4
    // 0xb9bbcc: r4 = LoadClassIdInstr(r0)
    //     0xb9bbcc: ldur            x4, [x0, #-1]
    //     0xb9bbd0: ubfx            x4, x4, #0xc, #0x14
    // 0xb9bbd4: cmp             x4, #0xc79
    // 0xb9bbd8: b.eq            #0xb9bbf0
    // 0xb9bbdc: r8 = wfa
    //     0xb9bbdc: add             x8, PP, #0x4e, lsl #12  ; [pp+0x4eda0] Type: wfa
    //     0xb9bbe0: ldr             x8, [x8, #0xda0]
    // 0xb9bbe4: r3 = Null
    //     0xb9bbe4: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4edb8] Null
    //     0xb9bbe8: ldr             x3, [x3, #0xdb8]
    // 0xb9bbec: r0 = DefaultTypeTest()
    //     0xb9bbec: bl              #0xc5360c  ; DefaultTypeTestStub
    // 0xb9bbf0: ldr             x1, [fp, #0x18]
    // 0xb9bbf4: ldr             x2, [fp, #0x10]
    // 0xb9bbf8: r0 = call 0x4cacd8
    //     0xb9bbf8: bl              #0x4cacd8
    // 0xb9bbfc: LeaveFrame
    //     0xb9bbfc: mov             SP, fp
    //     0xb9bc00: ldp             fp, lr, [SP], #0x10
    // 0xb9bc04: ret
    //     0xb9bc04: ret             
    // 0xb9bc08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9bc08: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9bc0c: b               #0xb9bbb8
  }
  wfa *(wfa, double) {
    // ** addr: 0xb9bc34, size: 0x50
    // 0xb9bc34: EnterFrame
    //     0xb9bc34: stp             fp, lr, [SP, #-0x10]!
    //     0xb9bc38: mov             fp, SP
    // 0xb9bc3c: CheckStackOverflow
    //     0xb9bc3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb9bc40: cmp             SP, x16
    //     0xb9bc44: b.ls            #0xb9bc64
    // 0xb9bc48: ldr             x0, [fp, #0x10]
    // 0xb9bc4c: LoadField: d0 = r0->field_7
    //     0xb9bc4c: ldur            d0, [x0, #7]
    // 0xb9bc50: ldr             x1, [fp, #0x18]
    // 0xb9bc54: r0 = call 0xa1b138
    //     0xb9bc54: bl              #0xa1b138
    // 0xb9bc58: LeaveFrame
    //     0xb9bc58: mov             SP, fp
    //     0xb9bc5c: ldp             fp, lr, [SP], #0x10
    // 0xb9bc60: ret
    //     0xb9bc60: ret             
    // 0xb9bc64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9bc64: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9bc68: b               #0xb9bc48
  }
  wfa +(wfa, wfa) {
    // ** addr: 0xb9bc84, size: 0x84
    // 0xb9bc84: EnterFrame
    //     0xb9bc84: stp             fp, lr, [SP, #-0x10]!
    //     0xb9bc88: mov             fp, SP
    // 0xb9bc8c: CheckStackOverflow
    //     0xb9bc8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb9bc90: cmp             SP, x16
    //     0xb9bc94: b.ls            #0xb9bce8
    // 0xb9bc98: ldr             x0, [fp, #0x10]
    // 0xb9bc9c: r2 = Null
    //     0xb9bc9c: mov             x2, NULL
    // 0xb9bca0: r1 = Null
    //     0xb9bca0: mov             x1, NULL
    // 0xb9bca4: r4 = 60
    //     0xb9bca4: movz            x4, #0x3c
    // 0xb9bca8: branchIfSmi(r0, 0xb9bcb4)
    //     0xb9bca8: tbz             w0, #0, #0xb9bcb4
    // 0xb9bcac: r4 = LoadClassIdInstr(r0)
    //     0xb9bcac: ldur            x4, [x0, #-1]
    //     0xb9bcb0: ubfx            x4, x4, #0xc, #0x14
    // 0xb9bcb4: cmp             x4, #0xc79
    // 0xb9bcb8: b.eq            #0xb9bcd0
    // 0xb9bcbc: r8 = wfa
    //     0xb9bcbc: add             x8, PP, #0x4e, lsl #12  ; [pp+0x4eda0] Type: wfa
    //     0xb9bcc0: ldr             x8, [x8, #0xda0]
    // 0xb9bcc4: r3 = Null
    //     0xb9bcc4: add             x3, PP, #0x4e, lsl #12  ; [pp+0x4eda8] Null
    //     0xb9bcc8: ldr             x3, [x3, #0xda8]
    // 0xb9bccc: r0 = DefaultTypeTest()
    //     0xb9bccc: bl              #0xc5360c  ; DefaultTypeTestStub
    // 0xb9bcd0: ldr             x1, [fp, #0x18]
    // 0xb9bcd4: ldr             x2, [fp, #0x10]
    // 0xb9bcd8: r0 = call 0x4cad24
    //     0xb9bcd8: bl              #0x4cad24
    // 0xb9bcdc: LeaveFrame
    //     0xb9bcdc: mov             SP, fp
    //     0xb9bce0: ldp             fp, lr, [SP], #0x10
    // 0xb9bce4: ret
    //     0xb9bce4: ret             
    // 0xb9bce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb9bce8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb9bcec: b               #0xb9bc98
  }
}
