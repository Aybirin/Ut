// lib: , url: ddn

// class id: 1049710, size: 0x8
class :: {
}

// class id: 2579, size: 0x2c, field offset: 0x28
class iZa extends pya {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x4c97b4, size: -0x1
  }
}
