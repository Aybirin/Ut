// lib: , url: ocn

// class id: 1049670, size: 0x8
class :: {
}

// class id: 1720, size: 0x8, field offset: 0x8
class aYa extends Object {
}
