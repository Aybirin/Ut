// lib: , url: xjn

// class id: 1050029, size: 0x8
class :: {
}

// class id: 1240, size: 0x8, field offset: 0x8
//   const constructor, 
class BH extends Object
    implements Ja {
}

// class id: 1241, size: 0x18, field offset: 0x8
class AH<X0> extends Object {
}
