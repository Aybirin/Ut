// lib: , url: Etn

// class id: 1050485, size: 0x8
class :: {
}

// class id: 596, size: 0x8, field offset: 0x8
abstract class wyb extends Object {

  [closure] static Future<List<jyb>> xvj(dynamic) {
    // ** addr: 0x85effc, size: -0x1
  }
  [closure] static List<jyb> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x85f028, size: -0x1
  }
  [closure] static jyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x85f1a8, size: -0x1
  }
  [closure] static myb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x79758c, size: -0x1
  }
}
