// lib: tEn, url: iin

// class id: 1049968, size: 0x8
class :: {

  static late Map<dynamic, dynamic> obj; // offset: 0x1874
}
