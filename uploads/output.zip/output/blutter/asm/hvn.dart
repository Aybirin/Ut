// lib: , url: hvn

// class id: 1050565, size: 0x8
class :: {
}

// class id: 482, size: 0x8, field offset: 0x8
abstract class LAb extends Object {

  static late final List<String> ml; // offset: 0x1ae8
}
