// lib: , url: Xbn

// class id: 1049653, size: 0x8
class :: {
}

// class id: 1740, size: 0xc, field offset: 0xc
class rXa extends IWa {

  static late final Lrb _EXh; // offset: 0x168c

  [closure] static rXa SFc(dynamic) {
    // ** addr: 0xa9bf08, size: -0x1
  }
}

// class id: 1741, size: 0xc, field offset: 0xc
class qXa extends IWa {

  static late final Lrb _EXh; // offset: 0x1690

  [closure] static qXa SFc(dynamic) {
    // ** addr: 0xa9bf74, size: -0x1
  }
}
