// lib: , url: hjn

// class id: 1050020, size: 0x8
class :: {
}

// class id: 1337, size: 0x8, field offset: 0x8
abstract class BG extends Object {
}
