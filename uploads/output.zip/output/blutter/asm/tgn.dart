// lib: , url: tgn

// class id: 1049879, size: 0x8
class :: {
}

// class id: 1457, size: 0xa4, field offset: 0x8
class Afb extends Object {

  late int dMh; // offset: 0x98
  late int eMh; // offset: 0x9c
  late int fMh; // offset: 0xa0
  late int ZLh; // offset: 0x78
  late int YLh; // offset: 0x74
}

// class id: 7088, size: 0x14, field offset: 0x14
enum Dfb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7089, size: 0x14, field offset: 0x14
enum Cfb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7090, size: 0x14, field offset: 0x14
enum Bfb extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
