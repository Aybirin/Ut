// lib: , url: hln

// class id: 1050093, size: 0x8
class :: {
}

// class id: 1130, size: 0x10, field offset: 0x10
class mkb<C3X0> extends kkb<C3X0, dynamic> {
}
