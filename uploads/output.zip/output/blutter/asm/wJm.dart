// lib: , url: wJm

// class id: 1048879, size: 0x8
class :: {
}

// class id: 5544, size: 0x1c, field offset: 0x8
abstract class _IG extends JG {

  [closure] Future<Y0> <anonymous closure>(dynamic) async {
    // ** addr: 0xc2a4a8, size: 0x90
    // 0xc2a4a8: EnterFrame
    //     0xc2a4a8: stp             fp, lr, [SP, #-0x10]!
    //     0xc2a4ac: mov             fp, SP
    // 0xc2a4b0: AllocStack(0x20)
    //     0xc2a4b0: sub             SP, SP, #0x20
    // 0xc2a4b4: SetupParameters(_IG this /* r1 */)
    //     0xc2a4b4: stur            NULL, [fp, #-8]
    //     0xc2a4b8: movz            x0, #0
    //     0xc2a4bc: add             x1, fp, w0, sxtw #2
    //     0xc2a4c0: ldr             x1, [x1, #0x10]
    //     0xc2a4c4: ldur            w2, [x1, #0x17]
    //     0xc2a4c8: add             x2, x2, HEAP, lsl #32
    //     0xc2a4cc: stur            x2, [fp, #-0x18]
    // 0xc2a4d0: CheckStackOverflow
    //     0xc2a4d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2a4d4: cmp             SP, x16
    //     0xc2a4d8: b.ls            #0xc2a530
    // 0xc2a4dc: LoadField: r3 = r1->field_b
    //     0xc2a4dc: ldur            w3, [x1, #0xb]
    // 0xc2a4e0: DecompressPointer r3
    //     0xc2a4e0: add             x3, x3, HEAP, lsl #32
    // 0xc2a4e4: mov             x0, x3
    // 0xc2a4e8: stur            x3, [fp, #-0x10]
    // 0xc2a4ec: r0 = InitAsync()
    //     0xc2a4ec: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc2a4f0: ldur            x0, [fp, #-0x18]
    // 0xc2a4f4: LoadField: r1 = r0->field_13
    //     0xc2a4f4: ldur            w1, [x0, #0x13]
    // 0xc2a4f8: DecompressPointer r1
    //     0xc2a4f8: add             x1, x1, HEAP, lsl #32
    // 0xc2a4fc: tbnz            w1, #4, #0xc2a504
    // 0xc2a500: r0 = call 0x6c66bc
    //     0xc2a500: bl              #0x6c66bc
    // 0xc2a504: ldur            x1, [fp, #-0x18]
    // 0xc2a508: LoadField: r0 = r1->field_f
    //     0xc2a508: ldur            w0, [x1, #0xf]
    // 0xc2a50c: DecompressPointer r0
    //     0xc2a50c: add             x0, x0, HEAP, lsl #32
    // 0xc2a510: str             x0, [SP]
    // 0xc2a514: ClosureCall
    //     0xc2a514: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xc2a518: ldur            x2, [x0, #0x1f]
    //     0xc2a51c: blr             x2
    // 0xc2a520: mov             x1, x0
    // 0xc2a524: stur            x1, [fp, #-0x10]
    // 0xc2a528: r0 = Await()
    //     0xc2a528: bl              #0xb0c534  ; AwaitStub
    // 0xc2a52c: r0 = ReturnAsync()
    //     0xc2a52c: b               #0xb13694  ; ReturnAsyncStub
    // 0xc2a530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2a530: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2a534: b               #0xc2a4dc
  }
  [closure] Future<void> <anonymous closure>(dynamic) {
    // ** addr: 0x97a2cc, size: -0x1
  }
  [closure] Future<void> <anonymous closure>(dynamic) {
    // ** addr: 0x97ebb4, size: -0x1
  }
  [closure] Future<int> <anonymous closure>(dynamic) {
    // ** addr: 0x97e480, size: -0x1
  }
  [closure] Future<int> <anonymous closure>(dynamic) {
    // ** addr: 0x973a5c, size: -0x1
  }
  [closure] Future<kI> <anonymous closure>(dynamic) {
    // ** addr: 0x98aee0, size: -0x1
  }
}

// class id: 5545, size: 0x28, field offset: 0x1c
class _jI extends _IG {

  [closure] Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xc2e120, size: 0xb0
    // 0xc2e120: EnterFrame
    //     0xc2e120: stp             fp, lr, [SP, #-0x10]!
    //     0xc2e124: mov             fp, SP
    // 0xc2e128: AllocStack(0x20)
    //     0xc2e128: sub             SP, SP, #0x20
    // 0xc2e12c: SetupParameters(_jI this /* r1 */)
    //     0xc2e12c: stur            NULL, [fp, #-8]
    //     0xc2e130: movz            x0, #0
    //     0xc2e134: add             x1, fp, w0, sxtw #2
    //     0xc2e138: ldr             x1, [x1, #0x10]
    //     0xc2e13c: ldur            w2, [x1, #0x17]
    //     0xc2e140: add             x2, x2, HEAP, lsl #32
    //     0xc2e144: stur            x2, [fp, #-0x10]
    // 0xc2e148: CheckStackOverflow
    //     0xc2e148: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2e14c: cmp             SP, x16
    //     0xc2e150: b.ls            #0xc2e1c8
    // 0xc2e154: InitAsync() -> Future<Null?>
    //     0xc2e154: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xc2e158: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc2e15c: ldur            x0, [fp, #-0x10]
    // 0xc2e160: LoadField: r1 = r0->field_13
    //     0xc2e160: ldur            w1, [x0, #0x13]
    // 0xc2e164: DecompressPointer r1
    //     0xc2e164: add             x1, x1, HEAP, lsl #32
    // 0xc2e168: r16 = true
    //     0xc2e168: add             x16, NULL, #0x20  ; true
    // 0xc2e16c: str             x16, [SP]
    // 0xc2e170: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xc2e170: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xc2e174: r0 = call 0x9eda78
    //     0xc2e174: bl              #0x9eda78
    // 0xc2e178: ldur            x1, [fp, #-0x10]
    // 0xc2e17c: LoadField: r0 = r1->field_f
    //     0xc2e17c: ldur            w0, [x1, #0xf]
    // 0xc2e180: DecompressPointer r0
    //     0xc2e180: add             x0, x0, HEAP, lsl #32
    // 0xc2e184: LoadField: r2 = r0->field_23
    //     0xc2e184: ldur            w2, [x0, #0x23]
    // 0xc2e188: DecompressPointer r2
    //     0xc2e188: add             x2, x2, HEAP, lsl #32
    // 0xc2e18c: LoadField: r3 = r2->field_b
    //     0xc2e18c: ldur            w3, [x2, #0xb]
    // 0xc2e190: DecompressPointer r3
    //     0xc2e190: add             x3, x3, HEAP, lsl #32
    // 0xc2e194: mov             x0, x3
    // 0xc2e198: stur            x3, [fp, #-0x18]
    // 0xc2e19c: r0 = Await()
    //     0xc2e19c: bl              #0xb0c534  ; AwaitStub
    // 0xc2e1a0: ldur            x1, [fp, #-0x10]
    // 0xc2e1a4: LoadField: r2 = r1->field_f
    //     0xc2e1a4: ldur            w2, [x1, #0xf]
    // 0xc2e1a8: DecompressPointer r2
    //     0xc2e1a8: add             x2, x2, HEAP, lsl #32
    // 0xc2e1ac: LoadField: r1 = r2->field_1b
    //     0xc2e1ac: ldur            w1, [x2, #0x1b]
    // 0xc2e1b0: DecompressPointer r1
    //     0xc2e1b0: add             x1, x1, HEAP, lsl #32
    // 0xc2e1b4: LoadField: r2 = r1->field_b
    //     0xc2e1b4: ldur            x2, [x1, #0xb]
    // 0xc2e1b8: sub             x3, x2, #1
    // 0xc2e1bc: StoreField: r1->field_b = r3
    //     0xc2e1bc: stur            x3, [x1, #0xb]
    // 0xc2e1c0: r0 = Null
    //     0xc2e1c0: mov             x0, NULL
    // 0xc2e1c4: r0 = ReturnAsyncNotFuture()
    //     0xc2e1c4: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc2e1c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2e1c8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2e1cc: b               #0xc2e154
  }
}

// class id: 5546, size: 0x20, field offset: 0x1c
class _iI extends _IG {
}

// class id: 5547, size: 0x20, field offset: 0x1c
abstract class _fI extends _IG
    implements MG {
}

// class id: 5549, size: 0x44, field offset: 0x20
class _gI extends _fI {

  [closure] Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xc2dff0, size: 0x130
    // 0xc2dff0: EnterFrame
    //     0xc2dff0: stp             fp, lr, [SP, #-0x10]!
    //     0xc2dff4: mov             fp, SP
    // 0xc2dff8: AllocStack(0x60)
    //     0xc2dff8: sub             SP, SP, #0x60
    // 0xc2dffc: SetupParameters(_gI this /* r1, fp-0x58 */)
    //     0xc2dffc: stur            NULL, [fp, #-8]
    //     0xc2e000: movz            x0, #0
    //     0xc2e004: add             x1, fp, w0, sxtw #2
    //     0xc2e008: ldr             x1, [x1, #0x10]
    //     0xc2e00c: stur            x1, [fp, #-0x58]
    //     0xc2e010: ldur            w2, [x1, #0x17]
    //     0xc2e014: add             x2, x2, HEAP, lsl #32
    //     0xc2e018: stur            x2, [fp, #-0x50]
    // 0xc2e01c: CheckStackOverflow
    //     0xc2e01c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2e020: cmp             SP, x16
    //     0xc2e024: b.ls            #0xc2e110
    // 0xc2e028: InitAsync() -> Future<Null?>
    //     0xc2e028: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xc2e02c: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc2e030: ldur            x0, [fp, #-0x50]
    // 0xc2e034: r0 = call 0x6c66bc
    //     0xc2e034: bl              #0x6c66bc
    // 0xc2e038: ldur            x0, [fp, #-0x50]
    // 0xc2e03c: LoadField: r1 = r0->field_f
    //     0xc2e03c: ldur            w1, [x0, #0xf]
    // 0xc2e040: DecompressPointer r1
    //     0xc2e040: add             x1, x1, HEAP, lsl #32
    // 0xc2e044: LoadField: r2 = r1->field_37
    //     0xc2e044: ldur            w2, [x1, #0x37]
    // 0xc2e048: DecompressPointer r2
    //     0xc2e048: add             x2, x2, HEAP, lsl #32
    // 0xc2e04c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc2e04c: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc2e050: r0 = call 0x97eb10
    //     0xc2e050: bl              #0x97eb10
    // 0xc2e054: mov             x1, x0
    // 0xc2e058: stur            x1, [fp, #-0x58]
    // 0xc2e05c: r0 = Await()
    //     0xc2e05c: bl              #0xb0c534  ; AwaitStub
    // 0xc2e060: ldur            x0, [fp, #-0x50]
    // 0xc2e064: LoadField: r1 = r0->field_f
    //     0xc2e064: ldur            w1, [x0, #0xf]
    // 0xc2e068: DecompressPointer r1
    //     0xc2e068: add             x1, x1, HEAP, lsl #32
    // 0xc2e06c: LoadField: r2 = r1->field_23
    //     0xc2e06c: ldur            w2, [x1, #0x23]
    // 0xc2e070: DecompressPointer r2
    //     0xc2e070: add             x2, x2, HEAP, lsl #32
    // 0xc2e074: cmp             w2, NULL
    // 0xc2e078: b.eq            #0xc2e118
    // 0xc2e07c: r16 = true
    //     0xc2e07c: add             x16, NULL, #0x20  ; true
    // 0xc2e080: str             x16, [SP]
    // 0xc2e084: mov             x1, x2
    // 0xc2e088: r4 = const [0, 0x2, 0x1, 0x2, null]
    //     0xc2e088: ldr             x4, [PP, #0xd08]  ; [pp+0xd08] List(5) [0, 0x2, 0x1, 0x2, Null]
    // 0xc2e08c: r0 = call 0x9eda78
    //     0xc2e08c: bl              #0x9eda78
    // 0xc2e090: ldur            x1, [fp, #-0x50]
    // 0xc2e094: b               #0xc2e0e0
    // 0xc2e098: sub             SP, fp, #0x60
    // 0xc2e09c: mov             x2, x0
    // 0xc2e0a0: ldur            x0, [fp, #-0x20]
    // 0xc2e0a4: LoadField: r3 = r0->field_f
    //     0xc2e0a4: ldur            w3, [x0, #0xf]
    // 0xc2e0a8: DecompressPointer r3
    //     0xc2e0a8: add             x3, x3, HEAP, lsl #32
    // 0xc2e0ac: LoadField: r4 = r3->field_23
    //     0xc2e0ac: ldur            w4, [x3, #0x23]
    // 0xc2e0b0: DecompressPointer r4
    //     0xc2e0b0: add             x4, x4, HEAP, lsl #32
    // 0xc2e0b4: cmp             w4, NULL
    // 0xc2e0b8: b.eq            #0xc2e11c
    // 0xc2e0bc: str             x1, [SP]
    // 0xc2e0c0: mov             x1, x4
    // 0xc2e0c4: r4 = const [0, 0x3, 0x1, 0x3, null]
    //     0xc2e0c4: ldr             x4, [PP, #0xc88]  ; [pp+0xc88] List(5) [0, 0x3, 0x1, 0x3, Null]
    // 0xc2e0c8: r0 = call 0x36878c
    //     0xc2e0c8: bl              #0x36878c
    // 0xc2e0cc: ldur            x0, [fp, #-0x20]
    // 0xc2e0d0: LoadField: r1 = r0->field_f
    //     0xc2e0d0: ldur            w1, [x0, #0xf]
    // 0xc2e0d4: DecompressPointer r1
    //     0xc2e0d4: add             x1, x1, HEAP, lsl #32
    // 0xc2e0d8: r0 = call 0x99eff0
    //     0xc2e0d8: bl              #0x99eff0
    // 0xc2e0dc: ldur            x1, [fp, #-0x20]
    // 0xc2e0e0: stur            x1, [fp, #-0x58]
    // 0xc2e0e4: LoadField: r0 = r1->field_f
    //     0xc2e0e4: ldur            w0, [x1, #0xf]
    // 0xc2e0e8: DecompressPointer r0
    //     0xc2e0e8: add             x0, x0, HEAP, lsl #32
    // 0xc2e0ec: LoadField: r2 = r0->field_27
    //     0xc2e0ec: ldur            w2, [x0, #0x27]
    // 0xc2e0f0: DecompressPointer r2
    //     0xc2e0f0: add             x2, x2, HEAP, lsl #32
    // 0xc2e0f4: LoadField: r3 = r2->field_b
    //     0xc2e0f4: ldur            w3, [x2, #0xb]
    // 0xc2e0f8: DecompressPointer r3
    //     0xc2e0f8: add             x3, x3, HEAP, lsl #32
    // 0xc2e0fc: mov             x0, x3
    // 0xc2e100: stur            x3, [fp, #-0x50]
    // 0xc2e104: r0 = Await()
    //     0xc2e104: bl              #0xb0c534  ; AwaitStub
    // 0xc2e108: r0 = Null
    //     0xc2e108: mov             x0, NULL
    // 0xc2e10c: r0 = ReturnAsyncNotFuture()
    //     0xc2e10c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc2e110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2e110: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2e114: b               #0xc2e028
    // 0xc2e118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc2e118: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc2e11c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc2e11c: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] int <anonymous closure>(dynamic) {
    // ** addr: 0x99efa8, size: -0x1
  }
}

// class id: 5550, size: 0x30, field offset: 0x1c
abstract class wG extends _IG {

  [closure] Future<bool> <anonymous closure>(dynamic) async {
    // ** addr: 0xc2cb88, size: 0x210
    // 0xc2cb88: EnterFrame
    //     0xc2cb88: stp             fp, lr, [SP, #-0x10]!
    //     0xc2cb8c: mov             fp, SP
    // 0xc2cb90: AllocStack(0x80)
    //     0xc2cb90: sub             SP, SP, #0x80
    // 0xc2cb94: SetupParameters(wG this /* r1, fp-0x68 */)
    //     0xc2cb94: stur            NULL, [fp, #-8]
    //     0xc2cb98: movz            x0, #0
    //     0xc2cb9c: add             x1, fp, w0, sxtw #2
    //     0xc2cba0: ldr             x1, [x1, #0x10]
    //     0xc2cba4: stur            x1, [fp, #-0x68]
    //     0xc2cba8: ldur            w2, [x1, #0x17]
    //     0xc2cbac: add             x2, x2, HEAP, lsl #32
    //     0xc2cbb0: stur            x2, [fp, #-0x60]
    // 0xc2cbb4: CheckStackOverflow
    //     0xc2cbb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc2cbb8: cmp             SP, x16
    //     0xc2cbbc: b.ls            #0xc2cd90
    // 0xc2cbc0: InitAsync() -> Future<bool>
    //     0xc2cbc0: ldr             x0, [PP, #0x1a20]  ; [pp+0x1a20] TypeArguments: <bool>
    //     0xc2cbc4: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc2cbc8: ldur            x0, [fp, #-0x60]
    // 0xc2cbcc: LoadField: r1 = r0->field_f
    //     0xc2cbcc: ldur            w1, [x0, #0xf]
    // 0xc2cbd0: DecompressPointer r1
    //     0xc2cbd0: add             x1, x1, HEAP, lsl #32
    // 0xc2cbd4: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xc2cbd4: ldur            w2, [x1, #0x17]
    // 0xc2cbd8: DecompressPointer r2
    //     0xc2cbd8: add             x2, x2, HEAP, lsl #32
    // 0xc2cbdc: tbnz            w2, #4, #0xc2cc08
    // 0xc2cbe0: r0 = StateError()
    //     0xc2cbe0: bl              #0xb09194  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xc2cbe4: mov             x1, x0
    // 0xc2cbe8: r0 = "Can\'t re-open a database after closing it. Please create a new database connection and open that instead."
    //     0xc2cbe8: add             x0, PP, #0x13, lsl #12  ; [pp+0x13328] "Can\'t re-open a database after closing it. Please create a new database connection and open that instead."
    //     0xc2cbec: ldr             x0, [x0, #0x328]
    // 0xc2cbf0: StoreField: r1->field_b = r0
    //     0xc2cbf0: stur            w0, [x1, #0xb]
    // 0xc2cbf4: mov             x2, x1
    // 0xc2cbf8: r1 = <bool>
    //     0xc2cbf8: ldr             x1, [PP, #0x1a20]  ; [pp+0x1a20] TypeArguments: <bool>
    // 0xc2cbfc: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xc2cbfc: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xc2cc00: r0 = call 0x3713fc
    //     0xc2cc00: bl              #0x3713fc
    // 0xc2cc04: r0 = ReturnAsync()
    //     0xc2cc04: b               #0xb13694  ; ReturnAsyncStub
    // 0xc2cc08: LoadField: r3 = r1->field_1f
    //     0xc2cc08: ldur            w3, [x1, #0x1f]
    // 0xc2cc0c: DecompressPointer r3
    //     0xc2cc0c: add             x3, x3, HEAP, lsl #32
    // 0xc2cc10: stur            x3, [fp, #-0x70]
    // 0xc2cc14: cmp             w3, NULL
    // 0xc2cc18: b.eq            #0xc2cc30
    // 0xc2cc1c: LoadField: r1 = r3->field_f
    //     0xc2cc1c: ldur            w1, [x3, #0xf]
    // 0xc2cc20: DecompressPointer r1
    //     0xc2cc20: add             x1, x1, HEAP, lsl #32
    // 0xc2cc24: LoadField: r2 = r3->field_13
    //     0xc2cc24: ldur            w2, [x3, #0x13]
    // 0xc2cc28: DecompressPointer r2
    //     0xc2cc28: add             x2, x2, HEAP, lsl #32
    // 0xc2cc2c: r0 = call 0x36734c
    //     0xc2cc2c: bl              #0x36734c
    // 0xc2cc30: ldur            x0, [fp, #-0x60]
    // 0xc2cc34: LoadField: r1 = r0->field_f
    //     0xc2cc34: ldur            w1, [x0, #0xf]
    // 0xc2cc38: DecompressPointer r1
    //     0xc2cc38: add             x1, x1, HEAP, lsl #32
    // 0xc2cc3c: LoadField: r2 = r1->field_1b
    //     0xc2cc3c: ldur            w2, [x1, #0x1b]
    // 0xc2cc40: DecompressPointer r2
    //     0xc2cc40: add             x2, x2, HEAP, lsl #32
    // 0xc2cc44: LoadField: r3 = r2->field_13
    //     0xc2cc44: ldur            w3, [x2, #0x13]
    // 0xc2cc48: DecompressPointer r3
    //     0xc2cc48: add             x3, x3, HEAP, lsl #32
    // 0xc2cc4c: stur            x3, [fp, #-0x78]
    // 0xc2cc50: r1 = <bool>
    //     0xc2cc50: ldr             x1, [PP, #0x1a20]  ; [pp+0x1a20] TypeArguments: <bool>
    // 0xc2cc54: r0 = _Future()
    //     0xc2cc54: bl              #0xb0c7f0  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xc2cc58: stur            x0, [fp, #-0x80]
    // 0xc2cc5c: StoreField: r0->field_b = rZR
    //     0xc2cc5c: stur            xzr, [x0, #0xb]
    // 0xc2cc60: r0 = InitLateStaticField(0x3e4) // [dart:async] s::_current
    //     0xc2cc60: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xc2cc64: ldr             x0, [x0, #0x7c8]
    //     0xc2cc68: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xc2cc6c: cmp             w0, w16
    //     0xc2cc70: b.ne            #0xc2cc7c
    //     0xc2cc74: ldr             x2, [PP, #0x2f0]  ; [pp+0x2f0] Field <s._current@5048458>: static late (offset: 0x3e4)
    //     0xc2cc78: bl              #0xc5392c  ; InitLateStaticFieldStub
    // 0xc2cc7c: mov             x1, x0
    // 0xc2cc80: ldur            x0, [fp, #-0x80]
    // 0xc2cc84: StoreField: r0->field_13 = r1
    //     0xc2cc84: stur            w1, [x0, #0x13]
    // 0xc2cc88: mov             x1, x0
    // 0xc2cc8c: ldur            x2, [fp, #-0x78]
    // 0xc2cc90: r0 = call 0x364614
    //     0xc2cc90: bl              #0x364614
    // 0xc2cc94: ldur            x0, [fp, #-0x80]
    // 0xc2cc98: r1 = <bool>
    //     0xc2cc98: ldr             x1, [PP, #0x1a20]  ; [pp+0x1a20] TypeArguments: <bool>
    // 0xc2cc9c: r0 = AwaitWithTypeCheck()
    //     0xc2cc9c: bl              #0xb18c18  ; AwaitWithTypeCheckStub
    // 0xc2cca0: stur            x0, [fp, #-0x78]
    // 0xc2cca4: r16 = true
    //     0xc2cca4: add             x16, NULL, #0x20  ; true
    // 0xc2cca8: cmp             w0, w16
    // 0xc2ccac: b.ne            #0xc2cccc
    // 0xc2ccb0: ldur            x2, [fp, #-0x60]
    // 0xc2ccb4: r3 = true
    //     0xc2ccb4: add             x3, NULL, #0x20  ; true
    // 0xc2ccb8: LoadField: r0 = r2->field_f
    //     0xc2ccb8: ldur            w0, [x2, #0xf]
    // 0xc2ccbc: DecompressPointer r0
    //     0xc2ccbc: add             x0, x0, HEAP, lsl #32
    // 0xc2ccc0: StoreField: r0->field_13 = r3
    //     0xc2ccc0: stur            w3, [x0, #0x13]
    // 0xc2ccc4: mov             x0, x3
    // 0xc2ccc8: r0 = ReturnAsyncNotFuture()
    //     0xc2ccc8: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc2cccc: ldur            x2, [fp, #-0x60]
    // 0xc2ccd0: r3 = true
    //     0xc2ccd0: add             x3, NULL, #0x20  ; true
    // 0xc2ccd4: LoadField: r1 = r2->field_f
    //     0xc2ccd4: ldur            w1, [x2, #0xf]
    // 0xc2ccd8: DecompressPointer r1
    //     0xc2ccd8: add             x1, x1, HEAP, lsl #32
    // 0xc2ccdc: LoadField: r4 = r1->field_1b
    //     0xc2ccdc: ldur            w4, [x1, #0x1b]
    // 0xc2cce0: DecompressPointer r4
    //     0xc2cce0: add             x4, x4, HEAP, lsl #32
    // 0xc2cce4: mov             x1, x4
    // 0xc2cce8: r0 = __unknown_function__()
    //     0xc2cce8: bl              #0xc2d060  ; [] ::__unknown_function__
    // 0xc2ccec: mov             x1, x0
    // 0xc2ccf0: stur            x1, [fp, #-0x80]
    // 0xc2ccf4: r0 = Await()
    //     0xc2ccf4: bl              #0xb0c534  ; AwaitStub
    // 0xc2ccf8: ldur            x0, [fp, #-0x60]
    // 0xc2ccfc: LoadField: r1 = r0->field_f
    //     0xc2ccfc: ldur            w1, [x0, #0xf]
    // 0xc2cd00: DecompressPointer r1
    //     0xc2cd00: add             x1, x1, HEAP, lsl #32
    // 0xc2cd04: r3 = true
    //     0xc2cd04: add             x3, NULL, #0x20  ; true
    // 0xc2cd08: StoreField: r1->field_13 = r3
    //     0xc2cd08: stur            w3, [x1, #0x13]
    // 0xc2cd0c: LoadField: r2 = r0->field_13
    //     0xc2cd0c: ldur            w2, [x0, #0x13]
    // 0xc2cd10: DecompressPointer r2
    //     0xc2cd10: add             x2, x2, HEAP, lsl #32
    // 0xc2cd14: r0 = __unknown_function__()
    //     0xc2cd14: bl              #0xc2cd98  ; [] ::__unknown_function__
    // 0xc2cd18: mov             x1, x0
    // 0xc2cd1c: stur            x1, [fp, #-0x68]
    // 0xc2cd20: r0 = Await()
    //     0xc2cd20: bl              #0xb0c534  ; AwaitStub
    // 0xc2cd24: r0 = true
    //     0xc2cd24: add             x0, NULL, #0x20  ; true
    // 0xc2cd28: r0 = ReturnAsyncNotFuture()
    //     0xc2cd28: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc2cd2c: sub             SP, fp, #0x80
    // 0xc2cd30: ldur            x2, [fp, #-0x20]
    // 0xc2cd34: stur            x0, [fp, #-0x68]
    // 0xc2cd38: mov             x16, x1
    // 0xc2cd3c: mov             x1, x0
    // 0xc2cd40: mov             x0, x16
    // 0xc2cd44: stur            x0, [fp, #-0x70]
    // 0xc2cd48: LoadField: r4 = r2->field_f
    //     0xc2cd48: ldur            w4, [x2, #0xf]
    // 0xc2cd4c: DecompressPointer r4
    //     0xc2cd4c: add             x4, x4, HEAP, lsl #32
    // 0xc2cd50: mov             x2, x1
    // 0xc2cd54: mov             x3, x0
    // 0xc2cd58: stur            x4, [fp, #-0x60]
    // 0xc2cd5c: r0 = AllocateRecord2()
    //     0xc2cd5c: bl              #0xc5450c  ; AllocateRecord2Stub
    // 0xc2cd60: ldur            x1, [fp, #-0x60]
    // 0xc2cd64: StoreField: r1->field_1f = r0
    //     0xc2cd64: stur            w0, [x1, #0x1f]
    //     0xc2cd68: ldurb           w16, [x1, #-1]
    //     0xc2cd6c: ldurb           w17, [x0, #-1]
    //     0xc2cd70: and             x16, x17, x16, lsr #2
    //     0xc2cd74: tst             x16, HEAP, lsr #32
    //     0xc2cd78: b.eq            #0xc2cd80
    //     0xc2cd7c: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xc2cd80: ldur            x0, [fp, #-0x68]
    // 0xc2cd84: ldur            x1, [fp, #-0x70]
    // 0xc2cd88: r0 = ReThrow()
    //     0xc2cd88: bl              #0xc539d8  ; ReThrowStub
    // 0xc2cd8c: brk             #0
    // 0xc2cd90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2cd90: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc2cd94: b               #0xc2cbc0
  }
  [closure] Future<void> <anonymous closure>(dynamic) {
    // ** addr: 0x981944, size: -0x1
  }
}
