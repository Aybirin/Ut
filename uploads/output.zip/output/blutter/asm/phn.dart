// lib: , url: phn

// class id: 1049927, size: 0x8
class :: {
}

// class id: 7487, size: 0x28, field offset: 0xc
class Vgb extends Iterable<dynamic>
    implements tgb {

  int length(Vgb) {
    // ** addr: 0xbab324, size: 0x50
    // 0xbab324: ldr             x2, [SP]
    // 0xbab328: LoadField: r3 = r2->field_23
    //     0xbab328: ldur            w3, [x2, #0x23]
    // 0xbab32c: DecompressPointer r3
    //     0xbab32c: add             x3, x3, HEAP, lsl #32
    // 0xbab330: LoadField: r2 = r3->field_1b
    //     0xbab330: ldur            x2, [x3, #0x1b]
    // 0xbab334: r0 = BoxInt64Instr(r2)
    //     0xbab334: sbfiz           x0, x2, #1, #0x1f
    //     0xbab338: cmp             x2, x0, asr #1
    //     0xbab33c: b.eq            #0xbab358
    //     0xbab340: stp             fp, lr, [SP, #-0x10]!
    //     0xbab344: mov             fp, SP
    //     0xbab348: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xbab34c: mov             SP, fp
    //     0xbab350: ldp             fp, lr, [SP], #0x10
    //     0xbab354: stur            x2, [x0, #7]
    // 0xbab358: ret
    //     0xbab358: ret             
  }
  num [](Vgb, int) {
    // ** addr: 0xba9b70, size: 0x80
    // 0xba9b70: EnterFrame
    //     0xba9b70: stp             fp, lr, [SP, #-0x10]!
    //     0xba9b74: mov             fp, SP
    // 0xba9b78: CheckStackOverflow
    //     0xba9b78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xba9b7c: cmp             SP, x16
    //     0xba9b80: b.ls            #0xba9bd0
    // 0xba9b84: ldr             x0, [fp, #0x10]
    // 0xba9b88: r2 = Null
    //     0xba9b88: mov             x2, NULL
    // 0xba9b8c: r1 = Null
    //     0xba9b8c: mov             x1, NULL
    // 0xba9b90: branchIfSmi(r0, 0xba9bb8)
    //     0xba9b90: tbz             w0, #0, #0xba9bb8
    // 0xba9b94: r4 = LoadClassIdInstr(r0)
    //     0xba9b94: ldur            x4, [x0, #-1]
    //     0xba9b98: ubfx            x4, x4, #0xc, #0x14
    // 0xba9b9c: sub             x4, x4, #0x3c
    // 0xba9ba0: cmp             x4, #1
    // 0xba9ba4: b.ls            #0xba9bb8
    // 0xba9ba8: r8 = int
    //     0xba9ba8: ldr             x8, [PP, #0x3c0]  ; [pp+0x3c0] Type: int
    // 0xba9bac: r3 = Null
    //     0xba9bac: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3bb98] Null
    //     0xba9bb0: ldr             x3, [x3, #0xb98]
    // 0xba9bb4: r0 = int()
    //     0xba9bb4: bl              #0xc5adcc  ; IsType_int_Stub
    // 0xba9bb8: ldr             x1, [fp, #0x18]
    // 0xba9bbc: ldr             x2, [fp, #0x10]
    // 0xba9bc0: r0 = call 0x969754
    //     0xba9bc0: bl              #0x969754
    // 0xba9bc4: LeaveFrame
    //     0xba9bc4: mov             SP, fp
    //     0xba9bc8: ldp             fp, lr, [SP], #0x10
    // 0xba9bcc: ret
    //     0xba9bcc: ret             
    // 0xba9bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xba9bd0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xba9bd4: b               #0xba9b84
  }
}
