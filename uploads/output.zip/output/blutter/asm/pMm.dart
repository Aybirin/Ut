// lib: , url: pMm

// class id: 1048979, size: 0x8
class :: {
}

// class id: 3386, size: 0xc, field offset: 0x8
class aT extends Object {
}

// class id: 3457, size: 0x4c, field offset: 0x24
class bT extends cT {

  late NT _EGe; // offset: 0x40
  late double _Eff; // offset: 0x44

  [closure] static double _Fff(dynamic, double, double, double) {
    // ** addr: 0x69da80, size: -0x1
  }
  [closure] void PJd(dynamic, VQ) {
    // ** addr: 0x9451a8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x945794, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5b0cc8, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8a1c18, size: -0x1
  }
}

// class id: 7326, size: 0x14, field offset: 0x14
enum _ZS extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
