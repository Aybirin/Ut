// lib: , url: fbn

// class id: 1049629, size: 0x8
class :: {

  [closure] static Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xb311a4, size: 0xa0
    // 0xb311a4: EnterFrame
    //     0xb311a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb311a8: mov             fp, SP
    // 0xb311ac: AllocStack(0x48)
    //     0xb311ac: sub             SP, SP, #0x48
    // 0xb311b0: SetupParameters(dynamic _ /* r1, fp-0x48 */)
    //     0xb311b0: stur            NULL, [fp, #-8]
    //     0xb311b4: movz            x0, #0
    //     0xb311b8: add             x1, fp, w0, sxtw #2
    //     0xb311bc: ldr             x1, [x1, #0x10]
    //     0xb311c0: stur            x1, [fp, #-0x48]
    //     0xb311c4: ldur            w2, [x1, #0x17]
    //     0xb311c8: add             x2, x2, HEAP, lsl #32
    //     0xb311cc: stur            x2, [fp, #-0x40]
    // 0xb311d0: CheckStackOverflow
    //     0xb311d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb311d4: cmp             SP, x16
    //     0xb311d8: b.ls            #0xb3123c
    // 0xb311dc: InitAsync() -> Future<void?>
    //     0xb311dc: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xb311e0: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb311e4: ldur            x0, [fp, #-0x40]
    // 0xb311e8: LoadField: r3 = r0->field_13
    //     0xb311e8: ldur            w3, [x0, #0x13]
    // 0xb311ec: DecompressPointer r3
    //     0xb311ec: add             x3, x3, HEAP, lsl #32
    // 0xb311f0: stur            x3, [fp, #-0x48]
    // 0xb311f4: cmp             w3, NULL
    // 0xb311f8: b.eq            #0xb31234
    // 0xb311fc: LoadField: r1 = r0->field_f
    //     0xb311fc: ldur            w1, [x0, #0xf]
    // 0xb31200: DecompressPointer r1
    //     0xb31200: add             x1, x1, HEAP, lsl #32
    // 0xb31204: mov             x2, x3
    // 0xb31208: r0 = __unknown_function__()
    //     0xb31208: bl              #0xb313d0  ; [] ::__unknown_function__
    // 0xb3120c: mov             x1, x0
    // 0xb31210: stur            x1, [fp, #-0x40]
    // 0xb31214: r0 = Await()
    //     0xb31214: bl              #0xb0c534  ; AwaitStub
    // 0xb31218: ldur            x1, [fp, #-0x48]
    // 0xb3121c: r0 = __unknown_function__()
    //     0xb3121c: bl              #0xb31244  ; [] ::__unknown_function__
    // 0xb31220: mov             x1, x0
    // 0xb31224: stur            x1, [fp, #-0x40]
    // 0xb31228: r0 = Await()
    //     0xb31228: bl              #0xb0c534  ; AwaitStub
    // 0xb3122c: b               #0xb31234
    // 0xb31230: sub             SP, fp, #0x48
    // 0xb31234: r0 = Null
    //     0xb31234: mov             x0, NULL
    // 0xb31238: r0 = ReturnAsyncNotFuture()
    //     0xb31238: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb3123c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb3123c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb31240: b               #0xb311dc
  }
  [closure] static Future<List<iWa>> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb3a0c0, size: 0x100
    // 0xb3a0c0: EnterFrame
    //     0xb3a0c0: stp             fp, lr, [SP, #-0x10]!
    //     0xb3a0c4: mov             fp, SP
    // 0xb3a0c8: AllocStack(0x30)
    //     0xb3a0c8: sub             SP, SP, #0x30
    // 0xb3a0cc: SetupParameters(dynamic _ /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xb3a0cc: stur            NULL, [fp, #-8]
    //     0xb3a0d0: movz            x0, #0
    //     0xb3a0d4: add             x1, fp, w0, sxtw #2
    //     0xb3a0d8: ldr             x1, [x1, #0x18]
    //     0xb3a0dc: add             x2, fp, w0, sxtw #2
    //     0xb3a0e0: ldr             x2, [x2, #0x10]
    //     0xb3a0e4: stur            x2, [fp, #-0x18]
    //     0xb3a0e8: ldur            w3, [x1, #0x17]
    //     0xb3a0ec: add             x3, x3, HEAP, lsl #32
    //     0xb3a0f0: stur            x3, [fp, #-0x10]
    // 0xb3a0f4: CheckStackOverflow
    //     0xb3a0f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb3a0f8: cmp             SP, x16
    //     0xb3a0fc: b.ls            #0xb3a1b8
    // 0xb3a100: InitAsync() -> Future<List<iWa>>
    //     0xb3a100: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2a2c0] TypeArguments: <List<iWa>>
    //     0xb3a104: ldr             x0, [x0, #0x2c0]
    //     0xb3a108: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb3a10c: ldur            x0, [fp, #-0x10]
    // 0xb3a110: LoadField: r2 = r0->field_13
    //     0xb3a110: ldur            w2, [x0, #0x13]
    // 0xb3a114: DecompressPointer r2
    //     0xb3a114: add             x2, x2, HEAP, lsl #32
    // 0xb3a118: ldur            x1, [fp, #-0x18]
    // 0xb3a11c: r0 = call 0x430cb0
    //     0xb3a11c: bl              #0x430cb0
    // 0xb3a120: mov             x1, x0
    // 0xb3a124: stur            x1, [fp, #-0x18]
    // 0xb3a128: r0 = Await()
    //     0xb3a128: bl              #0xb0c534  ; AwaitStub
    // 0xb3a12c: mov             x2, x0
    // 0xb3a130: ldur            x0, [fp, #-0x10]
    // 0xb3a134: stur            x2, [fp, #-0x18]
    // 0xb3a138: LoadField: r1 = r0->field_f
    //     0xb3a138: ldur            w1, [x0, #0xf]
    // 0xb3a13c: DecompressPointer r1
    //     0xb3a13c: add             x1, x1, HEAP, lsl #32
    // 0xb3a140: r0 = call 0x430ba8
    //     0xb3a140: bl              #0x430ba8
    // 0xb3a144: r1 = Function '<anonymous closure>': static.
    //     0xb3a144: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2a2c8] AnonymousClosure: static (0x431038), of [fbn] 
    //     0xb3a148: ldr             x1, [x1, #0x2c8]
    // 0xb3a14c: r2 = Null
    //     0xb3a14c: mov             x2, NULL
    // 0xb3a150: r0 = AllocateClosure()
    //     0xb3a150: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb3a154: mov             x1, x0
    // 0xb3a158: ldur            x0, [fp, #-0x18]
    // 0xb3a15c: r2 = LoadClassIdInstr(r0)
    //     0xb3a15c: ldur            x2, [x0, #-1]
    //     0xb3a160: ubfx            x2, x2, #0xc, #0x14
    // 0xb3a164: r16 = <iWa>
    //     0xb3a164: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2a2d0] TypeArguments: <iWa>
    //     0xb3a168: ldr             x16, [x16, #0x2d0]
    // 0xb3a16c: stp             x0, x16, [SP, #8]
    // 0xb3a170: str             x1, [SP]
    // 0xb3a174: mov             x0, x2
    // 0xb3a178: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb3a178: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb3a17c: r0 = GDT[cid_x0 + 0xd511]()
    //     0xb3a17c: movz            x17, #0xd511
    //     0xb3a180: add             lr, x0, x17
    //     0xb3a184: ldr             lr, [x21, lr, lsl #3]
    //     0xb3a188: blr             lr
    // 0xb3a18c: r1 = LoadClassIdInstr(r0)
    //     0xb3a18c: ldur            x1, [x0, #-1]
    //     0xb3a190: ubfx            x1, x1, #0xc, #0x14
    // 0xb3a194: mov             x16, x0
    // 0xb3a198: mov             x0, x1
    // 0xb3a19c: mov             x1, x16
    // 0xb3a1a0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb3a1a0: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb3a1a4: r0 = GDT[cid_x0 + 0xcc10]()
    //     0xb3a1a4: movz            x17, #0xcc10
    //     0xb3a1a8: add             lr, x0, x17
    //     0xb3a1ac: ldr             lr, [x21, lr, lsl #3]
    //     0xb3a1b0: blr             lr
    // 0xb3a1b4: r0 = ReturnAsyncNotFuture()
    //     0xb3a1b4: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb3a1b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb3a1b8: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb3a1bc: b               #0xb3a100
  }
  [closure] static Future<List<FWa>> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb3bb58, size: 0x100
    // 0xb3bb58: EnterFrame
    //     0xb3bb58: stp             fp, lr, [SP, #-0x10]!
    //     0xb3bb5c: mov             fp, SP
    // 0xb3bb60: AllocStack(0x30)
    //     0xb3bb60: sub             SP, SP, #0x30
    // 0xb3bb64: SetupParameters(dynamic _ /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xb3bb64: stur            NULL, [fp, #-8]
    //     0xb3bb68: movz            x0, #0
    //     0xb3bb6c: add             x1, fp, w0, sxtw #2
    //     0xb3bb70: ldr             x1, [x1, #0x18]
    //     0xb3bb74: add             x2, fp, w0, sxtw #2
    //     0xb3bb78: ldr             x2, [x2, #0x10]
    //     0xb3bb7c: stur            x2, [fp, #-0x18]
    //     0xb3bb80: ldur            w3, [x1, #0x17]
    //     0xb3bb84: add             x3, x3, HEAP, lsl #32
    //     0xb3bb88: stur            x3, [fp, #-0x10]
    // 0xb3bb8c: CheckStackOverflow
    //     0xb3bb8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb3bb90: cmp             SP, x16
    //     0xb3bb94: b.ls            #0xb3bc50
    // 0xb3bb98: InitAsync() -> Future<List<FWa>>
    //     0xb3bb98: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2a3b0] TypeArguments: <List<FWa>>
    //     0xb3bb9c: ldr             x0, [x0, #0x3b0]
    //     0xb3bba0: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb3bba4: ldur            x0, [fp, #-0x10]
    // 0xb3bba8: LoadField: r2 = r0->field_13
    //     0xb3bba8: ldur            w2, [x0, #0x13]
    // 0xb3bbac: DecompressPointer r2
    //     0xb3bbac: add             x2, x2, HEAP, lsl #32
    // 0xb3bbb0: ldur            x1, [fp, #-0x18]
    // 0xb3bbb4: r0 = call 0x432bbc
    //     0xb3bbb4: bl              #0x432bbc
    // 0xb3bbb8: mov             x1, x0
    // 0xb3bbbc: stur            x1, [fp, #-0x18]
    // 0xb3bbc0: r0 = Await()
    //     0xb3bbc0: bl              #0xb0c534  ; AwaitStub
    // 0xb3bbc4: mov             x2, x0
    // 0xb3bbc8: ldur            x0, [fp, #-0x10]
    // 0xb3bbcc: stur            x2, [fp, #-0x18]
    // 0xb3bbd0: LoadField: r1 = r0->field_f
    //     0xb3bbd0: ldur            w1, [x0, #0xf]
    // 0xb3bbd4: DecompressPointer r1
    //     0xb3bbd4: add             x1, x1, HEAP, lsl #32
    // 0xb3bbd8: r0 = call 0x430ba8
    //     0xb3bbd8: bl              #0x430ba8
    // 0xb3bbdc: r1 = Function '<anonymous closure>': static.
    //     0xb3bbdc: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2a530] AnonymousClosure: static (0x432ce4), of [fbn] 
    //     0xb3bbe0: ldr             x1, [x1, #0x530]
    // 0xb3bbe4: r2 = Null
    //     0xb3bbe4: mov             x2, NULL
    // 0xb3bbe8: r0 = AllocateClosure()
    //     0xb3bbe8: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb3bbec: mov             x1, x0
    // 0xb3bbf0: ldur            x0, [fp, #-0x18]
    // 0xb3bbf4: r2 = LoadClassIdInstr(r0)
    //     0xb3bbf4: ldur            x2, [x0, #-1]
    //     0xb3bbf8: ubfx            x2, x2, #0xc, #0x14
    // 0xb3bbfc: r16 = <FWa>
    //     0xb3bbfc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a30] TypeArguments: <FWa>
    //     0xb3bc00: ldr             x16, [x16, #0xa30]
    // 0xb3bc04: stp             x0, x16, [SP, #8]
    // 0xb3bc08: str             x1, [SP]
    // 0xb3bc0c: mov             x0, x2
    // 0xb3bc10: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb3bc10: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb3bc14: r0 = GDT[cid_x0 + 0xd511]()
    //     0xb3bc14: movz            x17, #0xd511
    //     0xb3bc18: add             lr, x0, x17
    //     0xb3bc1c: ldr             lr, [x21, lr, lsl #3]
    //     0xb3bc20: blr             lr
    // 0xb3bc24: r1 = LoadClassIdInstr(r0)
    //     0xb3bc24: ldur            x1, [x0, #-1]
    //     0xb3bc28: ubfx            x1, x1, #0xc, #0x14
    // 0xb3bc2c: mov             x16, x0
    // 0xb3bc30: mov             x0, x1
    // 0xb3bc34: mov             x1, x16
    // 0xb3bc38: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb3bc38: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb3bc3c: r0 = GDT[cid_x0 + 0xcc10]()
    //     0xb3bc3c: movz            x17, #0xcc10
    //     0xb3bc40: add             lr, x0, x17
    //     0xb3bc44: ldr             lr, [x21, lr, lsl #3]
    //     0xb3bc48: blr             lr
    // 0xb3bc4c: r0 = ReturnAsyncNotFuture()
    //     0xb3bc4c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb3bc50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb3bc50: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb3bc54: b               #0xb3bb98
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb47218, size: 0x244
    // 0xb47218: EnterFrame
    //     0xb47218: stp             fp, lr, [SP, #-0x10]!
    //     0xb4721c: mov             fp, SP
    // 0xb47220: AllocStack(0x40)
    //     0xb47220: sub             SP, SP, #0x40
    // 0xb47224: SetupParameters(dynamic _ /* r1 */)
    //     0xb47224: stur            NULL, [fp, #-8]
    //     0xb47228: movz            x0, #0
    //     0xb4722c: add             x1, fp, w0, sxtw #2
    //     0xb47230: ldr             x1, [x1, #0x18]
    //     0xb47234: ldur            w2, [x1, #0x17]
    //     0xb47238: add             x2, x2, HEAP, lsl #32
    //     0xb4723c: stur            x2, [fp, #-0x10]
    // 0xb47240: CheckStackOverflow
    //     0xb47240: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb47244: cmp             SP, x16
    //     0xb47248: b.ls            #0xb47450
    // 0xb4724c: InitAsync() -> Future<int>
    //     0xb4724c: ldr             x0, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    //     0xb47250: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb47254: ldur            x0, [fp, #-0x10]
    // 0xb47258: LoadField: r2 = r0->field_f
    //     0xb47258: ldur            w2, [x0, #0xf]
    // 0xb4725c: DecompressPointer r2
    //     0xb4725c: add             x2, x2, HEAP, lsl #32
    // 0xb47260: mov             x1, x2
    // 0xb47264: stur            x2, [fp, #-0x18]
    // 0xb47268: r0 = call 0x3e0f38
    //     0xb47268: bl              #0x3e0f38
    // 0xb4726c: mov             x1, x0
    // 0xb47270: ldur            x0, [fp, #-0x10]
    // 0xb47274: LoadField: r2 = r0->field_13
    //     0xb47274: ldur            w2, [x0, #0x13]
    // 0xb47278: DecompressPointer r2
    //     0xb47278: add             x2, x2, HEAP, lsl #32
    // 0xb4727c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb4727c: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb47280: r0 = call 0x43fe50
    //     0xb47280: bl              #0x43fe50
    // 0xb47284: mov             x1, x0
    // 0xb47288: stur            x1, [fp, #-0x20]
    // 0xb4728c: r0 = Await()
    //     0xb4728c: bl              #0xb0c534  ; AwaitStub
    // 0xb47290: ldur            x1, [fp, #-0x18]
    // 0xb47294: r0 = call 0x3e0f38
    //     0xb47294: bl              #0x3e0f38
    // 0xb47298: mov             x1, x0
    // 0xb4729c: ldur            x0, [fp, #-0x10]
    // 0xb472a0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb472a0: ldur            w2, [x0, #0x17]
    // 0xb472a4: DecompressPointer r2
    //     0xb472a4: add             x2, x2, HEAP, lsl #32
    // 0xb472a8: LoadField: r3 = r0->field_13
    //     0xb472a8: ldur            w3, [x0, #0x13]
    // 0xb472ac: DecompressPointer r3
    //     0xb472ac: add             x3, x3, HEAP, lsl #32
    // 0xb472b0: LoadField: r4 = r0->field_1b
    //     0xb472b0: ldur            w4, [x0, #0x1b]
    // 0xb472b4: DecompressPointer r4
    //     0xb472b4: add             x4, x4, HEAP, lsl #32
    // 0xb472b8: r5 = LoadInt32Instr(r4)
    //     0xb472b8: sbfx            x5, x4, #1, #0x1f
    //     0xb472bc: tbz             w4, #0, #0xb472c4
    //     0xb472c0: ldur            x5, [x4, #7]
    // 0xb472c4: r0 = __unknown_function__()
    //     0xb472c4: bl              #0xb48bb0  ; [] ::__unknown_function__
    // 0xb472c8: mov             x1, x0
    // 0xb472cc: stur            x1, [fp, #-0x20]
    // 0xb472d0: r0 = Await()
    //     0xb472d0: bl              #0xb0c534  ; AwaitStub
    // 0xb472d4: stur            x0, [fp, #-0x20]
    // 0xb472d8: cmp             w0, NULL
    // 0xb472dc: b.eq            #0xb47458
    // 0xb472e0: r2 = LoadInt32Instr(r0)
    //     0xb472e0: sbfx            x2, x0, #1, #0x1f
    //     0xb472e4: tbz             w0, #0, #0xb472ec
    //     0xb472e8: ldur            x2, [x0, #7]
    // 0xb472ec: stur            x2, [fp, #-0x28]
    // 0xb472f0: cmp             x2, #0
    // 0xb472f4: b.le            #0xb473c8
    // 0xb472f8: ldur            x3, [fp, #-0x10]
    // 0xb472fc: ldur            x1, [fp, #-0x18]
    // 0xb47300: r0 = call 0x3e0f38
    //     0xb47300: bl              #0x3e0f38
    // 0xb47304: mov             x1, x0
    // 0xb47308: ldur            x0, [fp, #-0x10]
    // 0xb4730c: stur            x1, [fp, #-0x38]
    // 0xb47310: LoadField: r2 = r0->field_13
    //     0xb47310: ldur            w2, [x0, #0x13]
    // 0xb47314: DecompressPointer r2
    //     0xb47314: add             x2, x2, HEAP, lsl #32
    // 0xb47318: stur            x2, [fp, #-0x30]
    // 0xb4731c: r0 = InitLateStaticField(0x158c) // [zan] TTa::ZLc
    //     0xb4731c: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb47320: ldr             x0, [x0, #0x2b18]
    //     0xb47324: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb47328: cmp             w0, w16
    //     0xb4732c: b.ne            #0xb4733c
    //     0xb47330: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a68] Field <TTa.ZLc>: static late final (offset: 0x158c)
    //     0xb47334: ldr             x2, [x2, #0xa68]
    //     0xb47338: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb4733c: LoadField: r1 = r0->field_37
    //     0xb4733c: ldur            w1, [x0, #0x37]
    // 0xb47340: DecompressPointer r1
    //     0xb47340: add             x1, x1, HEAP, lsl #32
    // 0xb47344: LoadField: r2 = r1->field_13
    //     0xb47344: ldur            x2, [x1, #0x13]
    // 0xb47348: r0 = BoxInt64Instr(r2)
    //     0xb47348: sbfiz           x0, x2, #1, #0x1f
    //     0xb4734c: cmp             x2, x0, asr #1
    //     0xb47350: b.eq            #0xb4735c
    //     0xb47354: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb47358: stur            x2, [x0, #7]
    // 0xb4735c: r1 = 60
    //     0xb4735c: movz            x1, #0x3c
    // 0xb47360: branchIfSmi(r0, 0xb4736c)
    //     0xb47360: tbz             w0, #0, #0xb4736c
    // 0xb47364: r1 = LoadClassIdInstr(r0)
    //     0xb47364: ldur            x1, [x0, #-1]
    //     0xb47368: ubfx            x1, x1, #0xc, #0x14
    // 0xb4736c: str             x0, [SP]
    // 0xb47370: mov             x0, x1
    // 0xb47374: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb47374: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb47378: r0 = GDT[cid_x0 + 0x2bed]()
    //     0xb47378: movz            x17, #0x2bed
    //     0xb4737c: add             lr, x0, x17
    //     0xb47380: ldr             lr, [x21, lr, lsl #3]
    //     0xb47384: blr             lr
    // 0xb47388: mov             x1, x0
    // 0xb4738c: ldur            x0, [fp, #-0x10]
    // 0xb47390: LoadField: r2 = r0->field_1b
    //     0xb47390: ldur            w2, [x0, #0x1b]
    // 0xb47394: DecompressPointer r2
    //     0xb47394: add             x2, x2, HEAP, lsl #32
    // 0xb47398: r3 = LoadInt32Instr(r2)
    //     0xb47398: sbfx            x3, x2, #1, #0x1f
    //     0xb4739c: tbz             w2, #0, #0xb473a4
    //     0xb473a0: ldur            x3, [x2, #7]
    // 0xb473a4: mov             x5, x1
    // 0xb473a8: ldur            x1, [fp, #-0x38]
    // 0xb473ac: ldur            x2, [fp, #-0x30]
    // 0xb473b0: r0 = __unknown_function__()
    //     0xb473b0: bl              #0xb4745c  ; [] ::__unknown_function__
    // 0xb473b4: mov             x1, x0
    // 0xb473b8: stur            x1, [fp, #-0x30]
    // 0xb473bc: r0 = Await()
    //     0xb473bc: bl              #0xb0c534  ; AwaitStub
    // 0xb473c0: mov             x2, x0
    // 0xb473c4: b               #0xb473cc
    // 0xb473c8: r2 = Null
    //     0xb473c8: mov             x2, NULL
    // 0xb473cc: ldur            x0, [fp, #-0x28]
    // 0xb473d0: ldur            x1, [fp, #-0x18]
    // 0xb473d4: stur            x2, [fp, #-0x10]
    // 0xb473d8: r0 = call 0x430ba8
    //     0xb473d8: bl              #0x430ba8
    // 0xb473dc: ldur            x0, [fp, #-0x28]
    // 0xb473e0: cmp             x0, #0
    // 0xb473e4: b.le            #0xb47448
    // 0xb473e8: ldur            x2, [fp, #-0x10]
    // 0xb473ec: cmp             w2, NULL
    // 0xb473f0: b.eq            #0xb47420
    // 0xb473f4: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb473f4: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb473f8: ldr             x0, [x0, #0x29b8]
    //     0xb473fc: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb47400: cmp             w0, w16
    //     0xb47404: b.ne            #0xb47414
    //     0xb47408: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb4740c: ldr             x2, [x2, #0xa78]
    //     0xb47410: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb47414: mov             x1, x0
    // 0xb47418: ldur            x2, [fp, #-0x10]
    // 0xb4741c: r0 = call 0x442824
    //     0xb4741c: bl              #0x442824
    // 0xb47420: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb47420: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb47424: ldr             x0, [x0, #0x29b8]
    //     0xb47428: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb4742c: cmp             w0, w16
    //     0xb47430: b.ne            #0xb47440
    //     0xb47434: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb47438: ldr             x2, [x2, #0xa78]
    //     0xb4743c: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb47440: mov             x1, x0
    // 0xb47444: r0 = call 0x43f5b8
    //     0xb47444: bl              #0x43f5b8
    // 0xb47448: ldur            x0, [fp, #-0x20]
    // 0xb4744c: r0 = ReturnAsyncNotFuture()
    //     0xb4744c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb47450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb47450: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb47454: b               #0xb4724c
    // 0xb47458: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb47458: bl              #0xc560a8  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<Map<String, int>> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb497bc, size: 0xf8
    // 0xb497bc: EnterFrame
    //     0xb497bc: stp             fp, lr, [SP, #-0x10]!
    //     0xb497c0: mov             fp, SP
    // 0xb497c4: AllocStack(0x20)
    //     0xb497c4: sub             SP, SP, #0x20
    // 0xb497c8: SetupParameters(dynamic _ /* r1 */)
    //     0xb497c8: stur            NULL, [fp, #-8]
    //     0xb497cc: movz            x0, #0
    //     0xb497d0: add             x1, fp, w0, sxtw #2
    //     0xb497d4: ldr             x1, [x1, #0x18]
    //     0xb497d8: ldur            w2, [x1, #0x17]
    //     0xb497dc: add             x2, x2, HEAP, lsl #32
    //     0xb497e0: stur            x2, [fp, #-0x10]
    // 0xb497e4: CheckStackOverflow
    //     0xb497e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb497e8: cmp             SP, x16
    //     0xb497ec: b.ls            #0xb498ac
    // 0xb497f0: InitAsync() -> Future<Map<String, int>>
    //     0xb497f0: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b8a8] TypeArguments: <Map<String, int>>
    //     0xb497f4: ldr             x0, [x0, #0x8a8]
    //     0xb497f8: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb497fc: ldur            x0, [fp, #-0x10]
    // 0xb49800: LoadField: r2 = r0->field_f
    //     0xb49800: ldur            w2, [x0, #0xf]
    // 0xb49804: DecompressPointer r2
    //     0xb49804: add             x2, x2, HEAP, lsl #32
    // 0xb49808: mov             x1, x2
    // 0xb4980c: stur            x2, [fp, #-0x18]
    // 0xb49810: r0 = call 0x3e0f38
    //     0xb49810: bl              #0x3e0f38
    // 0xb49814: mov             x1, x0
    // 0xb49818: ldur            x0, [fp, #-0x10]
    // 0xb4981c: LoadField: r2 = r0->field_13
    //     0xb4981c: ldur            w2, [x0, #0x13]
    // 0xb49820: DecompressPointer r2
    //     0xb49820: add             x2, x2, HEAP, lsl #32
    // 0xb49824: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb49824: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb49828: r0 = call 0x43fe50
    //     0xb49828: bl              #0x43fe50
    // 0xb4982c: mov             x1, x0
    // 0xb49830: stur            x1, [fp, #-0x20]
    // 0xb49834: r0 = Await()
    //     0xb49834: bl              #0xb0c534  ; AwaitStub
    // 0xb49838: ldur            x1, [fp, #-0x18]
    // 0xb4983c: r0 = call 0x3e0f38
    //     0xb4983c: bl              #0x3e0f38
    // 0xb49840: mov             x1, x0
    // 0xb49844: ldur            x0, [fp, #-0x10]
    // 0xb49848: LoadField: r2 = r0->field_1b
    //     0xb49848: ldur            w2, [x0, #0x1b]
    // 0xb4984c: DecompressPointer r2
    //     0xb4984c: add             x2, x2, HEAP, lsl #32
    // 0xb49850: LoadField: r3 = r0->field_13
    //     0xb49850: ldur            w3, [x0, #0x13]
    // 0xb49854: DecompressPointer r3
    //     0xb49854: add             x3, x3, HEAP, lsl #32
    // 0xb49858: LoadField: r4 = r0->field_1f
    //     0xb49858: ldur            w4, [x0, #0x1f]
    // 0xb4985c: DecompressPointer r4
    //     0xb4985c: add             x4, x4, HEAP, lsl #32
    // 0xb49860: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xb49860: ldur            w5, [x0, #0x17]
    // 0xb49864: DecompressPointer r5
    //     0xb49864: add             x5, x5, HEAP, lsl #32
    // 0xb49868: r6 = LoadInt32Instr(r4)
    //     0xb49868: sbfx            x6, x4, #1, #0x1f
    //     0xb4986c: tbz             w4, #0, #0xb49874
    //     0xb49870: ldur            x6, [x4, #7]
    // 0xb49874: r4 = LoadInt32Instr(r5)
    //     0xb49874: sbfx            x4, x5, #1, #0x1f
    //     0xb49878: tbz             w5, #0, #0xb49880
    //     0xb4987c: ldur            x4, [x5, #7]
    // 0xb49880: mov             x5, x6
    // 0xb49884: mov             x6, x4
    // 0xb49888: r0 = __unknown_function__()
    //     0xb49888: bl              #0xb498b4  ; [] ::__unknown_function__
    // 0xb4988c: mov             x1, x0
    // 0xb49890: stur            x1, [fp, #-0x20]
    // 0xb49894: r0 = Await()
    //     0xb49894: bl              #0xb0c534  ; AwaitStub
    // 0xb49898: ldur            x1, [fp, #-0x18]
    // 0xb4989c: stur            x0, [fp, #-0x10]
    // 0xb498a0: r0 = call 0x430ba8
    //     0xb498a0: bl              #0x430ba8
    // 0xb498a4: ldur            x0, [fp, #-0x10]
    // 0xb498a8: r0 = ReturnAsync()
    //     0xb498a8: b               #0xb13694  ; ReturnAsyncStub
    // 0xb498ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb498ac: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb498b0: b               #0xb497f0
  }
  [closure] static Future<Map<String, int>> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb49df8, size: 0x100
    // 0xb49df8: EnterFrame
    //     0xb49df8: stp             fp, lr, [SP, #-0x10]!
    //     0xb49dfc: mov             fp, SP
    // 0xb49e00: AllocStack(0x20)
    //     0xb49e00: sub             SP, SP, #0x20
    // 0xb49e04: SetupParameters(dynamic _ /* r1 */)
    //     0xb49e04: stur            NULL, [fp, #-8]
    //     0xb49e08: movz            x0, #0
    //     0xb49e0c: add             x1, fp, w0, sxtw #2
    //     0xb49e10: ldr             x1, [x1, #0x18]
    //     0xb49e14: ldur            w2, [x1, #0x17]
    //     0xb49e18: add             x2, x2, HEAP, lsl #32
    //     0xb49e1c: stur            x2, [fp, #-0x10]
    // 0xb49e20: CheckStackOverflow
    //     0xb49e20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb49e24: cmp             SP, x16
    //     0xb49e28: b.ls            #0xb49ef0
    // 0xb49e2c: InitAsync() -> Future<Map<String, int>>
    //     0xb49e2c: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b8a8] TypeArguments: <Map<String, int>>
    //     0xb49e30: ldr             x0, [x0, #0x8a8]
    //     0xb49e34: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb49e38: ldur            x0, [fp, #-0x10]
    // 0xb49e3c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb49e3c: ldur            w1, [x0, #0x17]
    // 0xb49e40: DecompressPointer r1
    //     0xb49e40: add             x1, x1, HEAP, lsl #32
    // 0xb49e44: LoadField: r2 = r1->field_b
    //     0xb49e44: ldur            w2, [x1, #0xb]
    // 0xb49e48: cbnz            w2, #0xb49e58
    // 0xb49e4c: r0 = _ConstMap len:0
    //     0xb49e4c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13360] Map<String, int>(0)
    //     0xb49e50: ldr             x0, [x0, #0x360]
    // 0xb49e54: r0 = ReturnAsyncNotFuture()
    //     0xb49e54: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb49e58: LoadField: r2 = r0->field_f
    //     0xb49e58: ldur            w2, [x0, #0xf]
    // 0xb49e5c: DecompressPointer r2
    //     0xb49e5c: add             x2, x2, HEAP, lsl #32
    // 0xb49e60: mov             x1, x2
    // 0xb49e64: stur            x2, [fp, #-0x18]
    // 0xb49e68: r0 = call 0x3e0f38
    //     0xb49e68: bl              #0x3e0f38
    // 0xb49e6c: mov             x1, x0
    // 0xb49e70: ldur            x0, [fp, #-0x10]
    // 0xb49e74: LoadField: r2 = r0->field_1b
    //     0xb49e74: ldur            w2, [x0, #0x1b]
    // 0xb49e78: DecompressPointer r2
    //     0xb49e78: add             x2, x2, HEAP, lsl #32
    // 0xb49e7c: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb49e7c: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb49e80: r0 = call 0x43fe50
    //     0xb49e80: bl              #0x43fe50
    // 0xb49e84: mov             x1, x0
    // 0xb49e88: stur            x1, [fp, #-0x20]
    // 0xb49e8c: r0 = Await()
    //     0xb49e8c: bl              #0xb0c534  ; AwaitStub
    // 0xb49e90: ldur            x1, [fp, #-0x18]
    // 0xb49e94: r0 = call 0x3e0f38
    //     0xb49e94: bl              #0x3e0f38
    // 0xb49e98: mov             x1, x0
    // 0xb49e9c: ldur            x0, [fp, #-0x10]
    // 0xb49ea0: LoadField: r2 = r0->field_1b
    //     0xb49ea0: ldur            w2, [x0, #0x1b]
    // 0xb49ea4: DecompressPointer r2
    //     0xb49ea4: add             x2, x2, HEAP, lsl #32
    // 0xb49ea8: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xb49ea8: ldur            w3, [x0, #0x17]
    // 0xb49eac: DecompressPointer r3
    //     0xb49eac: add             x3, x3, HEAP, lsl #32
    // 0xb49eb0: LoadField: r5 = r0->field_13
    //     0xb49eb0: ldur            w5, [x0, #0x13]
    // 0xb49eb4: DecompressPointer r5
    //     0xb49eb4: add             x5, x5, HEAP, lsl #32
    // 0xb49eb8: LoadField: r4 = r0->field_1f
    //     0xb49eb8: ldur            w4, [x0, #0x1f]
    // 0xb49ebc: DecompressPointer r4
    //     0xb49ebc: add             x4, x4, HEAP, lsl #32
    // 0xb49ec0: r6 = LoadInt32Instr(r4)
    //     0xb49ec0: sbfx            x6, x4, #1, #0x1f
    //     0xb49ec4: tbz             w4, #0, #0xb49ecc
    //     0xb49ec8: ldur            x6, [x4, #7]
    // 0xb49ecc: r0 = __unknown_function__()
    //     0xb49ecc: bl              #0xb49ef8  ; [] ::__unknown_function__
    // 0xb49ed0: mov             x1, x0
    // 0xb49ed4: stur            x1, [fp, #-0x20]
    // 0xb49ed8: r0 = Await()
    //     0xb49ed8: bl              #0xb0c534  ; AwaitStub
    // 0xb49edc: ldur            x1, [fp, #-0x18]
    // 0xb49ee0: stur            x0, [fp, #-0x10]
    // 0xb49ee4: r0 = call 0x430ba8
    //     0xb49ee4: bl              #0x430ba8
    // 0xb49ee8: ldur            x0, [fp, #-0x10]
    // 0xb49eec: r0 = ReturnAsync()
    //     0xb49eec: b               #0xb13694  ; ReturnAsyncStub
    // 0xb49ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb49ef0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb49ef4: b               #0xb49e2c
  }
  [closure] static Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xb4a8e8, size: 0x498
    // 0xb4a8e8: EnterFrame
    //     0xb4a8e8: stp             fp, lr, [SP, #-0x10]!
    //     0xb4a8ec: mov             fp, SP
    // 0xb4a8f0: AllocStack(0x60)
    //     0xb4a8f0: sub             SP, SP, #0x60
    // 0xb4a8f4: SetupParameters(dynamic _ /* r1 */)
    //     0xb4a8f4: stur            NULL, [fp, #-8]
    //     0xb4a8f8: movz            x0, #0
    //     0xb4a8fc: add             x1, fp, w0, sxtw #2
    //     0xb4a900: ldr             x1, [x1, #0x10]
    //     0xb4a904: ldur            w2, [x1, #0x17]
    //     0xb4a908: add             x2, x2, HEAP, lsl #32
    //     0xb4a90c: stur            x2, [fp, #-0x10]
    // 0xb4a910: CheckStackOverflow
    //     0xb4a910: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb4a914: cmp             SP, x16
    //     0xb4a918: b.ls            #0xb4ad78
    // 0xb4a91c: InitAsync() -> Future<Null?>
    //     0xb4a91c: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xb4a920: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb4a924: ldur            x0, [fp, #-0x10]
    // 0xb4a928: LoadField: r3 = r0->field_f
    //     0xb4a928: ldur            w3, [x0, #0xf]
    // 0xb4a92c: DecompressPointer r3
    //     0xb4a92c: add             x3, x3, HEAP, lsl #32
    // 0xb4a930: stur            x3, [fp, #-0x20]
    // 0xb4a934: LoadField: r4 = r0->field_13
    //     0xb4a934: ldur            w4, [x0, #0x13]
    // 0xb4a938: DecompressPointer r4
    //     0xb4a938: add             x4, x4, HEAP, lsl #32
    // 0xb4a93c: mov             x1, x3
    // 0xb4a940: mov             x2, x4
    // 0xb4a944: stur            x4, [fp, #-0x18]
    // 0xb4a948: r0 = __unknown_function__()
    //     0xb4a948: bl              #0xb4a650  ; [] ::__unknown_function__
    // 0xb4a94c: mov             x1, x0
    // 0xb4a950: stur            x1, [fp, #-0x28]
    // 0xb4a954: r0 = Await()
    //     0xb4a954: bl              #0xb0c534  ; AwaitStub
    // 0xb4a958: stur            x0, [fp, #-0x28]
    // 0xb4a95c: cmp             w0, NULL
    // 0xb4a960: b.ne            #0xb4a96c
    // 0xb4a964: r0 = Null
    //     0xb4a964: mov             x0, NULL
    // 0xb4a968: r0 = ReturnAsyncNotFuture()
    //     0xb4a968: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb4a96c: ldur            x3, [fp, #-0x10]
    // 0xb4a970: r4 = true
    //     0xb4a970: add             x4, NULL, #0x20  ; true
    // 0xb4a974: StoreField: r3->field_1f = r4
    //     0xb4a974: stur            w4, [x3, #0x1f]
    // 0xb4a978: ldur            x1, [fp, #-0x18]
    // 0xb4a97c: mov             x2, x0
    // 0xb4a980: r0 = call 0x444194
    //     0xb4a980: bl              #0x444194
    // 0xb4a984: stur            x0, [fp, #-0x30]
    // 0xb4a988: cmp             w0, NULL
    // 0xb4a98c: b.eq            #0xb4a9a4
    // 0xb4a990: ldur            x1, [fp, #-0x20]
    // 0xb4a994: r0 = call 0x3e0f38
    //     0xb4a994: bl              #0x3e0f38
    // 0xb4a998: mov             x1, x0
    // 0xb4a99c: ldur            x2, [fp, #-0x30]
    // 0xb4a9a0: r0 = call 0x444e50
    //     0xb4a9a0: bl              #0x444e50
    // 0xb4a9a4: ldur            x0, [fp, #-0x28]
    // 0xb4a9a8: LoadField: r1 = r0->field_1b
    //     0xb4a9a8: ldur            x1, [x0, #0x1b]
    // 0xb4a9ac: cbz             x1, #0xb4a9b8
    // 0xb4a9b0: r2 = false
    //     0xb4a9b0: add             x2, NULL, #0x30  ; false
    // 0xb4a9b4: b               #0xb4a9bc
    // 0xb4a9b8: r2 = true
    //     0xb4a9b8: add             x2, NULL, #0x20  ; true
    // 0xb4a9bc: stur            x2, [fp, #-0x48]
    // 0xb4a9c0: LoadField: r3 = r0->field_3b
    //     0xb4a9c0: ldur            x3, [x0, #0x3b]
    // 0xb4a9c4: stur            x3, [fp, #-0x40]
    // 0xb4a9c8: LoadField: r1 = r0->field_33
    //     0xb4a9c8: ldur            x1, [x0, #0x33]
    // 0xb4a9cc: cmp             x3, x1
    // 0xb4a9d0: b.le            #0xb4a9dc
    // 0xb4a9d4: mov             x5, x3
    // 0xb4a9d8: b               #0xb4a9e0
    // 0xb4a9dc: mov             x5, x1
    // 0xb4a9e0: stur            x5, [fp, #-0x38]
    // 0xb4a9e4: tbnz            w2, #4, #0xb4aad4
    // 0xb4a9e8: ldur            x4, [fp, #-0x30]
    // 0xb4a9ec: cmp             w4, NULL
    // 0xb4a9f0: b.eq            #0xb4aacc
    // 0xb4a9f4: cmp             x5, x3
    // 0xb4a9f8: b.le            #0xb4aac4
    // 0xb4a9fc: ldur            x6, [fp, #-0x10]
    // 0xb4aa00: ldur            x1, [fp, #-0x20]
    // 0xb4aa04: r0 = call 0x3e0f38
    //     0xb4aa04: bl              #0x3e0f38
    // 0xb4aa08: stur            x0, [fp, #-0x50]
    // 0xb4aa0c: r0 = InitLateStaticField(0x158c) // [zan] TTa::ZLc
    //     0xb4aa0c: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb4aa10: ldr             x0, [x0, #0x2b18]
    //     0xb4aa14: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb4aa18: cmp             w0, w16
    //     0xb4aa1c: b.ne            #0xb4aa2c
    //     0xb4aa20: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a68] Field <TTa.ZLc>: static late final (offset: 0x158c)
    //     0xb4aa24: ldr             x2, [x2, #0xa68]
    //     0xb4aa28: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb4aa2c: LoadField: r1 = r0->field_37
    //     0xb4aa2c: ldur            w1, [x0, #0x37]
    // 0xb4aa30: DecompressPointer r1
    //     0xb4aa30: add             x1, x1, HEAP, lsl #32
    // 0xb4aa34: LoadField: r2 = r1->field_13
    //     0xb4aa34: ldur            x2, [x1, #0x13]
    // 0xb4aa38: r0 = BoxInt64Instr(r2)
    //     0xb4aa38: sbfiz           x0, x2, #1, #0x1f
    //     0xb4aa3c: cmp             x2, x0, asr #1
    //     0xb4aa40: b.eq            #0xb4aa4c
    //     0xb4aa44: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb4aa48: stur            x2, [x0, #7]
    // 0xb4aa4c: r1 = 60
    //     0xb4aa4c: movz            x1, #0x3c
    // 0xb4aa50: branchIfSmi(r0, 0xb4aa5c)
    //     0xb4aa50: tbz             w0, #0, #0xb4aa5c
    // 0xb4aa54: r1 = LoadClassIdInstr(r0)
    //     0xb4aa54: ldur            x1, [x0, #-1]
    //     0xb4aa58: ubfx            x1, x1, #0xc, #0x14
    // 0xb4aa5c: str             x0, [SP]
    // 0xb4aa60: mov             x0, x1
    // 0xb4aa64: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb4aa64: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb4aa68: r0 = GDT[cid_x0 + 0x2bed]()
    //     0xb4aa68: movz            x17, #0x2bed
    //     0xb4aa6c: add             lr, x0, x17
    //     0xb4aa70: ldr             lr, [x21, lr, lsl #3]
    //     0xb4aa74: blr             lr
    // 0xb4aa78: ldur            x1, [fp, #-0x50]
    // 0xb4aa7c: ldur            x2, [fp, #-0x30]
    // 0xb4aa80: ldur            x3, [fp, #-0x40]
    // 0xb4aa84: ldur            x5, [fp, #-0x38]
    // 0xb4aa88: mov             x6, x0
    // 0xb4aa8c: r0 = __unknown_function__()
    //     0xb4aa8c: bl              #0xb4b6d4  ; [] ::__unknown_function__
    // 0xb4aa90: mov             x1, x0
    // 0xb4aa94: stur            x1, [fp, #-0x50]
    // 0xb4aa98: r0 = Await()
    //     0xb4aa98: bl              #0xb0c534  ; AwaitStub
    // 0xb4aa9c: ldur            x2, [fp, #-0x10]
    // 0xb4aaa0: StoreField: r2->field_1b = r0
    //     0xb4aaa0: stur            w0, [x2, #0x1b]
    //     0xb4aaa4: tbz             w0, #0, #0xb4aac0
    //     0xb4aaa8: ldurb           w16, [x2, #-1]
    //     0xb4aaac: ldurb           w17, [x0, #-1]
    //     0xb4aab0: and             x16, x17, x16, lsr #2
    //     0xb4aab4: tst             x16, HEAP, lsr #32
    //     0xb4aab8: b.eq            #0xb4aac0
    //     0xb4aabc: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xb4aac0: b               #0xb4aad8
    // 0xb4aac4: ldur            x2, [fp, #-0x10]
    // 0xb4aac8: b               #0xb4aad8
    // 0xb4aacc: ldur            x2, [fp, #-0x10]
    // 0xb4aad0: b               #0xb4aad8
    // 0xb4aad4: ldur            x2, [fp, #-0x10]
    // 0xb4aad8: ldur            x0, [fp, #-0x48]
    // 0xb4aadc: tbnz            w0, #4, #0xb4ab30
    // 0xb4aae0: ldur            x3, [fp, #-0x28]
    // 0xb4aae4: LoadField: r0 = r3->field_4f
    //     0xb4aae4: ldur            x0, [x3, #0x4f]
    // 0xb4aae8: LoadField: r1 = r2->field_1b
    //     0xb4aae8: ldur            w1, [x2, #0x1b]
    // 0xb4aaec: DecompressPointer r1
    //     0xb4aaec: add             x1, x1, HEAP, lsl #32
    // 0xb4aaf0: r4 = LoadInt32Instr(r1)
    //     0xb4aaf0: sbfx            x4, x1, #1, #0x1f
    //     0xb4aaf4: tbz             w1, #0, #0xb4aafc
    //     0xb4aaf8: ldur            x4, [x1, #7]
    // 0xb4aafc: sub             x1, x0, x4
    // 0xb4ab00: tbz             x1, #0x3f, #0xb4ab0c
    // 0xb4ab04: r4 = 0
    //     0xb4ab04: movz            x4, #0
    // 0xb4ab08: b               #0xb4ab10
    // 0xb4ab0c: mov             x4, x1
    // 0xb4ab10: r0 = BoxInt64Instr(r4)
    //     0xb4ab10: sbfiz           x0, x4, #1, #0x1f
    //     0xb4ab14: cmp             x4, x0, asr #1
    //     0xb4ab18: b.eq            #0xb4ab24
    //     0xb4ab1c: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb4ab20: stur            x4, [x0, #7]
    // 0xb4ab24: mov             x2, x3
    // 0xb4ab28: mov             x3, x0
    // 0xb4ab2c: b               #0xb4abfc
    // 0xb4ab30: ldur            x3, [fp, #-0x28]
    // 0xb4ab34: ldur            x0, [fp, #-0x30]
    // 0xb4ab38: cmp             w0, NULL
    // 0xb4ab3c: b.ne            #0xb4ab5c
    // 0xb4ab40: LoadField: r4 = r3->field_4f
    //     0xb4ab40: ldur            x4, [x3, #0x4f]
    // 0xb4ab44: r0 = BoxInt64Instr(r4)
    //     0xb4ab44: sbfiz           x0, x4, #1, #0x1f
    //     0xb4ab48: cmp             x4, x0, asr #1
    //     0xb4ab4c: b.eq            #0xb4ab58
    //     0xb4ab50: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb4ab54: stur            x4, [x0, #7]
    // 0xb4ab58: b               #0xb4abf4
    // 0xb4ab5c: ldur            x1, [fp, #-0x20]
    // 0xb4ab60: r0 = call 0x3e0f38
    //     0xb4ab60: bl              #0x3e0f38
    // 0xb4ab64: stur            x0, [fp, #-0x48]
    // 0xb4ab68: r0 = InitLateStaticField(0x158c) // [zan] TTa::ZLc
    //     0xb4ab68: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb4ab6c: ldr             x0, [x0, #0x2b18]
    //     0xb4ab70: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb4ab74: cmp             w0, w16
    //     0xb4ab78: b.ne            #0xb4ab88
    //     0xb4ab7c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a68] Field <TTa.ZLc>: static late final (offset: 0x158c)
    //     0xb4ab80: ldr             x2, [x2, #0xa68]
    //     0xb4ab84: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb4ab88: LoadField: r1 = r0->field_37
    //     0xb4ab88: ldur            w1, [x0, #0x37]
    // 0xb4ab8c: DecompressPointer r1
    //     0xb4ab8c: add             x1, x1, HEAP, lsl #32
    // 0xb4ab90: LoadField: r2 = r1->field_13
    //     0xb4ab90: ldur            x2, [x1, #0x13]
    // 0xb4ab94: r0 = BoxInt64Instr(r2)
    //     0xb4ab94: sbfiz           x0, x2, #1, #0x1f
    //     0xb4ab98: cmp             x2, x0, asr #1
    //     0xb4ab9c: b.eq            #0xb4aba8
    //     0xb4aba0: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb4aba4: stur            x2, [x0, #7]
    // 0xb4aba8: r1 = 60
    //     0xb4aba8: movz            x1, #0x3c
    // 0xb4abac: branchIfSmi(r0, 0xb4abb8)
    //     0xb4abac: tbz             w0, #0, #0xb4abb8
    // 0xb4abb0: r1 = LoadClassIdInstr(r0)
    //     0xb4abb0: ldur            x1, [x0, #-1]
    //     0xb4abb4: ubfx            x1, x1, #0xc, #0x14
    // 0xb4abb8: str             x0, [SP]
    // 0xb4abbc: mov             x0, x1
    // 0xb4abc0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb4abc0: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb4abc4: r0 = GDT[cid_x0 + 0x2bed]()
    //     0xb4abc4: movz            x17, #0x2bed
    //     0xb4abc8: add             lr, x0, x17
    //     0xb4abcc: ldr             lr, [x21, lr, lsl #3]
    //     0xb4abd0: blr             lr
    // 0xb4abd4: ldur            x1, [fp, #-0x48]
    // 0xb4abd8: ldur            x2, [fp, #-0x30]
    // 0xb4abdc: ldur            x3, [fp, #-0x38]
    // 0xb4abe0: mov             x5, x0
    // 0xb4abe4: r0 = __unknown_function__()
    //     0xb4abe4: bl              #0xb4b3c8  ; [] ::__unknown_function__
    // 0xb4abe8: mov             x1, x0
    // 0xb4abec: stur            x1, [fp, #-0x30]
    // 0xb4abf0: r0 = Await()
    //     0xb4abf0: bl              #0xb0c534  ; AwaitStub
    // 0xb4abf4: mov             x3, x0
    // 0xb4abf8: ldur            x2, [fp, #-0x28]
    // 0xb4abfc: stur            x3, [fp, #-0x30]
    // 0xb4ac00: LoadField: r4 = r2->field_4f
    //     0xb4ac00: ldur            x4, [x2, #0x4f]
    // 0xb4ac04: r0 = BoxInt64Instr(r4)
    //     0xb4ac04: sbfiz           x0, x4, #1, #0x1f
    //     0xb4ac08: cmp             x4, x0, asr #1
    //     0xb4ac0c: b.eq            #0xb4ac18
    //     0xb4ac10: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb4ac14: stur            x4, [x0, #7]
    // 0xb4ac18: stp             x3, x0, [SP]
    // 0xb4ac1c: r0 = call 0xa08768
    //     0xb4ac1c: bl              #0xa08768
    // 0xb4ac20: tbz             w0, #4, #0xb4ac2c
    // 0xb4ac24: ldur            x2, [fp, #-0x38]
    // 0xb4ac28: b               #0xb4ac40
    // 0xb4ac2c: ldur            x0, [fp, #-0x28]
    // 0xb4ac30: ldur            x2, [fp, #-0x38]
    // 0xb4ac34: LoadField: r1 = r0->field_3b
    //     0xb4ac34: ldur            x1, [x0, #0x3b]
    // 0xb4ac38: cmp             x1, x2
    // 0xb4ac3c: b.eq            #0xb4ad70
    // 0xb4ac40: ldur            x3, [fp, #-0x10]
    // 0xb4ac44: ldur            x0, [fp, #-0x30]
    // 0xb4ac48: ldur            x1, [fp, #-0x20]
    // 0xb4ac4c: r0 = call 0x3e0f38
    //     0xb4ac4c: bl              #0x3e0f38
    // 0xb4ac50: r1 = <int?>
    //     0xb4ac50: ldr             x1, [PP, #0x18c8]  ; [pp+0x18c8] TypeArguments: <int?>
    // 0xb4ac54: stur            x0, [fp, #-0x20]
    // 0xb4ac58: r0 = GH()
    //     0xb4ac58: bl              #0xb38c00  ; AllocateGHStub -> GH<X0> (size=0x14)
    // 0xb4ac5c: mov             x2, x0
    // 0xb4ac60: ldur            x0, [fp, #-0x30]
    // 0xb4ac64: stur            x2, [fp, #-0x48]
    // 0xb4ac68: StoreField: r2->field_f = r0
    //     0xb4ac68: stur            w0, [x2, #0xf]
    // 0xb4ac6c: r3 = true
    //     0xb4ac6c: add             x3, NULL, #0x20  ; true
    // 0xb4ac70: StoreField: r2->field_b = r3
    //     0xb4ac70: stur            w3, [x2, #0xb]
    // 0xb4ac74: ldur            x4, [fp, #-0x38]
    // 0xb4ac78: r0 = BoxInt64Instr(r4)
    //     0xb4ac78: sbfiz           x0, x4, #1, #0x1f
    //     0xb4ac7c: cmp             x4, x0, asr #1
    //     0xb4ac80: b.eq            #0xb4ac8c
    //     0xb4ac84: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb4ac88: stur            x4, [x0, #7]
    // 0xb4ac8c: r1 = <int?>
    //     0xb4ac8c: ldr             x1, [PP, #0x18c8]  ; [pp+0x18c8] TypeArguments: <int?>
    // 0xb4ac90: stur            x0, [fp, #-0x28]
    // 0xb4ac94: r0 = GH()
    //     0xb4ac94: bl              #0xb38c00  ; AllocateGHStub -> GH<X0> (size=0x14)
    // 0xb4ac98: mov             x2, x0
    // 0xb4ac9c: ldur            x0, [fp, #-0x28]
    // 0xb4aca0: stur            x2, [fp, #-0x30]
    // 0xb4aca4: StoreField: r2->field_f = r0
    //     0xb4aca4: stur            w0, [x2, #0xf]
    // 0xb4aca8: r0 = true
    //     0xb4aca8: add             x0, NULL, #0x20  ; true
    // 0xb4acac: StoreField: r2->field_b = r0
    //     0xb4acac: stur            w0, [x2, #0xb]
    // 0xb4acb0: r1 = <PVa>
    //     0xb4acb0: add             x1, PP, #0x2b, lsl #12  ; [pp+0x2b918] TypeArguments: <PVa>
    //     0xb4acb4: ldr             x1, [x1, #0x918]
    // 0xb4acb8: r0 = QVa()
    //     0xb4acb8: bl              #0xb4b3bc  ; AllocateQVaStub -> QVa (size=0x54)
    // 0xb4acbc: mov             x1, x0
    // 0xb4acc0: r0 = Instance_GH
    //     0xb4acc0: add             x0, PP, #0x29, lsl #12  ; [pp+0x293b0] Obj!GH<String?>@675341
    //     0xb4acc4: ldr             x0, [x0, #0x3b0]
    // 0xb4acc8: StoreField: r1->field_b = r0
    //     0xb4acc8: stur            w0, [x1, #0xb]
    // 0xb4accc: StoreField: r1->field_f = r0
    //     0xb4accc: stur            w0, [x1, #0xf]
    // 0xb4acd0: r2 = Instance_GH
    //     0xb4acd0: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2a4d0] Obj!GH<int?>@675381
    //     0xb4acd4: ldr             x2, [x2, #0x4d0]
    // 0xb4acd8: StoreField: r1->field_13 = r2
    //     0xb4acd8: stur            w2, [x1, #0x13]
    // 0xb4acdc: ArrayStore: r1[0] = r0  ; List_4
    //     0xb4acdc: stur            w0, [x1, #0x17]
    // 0xb4ace0: StoreField: r1->field_1b = r2
    //     0xb4ace0: stur            w2, [x1, #0x1b]
    // 0xb4ace4: ldur            x3, [fp, #-0x48]
    // 0xb4ace8: StoreField: r1->field_1f = r3
    //     0xb4ace8: stur            w3, [x1, #0x1f]
    // 0xb4acec: StoreField: r1->field_23 = r2
    //     0xb4acec: stur            w2, [x1, #0x23]
    // 0xb4acf0: StoreField: r1->field_27 = r0
    //     0xb4acf0: stur            w0, [x1, #0x27]
    // 0xb4acf4: StoreField: r1->field_2b = r0
    //     0xb4acf4: stur            w0, [x1, #0x2b]
    // 0xb4acf8: StoreField: r1->field_2f = r2
    //     0xb4acf8: stur            w2, [x1, #0x2f]
    // 0xb4acfc: StoreField: r1->field_33 = r2
    //     0xb4acfc: stur            w2, [x1, #0x33]
    // 0xb4ad00: StoreField: r1->field_37 = r2
    //     0xb4ad00: stur            w2, [x1, #0x37]
    // 0xb4ad04: ldur            x3, [fp, #-0x30]
    // 0xb4ad08: StoreField: r1->field_3b = r3
    //     0xb4ad08: stur            w3, [x1, #0x3b]
    // 0xb4ad0c: StoreField: r1->field_3f = r2
    //     0xb4ad0c: stur            w2, [x1, #0x3f]
    // 0xb4ad10: StoreField: r1->field_43 = r0
    //     0xb4ad10: stur            w0, [x1, #0x43]
    // 0xb4ad14: r0 = Instance_GH
    //     0xb4ad14: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b920] Obj!GH<int>@6753c1
    //     0xb4ad18: ldr             x0, [x0, #0x920]
    // 0xb4ad1c: StoreField: r1->field_47 = r0
    //     0xb4ad1c: stur            w0, [x1, #0x47]
    // 0xb4ad20: r2 = Instance_GH
    //     0xb4ad20: add             x2, PP, #0x2b, lsl #12  ; [pp+0x2b928] Obj!GH<String>@6753a1
    //     0xb4ad24: ldr             x2, [x2, #0x928]
    // 0xb4ad28: StoreField: r1->field_4b = r2
    //     0xb4ad28: stur            w2, [x1, #0x4b]
    // 0xb4ad2c: StoreField: r1->field_4f = r0
    //     0xb4ad2c: stur            w0, [x1, #0x4f]
    // 0xb4ad30: mov             x3, x1
    // 0xb4ad34: ldur            x1, [fp, #-0x20]
    // 0xb4ad38: ldur            x2, [fp, #-0x18]
    // 0xb4ad3c: r0 = __unknown_function__()
    //     0xb4ad3c: bl              #0xb4ad80  ; [] ::__unknown_function__
    // 0xb4ad40: mov             x1, x0
    // 0xb4ad44: stur            x1, [fp, #-0x18]
    // 0xb4ad48: r0 = Await()
    //     0xb4ad48: bl              #0xb0c534  ; AwaitStub
    // 0xb4ad4c: ldur            x1, [fp, #-0x10]
    // 0xb4ad50: ArrayStore: r1[0] = r0  ; List_4
    //     0xb4ad50: stur            w0, [x1, #0x17]
    //     0xb4ad54: tbz             w0, #0, #0xb4ad70
    //     0xb4ad58: ldurb           w16, [x1, #-1]
    //     0xb4ad5c: ldurb           w17, [x0, #-1]
    //     0xb4ad60: and             x16, x17, x16, lsr #2
    //     0xb4ad64: tst             x16, HEAP, lsr #32
    //     0xb4ad68: b.eq            #0xb4ad70
    //     0xb4ad6c: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xb4ad70: r0 = Null
    //     0xb4ad70: mov             x0, NULL
    // 0xb4ad74: r0 = ReturnAsyncNotFuture()
    //     0xb4ad74: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb4ad78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4ad78: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4ad7c: b               #0xb4a91c
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb4ba60, size: 0x1fc
    // 0xb4ba60: EnterFrame
    //     0xb4ba60: stp             fp, lr, [SP, #-0x10]!
    //     0xb4ba64: mov             fp, SP
    // 0xb4ba68: AllocStack(0x30)
    //     0xb4ba68: sub             SP, SP, #0x30
    // 0xb4ba6c: SetupParameters(dynamic _ /* r0 */)
    //     0xb4ba6c: stur            NULL, [fp, #-8]
    //     0xb4ba70: movz            x1, #0
    //     0xb4ba74: add             x0, fp, w1, sxtw #2
    //     0xb4ba78: ldr             x0, [x0, #0x18]
    //     0xb4ba7c: ldur            w2, [x0, #0x17]
    //     0xb4ba80: add             x2, x2, HEAP, lsl #32
    //     0xb4ba84: stur            x2, [fp, #-0x10]
    // 0xb4ba88: CheckStackOverflow
    //     0xb4ba88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb4ba8c: cmp             SP, x16
    //     0xb4ba90: b.ls            #0xb4bc50
    // 0xb4ba94: InitAsync() -> Future<int>
    //     0xb4ba94: ldr             x0, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    //     0xb4ba98: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb4ba9c: ldur            x0, [fp, #-0x10]
    // 0xb4baa0: LoadField: r1 = r0->field_1b
    //     0xb4baa0: ldur            w1, [x0, #0x1b]
    // 0xb4baa4: DecompressPointer r1
    //     0xb4baa4: add             x1, x1, HEAP, lsl #32
    // 0xb4baa8: r2 = LoadInt32Instr(r1)
    //     0xb4baa8: sbfx            x2, x1, #1, #0x1f
    //     0xb4baac: tbz             w1, #0, #0xb4bab4
    //     0xb4bab0: ldur            x2, [x1, #7]
    // 0xb4bab4: cmp             x2, #0
    // 0xb4bab8: b.gt            #0xb4bac4
    // 0xb4babc: r0 = 0
    //     0xb4babc: movz            x0, #0
    // 0xb4bac0: r0 = ReturnAsyncNotFuture()
    //     0xb4bac0: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb4bac4: LoadField: r2 = r0->field_f
    //     0xb4bac4: ldur            w2, [x0, #0xf]
    // 0xb4bac8: DecompressPointer r2
    //     0xb4bac8: add             x2, x2, HEAP, lsl #32
    // 0xb4bacc: mov             x1, x2
    // 0xb4bad0: stur            x2, [fp, #-0x18]
    // 0xb4bad4: r0 = call 0x3e0f38
    //     0xb4bad4: bl              #0x3e0f38
    // 0xb4bad8: mov             x1, x0
    // 0xb4badc: ldur            x0, [fp, #-0x10]
    // 0xb4bae0: LoadField: r2 = r0->field_13
    //     0xb4bae0: ldur            w2, [x0, #0x13]
    // 0xb4bae4: DecompressPointer r2
    //     0xb4bae4: add             x2, x2, HEAP, lsl #32
    // 0xb4bae8: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb4bae8: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb4baec: r0 = call 0x43fe50
    //     0xb4baec: bl              #0x43fe50
    // 0xb4baf0: mov             x1, x0
    // 0xb4baf4: stur            x1, [fp, #-0x20]
    // 0xb4baf8: r0 = Await()
    //     0xb4baf8: bl              #0xb0c534  ; AwaitStub
    // 0xb4bafc: ldur            x1, [fp, #-0x18]
    // 0xb4bb00: r0 = call 0x3e0f38
    //     0xb4bb00: bl              #0x3e0f38
    // 0xb4bb04: mov             x1, x0
    // 0xb4bb08: ldur            x0, [fp, #-0x10]
    // 0xb4bb0c: LoadField: r2 = r0->field_13
    //     0xb4bb0c: ldur            w2, [x0, #0x13]
    // 0xb4bb10: DecompressPointer r2
    //     0xb4bb10: add             x2, x2, HEAP, lsl #32
    // 0xb4bb14: LoadField: r3 = r0->field_1b
    //     0xb4bb14: ldur            w3, [x0, #0x1b]
    // 0xb4bb18: DecompressPointer r3
    //     0xb4bb18: add             x3, x3, HEAP, lsl #32
    // 0xb4bb1c: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xb4bb1c: ldur            w4, [x0, #0x17]
    // 0xb4bb20: DecompressPointer r4
    //     0xb4bb20: add             x4, x4, HEAP, lsl #32
    // 0xb4bb24: r5 = LoadInt32Instr(r3)
    //     0xb4bb24: sbfx            x5, x3, #1, #0x1f
    //     0xb4bb28: tbz             w3, #0, #0xb4bb30
    //     0xb4bb2c: ldur            x5, [x3, #7]
    // 0xb4bb30: r3 = LoadInt32Instr(r4)
    //     0xb4bb30: sbfx            x3, x4, #1, #0x1f
    //     0xb4bb34: tbz             w4, #0, #0xb4bb3c
    //     0xb4bb38: ldur            x3, [x4, #7]
    // 0xb4bb3c: mov             x16, x3
    // 0xb4bb40: mov             x3, x5
    // 0xb4bb44: mov             x5, x16
    // 0xb4bb48: r0 = __unknown_function__()
    //     0xb4bb48: bl              #0xb4bc5c  ; [] ::__unknown_function__
    // 0xb4bb4c: mov             x1, x0
    // 0xb4bb50: stur            x1, [fp, #-0x20]
    // 0xb4bb54: r0 = Await()
    //     0xb4bb54: bl              #0xb0c534  ; AwaitStub
    // 0xb4bb58: stur            x0, [fp, #-0x20]
    // 0xb4bb5c: cmp             w0, NULL
    // 0xb4bb60: b.eq            #0xb4bc58
    // 0xb4bb64: r2 = LoadInt32Instr(r0)
    //     0xb4bb64: sbfx            x2, x0, #1, #0x1f
    //     0xb4bb68: tbz             w0, #0, #0xb4bb70
    //     0xb4bb6c: ldur            x2, [x0, #7]
    // 0xb4bb70: stur            x2, [fp, #-0x28]
    // 0xb4bb74: cmp             x2, #0
    // 0xb4bb78: b.le            #0xb4bbc8
    // 0xb4bb7c: ldur            x3, [fp, #-0x10]
    // 0xb4bb80: ldur            x1, [fp, #-0x18]
    // 0xb4bb84: r0 = call 0x3e0f38
    //     0xb4bb84: bl              #0x3e0f38
    // 0xb4bb88: mov             x1, x0
    // 0xb4bb8c: ldur            x0, [fp, #-0x10]
    // 0xb4bb90: LoadField: r5 = r0->field_13
    //     0xb4bb90: ldur            w5, [x0, #0x13]
    // 0xb4bb94: DecompressPointer r5
    //     0xb4bb94: add             x5, x5, HEAP, lsl #32
    // 0xb4bb98: LoadField: r2 = r0->field_1b
    //     0xb4bb98: ldur            w2, [x0, #0x1b]
    // 0xb4bb9c: DecompressPointer r2
    //     0xb4bb9c: add             x2, x2, HEAP, lsl #32
    // 0xb4bba0: r3 = LoadInt32Instr(r2)
    //     0xb4bba0: sbfx            x3, x2, #1, #0x1f
    //     0xb4bba4: tbz             w2, #0, #0xb4bbac
    //     0xb4bba8: ldur            x3, [x2, #7]
    // 0xb4bbac: mov             x2, x5
    // 0xb4bbb0: r0 = __unknown_function__()
    //     0xb4bbb0: bl              #0xb4745c  ; [] ::__unknown_function__
    // 0xb4bbb4: mov             x1, x0
    // 0xb4bbb8: stur            x1, [fp, #-0x30]
    // 0xb4bbbc: r0 = Await()
    //     0xb4bbbc: bl              #0xb0c534  ; AwaitStub
    // 0xb4bbc0: mov             x2, x0
    // 0xb4bbc4: b               #0xb4bbcc
    // 0xb4bbc8: r2 = Null
    //     0xb4bbc8: mov             x2, NULL
    // 0xb4bbcc: ldur            x0, [fp, #-0x28]
    // 0xb4bbd0: ldur            x1, [fp, #-0x18]
    // 0xb4bbd4: stur            x2, [fp, #-0x10]
    // 0xb4bbd8: r0 = call 0x430ba8
    //     0xb4bbd8: bl              #0x430ba8
    // 0xb4bbdc: ldur            x0, [fp, #-0x28]
    // 0xb4bbe0: cmp             x0, #0
    // 0xb4bbe4: b.le            #0xb4bc48
    // 0xb4bbe8: ldur            x2, [fp, #-0x10]
    // 0xb4bbec: cmp             w2, NULL
    // 0xb4bbf0: b.eq            #0xb4bc20
    // 0xb4bbf4: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb4bbf4: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb4bbf8: ldr             x0, [x0, #0x29b8]
    //     0xb4bbfc: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb4bc00: cmp             w0, w16
    //     0xb4bc04: b.ne            #0xb4bc14
    //     0xb4bc08: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb4bc0c: ldr             x2, [x2, #0xa78]
    //     0xb4bc10: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb4bc14: mov             x1, x0
    // 0xb4bc18: ldur            x2, [fp, #-0x10]
    // 0xb4bc1c: r0 = call 0x442824
    //     0xb4bc1c: bl              #0x442824
    // 0xb4bc20: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb4bc20: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb4bc24: ldr             x0, [x0, #0x29b8]
    //     0xb4bc28: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb4bc2c: cmp             w0, w16
    //     0xb4bc30: b.ne            #0xb4bc40
    //     0xb4bc34: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb4bc38: ldr             x2, [x2, #0xa78]
    //     0xb4bc3c: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb4bc40: mov             x1, x0
    // 0xb4bc44: r0 = call 0x43f5b8
    //     0xb4bc44: bl              #0x43f5b8
    // 0xb4bc48: ldur            x0, [fp, #-0x20]
    // 0xb4bc4c: r0 = ReturnAsyncNotFuture()
    //     0xb4bc4c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb4bc50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4bc50: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4bc54: b               #0xb4ba94
    // 0xb4bc58: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb4bc58: bl              #0xc560a8  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb4c2fc, size: 0xf8
    // 0xb4c2fc: EnterFrame
    //     0xb4c2fc: stp             fp, lr, [SP, #-0x10]!
    //     0xb4c300: mov             fp, SP
    // 0xb4c304: AllocStack(0x20)
    //     0xb4c304: sub             SP, SP, #0x20
    // 0xb4c308: SetupParameters(dynamic _ /* r0 */)
    //     0xb4c308: stur            NULL, [fp, #-8]
    //     0xb4c30c: movz            x1, #0
    //     0xb4c310: add             x0, fp, w1, sxtw #2
    //     0xb4c314: ldr             x0, [x0, #0x18]
    //     0xb4c318: ldur            w2, [x0, #0x17]
    //     0xb4c31c: add             x2, x2, HEAP, lsl #32
    //     0xb4c320: stur            x2, [fp, #-0x10]
    // 0xb4c324: CheckStackOverflow
    //     0xb4c324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb4c328: cmp             SP, x16
    //     0xb4c32c: b.ls            #0xb4c3ec
    // 0xb4c330: InitAsync() -> Future<int>
    //     0xb4c330: ldr             x0, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    //     0xb4c334: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb4c338: ldur            x0, [fp, #-0x10]
    // 0xb4c33c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb4c33c: ldur            w1, [x0, #0x17]
    // 0xb4c340: DecompressPointer r1
    //     0xb4c340: add             x1, x1, HEAP, lsl #32
    // 0xb4c344: LoadField: r2 = r1->field_b
    //     0xb4c344: ldur            w2, [x1, #0xb]
    // 0xb4c348: cbnz            w2, #0xb4c354
    // 0xb4c34c: r0 = 0
    //     0xb4c34c: movz            x0, #0
    // 0xb4c350: r0 = ReturnAsyncNotFuture()
    //     0xb4c350: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb4c354: LoadField: r2 = r0->field_f
    //     0xb4c354: ldur            w2, [x0, #0xf]
    // 0xb4c358: DecompressPointer r2
    //     0xb4c358: add             x2, x2, HEAP, lsl #32
    // 0xb4c35c: mov             x1, x2
    // 0xb4c360: stur            x2, [fp, #-0x18]
    // 0xb4c364: r0 = call 0x3e0f38
    //     0xb4c364: bl              #0x3e0f38
    // 0xb4c368: mov             x1, x0
    // 0xb4c36c: ldur            x0, [fp, #-0x10]
    // 0xb4c370: LoadField: r2 = r0->field_1b
    //     0xb4c370: ldur            w2, [x0, #0x1b]
    // 0xb4c374: DecompressPointer r2
    //     0xb4c374: add             x2, x2, HEAP, lsl #32
    // 0xb4c378: r4 = const [0, 0x2, 0, 0x2, null]
    //     0xb4c378: ldr             x4, [PP, #0xe0]  ; [pp+0xe0] List(5) [0, 0x2, 0, 0x2, Null]
    // 0xb4c37c: r0 = call 0x43fe50
    //     0xb4c37c: bl              #0x43fe50
    // 0xb4c380: mov             x1, x0
    // 0xb4c384: stur            x1, [fp, #-0x20]
    // 0xb4c388: r0 = Await()
    //     0xb4c388: bl              #0xb0c534  ; AwaitStub
    // 0xb4c38c: ldur            x1, [fp, #-0x18]
    // 0xb4c390: r0 = call 0x3e0f38
    //     0xb4c390: bl              #0x3e0f38
    // 0xb4c394: mov             x1, x0
    // 0xb4c398: ldur            x0, [fp, #-0x10]
    // 0xb4c39c: LoadField: r2 = r0->field_1b
    //     0xb4c39c: ldur            w2, [x0, #0x1b]
    // 0xb4c3a0: DecompressPointer r2
    //     0xb4c3a0: add             x2, x2, HEAP, lsl #32
    // 0xb4c3a4: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xb4c3a4: ldur            w3, [x0, #0x17]
    // 0xb4c3a8: DecompressPointer r3
    //     0xb4c3a8: add             x3, x3, HEAP, lsl #32
    // 0xb4c3ac: LoadField: r5 = r0->field_13
    //     0xb4c3ac: ldur            w5, [x0, #0x13]
    // 0xb4c3b0: DecompressPointer r5
    //     0xb4c3b0: add             x5, x5, HEAP, lsl #32
    // 0xb4c3b4: LoadField: r4 = r0->field_1f
    //     0xb4c3b4: ldur            w4, [x0, #0x1f]
    // 0xb4c3b8: DecompressPointer r4
    //     0xb4c3b8: add             x4, x4, HEAP, lsl #32
    // 0xb4c3bc: r6 = LoadInt32Instr(r4)
    //     0xb4c3bc: sbfx            x6, x4, #1, #0x1f
    //     0xb4c3c0: tbz             w4, #0, #0xb4c3c8
    //     0xb4c3c4: ldur            x6, [x4, #7]
    // 0xb4c3c8: r0 = __unknown_function__()
    //     0xb4c3c8: bl              #0xb4c3f4  ; [] ::__unknown_function__
    // 0xb4c3cc: mov             x1, x0
    // 0xb4c3d0: stur            x1, [fp, #-0x20]
    // 0xb4c3d4: r0 = Await()
    //     0xb4c3d4: bl              #0xb0c534  ; AwaitStub
    // 0xb4c3d8: ldur            x1, [fp, #-0x18]
    // 0xb4c3dc: stur            x0, [fp, #-0x10]
    // 0xb4c3e0: r0 = call 0x430ba8
    //     0xb4c3e0: bl              #0x430ba8
    // 0xb4c3e4: ldur            x0, [fp, #-0x10]
    // 0xb4c3e8: r0 = ReturnAsync()
    //     0xb4c3e8: b               #0xb13694  ; ReturnAsyncStub
    // 0xb4c3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb4c3ec: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb4c3f0: b               #0xb4c330
  }
  [closure] static Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xb53500, size: 0x210
    // 0xb53500: EnterFrame
    //     0xb53500: stp             fp, lr, [SP, #-0x10]!
    //     0xb53504: mov             fp, SP
    // 0xb53508: AllocStack(0x40)
    //     0xb53508: sub             SP, SP, #0x40
    // 0xb5350c: SetupParameters(dynamic _ /* r1 */)
    //     0xb5350c: stur            NULL, [fp, #-8]
    //     0xb53510: movz            x0, #0
    //     0xb53514: add             x1, fp, w0, sxtw #2
    //     0xb53518: ldr             x1, [x1, #0x10]
    //     0xb5351c: ldur            w2, [x1, #0x17]
    //     0xb53520: add             x2, x2, HEAP, lsl #32
    //     0xb53524: stur            x2, [fp, #-0x10]
    // 0xb53528: CheckStackOverflow
    //     0xb53528: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb5352c: cmp             SP, x16
    //     0xb53530: b.ls            #0xb53708
    // 0xb53534: InitAsync() -> Future<Null?>
    //     0xb53534: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xb53538: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb5353c: ldur            x0, [fp, #-0x10]
    // 0xb53540: LoadField: r2 = r0->field_f
    //     0xb53540: ldur            w2, [x0, #0xf]
    // 0xb53544: DecompressPointer r2
    //     0xb53544: add             x2, x2, HEAP, lsl #32
    // 0xb53548: mov             x1, x2
    // 0xb5354c: stur            x2, [fp, #-0x18]
    // 0xb53550: r0 = call 0x3e0f38
    //     0xb53550: bl              #0x3e0f38
    // 0xb53554: mov             x1, x0
    // 0xb53558: ldur            x0, [fp, #-0x10]
    // 0xb5355c: LoadField: r2 = r0->field_13
    //     0xb5355c: ldur            w2, [x0, #0x13]
    // 0xb53560: DecompressPointer r2
    //     0xb53560: add             x2, x2, HEAP, lsl #32
    // 0xb53564: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xb53564: ldur            w3, [x0, #0x17]
    // 0xb53568: DecompressPointer r3
    //     0xb53568: add             x3, x3, HEAP, lsl #32
    // 0xb5356c: LoadField: r5 = r0->field_23
    //     0xb5356c: ldur            w5, [x0, #0x23]
    // 0xb53570: DecompressPointer r5
    //     0xb53570: add             x5, x5, HEAP, lsl #32
    // 0xb53574: LoadField: r6 = r0->field_27
    //     0xb53574: ldur            w6, [x0, #0x27]
    // 0xb53578: DecompressPointer r6
    //     0xb53578: add             x6, x6, HEAP, lsl #32
    // 0xb5357c: LoadField: r4 = r0->field_2b
    //     0xb5357c: ldur            w4, [x0, #0x2b]
    // 0xb53580: LoadField: r7 = r0->field_2f
    //     0xb53580: ldur            w7, [x0, #0x2f]
    // 0xb53584: DecompressPointer r7
    //     0xb53584: add             x7, x7, HEAP, lsl #32
    // 0xb53588: r8 = LoadInt32Instr(r4)
    //     0xb53588: sbfx            x8, x4, #1, #0x1f
    // 0xb5358c: str             x7, [SP]
    // 0xb53590: mov             x7, x8
    // 0xb53594: r0 = __unknown_function__()
    //     0xb53594: bl              #0xb4da94  ; [] ::__unknown_function__
    // 0xb53598: mov             x1, x0
    // 0xb5359c: stur            x1, [fp, #-0x20]
    // 0xb535a0: r0 = Await()
    //     0xb535a0: bl              #0xb0c534  ; AwaitStub
    // 0xb535a4: mov             x1, x0
    // 0xb535a8: ldur            x2, [fp, #-0x10]
    // 0xb535ac: StoreField: r2->field_33 = r0
    //     0xb535ac: stur            w0, [x2, #0x33]
    //     0xb535b0: tbz             w0, #0, #0xb535cc
    //     0xb535b4: ldurb           w16, [x2, #-1]
    //     0xb535b8: ldurb           w17, [x0, #-1]
    //     0xb535bc: and             x16, x17, x16, lsr #2
    //     0xb535c0: tst             x16, HEAP, lsr #32
    //     0xb535c4: b.eq            #0xb535cc
    //     0xb535c8: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xb535cc: cmp             w1, NULL
    // 0xb535d0: b.ne            #0xb535dc
    // 0xb535d4: r0 = Null
    //     0xb535d4: mov             x0, NULL
    // 0xb535d8: r0 = ReturnAsyncNotFuture()
    //     0xb535d8: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb535dc: LoadField: r0 = r2->field_27
    //     0xb535dc: ldur            w0, [x2, #0x27]
    // 0xb535e0: DecompressPointer r0
    //     0xb535e0: add             x0, x0, HEAP, lsl #32
    // 0xb535e4: LoadField: r1 = r0->field_73
    //     0xb535e4: ldur            w1, [x0, #0x73]
    // 0xb535e8: DecompressPointer r1
    //     0xb535e8: add             x1, x1, HEAP, lsl #32
    // 0xb535ec: cmp             w1, NULL
    // 0xb535f0: b.ne            #0xb535fc
    // 0xb535f4: r0 = Null
    //     0xb535f4: mov             x0, NULL
    // 0xb535f8: b               #0xb53600
    // 0xb535fc: r0 = call 0x378b94
    //     0xb535fc: bl              #0x378b94
    // 0xb53600: cmp             w0, NULL
    // 0xb53604: b.ne            #0xb53610
    // 0xb53608: r2 = ""
    //     0xb53608: ldr             x2, [PP, #0x958]  ; [pp+0x958] ""
    // 0xb5360c: b               #0xb53614
    // 0xb53610: mov             x2, x0
    // 0xb53614: ldur            x0, [fp, #-0x10]
    // 0xb53618: stur            x2, [fp, #-0x20]
    // 0xb5361c: LoadField: r1 = r0->field_1f
    //     0xb5361c: ldur            w1, [x0, #0x1f]
    // 0xb53620: DecompressPointer r1
    //     0xb53620: add             x1, x1, HEAP, lsl #32
    // 0xb53624: tbnz            w1, #4, #0xb536ac
    // 0xb53628: LoadField: r1 = r2->field_7
    //     0xb53628: ldur            w1, [x2, #7]
    // 0xb5362c: cbz             w1, #0xb536ac
    // 0xb53630: ldur            x1, [fp, #-0x18]
    // 0xb53634: r0 = call 0x3e0f38
    //     0xb53634: bl              #0x3e0f38
    // 0xb53638: mov             x3, x0
    // 0xb5363c: ldur            x0, [fp, #-0x10]
    // 0xb53640: stur            x3, [fp, #-0x30]
    // 0xb53644: LoadField: r4 = r0->field_2f
    //     0xb53644: ldur            w4, [x0, #0x2f]
    // 0xb53648: DecompressPointer r4
    //     0xb53648: add             x4, x4, HEAP, lsl #32
    // 0xb5364c: stur            x4, [fp, #-0x28]
    // 0xb53650: r1 = Null
    //     0xb53650: mov             x1, NULL
    // 0xb53654: r2 = 2
    //     0xb53654: movz            x2, #0x2
    // 0xb53658: r0 = AllocateArray()
    //     0xb53658: bl              #0xc55848  ; AllocateArrayStub
    // 0xb5365c: mov             x2, x0
    // 0xb53660: ldur            x0, [fp, #-0x20]
    // 0xb53664: stur            x2, [fp, #-0x38]
    // 0xb53668: StoreField: r2->field_f = r0
    //     0xb53668: stur            w0, [x2, #0xf]
    // 0xb5366c: r1 = <String>
    //     0xb5366c: ldr             x1, [PP, #0x928]  ; [pp+0x928] TypeArguments: <String>
    // 0xb53670: r0 = AllocateGrowableArray()
    //     0xb53670: bl              #0xc5477c  ; AllocateGrowableArrayStub
    // 0xb53674: mov             x1, x0
    // 0xb53678: ldur            x0, [fp, #-0x38]
    // 0xb5367c: StoreField: r1->field_f = r0
    //     0xb5367c: stur            w0, [x1, #0xf]
    // 0xb53680: r0 = 2
    //     0xb53680: movz            x0, #0x2
    // 0xb53684: StoreField: r1->field_b = r0
    //     0xb53684: stur            w0, [x1, #0xb]
    // 0xb53688: mov             x3, x1
    // 0xb5368c: ldur            x1, [fp, #-0x30]
    // 0xb53690: ldur            x2, [fp, #-0x28]
    // 0xb53694: r0 = __unknown_function__()
    //     0xb53694: bl              #0xb54cd0  ; [] ::__unknown_function__
    // 0xb53698: mov             x1, x0
    // 0xb5369c: stur            x1, [fp, #-0x20]
    // 0xb536a0: r0 = Await()
    //     0xb536a0: bl              #0xb0c534  ; AwaitStub
    // 0xb536a4: mov             x1, x0
    // 0xb536a8: b               #0xb536b0
    // 0xb536ac: r1 = 0
    //     0xb536ac: movz            x1, #0
    // 0xb536b0: ldur            x0, [fp, #-0x10]
    // 0xb536b4: LoadField: r2 = r0->field_1b
    //     0xb536b4: ldur            w2, [x0, #0x1b]
    // 0xb536b8: DecompressPointer r2
    //     0xb536b8: add             x2, x2, HEAP, lsl #32
    // 0xb536bc: str             x1, [SP]
    // 0xb536c0: ldur            x1, [fp, #-0x18]
    // 0xb536c4: r4 = const [0, 0x3, 0x1, 0x2, hUh, 0x2, null]
    //     0xb536c4: add             x4, PP, #0x2b, lsl #12  ; [pp+0x2bac0] List(7) [0, 0x3, 0x1, 0x2, "hUh", 0x2, Null]
    //     0xb536c8: ldr             x4, [x4, #0xac0]
    // 0xb536cc: r0 = call 0x446ef4
    //     0xb536cc: bl              #0x446ef4
    // 0xb536d0: mov             x1, x0
    // 0xb536d4: stur            x1, [fp, #-0x18]
    // 0xb536d8: r0 = Await()
    //     0xb536d8: bl              #0xb0c534  ; AwaitStub
    // 0xb536dc: ldur            x1, [fp, #-0x10]
    // 0xb536e0: StoreField: r1->field_37 = r0
    //     0xb536e0: stur            w0, [x1, #0x37]
    //     0xb536e4: tbz             w0, #0, #0xb53700
    //     0xb536e8: ldurb           w16, [x1, #-1]
    //     0xb536ec: ldurb           w17, [x0, #-1]
    //     0xb536f0: and             x16, x17, x16, lsr #2
    //     0xb536f4: tst             x16, HEAP, lsr #32
    //     0xb536f8: b.eq            #0xb53700
    //     0xb536fc: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xb53700: r0 = Null
    //     0xb53700: mov             x0, NULL
    // 0xb53704: r0 = ReturnAsyncNotFuture()
    //     0xb53704: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb53708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb53708: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5370c: b               #0xb53534
  }
  [closure] static Future<Y0> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb5d278, size: 0xa8
    // 0xb5d278: EnterFrame
    //     0xb5d278: stp             fp, lr, [SP, #-0x10]!
    //     0xb5d27c: mov             fp, SP
    // 0xb5d280: AllocStack(0x30)
    //     0xb5d280: sub             SP, SP, #0x30
    // 0xb5d284: SetupParameters(dynamic _ /* r1 */, dynamic _ /* r2, fp-0x20 */)
    //     0xb5d284: stur            NULL, [fp, #-8]
    //     0xb5d288: movz            x0, #0
    //     0xb5d28c: add             x1, fp, w0, sxtw #2
    //     0xb5d290: ldr             x1, [x1, #0x18]
    //     0xb5d294: add             x2, fp, w0, sxtw #2
    //     0xb5d298: ldr             x2, [x2, #0x10]
    //     0xb5d29c: stur            x2, [fp, #-0x20]
    //     0xb5d2a0: ldur            w3, [x1, #0x17]
    //     0xb5d2a4: add             x3, x3, HEAP, lsl #32
    //     0xb5d2a8: stur            x3, [fp, #-0x18]
    // 0xb5d2ac: CheckStackOverflow
    //     0xb5d2ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb5d2b0: cmp             SP, x16
    //     0xb5d2b4: b.ls            #0xb5d318
    // 0xb5d2b8: LoadField: r4 = r1->field_b
    //     0xb5d2b8: ldur            w4, [x1, #0xb]
    // 0xb5d2bc: DecompressPointer r4
    //     0xb5d2bc: add             x4, x4, HEAP, lsl #32
    // 0xb5d2c0: mov             x0, x4
    // 0xb5d2c4: stur            x4, [fp, #-0x10]
    // 0xb5d2c8: r0 = InitAsync()
    //     0xb5d2c8: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb5d2cc: ldur            x1, [fp, #-0x18]
    // 0xb5d2d0: LoadField: r0 = r1->field_13
    //     0xb5d2d0: ldur            w0, [x1, #0x13]
    // 0xb5d2d4: DecompressPointer r0
    //     0xb5d2d4: add             x0, x0, HEAP, lsl #32
    // 0xb5d2d8: ldur            x16, [fp, #-0x20]
    // 0xb5d2dc: stp             x16, x0, [SP]
    // 0xb5d2e0: ClosureCall
    //     0xb5d2e0: ldr             x4, [PP, #0x158]  ; [pp+0x158] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb5d2e4: ldur            x2, [x0, #0x1f]
    //     0xb5d2e8: blr             x2
    // 0xb5d2ec: mov             x1, x0
    // 0xb5d2f0: stur            x1, [fp, #-0x10]
    // 0xb5d2f4: r0 = Await()
    //     0xb5d2f4: bl              #0xb0c534  ; AwaitStub
    // 0xb5d2f8: mov             x2, x0
    // 0xb5d2fc: ldur            x0, [fp, #-0x18]
    // 0xb5d300: stur            x2, [fp, #-0x10]
    // 0xb5d304: LoadField: r1 = r0->field_f
    //     0xb5d304: ldur            w1, [x0, #0xf]
    // 0xb5d308: DecompressPointer r1
    //     0xb5d308: add             x1, x1, HEAP, lsl #32
    // 0xb5d30c: r0 = call 0x430ba8
    //     0xb5d30c: bl              #0x430ba8
    // 0xb5d310: ldur            x0, [fp, #-0x10]
    // 0xb5d314: r0 = ReturnAsync()
    //     0xb5d314: b               #0xb13694  ; ReturnAsyncStub
    // 0xb5d318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb5d318: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb5d31c: b               #0xb5d2b8
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb60308, size: 0x16c
    // 0xb60308: EnterFrame
    //     0xb60308: stp             fp, lr, [SP, #-0x10]!
    //     0xb6030c: mov             fp, SP
    // 0xb60310: AllocStack(0x28)
    //     0xb60310: sub             SP, SP, #0x28
    // 0xb60314: SetupParameters(dynamic _ /* r1 */)
    //     0xb60314: stur            NULL, [fp, #-8]
    //     0xb60318: movz            x0, #0
    //     0xb6031c: add             x1, fp, w0, sxtw #2
    //     0xb60320: ldr             x1, [x1, #0x18]
    //     0xb60324: ldur            w2, [x1, #0x17]
    //     0xb60328: add             x2, x2, HEAP, lsl #32
    //     0xb6032c: stur            x2, [fp, #-0x10]
    // 0xb60330: CheckStackOverflow
    //     0xb60330: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb60334: cmp             SP, x16
    //     0xb60338: b.ls            #0xb60468
    // 0xb6033c: InitAsync() -> Future<int>
    //     0xb6033c: ldr             x0, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    //     0xb60340: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb60344: ldur            x0, [fp, #-0x10]
    // 0xb60348: LoadField: r1 = r0->field_13
    //     0xb60348: ldur            w1, [x0, #0x13]
    // 0xb6034c: DecompressPointer r1
    //     0xb6034c: add             x1, x1, HEAP, lsl #32
    // 0xb60350: r0 = call 0x44c36c
    //     0xb60350: bl              #0x44c36c
    // 0xb60354: ldur            x0, [fp, #-0x10]
    // 0xb60358: LoadField: r4 = r0->field_f
    //     0xb60358: ldur            w4, [x0, #0xf]
    // 0xb6035c: DecompressPointer r4
    //     0xb6035c: add             x4, x4, HEAP, lsl #32
    // 0xb60360: stur            x4, [fp, #-0x18]
    // 0xb60364: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb60364: ldur            w2, [x0, #0x17]
    // 0xb60368: DecompressPointer r2
    //     0xb60368: add             x2, x2, HEAP, lsl #32
    // 0xb6036c: LoadField: r3 = r0->field_1b
    //     0xb6036c: ldur            w3, [x0, #0x1b]
    // 0xb60370: DecompressPointer r3
    //     0xb60370: add             x3, x3, HEAP, lsl #32
    // 0xb60374: r16 = true
    //     0xb60374: add             x16, NULL, #0x20  ; true
    // 0xb60378: str             x16, [SP]
    // 0xb6037c: mov             x1, x4
    // 0xb60380: r4 = const [0, 0x4, 0x1, 0x3, lWh, 0x3, null]
    //     0xb60380: add             x4, PP, #0x2b, lsl #12  ; [pp+0x2ba78] List(7) [0, 0x4, 0x1, 0x3, "lWh", 0x3, Null]
    //     0xb60384: ldr             x4, [x4, #0xa78]
    // 0xb60388: r0 = __unknown_function__()
    //     0xb60388: bl              #0xb553a0  ; [] ::__unknown_function__
    // 0xb6038c: mov             x1, x0
    // 0xb60390: stur            x1, [fp, #-0x20]
    // 0xb60394: r0 = Await()
    //     0xb60394: bl              #0xb0c534  ; AwaitStub
    // 0xb60398: cmp             w0, NULL
    // 0xb6039c: b.eq            #0xb603b4
    // 0xb603a0: ldur            x3, [fp, #-0x10]
    // 0xb603a4: LoadField: r1 = r3->field_13
    //     0xb603a4: ldur            w1, [x3, #0x13]
    // 0xb603a8: DecompressPointer r1
    //     0xb603a8: add             x1, x1, HEAP, lsl #32
    // 0xb603ac: mov             x2, x0
    // 0xb603b0: r0 = call 0x44c060
    //     0xb603b0: bl              #0x44c060
    // 0xb603b4: ldur            x0, [fp, #-0x10]
    // 0xb603b8: ldur            x1, [fp, #-0x18]
    // 0xb603bc: r0 = call 0x3e0f38
    //     0xb603bc: bl              #0x3e0f38
    // 0xb603c0: mov             x1, x0
    // 0xb603c4: ldur            x0, [fp, #-0x10]
    // 0xb603c8: LoadField: r2 = r0->field_1b
    //     0xb603c8: ldur            w2, [x0, #0x1b]
    // 0xb603cc: DecompressPointer r2
    //     0xb603cc: add             x2, x2, HEAP, lsl #32
    // 0xb603d0: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xb603d0: ldur            w3, [x0, #0x17]
    // 0xb603d4: DecompressPointer r3
    //     0xb603d4: add             x3, x3, HEAP, lsl #32
    // 0xb603d8: LoadField: r5 = r0->field_13
    //     0xb603d8: ldur            w5, [x0, #0x13]
    // 0xb603dc: DecompressPointer r5
    //     0xb603dc: add             x5, x5, HEAP, lsl #32
    // 0xb603e0: r0 = __unknown_function__()
    //     0xb603e0: bl              #0xb4defc  ; [] ::__unknown_function__
    // 0xb603e4: mov             x1, x0
    // 0xb603e8: stur            x1, [fp, #-0x20]
    // 0xb603ec: r0 = Await()
    //     0xb603ec: bl              #0xb0c534  ; AwaitStub
    // 0xb603f0: ldur            x1, [fp, #-0x18]
    // 0xb603f4: stur            x0, [fp, #-0x18]
    // 0xb603f8: r0 = call 0x430ba8
    //     0xb603f8: bl              #0x430ba8
    // 0xb603fc: ldur            x0, [fp, #-0x18]
    // 0xb60400: cmp             w0, NULL
    // 0xb60404: b.eq            #0xb60470
    // 0xb60408: r1 = LoadInt32Instr(r0)
    //     0xb60408: sbfx            x1, x0, #1, #0x1f
    //     0xb6040c: tbz             w0, #0, #0xb60414
    //     0xb60410: ldur            x1, [x0, #7]
    // 0xb60414: cmp             x1, #0
    // 0xb60418: b.le            #0xb60460
    // 0xb6041c: ldur            x1, [fp, #-0x10]
    // 0xb60420: LoadField: r2 = r1->field_1f
    //     0xb60420: ldur            w2, [x1, #0x1f]
    // 0xb60424: DecompressPointer r2
    //     0xb60424: add             x2, x2, HEAP, lsl #32
    // 0xb60428: tbnz            w2, #4, #0xb60460
    // 0xb6042c: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb6042c: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb60430: ldr             x0, [x0, #0x29b8]
    //     0xb60434: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb60438: cmp             w0, w16
    //     0xb6043c: b.ne            #0xb6044c
    //     0xb60440: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb60444: ldr             x2, [x2, #0xa78]
    //     0xb60448: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb6044c: mov             x1, x0
    // 0xb60450: ldur            x0, [fp, #-0x10]
    // 0xb60454: LoadField: r2 = r0->field_13
    //     0xb60454: ldur            w2, [x0, #0x13]
    // 0xb60458: DecompressPointer r2
    //     0xb60458: add             x2, x2, HEAP, lsl #32
    // 0xb6045c: r0 = call 0x442824
    //     0xb6045c: bl              #0x442824
    // 0xb60460: ldur            x0, [fp, #-0x18]
    // 0xb60464: r0 = ReturnAsyncNotFuture()
    //     0xb60464: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb60468: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60468: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6046c: b               #0xb6033c
    // 0xb60470: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb60470: bl              #0xc560a8  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<qWa?> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb609dc, size: 0x370
    // 0xb609dc: EnterFrame
    //     0xb609dc: stp             fp, lr, [SP, #-0x10]!
    //     0xb609e0: mov             fp, SP
    // 0xb609e4: AllocStack(0x48)
    //     0xb609e4: sub             SP, SP, #0x48
    // 0xb609e8: SetupParameters(dynamic _ /* r1 */)
    //     0xb609e8: stur            NULL, [fp, #-8]
    //     0xb609ec: movz            x0, #0
    //     0xb609f0: add             x1, fp, w0, sxtw #2
    //     0xb609f4: ldr             x1, [x1, #0x18]
    //     0xb609f8: ldur            w2, [x1, #0x17]
    //     0xb609fc: add             x2, x2, HEAP, lsl #32
    //     0xb60a00: stur            x2, [fp, #-0x10]
    // 0xb60a04: CheckStackOverflow
    //     0xb60a04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb60a08: cmp             SP, x16
    //     0xb60a0c: b.ls            #0xb60d3c
    // 0xb60a10: InitAsync() -> Future<qWa?>
    //     0xb60a10: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b6f8] TypeArguments: <qWa?>
    //     0xb60a14: ldr             x0, [x0, #0x6f8]
    //     0xb60a18: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb60a1c: ldur            x0, [fp, #-0x10]
    // 0xb60a20: LoadField: r1 = r0->field_2b
    //     0xb60a20: ldur            w1, [x0, #0x2b]
    // 0xb60a24: DecompressPointer r1
    //     0xb60a24: add             x1, x1, HEAP, lsl #32
    // 0xb60a28: cmp             w1, NULL
    // 0xb60a2c: b.ne            #0xb60a70
    // 0xb60a30: LoadField: r1 = r0->field_f
    //     0xb60a30: ldur            w1, [x0, #0xf]
    // 0xb60a34: DecompressPointer r1
    //     0xb60a34: add             x1, x1, HEAP, lsl #32
    // 0xb60a38: LoadField: r2 = r0->field_23
    //     0xb60a38: ldur            w2, [x0, #0x23]
    // 0xb60a3c: DecompressPointer r2
    //     0xb60a3c: add             x2, x2, HEAP, lsl #32
    // 0xb60a40: LoadField: r3 = r0->field_2f
    //     0xb60a40: ldur            w3, [x0, #0x2f]
    // 0xb60a44: DecompressPointer r3
    //     0xb60a44: add             x3, x3, HEAP, lsl #32
    // 0xb60a48: r16 = true
    //     0xb60a48: add             x16, NULL, #0x20  ; true
    // 0xb60a4c: str             x16, [SP]
    // 0xb60a50: r4 = const [0, 0x4, 0x1, 0x3, lWh, 0x3, null]
    //     0xb60a50: add             x4, PP, #0x2b, lsl #12  ; [pp+0x2ba78] List(7) [0, 0x4, 0x1, 0x3, "lWh", 0x3, Null]
    //     0xb60a54: ldr             x4, [x4, #0xa78]
    // 0xb60a58: r0 = __unknown_function__()
    //     0xb60a58: bl              #0xb553a0  ; [] ::__unknown_function__
    // 0xb60a5c: mov             x1, x0
    // 0xb60a60: stur            x1, [fp, #-0x18]
    // 0xb60a64: r0 = Await()
    //     0xb60a64: bl              #0xb0c534  ; AwaitStub
    // 0xb60a68: mov             x3, x0
    // 0xb60a6c: b               #0xb60a74
    // 0xb60a70: mov             x3, x1
    // 0xb60a74: stur            x3, [fp, #-0x20]
    // 0xb60a78: cmp             w3, NULL
    // 0xb60a7c: b.ne            #0xb60a88
    // 0xb60a80: r0 = Null
    //     0xb60a80: mov             x0, NULL
    // 0xb60a84: r0 = ReturnAsyncNotFuture()
    //     0xb60a84: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb60a88: ldur            x0, [fp, #-0x10]
    // 0xb60a8c: LoadField: r2 = r0->field_1b
    //     0xb60a8c: ldur            w2, [x0, #0x1b]
    // 0xb60a90: DecompressPointer r2
    //     0xb60a90: add             x2, x2, HEAP, lsl #32
    // 0xb60a94: stur            x2, [fp, #-0x18]
    // 0xb60a98: LoadField: r1 = r0->field_1f
    //     0xb60a98: ldur            w1, [x0, #0x1f]
    // 0xb60a9c: DecompressPointer r1
    //     0xb60a9c: add             x1, x1, HEAP, lsl #32
    // 0xb60aa0: cmp             w1, NULL
    // 0xb60aa4: b.ne            #0xb60ab0
    // 0xb60aa8: r0 = Null
    //     0xb60aa8: mov             x0, NULL
    // 0xb60aac: b               #0xb60ac8
    // 0xb60ab0: r0 = call 0x378b94
    //     0xb60ab0: bl              #0x378b94
    // 0xb60ab4: LoadField: r1 = r0->field_7
    //     0xb60ab4: ldur            w1, [x0, #7]
    // 0xb60ab8: cbnz            w1, #0xb60ac4
    // 0xb60abc: r0 = false
    //     0xb60abc: add             x0, NULL, #0x30  ; false
    // 0xb60ac0: b               #0xb60ac8
    // 0xb60ac4: r0 = true
    //     0xb60ac4: add             x0, NULL, #0x20  ; true
    // 0xb60ac8: cmp             w0, NULL
    // 0xb60acc: b.eq            #0xb60af4
    // 0xb60ad0: tbnz            w0, #4, #0xb60af4
    // 0xb60ad4: ldur            x0, [fp, #-0x10]
    // 0xb60ad8: LoadField: r1 = r0->field_1f
    //     0xb60ad8: ldur            w1, [x0, #0x1f]
    // 0xb60adc: DecompressPointer r1
    //     0xb60adc: add             x1, x1, HEAP, lsl #32
    // 0xb60ae0: cmp             w1, NULL
    // 0xb60ae4: b.eq            #0xb60d44
    // 0xb60ae8: r0 = call 0x378b94
    //     0xb60ae8: bl              #0x378b94
    // 0xb60aec: mov             x6, x0
    // 0xb60af0: b               #0xb60b64
    // 0xb60af4: r0 = InitLateStaticField(0x158c) // [zan] TTa::ZLc
    //     0xb60af4: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb60af8: ldr             x0, [x0, #0x2b18]
    //     0xb60afc: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb60b00: cmp             w0, w16
    //     0xb60b04: b.ne            #0xb60b14
    //     0xb60b08: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a68] Field <TTa.ZLc>: static late final (offset: 0x158c)
    //     0xb60b0c: ldr             x2, [x2, #0xa68]
    //     0xb60b10: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb60b14: LoadField: r1 = r0->field_37
    //     0xb60b14: ldur            w1, [x0, #0x37]
    // 0xb60b18: DecompressPointer r1
    //     0xb60b18: add             x1, x1, HEAP, lsl #32
    // 0xb60b1c: LoadField: r2 = r1->field_13
    //     0xb60b1c: ldur            x2, [x1, #0x13]
    // 0xb60b20: r0 = BoxInt64Instr(r2)
    //     0xb60b20: sbfiz           x0, x2, #1, #0x1f
    //     0xb60b24: cmp             x2, x0, asr #1
    //     0xb60b28: b.eq            #0xb60b34
    //     0xb60b2c: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb60b30: stur            x2, [x0, #7]
    // 0xb60b34: r1 = 60
    //     0xb60b34: movz            x1, #0x3c
    // 0xb60b38: branchIfSmi(r0, 0xb60b44)
    //     0xb60b38: tbz             w0, #0, #0xb60b44
    // 0xb60b3c: r1 = LoadClassIdInstr(r0)
    //     0xb60b3c: ldur            x1, [x0, #-1]
    //     0xb60b40: ubfx            x1, x1, #0xc, #0x14
    // 0xb60b44: str             x0, [SP]
    // 0xb60b48: mov             x0, x1
    // 0xb60b4c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb60b4c: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb60b50: r0 = GDT[cid_x0 + 0x2bed]()
    //     0xb60b50: movz            x17, #0x2bed
    //     0xb60b54: add             lr, x0, x17
    //     0xb60b58: ldr             lr, [x21, lr, lsl #3]
    //     0xb60b5c: blr             lr
    // 0xb60b60: mov             x6, x0
    // 0xb60b64: ldur            x0, [fp, #-0x10]
    // 0xb60b68: stur            x6, [fp, #-0x38]
    // 0xb60b6c: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb60b6c: ldur            w1, [x0, #0x17]
    // 0xb60b70: DecompressPointer r1
    //     0xb60b70: add             x1, x1, HEAP, lsl #32
    // 0xb60b74: cmp             w1, NULL
    // 0xb60b78: b.ne            #0xb60b90
    // 0xb60b7c: ldur            x3, [fp, #-0x20]
    // 0xb60b80: LoadField: r1 = r3->field_a7
    //     0xb60b80: ldur            x1, [x3, #0xa7]
    // 0xb60b84: add             x2, x1, #1
    // 0xb60b88: mov             x4, x2
    // 0xb60b8c: b               #0xb60ba4
    // 0xb60b90: ldur            x3, [fp, #-0x20]
    // 0xb60b94: r2 = LoadInt32Instr(r1)
    //     0xb60b94: sbfx            x2, x1, #1, #0x1f
    //     0xb60b98: tbz             w1, #0, #0xb60ba0
    //     0xb60b9c: ldur            x2, [x1, #7]
    // 0xb60ba0: mov             x4, x2
    // 0xb60ba4: ldur            x2, [fp, #-0x18]
    // 0xb60ba8: stur            x4, [fp, #-0x30]
    // 0xb60bac: LoadField: r5 = r0->field_f
    //     0xb60bac: ldur            w5, [x0, #0xf]
    // 0xb60bb0: DecompressPointer r5
    //     0xb60bb0: add             x5, x5, HEAP, lsl #32
    // 0xb60bb4: mov             x1, x5
    // 0xb60bb8: stur            x5, [fp, #-0x28]
    // 0xb60bbc: r0 = call 0x3e0f38
    //     0xb60bbc: bl              #0x3e0f38
    // 0xb60bc0: mov             x1, x0
    // 0xb60bc4: ldur            x0, [fp, #-0x10]
    // 0xb60bc8: LoadField: r2 = r0->field_13
    //     0xb60bc8: ldur            w2, [x0, #0x13]
    // 0xb60bcc: DecompressPointer r2
    //     0xb60bcc: add             x2, x2, HEAP, lsl #32
    // 0xb60bd0: LoadField: r7 = r0->field_23
    //     0xb60bd0: ldur            w7, [x0, #0x23]
    // 0xb60bd4: DecompressPointer r7
    //     0xb60bd4: add             x7, x7, HEAP, lsl #32
    // 0xb60bd8: LoadField: r3 = r0->field_2f
    //     0xb60bd8: ldur            w3, [x0, #0x2f]
    // 0xb60bdc: DecompressPointer r3
    //     0xb60bdc: add             x3, x3, HEAP, lsl #32
    // 0xb60be0: ldur            x4, [fp, #-0x18]
    // 0xb60be4: r5 = LoadInt32Instr(r4)
    //     0xb60be4: sbfx            x5, x4, #1, #0x1f
    //     0xb60be8: tbz             w4, #0, #0xb60bf0
    //     0xb60bec: ldur            x5, [x4, #7]
    // 0xb60bf0: str             x3, [SP]
    // 0xb60bf4: ldur            x3, [fp, #-0x30]
    // 0xb60bf8: ldur            x6, [fp, #-0x38]
    // 0xb60bfc: r0 = __unknown_function__()
    //     0xb60bfc: bl              #0xb60f14  ; [] ::__unknown_function__
    // 0xb60c00: mov             x1, x0
    // 0xb60c04: stur            x1, [fp, #-0x40]
    // 0xb60c08: r0 = Await()
    //     0xb60c08: bl              #0xb0c534  ; AwaitStub
    // 0xb60c0c: cmp             w0, NULL
    // 0xb60c10: b.eq            #0xb60d48
    // 0xb60c14: r1 = LoadInt32Instr(r0)
    //     0xb60c14: sbfx            x1, x0, #1, #0x1f
    //     0xb60c18: tbz             w0, #0, #0xb60c20
    //     0xb60c1c: ldur            x1, [x0, #7]
    // 0xb60c20: cmp             x1, #0
    // 0xb60c24: b.gt            #0xb60c38
    // 0xb60c28: ldur            x1, [fp, #-0x28]
    // 0xb60c2c: r0 = call 0x430ba8
    //     0xb60c2c: bl              #0x430ba8
    // 0xb60c30: r0 = Null
    //     0xb60c30: mov             x0, NULL
    // 0xb60c34: r0 = ReturnAsyncNotFuture()
    //     0xb60c34: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb60c38: ldur            x2, [fp, #-0x10]
    // 0xb60c3c: ldur            x3, [fp, #-0x20]
    // 0xb60c40: ldur            x1, [fp, #-0x30]
    // 0xb60c44: r0 = 1
    //     0xb60c44: movz            x0, #0x1
    // 0xb60c48: StoreField: r3->field_97 = r0
    //     0xb60c48: stur            x0, [x3, #0x97]
    // 0xb60c4c: ldur            x0, [fp, #-0x18]
    // 0xb60c50: StoreField: r3->field_9f = r0
    //     0xb60c50: stur            w0, [x3, #0x9f]
    //     0xb60c54: tbz             w0, #0, #0xb60c70
    //     0xb60c58: ldurb           w16, [x3, #-1]
    //     0xb60c5c: ldurb           w17, [x0, #-1]
    //     0xb60c60: and             x16, x17, x16, lsr #2
    //     0xb60c64: tst             x16, HEAP, lsr #32
    //     0xb60c68: b.eq            #0xb60c70
    //     0xb60c6c: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb60c70: ldur            x0, [fp, #-0x38]
    // 0xb60c74: StoreField: r3->field_a3 = r0
    //     0xb60c74: stur            w0, [x3, #0xa3]
    //     0xb60c78: ldurb           w16, [x3, #-1]
    //     0xb60c7c: ldurb           w17, [x0, #-1]
    //     0xb60c80: and             x16, x17, x16, lsr #2
    //     0xb60c84: tst             x16, HEAP, lsr #32
    //     0xb60c88: b.eq            #0xb60c90
    //     0xb60c8c: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb60c90: StoreField: r3->field_a7 = r1
    //     0xb60c90: stur            x1, [x3, #0xa7]
    // 0xb60c94: LoadField: r0 = r2->field_13
    //     0xb60c94: ldur            w0, [x2, #0x13]
    // 0xb60c98: DecompressPointer r0
    //     0xb60c98: add             x0, x0, HEAP, lsl #32
    // 0xb60c9c: StoreField: r3->field_13 = r0
    //     0xb60c9c: stur            w0, [x3, #0x13]
    //     0xb60ca0: ldurb           w16, [x3, #-1]
    //     0xb60ca4: ldurb           w17, [x0, #-1]
    //     0xb60ca8: and             x16, x17, x16, lsr #2
    //     0xb60cac: tst             x16, HEAP, lsr #32
    //     0xb60cb0: b.eq            #0xb60cb8
    //     0xb60cb4: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb60cb8: ldur            x1, [fp, #-0x28]
    // 0xb60cbc: r0 = call 0x3e0f38
    //     0xb60cbc: bl              #0x3e0f38
    // 0xb60cc0: mov             x1, x0
    // 0xb60cc4: ldur            x0, [fp, #-0x10]
    // 0xb60cc8: LoadField: r2 = r0->field_2f
    //     0xb60cc8: ldur            w2, [x0, #0x2f]
    // 0xb60ccc: DecompressPointer r2
    //     0xb60ccc: add             x2, x2, HEAP, lsl #32
    // 0xb60cd0: ldur            x3, [fp, #-0x20]
    // 0xb60cd4: r0 = __unknown_function__()
    //     0xb60cd4: bl              #0xb60d4c  ; [] ::__unknown_function__
    // 0xb60cd8: mov             x1, x0
    // 0xb60cdc: stur            x1, [fp, #-0x18]
    // 0xb60ce0: r0 = Await()
    //     0xb60ce0: bl              #0xb0c534  ; AwaitStub
    // 0xb60ce4: ldur            x1, [fp, #-0x28]
    // 0xb60ce8: r0 = call 0x430ba8
    //     0xb60ce8: bl              #0x430ba8
    // 0xb60cec: ldur            x0, [fp, #-0x10]
    // 0xb60cf0: LoadField: r1 = r0->field_27
    //     0xb60cf0: ldur            w1, [x0, #0x27]
    // 0xb60cf4: DecompressPointer r1
    //     0xb60cf4: add             x1, x1, HEAP, lsl #32
    // 0xb60cf8: tbnz            w1, #4, #0xb60d34
    // 0xb60cfc: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb60cfc: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb60d00: ldr             x0, [x0, #0x29b8]
    //     0xb60d04: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb60d08: cmp             w0, w16
    //     0xb60d0c: b.ne            #0xb60d1c
    //     0xb60d10: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb60d14: ldr             x2, [x2, #0xa78]
    //     0xb60d18: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb60d1c: mov             x1, x0
    // 0xb60d20: ldur            x2, [fp, #-0x20]
    // 0xb60d24: stur            x0, [fp, #-0x10]
    // 0xb60d28: r0 = call 0x442824
    //     0xb60d28: bl              #0x442824
    // 0xb60d2c: ldur            x1, [fp, #-0x10]
    // 0xb60d30: r0 = call 0x43f5b8
    //     0xb60d30: bl              #0x43f5b8
    // 0xb60d34: ldur            x0, [fp, #-0x20]
    // 0xb60d38: r0 = ReturnAsync()
    //     0xb60d38: b               #0xb13694  ; ReturnAsyncStub
    // 0xb60d3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb60d3c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb60d40: b               #0xb60a10
    // 0xb60d44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb60d44: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb60d48: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb60d48: bl              #0xc560a8  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xb622f0, size: 0x420
    // 0xb622f0: EnterFrame
    //     0xb622f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb622f4: mov             fp, SP
    // 0xb622f8: AllocStack(0x58)
    //     0xb622f8: sub             SP, SP, #0x58
    // 0xb622fc: SetupParameters(dynamic _ /* r1 */)
    //     0xb622fc: stur            NULL, [fp, #-8]
    //     0xb62300: movz            x0, #0
    //     0xb62304: add             x1, fp, w0, sxtw #2
    //     0xb62308: ldr             x1, [x1, #0x10]
    //     0xb6230c: ldur            w2, [x1, #0x17]
    //     0xb62310: add             x2, x2, HEAP, lsl #32
    //     0xb62314: stur            x2, [fp, #-0x10]
    // 0xb62318: CheckStackOverflow
    //     0xb62318: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb6231c: cmp             SP, x16
    //     0xb62320: b.ls            #0xb62704
    // 0xb62324: InitAsync() -> Future<Null?>
    //     0xb62324: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xb62328: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb6232c: ldur            x0, [fp, #-0x10]
    // 0xb62330: LoadField: r1 = r0->field_13
    //     0xb62330: ldur            w1, [x0, #0x13]
    // 0xb62334: DecompressPointer r1
    //     0xb62334: add             x1, x1, HEAP, lsl #32
    // 0xb62338: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb62338: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb6233c: r0 = call 0x36a13c
    //     0xb6233c: bl              #0x36a13c
    // 0xb62340: cmp             w0, NULL
    // 0xb62344: b.ne            #0xb62350
    // 0xb62348: r0 = Null
    //     0xb62348: mov             x0, NULL
    // 0xb6234c: b               #0xb62364
    // 0xb62350: r2 = LoadInt32Instr(r0)
    //     0xb62350: sbfx            x2, x0, #1, #0x1f
    //     0xb62354: tbz             w0, #0, #0xb6235c
    //     0xb62358: ldur            x2, [x0, #7]
    // 0xb6235c: r1 = 0
    //     0xb6235c: movz            x1, #0
    // 0xb62360: r0 = call 0x445488
    //     0xb62360: bl              #0x445488
    // 0xb62364: stur            x0, [fp, #-0x18]
    // 0xb62368: cmp             w0, NULL
    // 0xb6236c: b.ne            #0xb62378
    // 0xb62370: r0 = Null
    //     0xb62370: mov             x0, NULL
    // 0xb62374: b               #0xb62398
    // 0xb62378: ldur            x3, [fp, #-0x10]
    // 0xb6237c: LoadField: r1 = r3->field_f
    //     0xb6237c: ldur            w1, [x3, #0xf]
    // 0xb62380: DecompressPointer r1
    //     0xb62380: add             x1, x1, HEAP, lsl #32
    // 0xb62384: mov             x2, x0
    // 0xb62388: r0 = __unknown_function__()
    //     0xb62388: bl              #0xb4a650  ; [] ::__unknown_function__
    // 0xb6238c: mov             x1, x0
    // 0xb62390: stur            x1, [fp, #-0x20]
    // 0xb62394: r0 = Await()
    //     0xb62394: bl              #0xb0c534  ; AwaitStub
    // 0xb62398: stur            x0, [fp, #-0x20]
    // 0xb6239c: cmp             w0, NULL
    // 0xb623a0: b.eq            #0xb6249c
    // 0xb623a4: ldur            x2, [fp, #-0x10]
    // 0xb623a8: LoadField: r1 = r2->field_f
    //     0xb623a8: ldur            w1, [x2, #0xf]
    // 0xb623ac: DecompressPointer r1
    //     0xb623ac: add             x1, x1, HEAP, lsl #32
    // 0xb623b0: r0 = call 0x3e0f38
    //     0xb623b0: bl              #0x3e0f38
    // 0xb623b4: mov             x1, x0
    // 0xb623b8: ldur            x0, [fp, #-0x10]
    // 0xb623bc: stur            x1, [fp, #-0x38]
    // 0xb623c0: LoadField: r2 = r0->field_13
    //     0xb623c0: ldur            w2, [x0, #0x13]
    // 0xb623c4: DecompressPointer r2
    //     0xb623c4: add             x2, x2, HEAP, lsl #32
    // 0xb623c8: ldur            x3, [fp, #-0x20]
    // 0xb623cc: stur            x2, [fp, #-0x30]
    // 0xb623d0: LoadField: r6 = r3->field_3b
    //     0xb623d0: ldur            x6, [x3, #0x3b]
    // 0xb623d4: stur            x6, [fp, #-0x28]
    // 0xb623d8: r0 = InitLateStaticField(0x158c) // [zan] TTa::ZLc
    //     0xb623d8: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb623dc: ldr             x0, [x0, #0x2b18]
    //     0xb623e0: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb623e4: cmp             w0, w16
    //     0xb623e8: b.ne            #0xb623f8
    //     0xb623ec: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a68] Field <TTa.ZLc>: static late final (offset: 0x158c)
    //     0xb623f0: ldr             x2, [x2, #0xa68]
    //     0xb623f4: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb623f8: LoadField: r1 = r0->field_37
    //     0xb623f8: ldur            w1, [x0, #0x37]
    // 0xb623fc: DecompressPointer r1
    //     0xb623fc: add             x1, x1, HEAP, lsl #32
    // 0xb62400: LoadField: r2 = r1->field_13
    //     0xb62400: ldur            x2, [x1, #0x13]
    // 0xb62404: r0 = BoxInt64Instr(r2)
    //     0xb62404: sbfiz           x0, x2, #1, #0x1f
    //     0xb62408: cmp             x2, x0, asr #1
    //     0xb6240c: b.eq            #0xb62418
    //     0xb62410: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb62414: stur            x2, [x0, #7]
    // 0xb62418: r1 = 60
    //     0xb62418: movz            x1, #0x3c
    // 0xb6241c: branchIfSmi(r0, 0xb62428)
    //     0xb6241c: tbz             w0, #0, #0xb62428
    // 0xb62420: r1 = LoadClassIdInstr(r0)
    //     0xb62420: ldur            x1, [x0, #-1]
    //     0xb62424: ubfx            x1, x1, #0xc, #0x14
    // 0xb62428: str             x0, [SP]
    // 0xb6242c: mov             x0, x1
    // 0xb62430: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb62430: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb62434: r0 = GDT[cid_x0 + 0x2bed]()
    //     0xb62434: movz            x17, #0x2bed
    //     0xb62438: add             lr, x0, x17
    //     0xb6243c: ldr             lr, [x21, lr, lsl #3]
    //     0xb62440: blr             lr
    // 0xb62444: mov             x1, x0
    // 0xb62448: ldur            x0, [fp, #-0x10]
    // 0xb6244c: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xb6244c: ldur            w3, [x0, #0x17]
    // 0xb62450: DecompressPointer r3
    //     0xb62450: add             x3, x3, HEAP, lsl #32
    // 0xb62454: mov             x5, x1
    // 0xb62458: ldur            x1, [fp, #-0x38]
    // 0xb6245c: ldur            x2, [fp, #-0x30]
    // 0xb62460: ldur            x6, [fp, #-0x28]
    // 0xb62464: r0 = __unknown_function__()
    //     0xb62464: bl              #0xb62e68  ; [] ::__unknown_function__
    // 0xb62468: mov             x1, x0
    // 0xb6246c: stur            x1, [fp, #-0x30]
    // 0xb62470: r0 = Await()
    //     0xb62470: bl              #0xb0c534  ; AwaitStub
    // 0xb62474: ldur            x2, [fp, #-0x10]
    // 0xb62478: StoreField: r2->field_1f = r0
    //     0xb62478: stur            w0, [x2, #0x1f]
    //     0xb6247c: tbz             w0, #0, #0xb62498
    //     0xb62480: ldurb           w16, [x2, #-1]
    //     0xb62484: ldurb           w17, [x0, #-1]
    //     0xb62488: and             x16, x17, x16, lsr #2
    //     0xb6248c: tst             x16, HEAP, lsr #32
    //     0xb62490: b.eq            #0xb62498
    //     0xb62494: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xb62498: b               #0xb624a0
    // 0xb6249c: ldur            x2, [fp, #-0x10]
    // 0xb624a0: LoadField: r0 = r2->field_1b
    //     0xb624a0: ldur            w0, [x2, #0x1b]
    // 0xb624a4: DecompressPointer r0
    //     0xb624a4: add             x0, x0, HEAP, lsl #32
    // 0xb624a8: stur            x0, [fp, #-0x38]
    // 0xb624ac: LoadField: r3 = r2->field_f
    //     0xb624ac: ldur            w3, [x2, #0xf]
    // 0xb624b0: DecompressPointer r3
    //     0xb624b0: add             x3, x3, HEAP, lsl #32
    // 0xb624b4: mov             x1, x3
    // 0xb624b8: stur            x3, [fp, #-0x30]
    // 0xb624bc: r0 = call 0x3e0f38
    //     0xb624bc: bl              #0x3e0f38
    // 0xb624c0: mov             x1, x0
    // 0xb624c4: ldur            x0, [fp, #-0x10]
    // 0xb624c8: LoadField: r2 = r0->field_13
    //     0xb624c8: ldur            w2, [x0, #0x13]
    // 0xb624cc: DecompressPointer r2
    //     0xb624cc: add             x2, x2, HEAP, lsl #32
    // 0xb624d0: ArrayLoad: r4 = r0[0]  ; List_4
    //     0xb624d0: ldur            w4, [x0, #0x17]
    // 0xb624d4: DecompressPointer r4
    //     0xb624d4: add             x4, x4, HEAP, lsl #32
    // 0xb624d8: mov             x3, x4
    // 0xb624dc: stur            x4, [fp, #-0x40]
    // 0xb624e0: r0 = __unknown_function__()
    //     0xb624e0: bl              #0xb62934  ; [] ::__unknown_function__
    // 0xb624e4: mov             x1, x0
    // 0xb624e8: stur            x1, [fp, #-0x48]
    // 0xb624ec: r0 = Await()
    //     0xb624ec: bl              #0xb0c534  ; AwaitStub
    // 0xb624f0: ldur            x16, [fp, #-0x38]
    // 0xb624f4: stp             x0, x16, [SP]
    // 0xb624f8: r0 = call 0xb01138
    //     0xb624f8: bl              #0xb01138
    // 0xb624fc: ldur            x2, [fp, #-0x10]
    // 0xb62500: StoreField: r2->field_1b = r0
    //     0xb62500: stur            w0, [x2, #0x1b]
    //     0xb62504: tbz             w0, #0, #0xb62520
    //     0xb62508: ldurb           w16, [x2, #-1]
    //     0xb6250c: ldurb           w17, [x0, #-1]
    //     0xb62510: and             x16, x17, x16, lsr #2
    //     0xb62514: tst             x16, HEAP, lsr #32
    //     0xb62518: b.eq            #0xb62520
    //     0xb6251c: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xb62520: ldur            x1, [fp, #-0x30]
    // 0xb62524: r0 = call 0x3e0f38
    //     0xb62524: bl              #0x3e0f38
    // 0xb62528: mov             x1, x0
    // 0xb6252c: ldur            x0, [fp, #-0x10]
    // 0xb62530: LoadField: r2 = r0->field_13
    //     0xb62530: ldur            w2, [x0, #0x13]
    // 0xb62534: DecompressPointer r2
    //     0xb62534: add             x2, x2, HEAP, lsl #32
    // 0xb62538: ldur            x3, [fp, #-0x40]
    // 0xb6253c: r0 = __unknown_function__()
    //     0xb6253c: bl              #0xb62710  ; [] ::__unknown_function__
    // 0xb62540: mov             x1, x0
    // 0xb62544: stur            x1, [fp, #-0x38]
    // 0xb62548: r0 = Await()
    //     0xb62548: bl              #0xb0c534  ; AwaitStub
    // 0xb6254c: mov             x1, x0
    // 0xb62550: ldur            x0, [fp, #-0x10]
    // 0xb62554: stur            x1, [fp, #-0x38]
    // 0xb62558: LoadField: r2 = r0->field_1b
    //     0xb62558: ldur            w2, [x0, #0x1b]
    // 0xb6255c: DecompressPointer r2
    //     0xb6255c: add             x2, x2, HEAP, lsl #32
    // 0xb62560: stp             x1, x2, [SP]
    // 0xb62564: r0 = call 0xb01138
    //     0xb62564: bl              #0xb01138
    // 0xb62568: ldur            x2, [fp, #-0x10]
    // 0xb6256c: StoreField: r2->field_1b = r0
    //     0xb6256c: stur            w0, [x2, #0x1b]
    //     0xb62570: tbz             w0, #0, #0xb6258c
    //     0xb62574: ldurb           w16, [x2, #-1]
    //     0xb62578: ldurb           w17, [x0, #-1]
    //     0xb6257c: and             x16, x17, x16, lsr #2
    //     0xb62580: tst             x16, HEAP, lsr #32
    //     0xb62584: b.eq            #0xb6258c
    //     0xb62588: bl              #0xc53f94  ; WriteBarrierWrappersStub
    // 0xb6258c: ldur            x0, [fp, #-0x38]
    // 0xb62590: cmp             w0, NULL
    // 0xb62594: b.eq            #0xb6270c
    // 0xb62598: r1 = LoadInt32Instr(r0)
    //     0xb62598: sbfx            x1, x0, #1, #0x1f
    //     0xb6259c: tbz             w0, #0, #0xb625a4
    //     0xb625a0: ldur            x1, [x0, #7]
    // 0xb625a4: cmp             x1, #0
    // 0xb625a8: b.le            #0xb626fc
    // 0xb625ac: LoadField: r0 = r2->field_1f
    //     0xb625ac: ldur            w0, [x2, #0x1f]
    // 0xb625b0: DecompressPointer r0
    //     0xb625b0: add             x0, x0, HEAP, lsl #32
    // 0xb625b4: r1 = LoadInt32Instr(r0)
    //     0xb625b4: sbfx            x1, x0, #1, #0x1f
    //     0xb625b8: tbz             w0, #0, #0xb625c0
    //     0xb625bc: ldur            x1, [x0, #7]
    // 0xb625c0: cmp             x1, #0
    // 0xb625c4: b.le            #0xb626fc
    // 0xb625c8: ldur            x0, [fp, #-0x20]
    // 0xb625cc: cmp             w0, NULL
    // 0xb625d0: b.eq            #0xb626fc
    // 0xb625d4: ldur            x3, [fp, #-0x18]
    // 0xb625d8: cmp             w3, NULL
    // 0xb625dc: b.eq            #0xb626fc
    // 0xb625e0: LoadField: r4 = r0->field_4f
    //     0xb625e0: ldur            x4, [x0, #0x4f]
    // 0xb625e4: sub             x0, x4, x1
    // 0xb625e8: tbz             x0, #0x3f, #0xb625f0
    // 0xb625ec: r0 = 0
    //     0xb625ec: movz            x0, #0
    // 0xb625f0: ldur            x1, [fp, #-0x30]
    // 0xb625f4: stur            x0, [fp, #-0x28]
    // 0xb625f8: r0 = call 0x3e0f38
    //     0xb625f8: bl              #0x3e0f38
    // 0xb625fc: mov             x3, x0
    // 0xb62600: ldur            x2, [fp, #-0x28]
    // 0xb62604: stur            x3, [fp, #-0x30]
    // 0xb62608: r0 = BoxInt64Instr(r2)
    //     0xb62608: sbfiz           x0, x2, #1, #0x1f
    //     0xb6260c: cmp             x2, x0, asr #1
    //     0xb62610: b.eq            #0xb6261c
    //     0xb62614: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb62618: stur            x2, [x0, #7]
    // 0xb6261c: r1 = <int?>
    //     0xb6261c: ldr             x1, [PP, #0x18c8]  ; [pp+0x18c8] TypeArguments: <int?>
    // 0xb62620: stur            x0, [fp, #-0x20]
    // 0xb62624: r0 = GH()
    //     0xb62624: bl              #0xb38c00  ; AllocateGHStub -> GH<X0> (size=0x14)
    // 0xb62628: mov             x2, x0
    // 0xb6262c: ldur            x0, [fp, #-0x20]
    // 0xb62630: stur            x2, [fp, #-0x38]
    // 0xb62634: StoreField: r2->field_f = r0
    //     0xb62634: stur            w0, [x2, #0xf]
    // 0xb62638: r0 = true
    //     0xb62638: add             x0, NULL, #0x20  ; true
    // 0xb6263c: StoreField: r2->field_b = r0
    //     0xb6263c: stur            w0, [x2, #0xb]
    // 0xb62640: r1 = <PVa>
    //     0xb62640: add             x1, PP, #0x2b, lsl #12  ; [pp+0x2b918] TypeArguments: <PVa>
    //     0xb62644: ldr             x1, [x1, #0x918]
    // 0xb62648: r0 = QVa()
    //     0xb62648: bl              #0xb4b3bc  ; AllocateQVaStub -> QVa (size=0x54)
    // 0xb6264c: mov             x1, x0
    // 0xb62650: r0 = Instance_GH
    //     0xb62650: add             x0, PP, #0x29, lsl #12  ; [pp+0x293b0] Obj!GH<String?>@675341
    //     0xb62654: ldr             x0, [x0, #0x3b0]
    // 0xb62658: StoreField: r1->field_b = r0
    //     0xb62658: stur            w0, [x1, #0xb]
    // 0xb6265c: StoreField: r1->field_f = r0
    //     0xb6265c: stur            w0, [x1, #0xf]
    // 0xb62660: r2 = Instance_GH
    //     0xb62660: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2a4d0] Obj!GH<int?>@675381
    //     0xb62664: ldr             x2, [x2, #0x4d0]
    // 0xb62668: StoreField: r1->field_13 = r2
    //     0xb62668: stur            w2, [x1, #0x13]
    // 0xb6266c: ArrayStore: r1[0] = r0  ; List_4
    //     0xb6266c: stur            w0, [x1, #0x17]
    // 0xb62670: StoreField: r1->field_1b = r2
    //     0xb62670: stur            w2, [x1, #0x1b]
    // 0xb62674: ldur            x3, [fp, #-0x38]
    // 0xb62678: StoreField: r1->field_1f = r3
    //     0xb62678: stur            w3, [x1, #0x1f]
    // 0xb6267c: StoreField: r1->field_23 = r2
    //     0xb6267c: stur            w2, [x1, #0x23]
    // 0xb62680: StoreField: r1->field_27 = r0
    //     0xb62680: stur            w0, [x1, #0x27]
    // 0xb62684: StoreField: r1->field_2b = r0
    //     0xb62684: stur            w0, [x1, #0x2b]
    // 0xb62688: StoreField: r1->field_2f = r2
    //     0xb62688: stur            w2, [x1, #0x2f]
    // 0xb6268c: StoreField: r1->field_33 = r2
    //     0xb6268c: stur            w2, [x1, #0x33]
    // 0xb62690: StoreField: r1->field_37 = r2
    //     0xb62690: stur            w2, [x1, #0x37]
    // 0xb62694: StoreField: r1->field_3b = r2
    //     0xb62694: stur            w2, [x1, #0x3b]
    // 0xb62698: StoreField: r1->field_3f = r2
    //     0xb62698: stur            w2, [x1, #0x3f]
    // 0xb6269c: StoreField: r1->field_43 = r0
    //     0xb6269c: stur            w0, [x1, #0x43]
    // 0xb626a0: r0 = Instance_GH
    //     0xb626a0: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b920] Obj!GH<int>@6753c1
    //     0xb626a4: ldr             x0, [x0, #0x920]
    // 0xb626a8: StoreField: r1->field_47 = r0
    //     0xb626a8: stur            w0, [x1, #0x47]
    // 0xb626ac: r2 = Instance_GH
    //     0xb626ac: add             x2, PP, #0x2b, lsl #12  ; [pp+0x2b928] Obj!GH<String>@6753a1
    //     0xb626b0: ldr             x2, [x2, #0x928]
    // 0xb626b4: StoreField: r1->field_4b = r2
    //     0xb626b4: stur            w2, [x1, #0x4b]
    // 0xb626b8: StoreField: r1->field_4f = r0
    //     0xb626b8: stur            w0, [x1, #0x4f]
    // 0xb626bc: mov             x3, x1
    // 0xb626c0: ldur            x1, [fp, #-0x30]
    // 0xb626c4: ldur            x2, [fp, #-0x18]
    // 0xb626c8: r0 = __unknown_function__()
    //     0xb626c8: bl              #0xb4ad80  ; [] ::__unknown_function__
    // 0xb626cc: mov             x1, x0
    // 0xb626d0: stur            x1, [fp, #-0x18]
    // 0xb626d4: r0 = Await()
    //     0xb626d4: bl              #0xb0c534  ; AwaitStub
    // 0xb626d8: ldur            x1, [fp, #-0x10]
    // 0xb626dc: StoreField: r1->field_23 = r0
    //     0xb626dc: stur            w0, [x1, #0x23]
    //     0xb626e0: tbz             w0, #0, #0xb626fc
    //     0xb626e4: ldurb           w16, [x1, #-1]
    //     0xb626e8: ldurb           w17, [x0, #-1]
    //     0xb626ec: and             x16, x17, x16, lsr #2
    //     0xb626f0: tst             x16, HEAP, lsr #32
    //     0xb626f4: b.eq            #0xb626fc
    //     0xb626f8: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xb626fc: r0 = Null
    //     0xb626fc: mov             x0, NULL
    // 0xb62700: r0 = ReturnAsyncNotFuture()
    //     0xb62700: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb62704: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb62704: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb62708: b               #0xb62324
    // 0xb6270c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb6270c: bl              #0xc560a8  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb63fc4, size: 0x79c
    // 0xb63fc4: EnterFrame
    //     0xb63fc4: stp             fp, lr, [SP, #-0x10]!
    //     0xb63fc8: mov             fp, SP
    // 0xb63fcc: AllocStack(0x80)
    //     0xb63fcc: sub             SP, SP, #0x80
    // 0xb63fd0: SetupParameters(dynamic _ /* r1 */)
    //     0xb63fd0: stur            NULL, [fp, #-8]
    //     0xb63fd4: movz            x0, #0
    //     0xb63fd8: add             x1, fp, w0, sxtw #2
    //     0xb63fdc: ldr             x1, [x1, #0x18]
    //     0xb63fe0: ldur            w2, [x1, #0x17]
    //     0xb63fe4: add             x2, x2, HEAP, lsl #32
    //     0xb63fe8: stur            x2, [fp, #-0x10]
    // 0xb63fec: CheckStackOverflow
    //     0xb63fec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb63ff0: cmp             SP, x16
    //     0xb63ff4: b.ls            #0xb6473c
    // 0xb63ff8: InitAsync() -> Future<int>
    //     0xb63ff8: ldr             x0, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    //     0xb63ffc: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb64000: ldur            x0, [fp, #-0x10]
    // 0xb64004: LoadField: r3 = r0->field_13
    //     0xb64004: ldur            w3, [x0, #0x13]
    // 0xb64008: DecompressPointer r3
    //     0xb64008: add             x3, x3, HEAP, lsl #32
    // 0xb6400c: stur            x3, [fp, #-0x18]
    // 0xb64010: r1 = Function '<anonymous closure>': static.
    //     0xb64010: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c688] AnonymousClosure: static (0x3ae590), in [dart:_http] _Vo::jKk (0x3c7b9c)
    //     0xb64014: ldr             x1, [x1, #0x688]
    // 0xb64018: r2 = Null
    //     0xb64018: mov             x2, NULL
    // 0xb6401c: r0 = AllocateClosure()
    //     0xb6401c: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb64020: r16 = <String>
    //     0xb64020: ldr             x16, [PP, #0x928]  ; [pp+0x928] TypeArguments: <String>
    // 0xb64024: ldur            lr, [fp, #-0x18]
    // 0xb64028: stp             lr, x16, [SP, #8]
    // 0xb6402c: str             x0, [SP]
    // 0xb64030: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb64030: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb64034: r0 = call 0x7c5c34
    //     0xb64034: bl              #0x7c5c34
    // 0xb64038: r1 = Function '<anonymous closure>': static.
    //     0xb64038: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c690] AnonymousClosure: static (0x39da88), of [gMm] HP
    //     0xb6403c: ldr             x1, [x1, #0x690]
    // 0xb64040: r2 = Null
    //     0xb64040: mov             x2, NULL
    // 0xb64044: stur            x0, [fp, #-0x18]
    // 0xb64048: r0 = AllocateClosure()
    //     0xb64048: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6404c: ldur            x1, [fp, #-0x18]
    // 0xb64050: mov             x2, x0
    // 0xb64054: r0 = call 0x5cf9c8
    //     0xb64054: bl              #0x5cf9c8
    // 0xb64058: mov             x1, x0
    // 0xb6405c: r0 = call 0x5b256c
    //     0xb6405c: bl              #0x5b256c
    // 0xb64060: mov             x1, x0
    // 0xb64064: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb64064: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb64068: r0 = call 0x82630c
    //     0xb64068: bl              #0x82630c
    // 0xb6406c: r1 = <qWa>
    //     0xb6406c: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c0e8] TypeArguments: <qWa>
    //     0xb64070: ldr             x1, [x1, #0xe8]
    // 0xb64074: r2 = 0
    //     0xb64074: movz            x2, #0
    // 0xb64078: stur            x0, [fp, #-0x18]
    // 0xb6407c: r0 = call 0x358510
    //     0xb6407c: bl              #0x358510
    // 0xb64080: mov             x4, x0
    // 0xb64084: ldur            x3, [fp, #-0x18]
    // 0xb64088: stur            x4, [fp, #-0x50]
    // 0xb6408c: LoadField: r5 = r3->field_7
    //     0xb6408c: ldur            w5, [x3, #7]
    // 0xb64090: DecompressPointer r5
    //     0xb64090: add             x5, x5, HEAP, lsl #32
    // 0xb64094: stur            x5, [fp, #-0x48]
    // 0xb64098: LoadField: r0 = r3->field_b
    //     0xb64098: ldur            w0, [x3, #0xb]
    // 0xb6409c: r6 = LoadInt32Instr(r0)
    //     0xb6409c: sbfx            x6, x0, #1, #0x1f
    // 0xb640a0: ldur            x7, [fp, #-0x10]
    // 0xb640a4: stur            x6, [fp, #-0x40]
    // 0xb640a8: LoadField: r8 = r7->field_f
    //     0xb640a8: ldur            w8, [x7, #0xf]
    // 0xb640ac: DecompressPointer r8
    //     0xb640ac: add             x8, x8, HEAP, lsl #32
    // 0xb640b0: stur            x8, [fp, #-0x38]
    // 0xb640b4: r9 = 0
    //     0xb640b4: movz            x9, #0
    // 0xb640b8: r0 = 0
    //     0xb640b8: movz            x0, #0
    // 0xb640bc: stur            x9, [fp, #-0x30]
    // 0xb640c0: CheckStackOverflow
    //     0xb640c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb640c4: cmp             SP, x16
    //     0xb640c8: b.ls            #0xb64744
    // 0xb640cc: LoadField: r1 = r3->field_b
    //     0xb640cc: ldur            w1, [x3, #0xb]
    // 0xb640d0: r2 = LoadInt32Instr(r1)
    //     0xb640d0: sbfx            x2, x1, #1, #0x1f
    // 0xb640d4: cmp             x6, x2
    // 0xb640d8: b.ne            #0xb6471c
    // 0xb640dc: cmp             x0, x2
    // 0xb640e0: b.ge            #0xb64338
    // 0xb640e4: LoadField: r1 = r3->field_f
    //     0xb640e4: ldur            w1, [x3, #0xf]
    // 0xb640e8: DecompressPointer r1
    //     0xb640e8: add             x1, x1, HEAP, lsl #32
    // 0xb640ec: ArrayLoad: r10 = r1[r0]  ; Unknown_4
    //     0xb640ec: add             x16, x1, x0, lsl #2
    //     0xb640f0: ldur            w10, [x16, #0xf]
    // 0xb640f4: DecompressPointer r10
    //     0xb640f4: add             x10, x10, HEAP, lsl #32
    // 0xb640f8: stur            x10, [fp, #-0x28]
    // 0xb640fc: add             x11, x0, #1
    // 0xb64100: stur            x11, [fp, #-0x20]
    // 0xb64104: cmp             w10, NULL
    // 0xb64108: b.ne            #0xb6413c
    // 0xb6410c: mov             x0, x10
    // 0xb64110: mov             x2, x5
    // 0xb64114: r1 = Null
    //     0xb64114: mov             x1, NULL
    // 0xb64118: cmp             w2, NULL
    // 0xb6411c: b.eq            #0xb6413c
    // 0xb64120: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb64120: ldur            w4, [x2, #0x17]
    // 0xb64124: DecompressPointer r4
    //     0xb64124: add             x4, x4, HEAP, lsl #32
    // 0xb64128: r8 = X0
    //     0xb64128: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xb6412c: LoadField: r9 = r4->field_7
    //     0xb6412c: ldur            x9, [x4, #7]
    // 0xb64130: r3 = Null
    //     0xb64130: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c698] Null
    //     0xb64134: ldr             x3, [x3, #0x698]
    // 0xb64138: blr             x9
    // 0xb6413c: ldur            x0, [fp, #-0x10]
    // 0xb64140: LoadField: r3 = r0->field_1b
    //     0xb64140: ldur            w3, [x0, #0x1b]
    // 0xb64144: DecompressPointer r3
    //     0xb64144: add             x3, x3, HEAP, lsl #32
    // 0xb64148: r16 = true
    //     0xb64148: add             x16, NULL, #0x20  ; true
    // 0xb6414c: str             x16, [SP]
    // 0xb64150: ldur            x1, [fp, #-0x38]
    // 0xb64154: ldur            x2, [fp, #-0x28]
    // 0xb64158: r4 = const [0, 0x4, 0x1, 0x3, lWh, 0x3, null]
    //     0xb64158: add             x4, PP, #0x2b, lsl #12  ; [pp+0x2ba78] List(7) [0, 0x4, 0x1, 0x3, "lWh", 0x3, Null]
    //     0xb6415c: ldr             x4, [x4, #0xa78]
    // 0xb64160: r0 = __unknown_function__()
    //     0xb64160: bl              #0xb553a0  ; [] ::__unknown_function__
    // 0xb64164: mov             x1, x0
    // 0xb64168: stur            x1, [fp, #-0x58]
    // 0xb6416c: r0 = Await()
    //     0xb6416c: bl              #0xb0c534  ; AwaitStub
    // 0xb64170: stur            x0, [fp, #-0x60]
    // 0xb64174: cmp             w0, NULL
    // 0xb64178: b.ne            #0xb64188
    // 0xb6417c: ldur            x9, [fp, #-0x30]
    // 0xb64180: ldur            x3, [fp, #-0x50]
    // 0xb64184: b               #0xb64318
    // 0xb64188: LoadField: r1 = r0->field_3f
    //     0xb64188: ldur            w1, [x0, #0x3f]
    // 0xb6418c: DecompressPointer r1
    //     0xb6418c: add             x1, x1, HEAP, lsl #32
    // 0xb64190: cmp             w1, #2
    // 0xb64194: b.eq            #0xb64308
    // 0xb64198: ldur            x1, [fp, #-0x10]
    // 0xb6419c: ldur            x4, [fp, #-0x30]
    // 0xb641a0: ldur            x2, [fp, #-0x38]
    // 0xb641a4: ldur            x5, [fp, #-0x28]
    // 0xb641a8: r3 = 2
    //     0xb641a8: movz            x3, #0x2
    // 0xb641ac: StoreField: r0->field_3f = r3
    //     0xb641ac: stur            w3, [x0, #0x3f]
    // 0xb641b0: LoadField: r6 = r1->field_1b
    //     0xb641b0: ldur            w6, [x1, #0x1b]
    // 0xb641b4: DecompressPointer r6
    //     0xb641b4: add             x6, x6, HEAP, lsl #32
    // 0xb641b8: stur            x6, [fp, #-0x58]
    // 0xb641bc: r1 = 5
    //     0xb641bc: movz            x1, #0x5
    // 0xb641c0: r0 = AllocateContext()
    //     0xb641c0: bl              #0xc547b8  ; AllocateContextStub
    // 0xb641c4: mov             x1, x0
    // 0xb641c8: ldur            x0, [fp, #-0x38]
    // 0xb641cc: StoreField: r1->field_f = r0
    //     0xb641cc: stur            w0, [x1, #0xf]
    // 0xb641d0: ldur            x3, [fp, #-0x60]
    // 0xb641d4: StoreField: r1->field_13 = r3
    //     0xb641d4: stur            w3, [x1, #0x13]
    // 0xb641d8: ldur            x4, [fp, #-0x28]
    // 0xb641dc: ArrayStore: r1[0] = r4  ; List_4
    //     0xb641dc: stur            w4, [x1, #0x17]
    // 0xb641e0: ldur            x2, [fp, #-0x58]
    // 0xb641e4: StoreField: r1->field_1b = r2
    //     0xb641e4: stur            w2, [x1, #0x1b]
    // 0xb641e8: r5 = false
    //     0xb641e8: add             x5, NULL, #0x30  ; false
    // 0xb641ec: StoreField: r1->field_1f = r5
    //     0xb641ec: stur            w5, [x1, #0x1f]
    // 0xb641f0: mov             x2, x1
    // 0xb641f4: r1 = Function '<anonymous closure>': static.
    //     0xb641f4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c510] AnonymousClosure: static (0xb60308), of [fbn] 
    //     0xb641f8: ldr             x1, [x1, #0x510]
    // 0xb641fc: r0 = AllocateClosure()
    //     0xb641fc: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb64200: r16 = <int>
    //     0xb64200: ldr             x16, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    // 0xb64204: ldur            lr, [fp, #-0x38]
    // 0xb64208: stp             lr, x16, [SP, #8]
    // 0xb6420c: str             x0, [SP]
    // 0xb64210: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb64210: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb64214: r0 = __unknown_function__()
    //     0xb64214: bl              #0xb39ce8  ; [] ::__unknown_function__
    // 0xb64218: mov             x1, x0
    // 0xb6421c: stur            x1, [fp, #-0x58]
    // 0xb64220: r0 = Await()
    //     0xb64220: bl              #0xb0c534  ; AwaitStub
    // 0xb64224: mov             x3, x0
    // 0xb64228: ldur            x2, [fp, #-0x30]
    // 0xb6422c: stur            x3, [fp, #-0x28]
    // 0xb64230: r0 = BoxInt64Instr(r2)
    //     0xb64230: sbfiz           x0, x2, #1, #0x1f
    //     0xb64234: cmp             x2, x0, asr #1
    //     0xb64238: b.eq            #0xb64244
    //     0xb6423c: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb64240: stur            x2, [x0, #7]
    // 0xb64244: stp             x3, x0, [SP]
    // 0xb64248: r0 = call 0xb01138
    //     0xb64248: bl              #0xb01138
    // 0xb6424c: mov             x2, x0
    // 0xb64250: ldur            x0, [fp, #-0x28]
    // 0xb64254: stur            x2, [fp, #-0x58]
    // 0xb64258: cmp             w0, NULL
    // 0xb6425c: b.eq            #0xb6474c
    // 0xb64260: r1 = LoadInt32Instr(r0)
    //     0xb64260: sbfx            x1, x0, #1, #0x1f
    //     0xb64264: tbz             w0, #0, #0xb6426c
    //     0xb64268: ldur            x1, [x0, #7]
    // 0xb6426c: cmp             x1, #0
    // 0xb64270: b.le            #0xb642f0
    // 0xb64274: ldur            x0, [fp, #-0x50]
    // 0xb64278: LoadField: r1 = r0->field_b
    //     0xb64278: ldur            w1, [x0, #0xb]
    // 0xb6427c: LoadField: r3 = r0->field_f
    //     0xb6427c: ldur            w3, [x0, #0xf]
    // 0xb64280: DecompressPointer r3
    //     0xb64280: add             x3, x3, HEAP, lsl #32
    // 0xb64284: LoadField: r4 = r3->field_b
    //     0xb64284: ldur            w4, [x3, #0xb]
    // 0xb64288: r3 = LoadInt32Instr(r1)
    //     0xb64288: sbfx            x3, x1, #1, #0x1f
    // 0xb6428c: stur            x3, [fp, #-0x68]
    // 0xb64290: r1 = LoadInt32Instr(r4)
    //     0xb64290: sbfx            x1, x4, #1, #0x1f
    // 0xb64294: cmp             x3, x1
    // 0xb64298: b.ne            #0xb642a4
    // 0xb6429c: mov             x1, x0
    // 0xb642a0: r0 = call 0x35fcec
    //     0xb642a0: bl              #0x35fcec
    // 0xb642a4: ldur            x3, [fp, #-0x50]
    // 0xb642a8: ldur            x2, [fp, #-0x68]
    // 0xb642ac: add             x0, x2, #1
    // 0xb642b0: lsl             x1, x0, #1
    // 0xb642b4: StoreField: r3->field_b = r1
    //     0xb642b4: stur            w1, [x3, #0xb]
    // 0xb642b8: LoadField: r1 = r3->field_f
    //     0xb642b8: ldur            w1, [x3, #0xf]
    // 0xb642bc: DecompressPointer r1
    //     0xb642bc: add             x1, x1, HEAP, lsl #32
    // 0xb642c0: ldur            x0, [fp, #-0x60]
    // 0xb642c4: ArrayStore: r1[r2] = r0  ; List_4
    //     0xb642c4: add             x25, x1, x2, lsl #2
    //     0xb642c8: add             x25, x25, #0xf
    //     0xb642cc: str             w0, [x25]
    //     0xb642d0: tbz             w0, #0, #0xb642ec
    //     0xb642d4: ldurb           w16, [x1, #-1]
    //     0xb642d8: ldurb           w17, [x0, #-1]
    //     0xb642dc: and             x16, x17, x16, lsr #2
    //     0xb642e0: tst             x16, HEAP, lsr #32
    //     0xb642e4: b.eq            #0xb642ec
    //     0xb642e8: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xb642ec: b               #0xb642f4
    // 0xb642f0: ldur            x3, [fp, #-0x50]
    // 0xb642f4: ldur            x0, [fp, #-0x58]
    // 0xb642f8: r1 = LoadInt32Instr(r0)
    //     0xb642f8: sbfx            x1, x0, #1, #0x1f
    //     0xb642fc: tbz             w0, #0, #0xb64304
    //     0xb64300: ldur            x1, [x0, #7]
    // 0xb64304: b               #0xb64314
    // 0xb64308: ldur            x3, [fp, #-0x50]
    // 0xb6430c: ldur            x2, [fp, #-0x30]
    // 0xb64310: mov             x1, x2
    // 0xb64314: mov             x9, x1
    // 0xb64318: ldur            x0, [fp, #-0x20]
    // 0xb6431c: ldur            x7, [fp, #-0x10]
    // 0xb64320: mov             x4, x3
    // 0xb64324: ldur            x3, [fp, #-0x18]
    // 0xb64328: ldur            x8, [fp, #-0x38]
    // 0xb6432c: ldur            x5, [fp, #-0x48]
    // 0xb64330: ldur            x6, [fp, #-0x40]
    // 0xb64334: b               #0xb640bc
    // 0xb64338: mov             x0, x7
    // 0xb6433c: mov             x16, x4
    // 0xb64340: mov             x4, x3
    // 0xb64344: mov             x3, x16
    // 0xb64348: mov             x2, x9
    // 0xb6434c: ldur            x1, [fp, #-0x38]
    // 0xb64350: r0 = call 0x3e0f38
    //     0xb64350: bl              #0x3e0f38
    // 0xb64354: mov             x1, x0
    // 0xb64358: ldur            x0, [fp, #-0x10]
    // 0xb6435c: LoadField: r2 = r0->field_1b
    //     0xb6435c: ldur            w2, [x0, #0x1b]
    // 0xb64360: DecompressPointer r2
    //     0xb64360: add             x2, x2, HEAP, lsl #32
    // 0xb64364: ldur            x3, [fp, #-0x18]
    // 0xb64368: r0 = __unknown_function__()
    //     0xb64368: bl              #0xb648c4  ; [] ::__unknown_function__
    // 0xb6436c: mov             x1, x0
    // 0xb64370: stur            x1, [fp, #-0x28]
    // 0xb64374: r0 = Await()
    //     0xb64374: bl              #0xb0c534  ; AwaitStub
    // 0xb64378: mov             x3, x0
    // 0xb6437c: ldur            x2, [fp, #-0x30]
    // 0xb64380: r0 = BoxInt64Instr(r2)
    //     0xb64380: sbfiz           x0, x2, #1, #0x1f
    //     0xb64384: cmp             x2, x0, asr #1
    //     0xb64388: b.eq            #0xb64394
    //     0xb6438c: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb64390: stur            x2, [x0, #7]
    // 0xb64394: stp             x3, x0, [SP]
    // 0xb64398: r0 = call 0xb01138
    //     0xb64398: bl              #0xb01138
    // 0xb6439c: ldur            x1, [fp, #-0x38]
    // 0xb643a0: ldur            x2, [fp, #-0x18]
    // 0xb643a4: stur            x0, [fp, #-0x28]
    // 0xb643a8: r0 = call 0x44ca44
    //     0xb643a8: bl              #0x44ca44
    // 0xb643ac: mov             x1, x0
    // 0xb643b0: stur            x1, [fp, #-0x58]
    // 0xb643b4: r0 = Await()
    //     0xb643b4: bl              #0xb0c534  ; AwaitStub
    // 0xb643b8: ldur            x3, [fp, #-0x18]
    // 0xb643bc: LoadField: r0 = r3->field_b
    //     0xb643bc: ldur            w0, [x3, #0xb]
    // 0xb643c0: r4 = LoadInt32Instr(r0)
    //     0xb643c0: sbfx            x4, x0, #1, #0x1f
    // 0xb643c4: stur            x4, [fp, #-0x30]
    // 0xb643c8: r0 = 0
    //     0xb643c8: movz            x0, #0
    // 0xb643cc: ldur            x5, [fp, #-0x10]
    // 0xb643d0: ldur            x6, [fp, #-0x38]
    // 0xb643d4: CheckStackOverflow
    //     0xb643d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb643d8: cmp             SP, x16
    //     0xb643dc: b.ls            #0xb64750
    // 0xb643e0: LoadField: r1 = r3->field_b
    //     0xb643e0: ldur            w1, [x3, #0xb]
    // 0xb643e4: r2 = LoadInt32Instr(r1)
    //     0xb643e4: sbfx            x2, x1, #1, #0x1f
    // 0xb643e8: cmp             x4, x2
    // 0xb643ec: b.ne            #0xb646fc
    // 0xb643f0: cmp             x0, x2
    // 0xb643f4: b.ge            #0xb645c0
    // 0xb643f8: LoadField: r1 = r3->field_f
    //     0xb643f8: ldur            w1, [x3, #0xf]
    // 0xb643fc: DecompressPointer r1
    //     0xb643fc: add             x1, x1, HEAP, lsl #32
    // 0xb64400: ArrayLoad: r7 = r1[r0]  ; Unknown_4
    //     0xb64400: add             x16, x1, x0, lsl #2
    //     0xb64404: ldur            w7, [x16, #0xf]
    // 0xb64408: DecompressPointer r7
    //     0xb64408: add             x7, x7, HEAP, lsl #32
    // 0xb6440c: stur            x7, [fp, #-0x58]
    // 0xb64410: add             x8, x0, #1
    // 0xb64414: stur            x8, [fp, #-0x20]
    // 0xb64418: cmp             w7, NULL
    // 0xb6441c: b.ne            #0xb64450
    // 0xb64420: mov             x0, x7
    // 0xb64424: ldur            x2, [fp, #-0x48]
    // 0xb64428: r1 = Null
    //     0xb64428: mov             x1, NULL
    // 0xb6442c: cmp             w2, NULL
    // 0xb64430: b.eq            #0xb64450
    // 0xb64434: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb64434: ldur            w4, [x2, #0x17]
    // 0xb64438: DecompressPointer r4
    //     0xb64438: add             x4, x4, HEAP, lsl #32
    // 0xb6443c: r8 = X0
    //     0xb6443c: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xb64440: LoadField: r9 = r4->field_7
    //     0xb64440: ldur            x9, [x4, #7]
    // 0xb64444: r3 = Null
    //     0xb64444: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c6a8] Null
    //     0xb64448: ldr             x3, [x3, #0x6a8]
    // 0xb6444c: blr             x9
    // 0xb64450: ldur            x0, [fp, #-0x10]
    // 0xb64454: LoadField: r2 = r0->field_1b
    //     0xb64454: ldur            w2, [x0, #0x1b]
    // 0xb64458: DecompressPointer r2
    //     0xb64458: add             x2, x2, HEAP, lsl #32
    // 0xb6445c: ldur            x1, [fp, #-0x38]
    // 0xb64460: stur            x2, [fp, #-0x60]
    // 0xb64464: r0 = call 0x3e0f38
    //     0xb64464: bl              #0x3e0f38
    // 0xb64468: mov             x1, x0
    // 0xb6446c: ldur            x2, [fp, #-0x60]
    // 0xb64470: ldur            x3, [fp, #-0x58]
    // 0xb64474: r0 = __unknown_function__()
    //     0xb64474: bl              #0xb64760  ; [] ::__unknown_function__
    // 0xb64478: mov             x1, x0
    // 0xb6447c: stur            x1, [fp, #-0x60]
    // 0xb64480: r0 = Await()
    //     0xb64480: bl              #0xb0c534  ; AwaitStub
    // 0xb64484: cmp             w0, NULL
    // 0xb64488: b.eq            #0xb645b0
    // 0xb6448c: ldur            x0, [fp, #-0x10]
    // 0xb64490: LoadField: r2 = r0->field_1b
    //     0xb64490: ldur            w2, [x0, #0x1b]
    // 0xb64494: DecompressPointer r2
    //     0xb64494: add             x2, x2, HEAP, lsl #32
    // 0xb64498: ldur            x1, [fp, #-0x38]
    // 0xb6449c: stur            x2, [fp, #-0x60]
    // 0xb644a0: r0 = call 0x3e0f38
    //     0xb644a0: bl              #0x3e0f38
    // 0xb644a4: mov             x1, x0
    // 0xb644a8: ldur            x2, [fp, #-0x60]
    // 0xb644ac: ldur            x3, [fp, #-0x58]
    // 0xb644b0: r0 = __unknown_function__()
    //     0xb644b0: bl              #0xb3d160  ; [] ::__unknown_function__
    // 0xb644b4: mov             x1, x0
    // 0xb644b8: stur            x1, [fp, #-0x60]
    // 0xb644bc: r0 = Await()
    //     0xb644bc: bl              #0xb0c534  ; AwaitStub
    // 0xb644c0: r0 = InitLateStaticField(0x3e4) // [dart:async] s::_current
    //     0xb644c0: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb644c4: ldr             x0, [x0, #0x7c8]
    //     0xb644c8: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb644cc: cmp             w0, w16
    //     0xb644d0: b.ne            #0xb644dc
    //     0xb644d4: ldr             x2, [PP, #0x2f0]  ; [pp+0x2f0] Field <s._current@5048458>: static late (offset: 0x3e4)
    //     0xb644d8: bl              #0xc5392c  ; InitLateStaticFieldStub
    // 0xb644dc: stur            x0, [fp, #-0x58]
    // 0xb644e0: r0 = InitLateStaticField(0x14e4) // [fbn] iVa::_ITh
    //     0xb644e0: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb644e4: ldr             x0, [x0, #0x29c8]
    //     0xb644e8: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb644ec: cmp             w0, w16
    //     0xb644f0: b.ne            #0xb64500
    //     0xb644f4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28d20] Field <iVa._ITh@1448078468>: static late final (offset: 0x14e4)
    //     0xb644f8: ldr             x2, [x2, #0xd20]
    //     0xb644fc: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb64500: ldur            x1, [fp, #-0x58]
    // 0xb64504: r2 = LoadClassIdInstr(r1)
    //     0xb64504: ldur            x2, [x1, #-1]
    //     0xb64508: ubfx            x2, x2, #0xc, #0x14
    // 0xb6450c: mov             x16, x0
    // 0xb64510: mov             x0, x2
    // 0xb64514: mov             x2, x16
    // 0xb64518: r0 = GDT[cid_x0 + -0xfe1]()
    //     0xb64518: sub             lr, x0, #0xfe1
    //     0xb6451c: ldr             lr, [x21, lr, lsl #3]
    //     0xb64520: blr             lr
    // 0xb64524: r1 = 60
    //     0xb64524: movz            x1, #0x3c
    // 0xb64528: branchIfSmi(r0, 0xb64534)
    //     0xb64528: tbz             w0, #0, #0xb64534
    // 0xb6452c: r1 = LoadClassIdInstr(r0)
    //     0xb6452c: ldur            x1, [x0, #-1]
    //     0xb64530: ubfx            x1, x1, #0xc, #0x14
    // 0xb64534: cmp             x1, #0x71c
    // 0xb64538: b.ne            #0xb64578
    // 0xb6453c: ldur            x1, [fp, #-0x38]
    // 0xb64540: LoadField: r2 = r1->field_27
    //     0xb64540: ldur            w2, [x1, #0x27]
    // 0xb64544: DecompressPointer r2
    //     0xb64544: add             x2, x2, HEAP, lsl #32
    // 0xb64548: tbnz            w2, #4, #0xb646bc
    // 0xb6454c: LoadField: r2 = r1->field_1f
    //     0xb6454c: ldur            x2, [x1, #0x1f]
    // 0xb64550: LoadField: r3 = r0->field_b
    //     0xb64550: ldur            x3, [x0, #0xb]
    // 0xb64554: cmp             x2, x3
    // 0xb64558: b.ne            #0xb646bc
    // 0xb6455c: LoadField: r2 = r1->field_7
    //     0xb6455c: ldur            w2, [x1, #7]
    // 0xb64560: DecompressPointer r2
    //     0xb64560: add             x2, x2, HEAP, lsl #32
    // 0xb64564: LoadField: r3 = r0->field_7
    //     0xb64564: ldur            w3, [x0, #7]
    // 0xb64568: DecompressPointer r3
    //     0xb64568: add             x3, x3, HEAP, lsl #32
    // 0xb6456c: cmp             w2, w3
    // 0xb64570: b.eq            #0xb6457c
    // 0xb64574: b               #0xb646bc
    // 0xb64578: ldur            x1, [fp, #-0x38]
    // 0xb6457c: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb6457c: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb64580: ldr             x0, [x0, #0x29b8]
    //     0xb64584: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb64588: cmp             w0, w16
    //     0xb6458c: b.ne            #0xb6459c
    //     0xb64590: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb64594: ldr             x2, [x2, #0xa78]
    //     0xb64598: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb6459c: stur            x0, [fp, #-0x58]
    // 0xb645a0: r0 = CWa()
    //     0xb645a0: bl              #0xb3d800  ; AllocateCWaStub -> CWa (size=0x8)
    // 0xb645a4: ldur            x1, [fp, #-0x58]
    // 0xb645a8: mov             x2, x0
    // 0xb645ac: r0 = call 0x43b000
    //     0xb645ac: bl              #0x43b000
    // 0xb645b0: ldur            x0, [fp, #-0x20]
    // 0xb645b4: ldur            x3, [fp, #-0x18]
    // 0xb645b8: ldur            x4, [fp, #-0x30]
    // 0xb645bc: b               #0xb643cc
    // 0xb645c0: ldur            x0, [fp, #-0x28]
    // 0xb645c4: ldur            x1, [fp, #-0x38]
    // 0xb645c8: r0 = call 0x430ba8
    //     0xb645c8: bl              #0x430ba8
    // 0xb645cc: ldur            x0, [fp, #-0x28]
    // 0xb645d0: r1 = LoadInt32Instr(r0)
    //     0xb645d0: sbfx            x1, x0, #1, #0x1f
    //     0xb645d4: tbz             w0, #0, #0xb645dc
    //     0xb645d8: ldur            x1, [x0, #7]
    // 0xb645dc: cmp             x1, #0
    // 0xb645e0: b.le            #0xb646b4
    // 0xb645e4: ldur            x1, [fp, #-0x10]
    // 0xb645e8: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb645e8: ldur            w2, [x1, #0x17]
    // 0xb645ec: DecompressPointer r2
    //     0xb645ec: add             x2, x2, HEAP, lsl #32
    // 0xb645f0: tbnz            w2, #4, #0xb646b4
    // 0xb645f4: ldur            x1, [fp, #-0x50]
    // 0xb645f8: LoadField: r2 = r1->field_b
    //     0xb645f8: ldur            w2, [x1, #0xb]
    // 0xb645fc: r3 = LoadInt32Instr(r2)
    //     0xb645fc: sbfx            x3, x2, #1, #0x1f
    // 0xb64600: stur            x3, [fp, #-0x30]
    // 0xb64604: r2 = 0
    //     0xb64604: movz            x2, #0
    // 0xb64608: CheckStackOverflow
    //     0xb64608: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb6460c: cmp             SP, x16
    //     0xb64610: b.ls            #0xb64758
    // 0xb64614: LoadField: r4 = r1->field_b
    //     0xb64614: ldur            w4, [x1, #0xb]
    // 0xb64618: r5 = LoadInt32Instr(r4)
    //     0xb64618: sbfx            x5, x4, #1, #0x1f
    // 0xb6461c: cmp             x3, x5
    // 0xb64620: b.ne            #0xb646dc
    // 0xb64624: cmp             x2, x5
    // 0xb64628: b.ge            #0xb6468c
    // 0xb6462c: LoadField: r4 = r1->field_f
    //     0xb6462c: ldur            w4, [x1, #0xf]
    // 0xb64630: DecompressPointer r4
    //     0xb64630: add             x4, x4, HEAP, lsl #32
    // 0xb64634: ArrayLoad: r5 = r4[r2]  ; Unknown_4
    //     0xb64634: add             x16, x4, x2, lsl #2
    //     0xb64638: ldur            w5, [x16, #0xf]
    // 0xb6463c: DecompressPointer r5
    //     0xb6463c: add             x5, x5, HEAP, lsl #32
    // 0xb64640: stur            x5, [fp, #-0x10]
    // 0xb64644: add             x4, x2, #1
    // 0xb64648: stur            x4, [fp, #-0x20]
    // 0xb6464c: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb6464c: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb64650: ldr             x0, [x0, #0x29b8]
    //     0xb64654: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb64658: cmp             w0, w16
    //     0xb6465c: b.ne            #0xb6466c
    //     0xb64660: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb64664: ldr             x2, [x2, #0xa78]
    //     0xb64668: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb6466c: mov             x1, x0
    // 0xb64670: ldur            x2, [fp, #-0x10]
    // 0xb64674: r0 = call 0x442824
    //     0xb64674: bl              #0x442824
    // 0xb64678: ldur            x2, [fp, #-0x20]
    // 0xb6467c: ldur            x1, [fp, #-0x50]
    // 0xb64680: ldur            x0, [fp, #-0x28]
    // 0xb64684: ldur            x3, [fp, #-0x30]
    // 0xb64688: b               #0xb64608
    // 0xb6468c: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb6468c: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb64690: ldr             x0, [x0, #0x29b8]
    //     0xb64694: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb64698: cmp             w0, w16
    //     0xb6469c: b.ne            #0xb646ac
    //     0xb646a0: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb646a4: ldr             x2, [x2, #0xa78]
    //     0xb646a8: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb646ac: mov             x1, x0
    // 0xb646b0: r0 = call 0x43f5b8
    //     0xb646b0: bl              #0x43f5b8
    // 0xb646b4: ldur            x0, [fp, #-0x28]
    // 0xb646b8: r0 = ReturnAsyncNotFuture()
    //     0xb646b8: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb646bc: r0 = StateError()
    //     0xb646bc: bl              #0xb09194  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb646c0: mov             x1, x0
    // 0xb646c4: r0 = "Database operation cancelled by account switch"
    //     0xb646c4: add             x0, PP, #0x29, lsl #12  ; [pp+0x294f0] "Database operation cancelled by account switch"
    //     0xb646c8: ldr             x0, [x0, #0x4f0]
    // 0xb646cc: StoreField: r1->field_b = r0
    //     0xb646cc: stur            w0, [x1, #0xb]
    // 0xb646d0: mov             x0, x1
    // 0xb646d4: r0 = Throw()
    //     0xb646d4: bl              #0xc53a04  ; ThrowStub
    // 0xb646d8: brk             #0
    // 0xb646dc: mov             x0, x1
    // 0xb646e0: r0 = Ia()
    //     0xb646e0: bl              #0xb09188  ; AllocateIaStub -> Ia (size=0x10)
    // 0xb646e4: mov             x1, x0
    // 0xb646e8: ldur            x0, [fp, #-0x50]
    // 0xb646ec: StoreField: r1->field_b = r0
    //     0xb646ec: stur            w0, [x1, #0xb]
    // 0xb646f0: mov             x0, x1
    // 0xb646f4: r0 = Throw()
    //     0xb646f4: bl              #0xc53a04  ; ThrowStub
    // 0xb646f8: brk             #0
    // 0xb646fc: mov             x0, x3
    // 0xb64700: r0 = Ia()
    //     0xb64700: bl              #0xb09188  ; AllocateIaStub -> Ia (size=0x10)
    // 0xb64704: mov             x1, x0
    // 0xb64708: ldur            x0, [fp, #-0x18]
    // 0xb6470c: StoreField: r1->field_b = r0
    //     0xb6470c: stur            w0, [x1, #0xb]
    // 0xb64710: mov             x0, x1
    // 0xb64714: r0 = Throw()
    //     0xb64714: bl              #0xc53a04  ; ThrowStub
    // 0xb64718: brk             #0
    // 0xb6471c: mov             x0, x3
    // 0xb64720: r0 = Ia()
    //     0xb64720: bl              #0xb09188  ; AllocateIaStub -> Ia (size=0x10)
    // 0xb64724: mov             x1, x0
    // 0xb64728: ldur            x0, [fp, #-0x18]
    // 0xb6472c: StoreField: r1->field_b = r0
    //     0xb6472c: stur            w0, [x1, #0xb]
    // 0xb64730: mov             x0, x1
    // 0xb64734: r0 = Throw()
    //     0xb64734: bl              #0xc53a04  ; ThrowStub
    // 0xb64738: brk             #0
    // 0xb6473c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb6473c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb64740: b               #0xb63ff8
    // 0xb64744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb64744: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb64748: b               #0xb640cc
    // 0xb6474c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb6474c: bl              #0xc560a8  ; NullErrorSharedWithoutFPURegsStub
    // 0xb64750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb64750: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb64754: b               #0xb643e0
    // 0xb64758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb64758: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb6475c: b               #0xb64614
  }
  [closure] static Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xb6f91c, size: 0x1320
    // 0xb6f91c: EnterFrame
    //     0xb6f91c: stp             fp, lr, [SP, #-0x10]!
    //     0xb6f920: mov             fp, SP
    // 0xb6f924: AllocStack(0x100)
    //     0xb6f924: sub             SP, SP, #0x100
    // 0xb6f928: SetupParameters(dynamic _ /* r1 */)
    //     0xb6f928: stur            NULL, [fp, #-8]
    //     0xb6f92c: movz            x0, #0
    //     0xb6f930: add             x1, fp, w0, sxtw #2
    //     0xb6f934: ldr             x1, [x1, #0x10]
    //     0xb6f938: ldur            w2, [x1, #0x17]
    //     0xb6f93c: add             x2, x2, HEAP, lsl #32
    //     0xb6f940: stur            x2, [fp, #-0x10]
    // 0xb6f944: CheckStackOverflow
    //     0xb6f944: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb6f948: cmp             SP, x16
    //     0xb6f94c: b.ls            #0xb70c10
    // 0xb6f950: InitAsync() -> Future<Null?>
    //     0xb6f950: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xb6f954: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb6f958: ldur            x0, [fp, #-0x10]
    // 0xb6f95c: LoadField: r3 = r0->field_13
    //     0xb6f95c: ldur            w3, [x0, #0x13]
    // 0xb6f960: DecompressPointer r3
    //     0xb6f960: add             x3, x3, HEAP, lsl #32
    // 0xb6f964: stur            x3, [fp, #-0x18]
    // 0xb6f968: r1 = Function '<anonymous closure>': static.
    //     0xb6f968: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cc38] AnonymousClosure: static (0x4540a8), in [fbn] ::<anonymous closure> (0xb6f91c)
    //     0xb6f96c: ldr             x1, [x1, #0xc38]
    // 0xb6f970: r2 = Null
    //     0xb6f970: mov             x2, NULL
    // 0xb6f974: r0 = AllocateClosure()
    //     0xb6f974: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6f978: ldur            x1, [fp, #-0x18]
    // 0xb6f97c: mov             x2, x0
    // 0xb6f980: r0 = call 0x5cf9c8
    //     0xb6f980: bl              #0x5cf9c8
    // 0xb6f984: r1 = Function '<anonymous closure>': static.
    //     0xb6f984: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cc40] AnonymousClosure: static (0x454048), in [fbn] ::<anonymous closure> (0xb6f91c)
    //     0xb6f988: ldr             x1, [x1, #0xc40]
    // 0xb6f98c: r2 = Null
    //     0xb6f98c: mov             x2, NULL
    // 0xb6f990: stur            x0, [fp, #-0x18]
    // 0xb6f994: r0 = AllocateClosure()
    //     0xb6f994: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6f998: r16 = <String>
    //     0xb6f998: ldr             x16, [PP, #0x928]  ; [pp+0x928] TypeArguments: <String>
    // 0xb6f99c: ldur            lr, [fp, #-0x18]
    // 0xb6f9a0: stp             lr, x16, [SP, #8]
    // 0xb6f9a4: str             x0, [SP]
    // 0xb6f9a8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb6f9a8: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb6f9ac: r0 = call 0x597c54
    //     0xb6f9ac: bl              #0x597c54
    // 0xb6f9b0: r1 = Function '<anonymous closure>': static.
    //     0xb6f9b0: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cc48] AnonymousClosure: static (0x39da88), of [gMm] HP
    //     0xb6f9b4: ldr             x1, [x1, #0xc48]
    // 0xb6f9b8: r2 = Null
    //     0xb6f9b8: mov             x2, NULL
    // 0xb6f9bc: stur            x0, [fp, #-0x18]
    // 0xb6f9c0: r0 = AllocateClosure()
    //     0xb6f9c0: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6f9c4: ldur            x1, [fp, #-0x18]
    // 0xb6f9c8: mov             x2, x0
    // 0xb6f9cc: r0 = call 0x5cf9c8
    //     0xb6f9cc: bl              #0x5cf9c8
    // 0xb6f9d0: mov             x1, x0
    // 0xb6f9d4: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb6f9d4: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb6f9d8: r0 = call 0x5b0440
    //     0xb6f9d8: bl              #0x5b0440
    // 0xb6f9dc: mov             x2, x0
    // 0xb6f9e0: ldur            x0, [fp, #-0x10]
    // 0xb6f9e4: stur            x2, [fp, #-0x20]
    // 0xb6f9e8: LoadField: r3 = r0->field_f
    //     0xb6f9e8: ldur            w3, [x0, #0xf]
    // 0xb6f9ec: DecompressPointer r3
    //     0xb6f9ec: add             x3, x3, HEAP, lsl #32
    // 0xb6f9f0: mov             x1, x3
    // 0xb6f9f4: stur            x3, [fp, #-0x18]
    // 0xb6f9f8: r0 = call 0x3e0f38
    //     0xb6f9f8: bl              #0x3e0f38
    // 0xb6f9fc: mov             x1, x0
    // 0xb6fa00: ldur            x2, [fp, #-0x20]
    // 0xb6fa04: r0 = __unknown_function__()
    //     0xb6fa04: bl              #0xb5ecb8  ; [] ::__unknown_function__
    // 0xb6fa08: mov             x1, x0
    // 0xb6fa0c: stur            x1, [fp, #-0x20]
    // 0xb6fa10: r0 = Await()
    //     0xb6fa10: bl              #0xb0c534  ; AwaitStub
    // 0xb6fa14: r1 = <WVa>
    //     0xb6fa14: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cc50] TypeArguments: <WVa>
    //     0xb6fa18: ldr             x1, [x1, #0xc50]
    // 0xb6fa1c: r2 = 0
    //     0xb6fa1c: movz            x2, #0
    // 0xb6fa20: stur            x0, [fp, #-0x20]
    // 0xb6fa24: r0 = call 0x358510
    //     0xb6fa24: bl              #0x358510
    // 0xb6fa28: stur            x0, [fp, #-0x28]
    // 0xb6fa2c: r16 = <String, String?>
    //     0xb6fa2c: add             x16, PP, #0xb, lsl #12  ; [pp+0xbb90] TypeArguments: <String, String?>
    //     0xb6fa30: ldr             x16, [x16, #0xb90]
    // 0xb6fa34: ldr             lr, [THR, #0x90]  ; THR::empty_array
    // 0xb6fa38: stp             lr, x16, [SP]
    // 0xb6fa3c: r0 = Map._fromLiteral()
    //     0xb6fa3c: bl              #0x365604  ; [dart:core] Map::Map._fromLiteral
    // 0xb6fa40: stur            x0, [fp, #-0x30]
    // 0xb6fa44: r16 = <String, Set<String>>
    //     0xb6fa44: add             x16, PP, #0x15, lsl #12  ; [pp+0x15ab8] TypeArguments: <String, Set<String>>
    //     0xb6fa48: ldr             x16, [x16, #0xab8]
    // 0xb6fa4c: ldr             lr, [THR, #0x90]  ; THR::empty_array
    // 0xb6fa50: stp             lr, x16, [SP]
    // 0xb6fa54: r0 = Map._fromLiteral()
    //     0xb6fa54: bl              #0x365604  ; [dart:core] Map::Map._fromLiteral
    // 0xb6fa58: mov             x2, x0
    // 0xb6fa5c: ldur            x0, [fp, #-0x10]
    // 0xb6fa60: stur            x2, [fp, #-0x40]
    // 0xb6fa64: LoadField: r3 = r0->field_23
    //     0xb6fa64: ldur            w3, [x0, #0x23]
    // 0xb6fa68: DecompressPointer r3
    //     0xb6fa68: add             x3, x3, HEAP, lsl #32
    // 0xb6fa6c: mov             x1, x3
    // 0xb6fa70: stur            x3, [fp, #-0x38]
    // 0xb6fa74: r0 = call 0x9efcf8
    //     0xb6fa74: bl              #0x9efcf8
    // 0xb6fa78: mov             x1, x0
    // 0xb6fa7c: r0 = call 0x5b482c
    //     0xb6fa7c: bl              #0x5b482c
    // 0xb6fa80: mov             x2, x0
    // 0xb6fa84: stur            x2, [fp, #-0x80]
    // 0xb6fa88: LoadField: r3 = r2->field_f
    //     0xb6fa88: ldur            w3, [x2, #0xf]
    // 0xb6fa8c: DecompressPointer r3
    //     0xb6fa8c: add             x3, x3, HEAP, lsl #32
    // 0xb6fa90: stur            x3, [fp, #-0x78]
    // 0xb6fa94: LoadField: r4 = r2->field_13
    //     0xb6fa94: ldur            w4, [x2, #0x13]
    // 0xb6fa98: DecompressPointer r4
    //     0xb6fa98: add             x4, x4, HEAP, lsl #32
    // 0xb6fa9c: ldur            x5, [fp, #-0x10]
    // 0xb6faa0: stur            x4, [fp, #-0x70]
    // 0xb6faa4: LoadField: r6 = r5->field_1b
    //     0xb6faa4: ldur            w6, [x5, #0x1b]
    // 0xb6faa8: DecompressPointer r6
    //     0xb6faa8: add             x6, x6, HEAP, lsl #32
    // 0xb6faac: ldur            x7, [fp, #-0x30]
    // 0xb6fab0: stur            x6, [fp, #-0x68]
    // 0xb6fab4: LoadField: r8 = r7->field_7
    //     0xb6fab4: ldur            w8, [x7, #7]
    // 0xb6fab8: DecompressPointer r8
    //     0xb6fab8: add             x8, x8, HEAP, lsl #32
    // 0xb6fabc: ldur            x9, [fp, #-0x40]
    // 0xb6fac0: stur            x8, [fp, #-0x60]
    // 0xb6fac4: LoadField: r10 = r9->field_7
    //     0xb6fac4: ldur            w10, [x9, #7]
    // 0xb6fac8: DecompressPointer r10
    //     0xb6fac8: add             x10, x10, HEAP, lsl #32
    // 0xb6facc: stur            x10, [fp, #-0x58]
    // 0xb6fad0: LoadField: r11 = r5->field_1f
    //     0xb6fad0: ldur            w11, [x5, #0x1f]
    // 0xb6fad4: DecompressPointer r11
    //     0xb6fad4: add             x11, x11, HEAP, lsl #32
    // 0xb6fad8: stur            x11, [fp, #-0x50]
    // 0xb6fadc: LoadField: r12 = r2->field_7
    //     0xb6fadc: ldur            w12, [x2, #7]
    // 0xb6fae0: DecompressPointer r12
    //     0xb6fae0: add             x12, x12, HEAP, lsl #32
    // 0xb6fae4: stur            x12, [fp, #-0x48]
    // 0xb6fae8: ldur            x13, [fp, #-0x28]
    // 0xb6faec: CheckStackOverflow
    //     0xb6faec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb6faf0: cmp             SP, x16
    //     0xb6faf4: b.ls            #0xb70c18
    // 0xb6faf8: r0 = LoadClassIdInstr(r3)
    //     0xb6faf8: ldur            x0, [x3, #-1]
    //     0xb6fafc: ubfx            x0, x0, #0xc, #0x14
    // 0xb6fb00: mov             x1, x3
    // 0xb6fb04: r0 = GDT[cid_x0 + 0x14761]()
    //     0xb6fb04: movz            x17, #0x4761
    //     0xb6fb08: movk            x17, #0x1, lsl #16
    //     0xb6fb0c: add             lr, x0, x17
    //     0xb6fb10: ldr             lr, [x21, lr, lsl #3]
    //     0xb6fb14: blr             lr
    // 0xb6fb18: tbnz            w0, #4, #0xb706b8
    // 0xb6fb1c: ldur            x2, [fp, #-0x80]
    // 0xb6fb20: ldur            x3, [fp, #-0x78]
    // 0xb6fb24: r0 = LoadClassIdInstr(r3)
    //     0xb6fb24: ldur            x0, [x3, #-1]
    //     0xb6fb28: ubfx            x0, x0, #0xc, #0x14
    // 0xb6fb2c: mov             x1, x3
    // 0xb6fb30: r0 = GDT[cid_x0 + 0x14caa]()
    //     0xb6fb30: movz            x17, #0x4caa
    //     0xb6fb34: movk            x17, #0x1, lsl #16
    //     0xb6fb38: add             lr, x0, x17
    //     0xb6fb3c: ldr             lr, [x21, lr, lsl #3]
    //     0xb6fb40: blr             lr
    // 0xb6fb44: ldur            x16, [fp, #-0x70]
    // 0xb6fb48: stp             x0, x16, [SP]
    // 0xb6fb4c: ldur            x0, [fp, #-0x70]
    // 0xb6fb50: ClosureCall
    //     0xb6fb50: ldr             x4, [PP, #0x158]  ; [pp+0x158] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb6fb54: ldur            x2, [x0, #0x1f]
    //     0xb6fb58: blr             x2
    // 0xb6fb5c: mov             x4, x0
    // 0xb6fb60: ldur            x3, [fp, #-0x80]
    // 0xb6fb64: stur            x4, [fp, #-0x88]
    // 0xb6fb68: StoreField: r3->field_b = r0
    //     0xb6fb68: stur            w0, [x3, #0xb]
    //     0xb6fb6c: tbz             w0, #0, #0xb6fb88
    //     0xb6fb70: ldurb           w16, [x3, #-1]
    //     0xb6fb74: ldurb           w17, [x0, #-1]
    //     0xb6fb78: and             x16, x17, x16, lsr #2
    //     0xb6fb7c: tst             x16, HEAP, lsr #32
    //     0xb6fb80: b.eq            #0xb6fb88
    //     0xb6fb84: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb6fb88: cmp             w4, NULL
    // 0xb6fb8c: b.ne            #0xb6fbc0
    // 0xb6fb90: mov             x0, x4
    // 0xb6fb94: ldur            x2, [fp, #-0x48]
    // 0xb6fb98: r1 = Null
    //     0xb6fb98: mov             x1, NULL
    // 0xb6fb9c: cmp             w2, NULL
    // 0xb6fba0: b.eq            #0xb6fbc0
    // 0xb6fba4: LoadField: r4 = r2->field_1b
    //     0xb6fba4: ldur            w4, [x2, #0x1b]
    // 0xb6fba8: DecompressPointer r4
    //     0xb6fba8: add             x4, x4, HEAP, lsl #32
    // 0xb6fbac: r8 = X1
    //     0xb6fbac: ldr             x8, [PP, #0xe68]  ; [pp+0xe68] TypeParameter: X1
    // 0xb6fbb0: LoadField: r9 = r4->field_7
    //     0xb6fbb0: ldur            x9, [x4, #7]
    // 0xb6fbb4: r3 = Null
    //     0xb6fbb4: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cc58] Null
    //     0xb6fbb8: ldr             x3, [x3, #0xc58]
    // 0xb6fbbc: blr             x9
    // 0xb6fbc0: ldur            x1, [fp, #-0x10]
    // 0xb6fbc4: ldur            x0, [fp, #-0x88]
    // 0xb6fbc8: r1 = 1
    //     0xb6fbc8: movz            x1, #0x1
    // 0xb6fbcc: r0 = AllocateContext()
    //     0xb6fbcc: bl              #0xc547b8  ; AllocateContextStub
    // 0xb6fbd0: mov             x3, x0
    // 0xb6fbd4: ldur            x2, [fp, #-0x10]
    // 0xb6fbd8: stur            x3, [fp, #-0xa0]
    // 0xb6fbdc: StoreField: r3->field_b = r2
    //     0xb6fbdc: stur            w2, [x3, #0xb]
    // 0xb6fbe0: ldur            x0, [fp, #-0x88]
    // 0xb6fbe4: LoadField: r4 = r0->field_b
    //     0xb6fbe4: ldur            w4, [x0, #0xb]
    // 0xb6fbe8: DecompressPointer r4
    //     0xb6fbe8: add             x4, x4, HEAP, lsl #32
    // 0xb6fbec: stur            x4, [fp, #-0x98]
    // 0xb6fbf0: LoadField: r5 = r0->field_f
    //     0xb6fbf0: ldur            w5, [x0, #0xf]
    // 0xb6fbf4: DecompressPointer r5
    //     0xb6fbf4: add             x5, x5, HEAP, lsl #32
    // 0xb6fbf8: stur            x5, [fp, #-0x90]
    // 0xb6fbfc: r0 = LoadClassIdInstr(r5)
    //     0xb6fbfc: ldur            x0, [x5, #-1]
    //     0xb6fc00: ubfx            x0, x0, #0xc, #0x14
    // 0xb6fc04: mov             x1, x5
    // 0xb6fc08: r0 = GDT[cid_x0 + 0xd5fa]()
    //     0xb6fc08: movz            x17, #0xd5fa
    //     0xb6fc0c: add             lr, x0, x17
    //     0xb6fc10: ldr             lr, [x21, lr, lsl #3]
    //     0xb6fc14: blr             lr
    // 0xb6fc18: LoadField: r1 = r0->field_23
    //     0xb6fc18: ldur            w1, [x0, #0x23]
    // 0xb6fc1c: DecompressPointer r1
    //     0xb6fc1c: add             x1, x1, HEAP, lsl #32
    // 0xb6fc20: cmp             w1, NULL
    // 0xb6fc24: b.ne            #0xb6fc30
    // 0xb6fc28: r0 = 0
    //     0xb6fc28: movz            x0, #0
    // 0xb6fc2c: b               #0xb6fc3c
    // 0xb6fc30: r0 = LoadInt32Instr(r1)
    //     0xb6fc30: sbfx            x0, x1, #1, #0x1f
    //     0xb6fc34: tbz             w1, #0, #0xb6fc3c
    //     0xb6fc38: ldur            x0, [x1, #7]
    // 0xb6fc3c: ldur            x1, [fp, #-0x98]
    // 0xb6fc40: stur            x0, [fp, #-0xa8]
    // 0xb6fc44: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb6fc44: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb6fc48: r0 = call 0x36a13c
    //     0xb6fc48: bl              #0x36a13c
    // 0xb6fc4c: stur            x0, [fp, #-0x88]
    // 0xb6fc50: cmp             w0, NULL
    // 0xb6fc54: b.ne            #0xb6fc60
    // 0xb6fc58: r3 = Null
    //     0xb6fc58: mov             x3, NULL
    // 0xb6fc5c: b               #0xb6fcac
    // 0xb6fc60: ldur            x3, [fp, #-0xa8]
    // 0xb6fc64: r1 = Null
    //     0xb6fc64: mov             x1, NULL
    // 0xb6fc68: r2 = 6
    //     0xb6fc68: movz            x2, #0x6
    // 0xb6fc6c: r0 = AllocateArray()
    //     0xb6fc6c: bl              #0xc55848  ; AllocateArrayStub
    // 0xb6fc70: mov             x2, x0
    // 0xb6fc74: ldur            x0, [fp, #-0x88]
    // 0xb6fc78: StoreField: r2->field_f = r0
    //     0xb6fc78: stur            w0, [x2, #0xf]
    // 0xb6fc7c: r16 = "_"
    //     0xb6fc7c: ldr             x16, [PP, #0x43f0]  ; [pp+0x43f0] "_"
    // 0xb6fc80: StoreField: r2->field_13 = r16
    //     0xb6fc80: stur            w16, [x2, #0x13]
    // 0xb6fc84: ldur            x3, [fp, #-0xa8]
    // 0xb6fc88: r0 = BoxInt64Instr(r3)
    //     0xb6fc88: sbfiz           x0, x3, #1, #0x1f
    //     0xb6fc8c: cmp             x3, x0, asr #1
    //     0xb6fc90: b.eq            #0xb6fc9c
    //     0xb6fc94: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb6fc98: stur            x3, [x0, #7]
    // 0xb6fc9c: ArrayStore: r2[0] = r0  ; List_4
    //     0xb6fc9c: stur            w0, [x2, #0x17]
    // 0xb6fca0: str             x2, [SP]
    // 0xb6fca4: r0 = _interpolate()
    //     0xb6fca4: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xb6fca8: mov             x3, x0
    // 0xb6fcac: ldur            x0, [fp, #-0x68]
    // 0xb6fcb0: stur            x3, [fp, #-0x88]
    // 0xb6fcb4: tbnz            w0, #4, #0xb6fce0
    // 0xb6fcb8: cmp             w3, NULL
    // 0xb6fcbc: b.eq            #0xb6fce0
    // 0xb6fcc0: ldur            x1, [fp, #-0x18]
    // 0xb6fcc4: mov             x2, x3
    // 0xb6fcc8: r0 = __unknown_function__()
    //     0xb6fcc8: bl              #0xb4a650  ; [] ::__unknown_function__
    // 0xb6fccc: mov             x1, x0
    // 0xb6fcd0: stur            x1, [fp, #-0xb0]
    // 0xb6fcd4: r0 = Await()
    //     0xb6fcd4: bl              #0xb0c534  ; AwaitStub
    // 0xb6fcd8: mov             x3, x0
    // 0xb6fcdc: b               #0xb6fce4
    // 0xb6fce0: r3 = Null
    //     0xb6fce0: mov             x3, NULL
    // 0xb6fce4: ldur            x0, [fp, #-0x98]
    // 0xb6fce8: ldur            x2, [fp, #-0x60]
    // 0xb6fcec: stur            x3, [fp, #-0xb0]
    // 0xb6fcf0: r1 = Null
    //     0xb6fcf0: mov             x1, NULL
    // 0xb6fcf4: cmp             w2, NULL
    // 0xb6fcf8: b.eq            #0xb6fd18
    // 0xb6fcfc: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb6fcfc: ldur            w4, [x2, #0x17]
    // 0xb6fd00: DecompressPointer r4
    //     0xb6fd00: add             x4, x4, HEAP, lsl #32
    // 0xb6fd04: r8 = X0
    //     0xb6fd04: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xb6fd08: LoadField: r9 = r4->field_7
    //     0xb6fd08: ldur            x9, [x4, #7]
    // 0xb6fd0c: r3 = Null
    //     0xb6fd0c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cc68] Null
    //     0xb6fd10: ldr             x3, [x3, #0xc68]
    // 0xb6fd14: blr             x9
    // 0xb6fd18: ldur            x0, [fp, #-0x88]
    // 0xb6fd1c: ldur            x2, [fp, #-0x60]
    // 0xb6fd20: r1 = Null
    //     0xb6fd20: mov             x1, NULL
    // 0xb6fd24: cmp             w2, NULL
    // 0xb6fd28: b.eq            #0xb6fd48
    // 0xb6fd2c: LoadField: r4 = r2->field_1b
    //     0xb6fd2c: ldur            w4, [x2, #0x1b]
    // 0xb6fd30: DecompressPointer r4
    //     0xb6fd30: add             x4, x4, HEAP, lsl #32
    // 0xb6fd34: r8 = X1
    //     0xb6fd34: ldr             x8, [PP, #0xe68]  ; [pp+0xe68] TypeParameter: X1
    // 0xb6fd38: LoadField: r9 = r4->field_7
    //     0xb6fd38: ldur            x9, [x4, #7]
    // 0xb6fd3c: r3 = Null
    //     0xb6fd3c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cc78] Null
    //     0xb6fd40: ldr             x3, [x3, #0xc78]
    // 0xb6fd44: blr             x9
    // 0xb6fd48: ldur            x1, [fp, #-0x30]
    // 0xb6fd4c: ldur            x2, [fp, #-0x98]
    // 0xb6fd50: r0 = call 0xafd568
    //     0xb6fd50: bl              #0xafd568
    // 0xb6fd54: mov             x2, x0
    // 0xb6fd58: r0 = BoxInt64Instr(r2)
    //     0xb6fd58: sbfiz           x0, x2, #1, #0x1f
    //     0xb6fd5c: cmp             x2, x0, asr #1
    //     0xb6fd60: b.eq            #0xb6fd6c
    //     0xb6fd64: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb6fd68: stur            x2, [x0, #7]
    // 0xb6fd6c: ldur            x1, [fp, #-0x30]
    // 0xb6fd70: ldur            x2, [fp, #-0x98]
    // 0xb6fd74: ldur            x3, [fp, #-0x88]
    // 0xb6fd78: mov             x5, x0
    // 0xb6fd7c: r0 = call 0xaf3698
    //     0xb6fd7c: bl              #0xaf3698
    // 0xb6fd80: ldur            x0, [fp, #-0xb0]
    // 0xb6fd84: cmp             w0, NULL
    // 0xb6fd88: b.ne            #0xb6fd94
    // 0xb6fd8c: r0 = Null
    //     0xb6fd8c: mov             x0, NULL
    // 0xb6fd90: b               #0xb6fdac
    // 0xb6fd94: LoadField: r2 = r0->field_3b
    //     0xb6fd94: ldur            x2, [x0, #0x3b]
    // 0xb6fd98: r0 = BoxInt64Instr(r2)
    //     0xb6fd98: sbfiz           x0, x2, #1, #0x1f
    //     0xb6fd9c: cmp             x2, x0, asr #1
    //     0xb6fda0: b.eq            #0xb6fdac
    //     0xb6fda4: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb6fda8: stur            x2, [x0, #7]
    // 0xb6fdac: cmp             w0, NULL
    // 0xb6fdb0: b.ne            #0xb6fdbc
    // 0xb6fdb4: r4 = 0
    //     0xb6fdb4: movz            x4, #0
    // 0xb6fdb8: b               #0xb6fdcc
    // 0xb6fdbc: r1 = LoadInt32Instr(r0)
    //     0xb6fdbc: sbfx            x1, x0, #1, #0x1f
    //     0xb6fdc0: tbz             w0, #0, #0xb6fdc8
    //     0xb6fdc4: ldur            x1, [x0, #7]
    // 0xb6fdc8: mov             x4, x1
    // 0xb6fdcc: ldur            x0, [fp, #-0xa0]
    // 0xb6fdd0: ldur            x3, [fp, #-0x90]
    // 0xb6fdd4: stur            x4, [fp, #-0xa8]
    // 0xb6fdd8: r1 = Function '<anonymous closure>': static.
    //     0xb6fdd8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cc88] AnonymousClosure: static (0x454048), in [fbn] ::<anonymous closure> (0xb6f91c)
    //     0xb6fddc: ldr             x1, [x1, #0xc88]
    // 0xb6fde0: r2 = Null
    //     0xb6fde0: mov             x2, NULL
    // 0xb6fde4: r0 = AllocateClosure()
    //     0xb6fde4: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6fde8: ldur            x1, [fp, #-0x90]
    // 0xb6fdec: r2 = LoadClassIdInstr(r1)
    //     0xb6fdec: ldur            x2, [x1, #-1]
    //     0xb6fdf0: ubfx            x2, x2, #0xc, #0x14
    // 0xb6fdf4: r16 = <String>
    //     0xb6fdf4: ldr             x16, [PP, #0x928]  ; [pp+0x928] TypeArguments: <String>
    // 0xb6fdf8: stp             x1, x16, [SP, #8]
    // 0xb6fdfc: str             x0, [SP]
    // 0xb6fe00: mov             x0, x2
    // 0xb6fe04: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb6fe04: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb6fe08: r0 = GDT[cid_x0 + 0xd511]()
    //     0xb6fe08: movz            x17, #0xd511
    //     0xb6fe0c: add             lr, x0, x17
    //     0xb6fe10: ldr             lr, [x21, lr, lsl #3]
    //     0xb6fe14: blr             lr
    // 0xb6fe18: r1 = Function '<anonymous closure>': static.
    //     0xb6fe18: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cc90] AnonymousClosure: static (0x39da88), of [gMm] HP
    //     0xb6fe1c: ldr             x1, [x1, #0xc90]
    // 0xb6fe20: r2 = Null
    //     0xb6fe20: mov             x2, NULL
    // 0xb6fe24: stur            x0, [fp, #-0x88]
    // 0xb6fe28: r0 = AllocateClosure()
    //     0xb6fe28: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6fe2c: ldur            x1, [fp, #-0x88]
    // 0xb6fe30: r2 = LoadClassIdInstr(r1)
    //     0xb6fe30: ldur            x2, [x1, #-1]
    //     0xb6fe34: ubfx            x2, x2, #0xc, #0x14
    // 0xb6fe38: mov             x16, x0
    // 0xb6fe3c: mov             x0, x2
    // 0xb6fe40: mov             x2, x16
    // 0xb6fe44: r0 = GDT[cid_x0 + 0xe0e0]()
    //     0xb6fe44: movz            x17, #0xe0e0
    //     0xb6fe48: add             lr, x0, x17
    //     0xb6fe4c: ldr             lr, [x21, lr, lsl #3]
    //     0xb6fe50: blr             lr
    // 0xb6fe54: r1 = LoadClassIdInstr(r0)
    //     0xb6fe54: ldur            x1, [x0, #-1]
    //     0xb6fe58: ubfx            x1, x1, #0xc, #0x14
    // 0xb6fe5c: mov             x16, x0
    // 0xb6fe60: mov             x0, x1
    // 0xb6fe64: mov             x1, x16
    // 0xb6fe68: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb6fe68: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb6fe6c: r0 = GDT[cid_x0 + 0xcc10]()
    //     0xb6fe6c: movz            x17, #0xcc10
    //     0xb6fe70: add             lr, x0, x17
    //     0xb6fe74: ldr             lr, [x21, lr, lsl #3]
    //     0xb6fe78: blr             lr
    // 0xb6fe7c: ldur            x1, [fp, #-0x18]
    // 0xb6fe80: stur            x0, [fp, #-0x88]
    // 0xb6fe84: r0 = call 0x3e0f38
    //     0xb6fe84: bl              #0x3e0f38
    // 0xb6fe88: mov             x1, x0
    // 0xb6fe8c: ldur            x2, [fp, #-0x98]
    // 0xb6fe90: ldur            x3, [fp, #-0x88]
    // 0xb6fe94: r0 = __unknown_function__()
    //     0xb6fe94: bl              #0xb69584  ; [] ::__unknown_function__
    // 0xb6fe98: mov             x1, x0
    // 0xb6fe9c: stur            x1, [fp, #-0x88]
    // 0xb6fea0: r0 = Await()
    //     0xb6fea0: bl              #0xb0c534  ; AwaitStub
    // 0xb6fea4: mov             x4, x0
    // 0xb6fea8: ldur            x3, [fp, #-0xa0]
    // 0xb6feac: stur            x4, [fp, #-0x88]
    // 0xb6feb0: StoreField: r3->field_f = r0
    //     0xb6feb0: stur            w0, [x3, #0xf]
    //     0xb6feb4: tbz             w0, #0, #0xb6fed0
    //     0xb6feb8: ldurb           w16, [x3, #-1]
    //     0xb6febc: ldurb           w17, [x0, #-1]
    //     0xb6fec0: and             x16, x17, x16, lsr #2
    //     0xb6fec4: tst             x16, HEAP, lsr #32
    //     0xb6fec8: b.eq            #0xb6fed0
    //     0xb6fecc: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb6fed0: mov             x2, x3
    // 0xb6fed4: r1 = Function '<anonymous closure>': static.
    //     0xb6fed4: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cc98] AnonymousClosure: static (0x453fac), in [fbn] ::<anonymous closure> (0xb6f91c)
    //     0xb6fed8: ldr             x1, [x1, #0xc98]
    // 0xb6fedc: r0 = AllocateClosure()
    //     0xb6fedc: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6fee0: ldur            x3, [fp, #-0x90]
    // 0xb6fee4: r1 = LoadClassIdInstr(r3)
    //     0xb6fee4: ldur            x1, [x3, #-1]
    //     0xb6fee8: ubfx            x1, x1, #0xc, #0x14
    // 0xb6feec: mov             x2, x0
    // 0xb6fef0: mov             x0, x1
    // 0xb6fef4: mov             x1, x3
    // 0xb6fef8: r0 = GDT[cid_x0 + 0xe0e0]()
    //     0xb6fef8: movz            x17, #0xe0e0
    //     0xb6fefc: add             lr, x0, x17
    //     0xb6ff00: ldr             lr, [x21, lr, lsl #3]
    //     0xb6ff04: blr             lr
    // 0xb6ff08: r1 = Function '<anonymous closure>': static.
    //     0xb6ff08: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cca0] AnonymousClosure: static (0x453f4c), in [fbn] ::<anonymous closure> (0xb6f91c)
    //     0xb6ff0c: ldr             x1, [x1, #0xca0]
    // 0xb6ff10: r2 = Null
    //     0xb6ff10: mov             x2, NULL
    // 0xb6ff14: stur            x0, [fp, #-0xb0]
    // 0xb6ff18: r0 = AllocateClosure()
    //     0xb6ff18: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6ff1c: mov             x1, x0
    // 0xb6ff20: ldur            x0, [fp, #-0xb0]
    // 0xb6ff24: r2 = LoadClassIdInstr(r0)
    //     0xb6ff24: ldur            x2, [x0, #-1]
    //     0xb6ff28: ubfx            x2, x2, #0xc, #0x14
    // 0xb6ff2c: r16 = <String>
    //     0xb6ff2c: ldr             x16, [PP, #0x928]  ; [pp+0x928] TypeArguments: <String>
    // 0xb6ff30: stp             x0, x16, [SP, #8]
    // 0xb6ff34: str             x1, [SP]
    // 0xb6ff38: mov             x0, x2
    // 0xb6ff3c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb6ff3c: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb6ff40: r0 = GDT[cid_x0 + 0xd511]()
    //     0xb6ff40: movz            x17, #0xd511
    //     0xb6ff44: add             lr, x0, x17
    //     0xb6ff48: ldr             lr, [x21, lr, lsl #3]
    //     0xb6ff4c: blr             lr
    // 0xb6ff50: r1 = Function '<anonymous closure>': static.
    //     0xb6ff50: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2cca8] AnonymousClosure: static (0x39da88), of [gMm] HP
    //     0xb6ff54: ldr             x1, [x1, #0xca8]
    // 0xb6ff58: r2 = Null
    //     0xb6ff58: mov             x2, NULL
    // 0xb6ff5c: stur            x0, [fp, #-0xb0]
    // 0xb6ff60: r0 = AllocateClosure()
    //     0xb6ff60: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb6ff64: ldur            x1, [fp, #-0xb0]
    // 0xb6ff68: r2 = LoadClassIdInstr(r1)
    //     0xb6ff68: ldur            x2, [x1, #-1]
    //     0xb6ff6c: ubfx            x2, x2, #0xc, #0x14
    // 0xb6ff70: mov             x16, x0
    // 0xb6ff74: mov             x0, x2
    // 0xb6ff78: mov             x2, x16
    // 0xb6ff7c: r0 = GDT[cid_x0 + 0xe0e0]()
    //     0xb6ff7c: movz            x17, #0xe0e0
    //     0xb6ff80: add             lr, x0, x17
    //     0xb6ff84: ldr             lr, [x21, lr, lsl #3]
    //     0xb6ff88: blr             lr
    // 0xb6ff8c: r1 = LoadClassIdInstr(r0)
    //     0xb6ff8c: ldur            x1, [x0, #-1]
    //     0xb6ff90: ubfx            x1, x1, #0xc, #0x14
    // 0xb6ff94: mov             x16, x0
    // 0xb6ff98: mov             x0, x1
    // 0xb6ff9c: mov             x1, x16
    // 0xb6ffa0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb6ffa0: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb6ffa4: r0 = GDT[cid_x0 + 0xcc10]()
    //     0xb6ffa4: movz            x17, #0xcc10
    //     0xb6ffa8: add             lr, x0, x17
    //     0xb6ffac: ldr             lr, [x21, lr, lsl #3]
    //     0xb6ffb0: blr             lr
    // 0xb6ffb4: ldur            x1, [fp, #-0x18]
    // 0xb6ffb8: stur            x0, [fp, #-0xb0]
    // 0xb6ffbc: r0 = call 0x3e0f38
    //     0xb6ffbc: bl              #0x3e0f38
    // 0xb6ffc0: mov             x1, x0
    // 0xb6ffc4: ldur            x2, [fp, #-0x98]
    // 0xb6ffc8: ldur            x3, [fp, #-0xb0]
    // 0xb6ffcc: r0 = __unknown_function__()
    //     0xb6ffcc: bl              #0xb712d8  ; [] ::__unknown_function__
    // 0xb6ffd0: mov             x1, x0
    // 0xb6ffd4: stur            x1, [fp, #-0xb0]
    // 0xb6ffd8: r0 = Await()
    //     0xb6ffd8: bl              #0xb0c534  ; AwaitStub
    // 0xb6ffdc: stur            x0, [fp, #-0xa0]
    // 0xb6ffe0: r0 = InitLateStaticField(0x3c4) // [dart:_compact_hash] ::_Dhc
    //     0xb6ffe0: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb6ffe4: ldr             x0, [x0, #0x788]
    //     0xb6ffe8: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb6ffec: cmp             w0, w16
    //     0xb6fff0: b.ne            #0xb6fffc
    //     0xb6fff4: ldr             x2, [PP, #0x18d8]  ; [pp+0x18d8] Field <::._Dhc@3099033>: static late final (offset: 0x3c4)
    //     0xb6fff8: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb6fffc: r1 = <String>
    //     0xb6fffc: ldr             x1, [PP, #0x928]  ; [pp+0x928] TypeArguments: <String>
    // 0xb70000: stur            x0, [fp, #-0xb0]
    // 0xb70004: r0 = _Set()
    //     0xb70004: bl              #0xb14d6c  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xb70008: mov             x1, x0
    // 0xb7000c: ldur            x0, [fp, #-0xb0]
    // 0xb70010: stur            x1, [fp, #-0xb8]
    // 0xb70014: StoreField: r1->field_1b = r0
    //     0xb70014: stur            w0, [x1, #0x1b]
    // 0xb70018: StoreField: r1->field_b = rZR
    //     0xb70018: stur            wzr, [x1, #0xb]
    // 0xb7001c: r0 = InitLateStaticField(0x3c8) // [dart:_compact_hash] ::_Ehc
    //     0xb7001c: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb70020: ldr             x0, [x0, #0x790]
    //     0xb70024: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb70028: cmp             w0, w16
    //     0xb7002c: b.ne            #0xb70038
    //     0xb70030: ldr             x2, [PP, #0x18e8]  ; [pp+0x18e8] Field <::._Ehc@3099033>: static late final (offset: 0x3c8)
    //     0xb70034: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb70038: ldur            x3, [fp, #-0xb8]
    // 0xb7003c: StoreField: r3->field_f = r0
    //     0xb7003c: stur            w0, [x3, #0xf]
    // 0xb70040: StoreField: r3->field_13 = rZR
    //     0xb70040: stur            wzr, [x3, #0x13]
    // 0xb70044: ArrayStore: r3[0] = rZR  ; List_4
    //     0xb70044: stur            wzr, [x3, #0x17]
    // 0xb70048: ldur            x0, [fp, #-0x98]
    // 0xb7004c: ldur            x2, [fp, #-0x58]
    // 0xb70050: r1 = Null
    //     0xb70050: mov             x1, NULL
    // 0xb70054: cmp             w2, NULL
    // 0xb70058: b.eq            #0xb70078
    // 0xb7005c: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb7005c: ldur            w4, [x2, #0x17]
    // 0xb70060: DecompressPointer r4
    //     0xb70060: add             x4, x4, HEAP, lsl #32
    // 0xb70064: r8 = X0
    //     0xb70064: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xb70068: LoadField: r9 = r4->field_7
    //     0xb70068: ldur            x9, [x4, #7]
    // 0xb7006c: r3 = Null
    //     0xb7006c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2ccb0] Null
    //     0xb70070: ldr             x3, [x3, #0xcb0]
    // 0xb70074: blr             x9
    // 0xb70078: ldur            x0, [fp, #-0xb8]
    // 0xb7007c: ldur            x2, [fp, #-0x58]
    // 0xb70080: r1 = Null
    //     0xb70080: mov             x1, NULL
    // 0xb70084: cmp             w2, NULL
    // 0xb70088: b.eq            #0xb700a8
    // 0xb7008c: LoadField: r4 = r2->field_1b
    //     0xb7008c: ldur            w4, [x2, #0x1b]
    // 0xb70090: DecompressPointer r4
    //     0xb70090: add             x4, x4, HEAP, lsl #32
    // 0xb70094: r8 = X1
    //     0xb70094: ldr             x8, [PP, #0xe68]  ; [pp+0xe68] TypeParameter: X1
    // 0xb70098: LoadField: r9 = r4->field_7
    //     0xb70098: ldur            x9, [x4, #7]
    // 0xb7009c: r3 = Null
    //     0xb7009c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2ccc0] Null
    //     0xb700a0: ldr             x3, [x3, #0xcc0]
    // 0xb700a4: blr             x9
    // 0xb700a8: ldur            x1, [fp, #-0x40]
    // 0xb700ac: ldur            x2, [fp, #-0x98]
    // 0xb700b0: r0 = call 0xafd568
    //     0xb700b0: bl              #0xafd568
    // 0xb700b4: mov             x2, x0
    // 0xb700b8: r0 = BoxInt64Instr(r2)
    //     0xb700b8: sbfiz           x0, x2, #1, #0x1f
    //     0xb700bc: cmp             x2, x0, asr #1
    //     0xb700c0: b.eq            #0xb700cc
    //     0xb700c4: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb700c8: stur            x2, [x0, #7]
    // 0xb700cc: ldur            x1, [fp, #-0x40]
    // 0xb700d0: ldur            x2, [fp, #-0x98]
    // 0xb700d4: ldur            x3, [fp, #-0xb8]
    // 0xb700d8: mov             x5, x0
    // 0xb700dc: r0 = call 0xaf3698
    //     0xb700dc: bl              #0xaf3698
    // 0xb700e0: ldur            x1, [fp, #-0x90]
    // 0xb700e4: r0 = LoadClassIdInstr(r1)
    //     0xb700e4: ldur            x0, [x1, #-1]
    //     0xb700e8: ubfx            x0, x0, #0xc, #0x14
    // 0xb700ec: r0 = GDT[cid_x0 + 0xca1c]()
    //     0xb700ec: movz            x17, #0xca1c
    //     0xb700f0: add             lr, x0, x17
    //     0xb700f4: ldr             lr, [x21, lr, lsl #3]
    //     0xb700f8: blr             lr
    // 0xb700fc: mov             x2, x0
    // 0xb70100: stur            x2, [fp, #-0x90]
    // 0xb70104: ldur            x6, [fp, #-0x10]
    // 0xb70108: ldur            x9, [fp, #-0x28]
    // 0xb7010c: ldur            x7, [fp, #-0x98]
    // 0xb70110: ldur            x5, [fp, #-0xa8]
    // 0xb70114: ldur            x4, [fp, #-0x88]
    // 0xb70118: ldur            x3, [fp, #-0xa0]
    // 0xb7011c: ldur            x8, [fp, #-0x50]
    // 0xb70120: CheckStackOverflow
    //     0xb70120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb70124: cmp             SP, x16
    //     0xb70128: b.ls            #0xb70c20
    // 0xb7012c: r0 = LoadClassIdInstr(r2)
    //     0xb7012c: ldur            x0, [x2, #-1]
    //     0xb70130: ubfx            x0, x0, #0xc, #0x14
    // 0xb70134: mov             x1, x2
    // 0xb70138: r0 = GDT[cid_x0 + 0x14761]()
    //     0xb70138: movz            x17, #0x4761
    //     0xb7013c: movk            x17, #0x1, lsl #16
    //     0xb70140: add             lr, x0, x17
    //     0xb70144: ldr             lr, [x21, lr, lsl #3]
    //     0xb70148: blr             lr
    // 0xb7014c: tbnz            w0, #4, #0xb70688
    // 0xb70150: ldur            x2, [fp, #-0x90]
    // 0xb70154: r0 = LoadClassIdInstr(r2)
    //     0xb70154: ldur            x0, [x2, #-1]
    //     0xb70158: ubfx            x0, x0, #0xc, #0x14
    // 0xb7015c: mov             x1, x2
    // 0xb70160: r0 = GDT[cid_x0 + 0x14caa]()
    //     0xb70160: movz            x17, #0x4caa
    //     0xb70164: movk            x17, #0x1, lsl #16
    //     0xb70168: add             lr, x0, x17
    //     0xb7016c: ldr             lr, [x21, lr, lsl #3]
    //     0xb70170: blr             lr
    // 0xb70174: stur            x0, [fp, #-0xc8]
    // 0xb70178: LoadField: r2 = r0->field_73
    //     0xb70178: ldur            w2, [x0, #0x73]
    // 0xb7017c: DecompressPointer r2
    //     0xb7017c: add             x2, x2, HEAP, lsl #32
    // 0xb70180: stur            x2, [fp, #-0xc0]
    // 0xb70184: cmp             w2, NULL
    // 0xb70188: b.eq            #0xb70c28
    // 0xb7018c: LoadField: r3 = r2->field_7
    //     0xb7018c: ldur            w3, [x2, #7]
    // 0xb70190: mov             x1, x2
    // 0xb70194: stur            x3, [fp, #-0xb0]
    // 0xb70198: r0 = call 0x35e91c
    //     0xb70198: bl              #0x35e91c
    // 0xb7019c: mov             x2, x0
    // 0xb701a0: ldur            x0, [fp, #-0xb0]
    // 0xb701a4: stur            x2, [fp, #-0xd8]
    // 0xb701a8: r3 = LoadInt32Instr(r0)
    //     0xb701a8: sbfx            x3, x0, #1, #0x1f
    // 0xb701ac: stur            x3, [fp, #-0xd0]
    // 0xb701b0: cmp             x3, x2
    // 0xb701b4: b.ne            #0xb701c0
    // 0xb701b8: r2 = ""
    //     0xb701b8: ldr             x2, [PP, #0x958]  ; [pp+0x958] ""
    // 0xb701bc: b               #0xb701f8
    // 0xb701c0: ldur            x1, [fp, #-0xc0]
    // 0xb701c4: r0 = call 0x35ea78
    //     0xb701c4: bl              #0x35ea78
    // 0xb701c8: add             x3, x0, #1
    // 0xb701cc: ldur            x2, [fp, #-0xd8]
    // 0xb701d0: cbnz            x2, #0xb701e8
    // 0xb701d4: ldur            x0, [fp, #-0xd0]
    // 0xb701d8: cmp             x3, x0
    // 0xb701dc: b.ne            #0xb701ec
    // 0xb701e0: ldur            x2, [fp, #-0xc0]
    // 0xb701e4: b               #0xb701f8
    // 0xb701e8: ldur            x0, [fp, #-0xd0]
    // 0xb701ec: ldur            x1, [fp, #-0xc0]
    // 0xb701f0: r0 = call 0x358e24
    //     0xb701f0: bl              #0x358e24
    // 0xb701f4: mov             x2, x0
    // 0xb701f8: ldur            x3, [fp, #-0x88]
    // 0xb701fc: r0 = LoadClassIdInstr(r3)
    //     0xb701fc: ldur            x0, [x3, #-1]
    //     0xb70200: ubfx            x0, x0, #0xc, #0x14
    // 0xb70204: mov             x1, x3
    // 0xb70208: r0 = GDT[cid_x0 + 0x3d3]()
    //     0xb70208: add             lr, x0, #0x3d3
    //     0xb7020c: ldr             lr, [x21, lr, lsl #3]
    //     0xb70210: blr             lr
    // 0xb70214: cmp             w0, NULL
    // 0xb70218: b.eq            #0xb702cc
    // 0xb7021c: ldur            x2, [fp, #-0x28]
    // 0xb70220: ldur            x0, [fp, #-0x98]
    // 0xb70224: ldur            x1, [fp, #-0xc8]
    // 0xb70228: r0 = WVa()
    //     0xb70228: bl              #0xb712ac  ; AllocateWVaStub -> WVa (size=0x18)
    // 0xb7022c: mov             x2, x0
    // 0xb70230: ldur            x0, [fp, #-0x98]
    // 0xb70234: stur            x2, [fp, #-0xb0]
    // 0xb70238: StoreField: r2->field_b = r0
    //     0xb70238: stur            w0, [x2, #0xb]
    // 0xb7023c: ldur            x3, [fp, #-0xc8]
    // 0xb70240: StoreField: r2->field_13 = r3
    //     0xb70240: stur            w3, [x2, #0x13]
    // 0xb70244: r3 = Instance_VVa
    //     0xb70244: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2ccd0] Obj!VVa@699ba1
    //     0xb70248: ldr             x3, [x3, #0xcd0]
    // 0xb7024c: StoreField: r2->field_7 = r3
    //     0xb7024c: stur            w3, [x2, #7]
    // 0xb70250: ldur            x4, [fp, #-0x28]
    // 0xb70254: LoadField: r1 = r4->field_b
    //     0xb70254: ldur            w1, [x4, #0xb]
    // 0xb70258: LoadField: r5 = r4->field_f
    //     0xb70258: ldur            w5, [x4, #0xf]
    // 0xb7025c: DecompressPointer r5
    //     0xb7025c: add             x5, x5, HEAP, lsl #32
    // 0xb70260: LoadField: r6 = r5->field_b
    //     0xb70260: ldur            w6, [x5, #0xb]
    // 0xb70264: r5 = LoadInt32Instr(r1)
    //     0xb70264: sbfx            x5, x1, #1, #0x1f
    // 0xb70268: stur            x5, [fp, #-0xd8]
    // 0xb7026c: r1 = LoadInt32Instr(r6)
    //     0xb7026c: sbfx            x1, x6, #1, #0x1f
    // 0xb70270: cmp             x5, x1
    // 0xb70274: b.ne            #0xb70280
    // 0xb70278: mov             x1, x4
    // 0xb7027c: r0 = call 0x35fcec
    //     0xb7027c: bl              #0x35fcec
    // 0xb70280: ldur            x2, [fp, #-0x28]
    // 0xb70284: ldur            x3, [fp, #-0xd8]
    // 0xb70288: add             x0, x3, #1
    // 0xb7028c: lsl             x1, x0, #1
    // 0xb70290: StoreField: r2->field_b = r1
    //     0xb70290: stur            w1, [x2, #0xb]
    // 0xb70294: LoadField: r1 = r2->field_f
    //     0xb70294: ldur            w1, [x2, #0xf]
    // 0xb70298: DecompressPointer r1
    //     0xb70298: add             x1, x1, HEAP, lsl #32
    // 0xb7029c: ldur            x0, [fp, #-0xb0]
    // 0xb702a0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb702a0: add             x25, x1, x3, lsl #2
    //     0xb702a4: add             x25, x25, #0xf
    //     0xb702a8: str             w0, [x25]
    //     0xb702ac: tbz             w0, #0, #0xb702c8
    //     0xb702b0: ldurb           w16, [x1, #-1]
    //     0xb702b4: ldurb           w17, [x0, #-1]
    //     0xb702b8: and             x16, x17, x16, lsr #2
    //     0xb702bc: tst             x16, HEAP, lsr #32
    //     0xb702c0: b.eq            #0xb702c8
    //     0xb702c4: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xb702c8: b               #0xb70680
    // 0xb702cc: ldur            x2, [fp, #-0x28]
    // 0xb702d0: ldur            x3, [fp, #-0xc8]
    // 0xb702d4: LoadField: r0 = r3->field_77
    //     0xb702d4: ldur            w0, [x3, #0x77]
    // 0xb702d8: DecompressPointer r0
    //     0xb702d8: add             x0, x0, HEAP, lsl #32
    // 0xb702dc: stur            x0, [fp, #-0xe0]
    // 0xb702e0: cmp             w0, NULL
    // 0xb702e4: b.ne            #0xb702f0
    // 0xb702e8: r0 = Null
    //     0xb702e8: mov             x0, NULL
    // 0xb702ec: b               #0xb70354
    // 0xb702f0: LoadField: r4 = r0->field_7
    //     0xb702f0: ldur            w4, [x0, #7]
    // 0xb702f4: mov             x1, x0
    // 0xb702f8: stur            x4, [fp, #-0xb0]
    // 0xb702fc: r0 = call 0x35e91c
    //     0xb702fc: bl              #0x35e91c
    // 0xb70300: mov             x2, x0
    // 0xb70304: ldur            x0, [fp, #-0xb0]
    // 0xb70308: stur            x2, [fp, #-0xe8]
    // 0xb7030c: r3 = LoadInt32Instr(r0)
    //     0xb7030c: sbfx            x3, x0, #1, #0x1f
    // 0xb70310: stur            x3, [fp, #-0xd8]
    // 0xb70314: cmp             x3, x2
    // 0xb70318: b.ne            #0xb70324
    // 0xb7031c: r0 = ""
    //     0xb7031c: ldr             x0, [PP, #0x958]  ; [pp+0x958] ""
    // 0xb70320: b               #0xb70354
    // 0xb70324: ldur            x1, [fp, #-0xe0]
    // 0xb70328: r0 = call 0x35ea78
    //     0xb70328: bl              #0x35ea78
    // 0xb7032c: add             x3, x0, #1
    // 0xb70330: ldur            x2, [fp, #-0xe8]
    // 0xb70334: cbnz            x2, #0xb7034c
    // 0xb70338: ldur            x0, [fp, #-0xd8]
    // 0xb7033c: cmp             x3, x0
    // 0xb70340: b.ne            #0xb7034c
    // 0xb70344: ldur            x0, [fp, #-0xe0]
    // 0xb70348: b               #0xb70354
    // 0xb7034c: ldur            x1, [fp, #-0xe0]
    // 0xb70350: r0 = call 0x358e24
    //     0xb70350: bl              #0x358e24
    // 0xb70354: cmp             w0, NULL
    // 0xb70358: b.ne            #0xb70364
    // 0xb7035c: r3 = ""
    //     0xb7035c: ldr             x3, [PP, #0x958]  ; [pp+0x958] ""
    // 0xb70360: b               #0xb70368
    // 0xb70364: mov             x3, x0
    // 0xb70368: stur            x3, [fp, #-0xb0]
    // 0xb7036c: LoadField: r0 = r3->field_7
    //     0xb7036c: ldur            w0, [x3, #7]
    // 0xb70370: cbnz            w0, #0xb7037c
    // 0xb70374: r2 = Null
    //     0xb70374: mov             x2, NULL
    // 0xb70378: b               #0xb703a0
    // 0xb7037c: ldur            x4, [fp, #-0xa0]
    // 0xb70380: r0 = LoadClassIdInstr(r4)
    //     0xb70380: ldur            x0, [x4, #-1]
    //     0xb70384: ubfx            x0, x0, #0xc, #0x14
    // 0xb70388: mov             x1, x4
    // 0xb7038c: mov             x2, x3
    // 0xb70390: r0 = GDT[cid_x0 + 0x3d3]()
    //     0xb70390: add             lr, x0, #0x3d3
    //     0xb70394: ldr             lr, [x21, lr, lsl #3]
    //     0xb70398: blr             lr
    // 0xb7039c: mov             x2, x0
    // 0xb703a0: cmp             w2, NULL
    // 0xb703a4: b.eq            #0xb7046c
    // 0xb703a8: ldur            x4, [fp, #-0x28]
    // 0xb703ac: ldur            x5, [fp, #-0x98]
    // 0xb703b0: ldur            x3, [fp, #-0xc8]
    // 0xb703b4: ldur            x0, [fp, #-0xb0]
    // 0xb703b8: mov             x1, x3
    // 0xb703bc: r0 = call 0x44c060
    //     0xb703bc: bl              #0x44c060
    // 0xb703c0: r0 = WVa()
    //     0xb703c0: bl              #0xb712ac  ; AllocateWVaStub -> WVa (size=0x18)
    // 0xb703c4: mov             x2, x0
    // 0xb703c8: ldur            x0, [fp, #-0x98]
    // 0xb703cc: stur            x2, [fp, #-0xe0]
    // 0xb703d0: StoreField: r2->field_b = r0
    //     0xb703d0: stur            w0, [x2, #0xb]
    // 0xb703d4: ldur            x1, [fp, #-0xc8]
    // 0xb703d8: StoreField: r2->field_13 = r1
    //     0xb703d8: stur            w1, [x2, #0x13]
    // 0xb703dc: r3 = Instance_VVa
    //     0xb703dc: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2ccd8] Obj!VVa@699b81
    //     0xb703e0: ldr             x3, [x3, #0xcd8]
    // 0xb703e4: StoreField: r2->field_7 = r3
    //     0xb703e4: stur            w3, [x2, #7]
    // 0xb703e8: ldur            x1, [fp, #-0xb0]
    // 0xb703ec: StoreField: r2->field_f = r1
    //     0xb703ec: stur            w1, [x2, #0xf]
    // 0xb703f0: ldur            x4, [fp, #-0x28]
    // 0xb703f4: LoadField: r1 = r4->field_b
    //     0xb703f4: ldur            w1, [x4, #0xb]
    // 0xb703f8: LoadField: r5 = r4->field_f
    //     0xb703f8: ldur            w5, [x4, #0xf]
    // 0xb703fc: DecompressPointer r5
    //     0xb703fc: add             x5, x5, HEAP, lsl #32
    // 0xb70400: LoadField: r6 = r5->field_b
    //     0xb70400: ldur            w6, [x5, #0xb]
    // 0xb70404: r5 = LoadInt32Instr(r1)
    //     0xb70404: sbfx            x5, x1, #1, #0x1f
    // 0xb70408: stur            x5, [fp, #-0xd8]
    // 0xb7040c: r1 = LoadInt32Instr(r6)
    //     0xb7040c: sbfx            x1, x6, #1, #0x1f
    // 0xb70410: cmp             x5, x1
    // 0xb70414: b.ne            #0xb70420
    // 0xb70418: mov             x1, x4
    // 0xb7041c: r0 = call 0x35fcec
    //     0xb7041c: bl              #0x35fcec
    // 0xb70420: ldur            x2, [fp, #-0x28]
    // 0xb70424: ldur            x3, [fp, #-0xd8]
    // 0xb70428: add             x0, x3, #1
    // 0xb7042c: lsl             x1, x0, #1
    // 0xb70430: StoreField: r2->field_b = r1
    //     0xb70430: stur            w1, [x2, #0xb]
    // 0xb70434: LoadField: r1 = r2->field_f
    //     0xb70434: ldur            w1, [x2, #0xf]
    // 0xb70438: DecompressPointer r1
    //     0xb70438: add             x1, x1, HEAP, lsl #32
    // 0xb7043c: ldur            x0, [fp, #-0xe0]
    // 0xb70440: ArrayStore: r1[r3] = r0  ; List_4
    //     0xb70440: add             x25, x1, x3, lsl #2
    //     0xb70444: add             x25, x25, #0xf
    //     0xb70448: str             w0, [x25]
    //     0xb7044c: tbz             w0, #0, #0xb70468
    //     0xb70450: ldurb           w16, [x1, #-1]
    //     0xb70454: ldurb           w17, [x0, #-1]
    //     0xb70458: and             x16, x17, x16, lsr #2
    //     0xb7045c: tst             x16, HEAP, lsr #32
    //     0xb70460: b.eq            #0xb70468
    //     0xb70464: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xb70468: b               #0xb70680
    // 0xb7046c: ldur            x2, [fp, #-0x28]
    // 0xb70470: ldur            x0, [fp, #-0x98]
    // 0xb70474: ldur            x1, [fp, #-0xc8]
    // 0xb70478: r0 = WVa()
    //     0xb70478: bl              #0xb712ac  ; AllocateWVaStub -> WVa (size=0x18)
    // 0xb7047c: mov             x2, x0
    // 0xb70480: ldur            x0, [fp, #-0x98]
    // 0xb70484: stur            x2, [fp, #-0xb0]
    // 0xb70488: StoreField: r2->field_b = r0
    //     0xb70488: stur            w0, [x2, #0xb]
    // 0xb7048c: ldur            x3, [fp, #-0xc8]
    // 0xb70490: StoreField: r2->field_13 = r3
    //     0xb70490: stur            w3, [x2, #0x13]
    // 0xb70494: r4 = Instance_VVa
    //     0xb70494: add             x4, PP, #0x2c, lsl #12  ; [pp+0x2cce0] Obj!VVa@699b61
    //     0xb70498: ldr             x4, [x4, #0xce0]
    // 0xb7049c: StoreField: r2->field_7 = r4
    //     0xb7049c: stur            w4, [x2, #7]
    // 0xb704a0: ldur            x5, [fp, #-0x28]
    // 0xb704a4: LoadField: r1 = r5->field_b
    //     0xb704a4: ldur            w1, [x5, #0xb]
    // 0xb704a8: LoadField: r6 = r5->field_f
    //     0xb704a8: ldur            w6, [x5, #0xf]
    // 0xb704ac: DecompressPointer r6
    //     0xb704ac: add             x6, x6, HEAP, lsl #32
    // 0xb704b0: LoadField: r7 = r6->field_b
    //     0xb704b0: ldur            w7, [x6, #0xb]
    // 0xb704b4: r6 = LoadInt32Instr(r1)
    //     0xb704b4: sbfx            x6, x1, #1, #0x1f
    // 0xb704b8: stur            x6, [fp, #-0xd8]
    // 0xb704bc: r1 = LoadInt32Instr(r7)
    //     0xb704bc: sbfx            x1, x7, #1, #0x1f
    // 0xb704c0: cmp             x6, x1
    // 0xb704c4: b.ne            #0xb704d0
    // 0xb704c8: mov             x1, x5
    // 0xb704cc: r0 = call 0x35fcec
    //     0xb704cc: bl              #0x35fcec
    // 0xb704d0: ldur            x3, [fp, #-0x28]
    // 0xb704d4: ldur            x2, [fp, #-0xc8]
    // 0xb704d8: ldur            x4, [fp, #-0xd8]
    // 0xb704dc: add             x0, x4, #1
    // 0xb704e0: lsl             x1, x0, #1
    // 0xb704e4: StoreField: r3->field_b = r1
    //     0xb704e4: stur            w1, [x3, #0xb]
    // 0xb704e8: LoadField: r1 = r3->field_f
    //     0xb704e8: ldur            w1, [x3, #0xf]
    // 0xb704ec: DecompressPointer r1
    //     0xb704ec: add             x1, x1, HEAP, lsl #32
    // 0xb704f0: ldur            x0, [fp, #-0xb0]
    // 0xb704f4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb704f4: add             x25, x1, x4, lsl #2
    //     0xb704f8: add             x25, x25, #0xf
    //     0xb704fc: str             w0, [x25]
    //     0xb70500: tbz             w0, #0, #0xb7051c
    //     0xb70504: ldurb           w16, [x1, #-1]
    //     0xb70508: ldurb           w17, [x0, #-1]
    //     0xb7050c: and             x16, x17, x16, lsr #2
    //     0xb70510: tst             x16, HEAP, lsr #32
    //     0xb70514: b.eq            #0xb7051c
    //     0xb70518: bl              #0xc53a28  ; ArrayWriteBarrierStub
    // 0xb7051c: LoadField: r0 = r2->field_1f
    //     0xb7051c: ldur            w0, [x2, #0x1f]
    // 0xb70520: DecompressPointer r0
    //     0xb70520: add             x0, x0, HEAP, lsl #32
    // 0xb70524: cmp             w0, NULL
    // 0xb70528: b.ne            #0xb70534
    // 0xb7052c: r1 = 0
    //     0xb7052c: movz            x1, #0
    // 0xb70530: b               #0xb70540
    // 0xb70534: r1 = LoadInt32Instr(r0)
    //     0xb70534: sbfx            x1, x0, #1, #0x1f
    //     0xb70538: tbz             w0, #0, #0xb70540
    //     0xb7053c: ldur            x1, [x0, #7]
    // 0xb70540: ldur            x0, [fp, #-0x10]
    // 0xb70544: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb70544: ldur            w2, [x0, #0x17]
    // 0xb70548: DecompressPointer r2
    //     0xb70548: add             x2, x2, HEAP, lsl #32
    // 0xb7054c: tbz             w2, #4, #0xb7055c
    // 0xb70550: ldur            x2, [fp, #-0xa8]
    // 0xb70554: r5 = true
    //     0xb70554: add             x5, NULL, #0x20  ; true
    // 0xb70558: b               #0xb70574
    // 0xb7055c: ldur            x2, [fp, #-0xa8]
    // 0xb70560: cmp             x1, x2
    // 0xb70564: r16 = true
    //     0xb70564: add             x16, NULL, #0x20  ; true
    // 0xb70568: r17 = false
    //     0xb70568: add             x17, NULL, #0x30  ; false
    // 0xb7056c: csel            x4, x16, x17, gt
    // 0xb70570: mov             x5, x4
    // 0xb70574: ldur            x4, [fp, #-0xd0]
    // 0xb70578: ldur            x1, [fp, #-0xc0]
    // 0xb7057c: stur            x5, [fp, #-0xb0]
    // 0xb70580: r0 = call 0x35e91c
    //     0xb70580: bl              #0x35e91c
    // 0xb70584: mov             x2, x0
    // 0xb70588: ldur            x0, [fp, #-0xd0]
    // 0xb7058c: stur            x2, [fp, #-0xd8]
    // 0xb70590: cmp             x0, x2
    // 0xb70594: b.ne            #0xb705a0
    // 0xb70598: r2 = ""
    //     0xb70598: ldr             x2, [PP, #0x958]  ; [pp+0x958] ""
    // 0xb7059c: b               #0xb705d8
    // 0xb705a0: ldur            x1, [fp, #-0xc0]
    // 0xb705a4: r0 = call 0x35ea78
    //     0xb705a4: bl              #0x35ea78
    // 0xb705a8: add             x3, x0, #1
    // 0xb705ac: ldur            x2, [fp, #-0xd8]
    // 0xb705b0: cbnz            x2, #0xb705c8
    // 0xb705b4: ldur            x0, [fp, #-0xd0]
    // 0xb705b8: cmp             x3, x0
    // 0xb705bc: b.ne            #0xb705cc
    // 0xb705c0: ldur            x2, [fp, #-0xc0]
    // 0xb705c4: b               #0xb705d8
    // 0xb705c8: ldur            x0, [fp, #-0xd0]
    // 0xb705cc: ldur            x1, [fp, #-0xc0]
    // 0xb705d0: r0 = call 0x358e24
    //     0xb705d0: bl              #0x358e24
    // 0xb705d4: mov             x2, x0
    // 0xb705d8: ldur            x0, [fp, #-0x50]
    // 0xb705dc: LoadField: r3 = r0->field_f
    //     0xb705dc: ldur            w3, [x0, #0xf]
    // 0xb705e0: DecompressPointer r3
    //     0xb705e0: add             x3, x3, HEAP, lsl #32
    // 0xb705e4: mov             x1, x0
    // 0xb705e8: stur            x3, [fp, #-0xc8]
    // 0xb705ec: r0 = call 0x3a6e50
    //     0xb705ec: bl              #0x3a6e50
    // 0xb705f0: mov             x1, x0
    // 0xb705f4: ldur            x0, [fp, #-0xc8]
    // 0xb705f8: cmp             w0, w1
    // 0xb705fc: b.eq            #0xb70680
    // 0xb70600: ldur            x0, [fp, #-0xb0]
    // 0xb70604: tbnz            w0, #4, #0xb70680
    // 0xb70608: ldur            x0, [fp, #-0xd0]
    // 0xb7060c: ldur            x1, [fp, #-0xc0]
    // 0xb70610: r0 = call 0x35e91c
    //     0xb70610: bl              #0x35e91c
    // 0xb70614: mov             x2, x0
    // 0xb70618: ldur            x0, [fp, #-0xd0]
    // 0xb7061c: stur            x2, [fp, #-0xd8]
    // 0xb70620: cmp             x0, x2
    // 0xb70624: b.ne            #0xb70630
    // 0xb70628: r0 = ""
    //     0xb70628: ldr             x0, [PP, #0x958]  ; [pp+0x958] ""
    // 0xb7062c: b               #0xb70660
    // 0xb70630: ldur            x1, [fp, #-0xc0]
    // 0xb70634: r0 = call 0x35ea78
    //     0xb70634: bl              #0x35ea78
    // 0xb70638: add             x3, x0, #1
    // 0xb7063c: ldur            x2, [fp, #-0xd8]
    // 0xb70640: cbnz            x2, #0xb70658
    // 0xb70644: ldur            x0, [fp, #-0xd0]
    // 0xb70648: cmp             x3, x0
    // 0xb7064c: b.ne            #0xb70658
    // 0xb70650: ldur            x0, [fp, #-0xc0]
    // 0xb70654: b               #0xb70660
    // 0xb70658: ldur            x1, [fp, #-0xc0]
    // 0xb7065c: r0 = call 0x358e24
    //     0xb7065c: bl              #0x358e24
    // 0xb70660: ldur            x1, [fp, #-0xb8]
    // 0xb70664: mov             x2, x0
    // 0xb70668: stur            x0, [fp, #-0xb0]
    // 0xb7066c: r0 = call 0xafd568
    //     0xb7066c: bl              #0xafd568
    // 0xb70670: ldur            x1, [fp, #-0xb8]
    // 0xb70674: ldur            x2, [fp, #-0xb0]
    // 0xb70678: mov             x3, x0
    // 0xb7067c: r0 = call 0x42e4b4
    //     0xb7067c: bl              #0x42e4b4
    // 0xb70680: ldur            x2, [fp, #-0x90]
    // 0xb70684: b               #0xb70104
    // 0xb70688: ldur            x5, [fp, #-0x10]
    // 0xb7068c: ldur            x7, [fp, #-0x30]
    // 0xb70690: ldur            x9, [fp, #-0x40]
    // 0xb70694: ldur            x2, [fp, #-0x80]
    // 0xb70698: ldur            x6, [fp, #-0x68]
    // 0xb7069c: ldur            x11, [fp, #-0x50]
    // 0xb706a0: ldur            x10, [fp, #-0x58]
    // 0xb706a4: ldur            x8, [fp, #-0x60]
    // 0xb706a8: ldur            x12, [fp, #-0x48]
    // 0xb706ac: ldur            x3, [fp, #-0x78]
    // 0xb706b0: ldur            x4, [fp, #-0x70]
    // 0xb706b4: b               #0xb6fae8
    // 0xb706b8: ldur            x0, [fp, #-0x10]
    // 0xb706bc: ldur            x1, [fp, #-0x80]
    // 0xb706c0: StoreField: r1->field_b = rNULL
    //     0xb706c0: stur            NULL, [x1, #0xb]
    // 0xb706c4: LoadField: r2 = r0->field_27
    //     0xb706c4: ldur            w2, [x0, #0x27]
    // 0xb706c8: DecompressPointer r2
    //     0xb706c8: add             x2, x2, HEAP, lsl #32
    // 0xb706cc: ldur            x1, [fp, #-0x18]
    // 0xb706d0: stur            x2, [fp, #-0x48]
    // 0xb706d4: r0 = call 0x3e0f38
    //     0xb706d4: bl              #0x3e0f38
    // 0xb706d8: mov             x1, x0
    // 0xb706dc: ldur            x2, [fp, #-0x28]
    // 0xb706e0: ldur            x3, [fp, #-0x20]
    // 0xb706e4: r0 = __unknown_function__()
    //     0xb706e4: bl              #0xb70c3c  ; [] ::__unknown_function__
    // 0xb706e8: mov             x1, x0
    // 0xb706ec: stur            x1, [fp, #-0x20]
    // 0xb706f0: r0 = Await()
    //     0xb706f0: bl              #0xb0c534  ; AwaitStub
    // 0xb706f4: ldur            x16, [fp, #-0x48]
    // 0xb706f8: stp             x0, x16, [SP]
    // 0xb706fc: r0 = call 0xb01138
    //     0xb706fc: bl              #0xb01138
    // 0xb70700: ldur            x1, [fp, #-0x10]
    // 0xb70704: StoreField: r1->field_27 = r0
    //     0xb70704: stur            w0, [x1, #0x27]
    //     0xb70708: tbz             w0, #0, #0xb70724
    //     0xb7070c: ldurb           w16, [x1, #-1]
    //     0xb70710: ldurb           w17, [x0, #-1]
    //     0xb70714: and             x16, x17, x16, lsr #2
    //     0xb70718: tst             x16, HEAP, lsr #32
    //     0xb7071c: b.eq            #0xb70724
    //     0xb70720: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xb70724: r16 = <String, int>
    //     0xb70724: ldr             x16, [PP, #0xdd8]  ; [pp+0xdd8] TypeArguments: <String, int>
    // 0xb70728: ldr             lr, [THR, #0x90]  ; THR::empty_array
    // 0xb7072c: stp             lr, x16, [SP]
    // 0xb70730: r0 = Map._fromLiteral()
    //     0xb70730: bl              #0x365604  ; [dart:core] Map::Map._fromLiteral
    // 0xb70734: ldur            x1, [fp, #-0x38]
    // 0xb70738: stur            x0, [fp, #-0x20]
    // 0xb7073c: r0 = call 0x9efcf8
    //     0xb7073c: bl              #0x9efcf8
    // 0xb70740: mov             x1, x0
    // 0xb70744: r0 = call 0x5b482c
    //     0xb70744: bl              #0x5b482c
    // 0xb70748: mov             x2, x0
    // 0xb7074c: stur            x2, [fp, #-0x60]
    // 0xb70750: LoadField: r3 = r2->field_f
    //     0xb70750: ldur            w3, [x2, #0xf]
    // 0xb70754: DecompressPointer r3
    //     0xb70754: add             x3, x3, HEAP, lsl #32
    // 0xb70758: stur            x3, [fp, #-0x58]
    // 0xb7075c: LoadField: r4 = r2->field_13
    //     0xb7075c: ldur            w4, [x2, #0x13]
    // 0xb70760: DecompressPointer r4
    //     0xb70760: add             x4, x4, HEAP, lsl #32
    // 0xb70764: ldur            x5, [fp, #-0x20]
    // 0xb70768: stur            x4, [fp, #-0x50]
    // 0xb7076c: LoadField: r6 = r5->field_7
    //     0xb7076c: ldur            w6, [x5, #7]
    // 0xb70770: DecompressPointer r6
    //     0xb70770: add             x6, x6, HEAP, lsl #32
    // 0xb70774: stur            x6, [fp, #-0x48]
    // 0xb70778: LoadField: r7 = r2->field_7
    //     0xb70778: ldur            w7, [x2, #7]
    // 0xb7077c: DecompressPointer r7
    //     0xb7077c: add             x7, x7, HEAP, lsl #32
    // 0xb70780: stur            x7, [fp, #-0x28]
    // 0xb70784: ldur            x8, [fp, #-0x40]
    // 0xb70788: CheckStackOverflow
    //     0xb70788: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7078c: cmp             SP, x16
    //     0xb70790: b.ls            #0xb70c2c
    // 0xb70794: r0 = LoadClassIdInstr(r3)
    //     0xb70794: ldur            x0, [x3, #-1]
    //     0xb70798: ubfx            x0, x0, #0xc, #0x14
    // 0xb7079c: mov             x1, x3
    // 0xb707a0: r0 = GDT[cid_x0 + 0x14761]()
    //     0xb707a0: movz            x17, #0x4761
    //     0xb707a4: movk            x17, #0x1, lsl #16
    //     0xb707a8: add             lr, x0, x17
    //     0xb707ac: ldr             lr, [x21, lr, lsl #3]
    //     0xb707b0: blr             lr
    // 0xb707b4: tbnz            w0, #4, #0xb709e4
    // 0xb707b8: ldur            x2, [fp, #-0x60]
    // 0xb707bc: ldur            x3, [fp, #-0x58]
    // 0xb707c0: r0 = LoadClassIdInstr(r3)
    //     0xb707c0: ldur            x0, [x3, #-1]
    //     0xb707c4: ubfx            x0, x0, #0xc, #0x14
    // 0xb707c8: mov             x1, x3
    // 0xb707cc: r0 = GDT[cid_x0 + 0x14caa]()
    //     0xb707cc: movz            x17, #0x4caa
    //     0xb707d0: movk            x17, #0x1, lsl #16
    //     0xb707d4: add             lr, x0, x17
    //     0xb707d8: ldr             lr, [x21, lr, lsl #3]
    //     0xb707dc: blr             lr
    // 0xb707e0: ldur            x16, [fp, #-0x50]
    // 0xb707e4: stp             x0, x16, [SP]
    // 0xb707e8: ldur            x0, [fp, #-0x50]
    // 0xb707ec: ClosureCall
    //     0xb707ec: ldr             x4, [PP, #0x158]  ; [pp+0x158] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb707f0: ldur            x2, [x0, #0x1f]
    //     0xb707f4: blr             x2
    // 0xb707f8: mov             x4, x0
    // 0xb707fc: ldur            x3, [fp, #-0x60]
    // 0xb70800: stur            x4, [fp, #-0x70]
    // 0xb70804: StoreField: r3->field_b = r0
    //     0xb70804: stur            w0, [x3, #0xb]
    //     0xb70808: tbz             w0, #0, #0xb70824
    //     0xb7080c: ldurb           w16, [x3, #-1]
    //     0xb70810: ldurb           w17, [x0, #-1]
    //     0xb70814: and             x16, x17, x16, lsr #2
    //     0xb70818: tst             x16, HEAP, lsr #32
    //     0xb7081c: b.eq            #0xb70824
    //     0xb70820: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb70824: cmp             w4, NULL
    // 0xb70828: b.ne            #0xb7085c
    // 0xb7082c: mov             x0, x4
    // 0xb70830: ldur            x2, [fp, #-0x28]
    // 0xb70834: r1 = Null
    //     0xb70834: mov             x1, NULL
    // 0xb70838: cmp             w2, NULL
    // 0xb7083c: b.eq            #0xb7085c
    // 0xb70840: LoadField: r4 = r2->field_1b
    //     0xb70840: ldur            w4, [x2, #0x1b]
    // 0xb70844: DecompressPointer r4
    //     0xb70844: add             x4, x4, HEAP, lsl #32
    // 0xb70848: r8 = X1
    //     0xb70848: ldr             x8, [PP, #0xe68]  ; [pp+0xe68] TypeParameter: X1
    // 0xb7084c: LoadField: r9 = r4->field_7
    //     0xb7084c: ldur            x9, [x4, #7]
    // 0xb70850: r3 = Null
    //     0xb70850: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cce8] Null
    //     0xb70854: ldr             x3, [x3, #0xce8]
    // 0xb70858: blr             x9
    // 0xb7085c: ldur            x3, [fp, #-0x40]
    // 0xb70860: ldur            x0, [fp, #-0x70]
    // 0xb70864: LoadField: r4 = r0->field_b
    //     0xb70864: ldur            w4, [x0, #0xb]
    // 0xb70868: DecompressPointer r4
    //     0xb70868: add             x4, x4, HEAP, lsl #32
    // 0xb7086c: mov             x1, x3
    // 0xb70870: mov             x2, x4
    // 0xb70874: stur            x4, [fp, #-0x78]
    // 0xb70878: r0 = call 0xafeaa4
    //     0xb70878: bl              #0xafeaa4
    // 0xb7087c: ldur            x2, [fp, #-0x40]
    // 0xb70880: LoadField: r1 = r2->field_f
    //     0xb70880: ldur            w1, [x2, #0xf]
    // 0xb70884: DecompressPointer r1
    //     0xb70884: add             x1, x1, HEAP, lsl #32
    // 0xb70888: cmp             w1, w0
    // 0xb7088c: b.ne            #0xb70894
    // 0xb70890: r0 = Null
    //     0xb70890: mov             x0, NULL
    // 0xb70894: cmp             w0, NULL
    // 0xb70898: b.ne            #0xb708a8
    // 0xb7089c: r3 = _ConstSet len:0
    //     0xb7089c: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c480] Set<String>(0)
    //     0xb708a0: ldr             x3, [x3, #0x480]
    // 0xb708a4: b               #0xb708ac
    // 0xb708a8: mov             x3, x0
    // 0xb708ac: stur            x3, [fp, #-0x70]
    // 0xb708b0: r0 = LoadClassIdInstr(r3)
    //     0xb708b0: ldur            x0, [x3, #-1]
    //     0xb708b4: ubfx            x0, x0, #0xc, #0x14
    // 0xb708b8: mov             x1, x3
    // 0xb708bc: r0 = GDT[cid_x0 + 0xd677]()
    //     0xb708bc: movz            x17, #0xd677
    //     0xb708c0: add             lr, x0, x17
    //     0xb708c4: ldr             lr, [x21, lr, lsl #3]
    //     0xb708c8: blr             lr
    // 0xb708cc: tbnz            w0, #4, #0xb70928
    // 0xb708d0: ldur            x0, [fp, #-0x70]
    // 0xb708d4: ldur            x1, [fp, #-0x18]
    // 0xb708d8: r0 = call 0x3e0f38
    //     0xb708d8: bl              #0x3e0f38
    // 0xb708dc: mov             x2, x0
    // 0xb708e0: ldur            x1, [fp, #-0x70]
    // 0xb708e4: stur            x2, [fp, #-0x80]
    // 0xb708e8: r0 = LoadClassIdInstr(r1)
    //     0xb708e8: ldur            x0, [x1, #-1]
    //     0xb708ec: ubfx            x0, x0, #0xc, #0x14
    // 0xb708f0: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb708f0: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb708f4: r0 = GDT[cid_x0 + 0xcc10]()
    //     0xb708f4: movz            x17, #0xcc10
    //     0xb708f8: add             lr, x0, x17
    //     0xb708fc: ldr             lr, [x21, lr, lsl #3]
    //     0xb70900: blr             lr
    // 0xb70904: ldur            x1, [fp, #-0x80]
    // 0xb70908: ldur            x2, [fp, #-0x78]
    // 0xb7090c: mov             x3, x0
    // 0xb70910: r0 = __unknown_function__()
    //     0xb70910: bl              #0xb54cd0  ; [] ::__unknown_function__
    // 0xb70914: mov             x1, x0
    // 0xb70918: stur            x1, [fp, #-0x70]
    // 0xb7091c: r0 = Await()
    //     0xb7091c: bl              #0xb0c534  ; AwaitStub
    // 0xb70920: mov             x3, x0
    // 0xb70924: b               #0xb7092c
    // 0xb70928: r3 = 0
    //     0xb70928: movz            x3, #0
    // 0xb7092c: ldur            x0, [fp, #-0x78]
    // 0xb70930: ldur            x2, [fp, #-0x48]
    // 0xb70934: stur            x3, [fp, #-0x70]
    // 0xb70938: r1 = Null
    //     0xb70938: mov             x1, NULL
    // 0xb7093c: cmp             w2, NULL
    // 0xb70940: b.eq            #0xb70960
    // 0xb70944: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb70944: ldur            w4, [x2, #0x17]
    // 0xb70948: DecompressPointer r4
    //     0xb70948: add             x4, x4, HEAP, lsl #32
    // 0xb7094c: r8 = X0
    //     0xb7094c: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xb70950: LoadField: r9 = r4->field_7
    //     0xb70950: ldur            x9, [x4, #7]
    // 0xb70954: r3 = Null
    //     0xb70954: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2ccf8] Null
    //     0xb70958: ldr             x3, [x3, #0xcf8]
    // 0xb7095c: blr             x9
    // 0xb70960: ldur            x0, [fp, #-0x70]
    // 0xb70964: ldur            x2, [fp, #-0x48]
    // 0xb70968: r1 = Null
    //     0xb70968: mov             x1, NULL
    // 0xb7096c: cmp             w2, NULL
    // 0xb70970: b.eq            #0xb70990
    // 0xb70974: LoadField: r4 = r2->field_1b
    //     0xb70974: ldur            w4, [x2, #0x1b]
    // 0xb70978: DecompressPointer r4
    //     0xb70978: add             x4, x4, HEAP, lsl #32
    // 0xb7097c: r8 = X1
    //     0xb7097c: ldr             x8, [PP, #0xe68]  ; [pp+0xe68] TypeParameter: X1
    // 0xb70980: LoadField: r9 = r4->field_7
    //     0xb70980: ldur            x9, [x4, #7]
    // 0xb70984: r3 = Null
    //     0xb70984: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cd08] Null
    //     0xb70988: ldr             x3, [x3, #0xd08]
    // 0xb7098c: blr             x9
    // 0xb70990: ldur            x1, [fp, #-0x20]
    // 0xb70994: ldur            x2, [fp, #-0x78]
    // 0xb70998: r0 = call 0xafd568
    //     0xb70998: bl              #0xafd568
    // 0xb7099c: mov             x2, x0
    // 0xb709a0: r0 = BoxInt64Instr(r2)
    //     0xb709a0: sbfiz           x0, x2, #1, #0x1f
    //     0xb709a4: cmp             x2, x0, asr #1
    //     0xb709a8: b.eq            #0xb709b4
    //     0xb709ac: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb709b0: stur            x2, [x0, #7]
    // 0xb709b4: ldur            x1, [fp, #-0x20]
    // 0xb709b8: ldur            x2, [fp, #-0x78]
    // 0xb709bc: ldur            x3, [fp, #-0x70]
    // 0xb709c0: mov             x5, x0
    // 0xb709c4: r0 = call 0xaf3698
    //     0xb709c4: bl              #0xaf3698
    // 0xb709c8: ldur            x5, [fp, #-0x20]
    // 0xb709cc: ldur            x2, [fp, #-0x60]
    // 0xb709d0: ldur            x6, [fp, #-0x48]
    // 0xb709d4: ldur            x7, [fp, #-0x28]
    // 0xb709d8: ldur            x3, [fp, #-0x58]
    // 0xb709dc: ldur            x4, [fp, #-0x50]
    // 0xb709e0: b               #0xb70784
    // 0xb709e4: ldur            x0, [fp, #-0x60]
    // 0xb709e8: ldur            x1, [fp, #-0x68]
    // 0xb709ec: StoreField: r0->field_b = rNULL
    //     0xb709ec: stur            NULL, [x0, #0xb]
    // 0xb709f0: tbnz            w1, #4, #0xb70c08
    // 0xb709f4: ldur            x0, [fp, #-0x38]
    // 0xb709f8: LoadField: r1 = r0->field_7
    //     0xb709f8: ldur            w1, [x0, #7]
    // 0xb709fc: DecompressPointer r1
    //     0xb709fc: add             x1, x1, HEAP, lsl #32
    // 0xb70a00: r0 = _qd()
    //     0xb70a00: bl              #0xb0ab9c  ; Allocate_qdStub -> _qd<X0> (size=0x20)
    // 0xb70a04: mov             x1, x0
    // 0xb70a08: ldur            x0, [fp, #-0x38]
    // 0xb70a0c: StoreField: r1->field_b = r0
    //     0xb70a0c: stur            w0, [x1, #0xb]
    // 0xb70a10: r0 = -2
    //     0xb70a10: orr             x0, xzr, #0xfffffffffffffffe
    // 0xb70a14: StoreField: r1->field_f = r0
    //     0xb70a14: stur            x0, [x1, #0xf]
    // 0xb70a18: r0 = 2
    //     0xb70a18: movz            x0, #0x2
    // 0xb70a1c: ArrayStore: r1[0] = r0  ; List_8
    //     0xb70a1c: stur            x0, [x1, #0x17]
    // 0xb70a20: r0 = call 0x5b43cc
    //     0xb70a20: bl              #0x5b43cc
    // 0xb70a24: stur            x0, [fp, #-0x38]
    // 0xb70a28: LoadField: r2 = r0->field_7
    //     0xb70a28: ldur            w2, [x0, #7]
    // 0xb70a2c: DecompressPointer r2
    //     0xb70a2c: add             x2, x2, HEAP, lsl #32
    // 0xb70a30: stur            x2, [fp, #-0x28]
    // 0xb70a34: ldur            x4, [fp, #-0x10]
    // 0xb70a38: ldur            x6, [fp, #-0x18]
    // 0xb70a3c: ldur            x5, [fp, #-0x30]
    // 0xb70a40: ldur            x3, [fp, #-0x20]
    // 0xb70a44: CheckStackOverflow
    //     0xb70a44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb70a48: cmp             SP, x16
    //     0xb70a4c: b.ls            #0xb70c34
    // 0xb70a50: mov             x1, x0
    // 0xb70a54: r0 = call 0x394764
    //     0xb70a54: bl              #0x394764
    // 0xb70a58: tbnz            w0, #4, #0xb70c08
    // 0xb70a5c: ldur            x3, [fp, #-0x38]
    // 0xb70a60: LoadField: r4 = r3->field_33
    //     0xb70a60: ldur            w4, [x3, #0x33]
    // 0xb70a64: DecompressPointer r4
    //     0xb70a64: add             x4, x4, HEAP, lsl #32
    // 0xb70a68: stur            x4, [fp, #-0x40]
    // 0xb70a6c: cmp             w4, NULL
    // 0xb70a70: b.ne            #0xb70aa4
    // 0xb70a74: mov             x0, x4
    // 0xb70a78: ldur            x2, [fp, #-0x28]
    // 0xb70a7c: r1 = Null
    //     0xb70a7c: mov             x1, NULL
    // 0xb70a80: cmp             w2, NULL
    // 0xb70a84: b.eq            #0xb70aa4
    // 0xb70a88: ArrayLoad: r4 = r2[0]  ; List_4
    //     0xb70a88: ldur            w4, [x2, #0x17]
    // 0xb70a8c: DecompressPointer r4
    //     0xb70a8c: add             x4, x4, HEAP, lsl #32
    // 0xb70a90: r8 = X0
    //     0xb70a90: ldr             x8, [PP, #0x330]  ; [pp+0x330] TypeParameter: X0
    // 0xb70a94: LoadField: r9 = r4->field_7
    //     0xb70a94: ldur            x9, [x4, #7]
    // 0xb70a98: r3 = Null
    //     0xb70a98: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2cd18] Null
    //     0xb70a9c: ldr             x3, [x3, #0xd18]
    // 0xb70aa0: blr             x9
    // 0xb70aa4: ldur            x0, [fp, #-0x30]
    // 0xb70aa8: mov             x1, x0
    // 0xb70aac: ldur            x2, [fp, #-0x40]
    // 0xb70ab0: r0 = call 0xafeaa4
    //     0xb70ab0: bl              #0xafeaa4
    // 0xb70ab4: mov             x1, x0
    // 0xb70ab8: ldur            x0, [fp, #-0x30]
    // 0xb70abc: LoadField: r2 = r0->field_f
    //     0xb70abc: ldur            w2, [x0, #0xf]
    // 0xb70ac0: DecompressPointer r2
    //     0xb70ac0: add             x2, x2, HEAP, lsl #32
    // 0xb70ac4: cmp             w2, w1
    // 0xb70ac8: b.ne            #0xb70ad4
    // 0xb70acc: r3 = Null
    //     0xb70acc: mov             x3, NULL
    // 0xb70ad0: b               #0xb70ad8
    // 0xb70ad4: mov             x3, x1
    // 0xb70ad8: stur            x3, [fp, #-0x50]
    // 0xb70adc: cmp             w3, NULL
    // 0xb70ae0: b.ne            #0xb70aec
    // 0xb70ae4: ldur            x1, [fp, #-0x10]
    // 0xb70ae8: b               #0xb70bf8
    // 0xb70aec: ldur            x5, [fp, #-0x10]
    // 0xb70af0: ldur            x4, [fp, #-0x20]
    // 0xb70af4: LoadField: r6 = r5->field_27
    //     0xb70af4: ldur            w6, [x5, #0x27]
    // 0xb70af8: DecompressPointer r6
    //     0xb70af8: add             x6, x6, HEAP, lsl #32
    // 0xb70afc: mov             x1, x4
    // 0xb70b00: ldur            x2, [fp, #-0x40]
    // 0xb70b04: stur            x6, [fp, #-0x48]
    // 0xb70b08: r0 = call 0xafeaa4
    //     0xb70b08: bl              #0xafeaa4
    // 0xb70b0c: mov             x1, x0
    // 0xb70b10: ldur            x0, [fp, #-0x20]
    // 0xb70b14: LoadField: r2 = r0->field_f
    //     0xb70b14: ldur            w2, [x0, #0xf]
    // 0xb70b18: DecompressPointer r2
    //     0xb70b18: add             x2, x2, HEAP, lsl #32
    // 0xb70b1c: cmp             w2, w1
    // 0xb70b20: b.ne            #0xb70b28
    // 0xb70b24: r1 = Null
    //     0xb70b24: mov             x1, NULL
    // 0xb70b28: cmp             w1, NULL
    // 0xb70b2c: b.ne            #0xb70b38
    // 0xb70b30: r4 = 0
    //     0xb70b30: movz            x4, #0
    // 0xb70b34: b               #0xb70b48
    // 0xb70b38: r2 = LoadInt32Instr(r1)
    //     0xb70b38: sbfx            x2, x1, #1, #0x1f
    //     0xb70b3c: tbz             w1, #0, #0xb70b44
    //     0xb70b40: ldur            x2, [x1, #7]
    // 0xb70b44: mov             x4, x2
    // 0xb70b48: ldur            x2, [fp, #-0x10]
    // 0xb70b4c: ldur            x3, [fp, #-0x18]
    // 0xb70b50: ldur            x1, [fp, #-0x50]
    // 0xb70b54: stur            x4, [fp, #-0xa8]
    // 0xb70b58: r1 = 4
    //     0xb70b58: movz            x1, #0x4
    // 0xb70b5c: r0 = AllocateContext()
    //     0xb70b5c: bl              #0xc547b8  ; AllocateContextStub
    // 0xb70b60: mov             x2, x0
    // 0xb70b64: ldur            x3, [fp, #-0x18]
    // 0xb70b68: StoreField: r2->field_f = r3
    //     0xb70b68: stur            w3, [x2, #0xf]
    // 0xb70b6c: ldur            x0, [fp, #-0x50]
    // 0xb70b70: StoreField: r2->field_13 = r0
    //     0xb70b70: stur            w0, [x2, #0x13]
    // 0xb70b74: r4 = false
    //     0xb70b74: add             x4, NULL, #0x30  ; false
    // 0xb70b78: ArrayStore: r2[0] = r4  ; List_4
    //     0xb70b78: stur            w4, [x2, #0x17]
    // 0xb70b7c: ldur            x5, [fp, #-0xa8]
    // 0xb70b80: r0 = BoxInt64Instr(r5)
    //     0xb70b80: sbfiz           x0, x5, #1, #0x1f
    //     0xb70b84: cmp             x5, x0, asr #1
    //     0xb70b88: b.eq            #0xb70b94
    //     0xb70b8c: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xb70b90: stur            x5, [x0, #7]
    // 0xb70b94: StoreField: r2->field_1b = r0
    //     0xb70b94: stur            w0, [x2, #0x1b]
    // 0xb70b98: r1 = Function '<anonymous closure>': static.
    //     0xb70b98: add             x1, PP, #0x2b, lsl #12  ; [pp+0x2bad0] AnonymousClosure: static (0x447010), of [fbn] 
    //     0xb70b9c: ldr             x1, [x1, #0xad0]
    // 0xb70ba0: r0 = AllocateClosure()
    //     0xb70ba0: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb70ba4: r16 = <int>
    //     0xb70ba4: ldr             x16, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    // 0xb70ba8: ldur            lr, [fp, #-0x18]
    // 0xb70bac: stp             lr, x16, [SP, #8]
    // 0xb70bb0: str             x0, [SP]
    // 0xb70bb4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb70bb4: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb70bb8: r0 = __unknown_function__()
    //     0xb70bb8: bl              #0xb39ce8  ; [] ::__unknown_function__
    // 0xb70bbc: mov             x1, x0
    // 0xb70bc0: stur            x1, [fp, #-0x40]
    // 0xb70bc4: r0 = Await()
    //     0xb70bc4: bl              #0xb0c534  ; AwaitStub
    // 0xb70bc8: ldur            x16, [fp, #-0x48]
    // 0xb70bcc: stp             x0, x16, [SP]
    // 0xb70bd0: r0 = call 0xb01138
    //     0xb70bd0: bl              #0xb01138
    // 0xb70bd4: ldur            x1, [fp, #-0x10]
    // 0xb70bd8: StoreField: r1->field_27 = r0
    //     0xb70bd8: stur            w0, [x1, #0x27]
    //     0xb70bdc: tbz             w0, #0, #0xb70bf8
    //     0xb70be0: ldurb           w16, [x1, #-1]
    //     0xb70be4: ldurb           w17, [x0, #-1]
    //     0xb70be8: and             x16, x17, x16, lsr #2
    //     0xb70bec: tst             x16, HEAP, lsr #32
    //     0xb70bf0: b.eq            #0xb70bf8
    //     0xb70bf4: bl              #0xc53f74  ; WriteBarrierWrappersStub
    // 0xb70bf8: mov             x4, x1
    // 0xb70bfc: ldur            x0, [fp, #-0x38]
    // 0xb70c00: ldur            x2, [fp, #-0x28]
    // 0xb70c04: b               #0xb70a38
    // 0xb70c08: r0 = Null
    //     0xb70c08: mov             x0, NULL
    // 0xb70c0c: r0 = ReturnAsyncNotFuture()
    //     0xb70c0c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb70c10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb70c10: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb70c14: b               #0xb6f950
    // 0xb70c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb70c18: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb70c1c: b               #0xb6faf8
    // 0xb70c20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb70c20: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb70c24: b               #0xb7012c
    // 0xb70c28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb70c28: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb70c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb70c2c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb70c30: b               #0xb70794
    // 0xb70c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb70c34: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb70c38: b               #0xb70a50
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb741c8, size: 0x150
    // 0xb741c8: EnterFrame
    //     0xb741c8: stp             fp, lr, [SP, #-0x10]!
    //     0xb741cc: mov             fp, SP
    // 0xb741d0: AllocStack(0x20)
    //     0xb741d0: sub             SP, SP, #0x20
    // 0xb741d4: SetupParameters(dynamic _ /* r1 */)
    //     0xb741d4: stur            NULL, [fp, #-8]
    //     0xb741d8: movz            x0, #0
    //     0xb741dc: add             x1, fp, w0, sxtw #2
    //     0xb741e0: ldr             x1, [x1, #0x18]
    //     0xb741e4: ldur            w2, [x1, #0x17]
    //     0xb741e8: add             x2, x2, HEAP, lsl #32
    //     0xb741ec: stur            x2, [fp, #-0x10]
    // 0xb741f0: CheckStackOverflow
    //     0xb741f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb741f4: cmp             SP, x16
    //     0xb741f8: b.ls            #0xb7430c
    // 0xb741fc: InitAsync() -> Future<int>
    //     0xb741fc: ldr             x0, [PP, #0x68]  ; [pp+0x68] TypeArguments: <int>
    //     0xb74200: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb74204: ldur            x0, [fp, #-0x10]
    // 0xb74208: ArrayLoad: r1 = r0[0]  ; List_4
    //     0xb74208: ldur            w1, [x0, #0x17]
    // 0xb7420c: DecompressPointer r1
    //     0xb7420c: add             x1, x1, HEAP, lsl #32
    // 0xb74210: r0 = call 0x44c36c
    //     0xb74210: bl              #0x44c36c
    // 0xb74214: ldur            x0, [fp, #-0x10]
    // 0xb74218: LoadField: r4 = r0->field_f
    //     0xb74218: ldur            w4, [x0, #0xf]
    // 0xb7421c: DecompressPointer r4
    //     0xb7421c: add             x4, x4, HEAP, lsl #32
    // 0xb74220: stur            x4, [fp, #-0x18]
    // 0xb74224: LoadField: r2 = r0->field_13
    //     0xb74224: ldur            w2, [x0, #0x13]
    // 0xb74228: DecompressPointer r2
    //     0xb74228: add             x2, x2, HEAP, lsl #32
    // 0xb7422c: LoadField: r3 = r0->field_1b
    //     0xb7422c: ldur            w3, [x0, #0x1b]
    // 0xb74230: DecompressPointer r3
    //     0xb74230: add             x3, x3, HEAP, lsl #32
    // 0xb74234: mov             x1, x4
    // 0xb74238: r0 = __unknown_function__()
    //     0xb74238: bl              #0xb76a30  ; [] ::__unknown_function__
    // 0xb7423c: mov             x1, x0
    // 0xb74240: stur            x1, [fp, #-0x20]
    // 0xb74244: r0 = Await()
    //     0xb74244: bl              #0xb0c534  ; AwaitStub
    // 0xb74248: cmp             w0, NULL
    // 0xb7424c: b.eq            #0xb74264
    // 0xb74250: ldur            x3, [fp, #-0x10]
    // 0xb74254: ArrayLoad: r1 = r3[0]  ; List_4
    //     0xb74254: ldur            w1, [x3, #0x17]
    // 0xb74258: DecompressPointer r1
    //     0xb74258: add             x1, x1, HEAP, lsl #32
    // 0xb7425c: mov             x2, x0
    // 0xb74260: r0 = call 0x44c060
    //     0xb74260: bl              #0x44c060
    // 0xb74264: ldur            x0, [fp, #-0x10]
    // 0xb74268: ldur            x1, [fp, #-0x18]
    // 0xb7426c: r0 = call 0x3e0f38
    //     0xb7426c: bl              #0x3e0f38
    // 0xb74270: mov             x1, x0
    // 0xb74274: ldur            x0, [fp, #-0x10]
    // 0xb74278: LoadField: r2 = r0->field_1b
    //     0xb74278: ldur            w2, [x0, #0x1b]
    // 0xb7427c: DecompressPointer r2
    //     0xb7427c: add             x2, x2, HEAP, lsl #32
    // 0xb74280: LoadField: r3 = r0->field_13
    //     0xb74280: ldur            w3, [x0, #0x13]
    // 0xb74284: DecompressPointer r3
    //     0xb74284: add             x3, x3, HEAP, lsl #32
    // 0xb74288: ArrayLoad: r5 = r0[0]  ; List_4
    //     0xb74288: ldur            w5, [x0, #0x17]
    // 0xb7428c: DecompressPointer r5
    //     0xb7428c: add             x5, x5, HEAP, lsl #32
    // 0xb74290: r0 = __unknown_function__()
    //     0xb74290: bl              #0xb74318  ; [] ::__unknown_function__
    // 0xb74294: mov             x1, x0
    // 0xb74298: stur            x1, [fp, #-0x20]
    // 0xb7429c: r0 = Await()
    //     0xb7429c: bl              #0xb0c534  ; AwaitStub
    // 0xb742a0: ldur            x1, [fp, #-0x18]
    // 0xb742a4: stur            x0, [fp, #-0x18]
    // 0xb742a8: r0 = call 0x430ba8
    //     0xb742a8: bl              #0x430ba8
    // 0xb742ac: ldur            x0, [fp, #-0x18]
    // 0xb742b0: cmp             w0, NULL
    // 0xb742b4: b.eq            #0xb74314
    // 0xb742b8: r1 = LoadInt32Instr(r0)
    //     0xb742b8: sbfx            x1, x0, #1, #0x1f
    //     0xb742bc: tbz             w0, #0, #0xb742c4
    //     0xb742c0: ldur            x1, [x0, #7]
    // 0xb742c4: cmp             x1, #0
    // 0xb742c8: b.le            #0xb74304
    // 0xb742cc: ldur            x1, [fp, #-0x10]
    // 0xb742d0: r0 = InitLateStaticField(0x14dc) // [Ban] YTa::_UMc
    //     0xb742d0: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xb742d4: ldr             x0, [x0, #0x29b8]
    //     0xb742d8: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xb742dc: cmp             w0, w16
    //     0xb742e0: b.ne            #0xb742f0
    //     0xb742e4: add             x2, PP, #0x28, lsl #12  ; [pp+0x28a78] Field <YTa._UMc@1446346532>: static late final (offset: 0x14dc)
    //     0xb742e8: ldr             x2, [x2, #0xa78]
    //     0xb742ec: bl              #0xc538c4  ; InitLateFinalStaticFieldStub
    // 0xb742f0: mov             x1, x0
    // 0xb742f4: ldur            x0, [fp, #-0x10]
    // 0xb742f8: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb742f8: ldur            w2, [x0, #0x17]
    // 0xb742fc: DecompressPointer r2
    //     0xb742fc: add             x2, x2, HEAP, lsl #32
    // 0xb74300: r0 = call 0x442824
    //     0xb74300: bl              #0x442824
    // 0xb74304: ldur            x0, [fp, #-0x18]
    // 0xb74308: r0 = ReturnAsyncNotFuture()
    //     0xb74308: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb7430c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7430c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb74310: b               #0xb741fc
    // 0xb74314: r0 = NullErrorSharedWithoutFPURegs()
    //     0xb74314: bl              #0xc560a8  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xb7a6f4, size: 0x128
    // 0xb7a6f4: EnterFrame
    //     0xb7a6f4: stp             fp, lr, [SP, #-0x10]!
    //     0xb7a6f8: mov             fp, SP
    // 0xb7a6fc: AllocStack(0x30)
    //     0xb7a6fc: sub             SP, SP, #0x30
    // 0xb7a700: SetupParameters(dynamic _ /* r1 */)
    //     0xb7a700: stur            NULL, [fp, #-8]
    //     0xb7a704: movz            x0, #0
    //     0xb7a708: add             x1, fp, w0, sxtw #2
    //     0xb7a70c: ldr             x1, [x1, #0x10]
    //     0xb7a710: ldur            w2, [x1, #0x17]
    //     0xb7a714: add             x2, x2, HEAP, lsl #32
    //     0xb7a718: stur            x2, [fp, #-0x10]
    // 0xb7a71c: CheckStackOverflow
    //     0xb7a71c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7a720: cmp             SP, x16
    //     0xb7a724: b.ls            #0xb7a814
    // 0xb7a728: InitAsync() -> Future<Null?>
    //     0xb7a728: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xb7a72c: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb7a730: ldur            x0, [fp, #-0x10]
    // 0xb7a734: LoadField: r1 = r0->field_1b
    //     0xb7a734: ldur            w1, [x0, #0x1b]
    // 0xb7a738: DecompressPointer r1
    //     0xb7a738: add             x1, x1, HEAP, lsl #32
    // 0xb7a73c: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xb7a73c: ldur            w2, [x1, #0x17]
    // 0xb7a740: DecompressPointer r2
    //     0xb7a740: add             x2, x2, HEAP, lsl #32
    // 0xb7a744: stur            x2, [fp, #-0x18]
    // 0xb7a748: LoadField: r1 = r2->field_f
    //     0xb7a748: ldur            w1, [x2, #0xf]
    // 0xb7a74c: DecompressPointer r1
    //     0xb7a74c: add             x1, x1, HEAP, lsl #32
    // 0xb7a750: r0 = call 0x430ba8
    //     0xb7a750: bl              #0x430ba8
    // 0xb7a754: ldur            x0, [fp, #-0x18]
    // 0xb7a758: LoadField: r1 = r0->field_13
    //     0xb7a758: ldur            w1, [x0, #0x13]
    // 0xb7a75c: DecompressPointer r1
    //     0xb7a75c: add             x1, x1, HEAP, lsl #32
    // 0xb7a760: str             x1, [SP]
    // 0xb7a764: mov             x0, x1
    // 0xb7a768: ClosureCall
    //     0xb7a768: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xb7a76c: ldur            x2, [x0, #0x1f]
    //     0xb7a770: blr             x2
    // 0xb7a774: r1 = 60
    //     0xb7a774: movz            x1, #0x3c
    // 0xb7a778: branchIfSmi(r0, 0xb7a784)
    //     0xb7a778: tbz             w0, #0, #0xb7a784
    // 0xb7a77c: r1 = LoadClassIdInstr(r0)
    //     0xb7a77c: ldur            x1, [x0, #-1]
    //     0xb7a780: ubfx            x1, x1, #0xc, #0x14
    // 0xb7a784: r16 = true
    //     0xb7a784: add             x16, NULL, #0x20  ; true
    // 0xb7a788: stp             x16, x0, [SP]
    // 0xb7a78c: mov             x0, x1
    // 0xb7a790: mov             lr, x0
    // 0xb7a794: ldr             lr, [x21, lr, lsl #3]
    // 0xb7a798: blr             lr
    // 0xb7a79c: tbz             w0, #4, #0xb7a7f4
    // 0xb7a7a0: ldur            x0, [fp, #-0x10]
    // 0xb7a7a4: LoadField: r3 = r0->field_1f
    //     0xb7a7a4: ldur            w3, [x0, #0x1f]
    // 0xb7a7a8: DecompressPointer r3
    //     0xb7a7a8: add             x3, x3, HEAP, lsl #32
    // 0xb7a7ac: stur            x3, [fp, #-0x18]
    // 0xb7a7b0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb7a7b0: ldur            w2, [x0, #0x17]
    // 0xb7a7b4: DecompressPointer r2
    //     0xb7a7b4: add             x2, x2, HEAP, lsl #32
    // 0xb7a7b8: mov             x1, x3
    // 0xb7a7bc: r0 = __unknown_function__()
    //     0xb7a7bc: bl              #0xb7a944  ; [] ::__unknown_function__
    // 0xb7a7c0: mov             x1, x0
    // 0xb7a7c4: stur            x1, [fp, #-0x20]
    // 0xb7a7c8: r0 = Await()
    //     0xb7a7c8: bl              #0xb0c534  ; AwaitStub
    // 0xb7a7cc: ldur            x0, [fp, #-0x10]
    // 0xb7a7d0: ArrayLoad: r2 = r0[0]  ; List_4
    //     0xb7a7d0: ldur            w2, [x0, #0x17]
    // 0xb7a7d4: DecompressPointer r2
    //     0xb7a7d4: add             x2, x2, HEAP, lsl #32
    // 0xb7a7d8: ldur            x1, [fp, #-0x18]
    // 0xb7a7dc: r0 = __unknown_function__()
    //     0xb7a7dc: bl              #0xb7a81c  ; [] ::__unknown_function__
    // 0xb7a7e0: mov             x1, x0
    // 0xb7a7e4: stur            x1, [fp, #-0x18]
    // 0xb7a7e8: r0 = Await()
    //     0xb7a7e8: bl              #0xb0c534  ; AwaitStub
    // 0xb7a7ec: r0 = Null
    //     0xb7a7ec: mov             x0, NULL
    // 0xb7a7f0: r0 = ReturnAsyncNotFuture()
    //     0xb7a7f0: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb7a7f4: r0 = StateError()
    //     0xb7a7f4: bl              #0xb09194  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb7a7f8: mov             x1, x0
    // 0xb7a7fc: r0 = "roaming initialization finalization cancelled"
    //     0xb7a7fc: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2d118] "roaming initialization finalization cancelled"
    //     0xb7a800: ldr             x0, [x0, #0x118]
    // 0xb7a804: StoreField: r1->field_b = r0
    //     0xb7a804: stur            w0, [x1, #0xb]
    // 0xb7a808: mov             x0, x1
    // 0xb7a80c: r0 = Throw()
    //     0xb7a80c: bl              #0xc53a04  ; ThrowStub
    // 0xb7a810: brk             #0
    // 0xb7a814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7a814: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7a818: b               #0xb7a728
  }
  [closure] static Future<void> <anonymous closure>(dynamic, tVa) async {
    // ** addr: 0xb7b698, size: 0xec
    // 0xb7b698: EnterFrame
    //     0xb7b698: stp             fp, lr, [SP, #-0x10]!
    //     0xb7b69c: mov             fp, SP
    // 0xb7b6a0: AllocStack(0x30)
    //     0xb7b6a0: sub             SP, SP, #0x30
    // 0xb7b6a4: SetupParameters(dynamic _ /* r1 */, dynamic _ /* r2, fp-0x18 */)
    //     0xb7b6a4: stur            NULL, [fp, #-8]
    //     0xb7b6a8: movz            x0, #0
    //     0xb7b6ac: add             x1, fp, w0, sxtw #2
    //     0xb7b6b0: ldr             x1, [x1, #0x18]
    //     0xb7b6b4: add             x2, fp, w0, sxtw #2
    //     0xb7b6b8: ldr             x2, [x2, #0x10]
    //     0xb7b6bc: stur            x2, [fp, #-0x18]
    //     0xb7b6c0: ldur            w3, [x1, #0x17]
    //     0xb7b6c4: add             x3, x3, HEAP, lsl #32
    //     0xb7b6c8: stur            x3, [fp, #-0x10]
    // 0xb7b6cc: CheckStackOverflow
    //     0xb7b6cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7b6d0: cmp             SP, x16
    //     0xb7b6d4: b.ls            #0xb7b77c
    // 0xb7b6d8: InitAsync() -> Future<void?>
    //     0xb7b6d8: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xb7b6dc: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb7b6e0: ldur            x1, [fp, #-0x10]
    // 0xb7b6e4: LoadField: r2 = r1->field_f
    //     0xb7b6e4: ldur            w2, [x1, #0xf]
    // 0xb7b6e8: DecompressPointer r2
    //     0xb7b6e8: add             x2, x2, HEAP, lsl #32
    // 0xb7b6ec: stur            x2, [fp, #-0x20]
    // 0xb7b6f0: LoadField: r0 = r2->field_27
    //     0xb7b6f0: ldur            w0, [x2, #0x27]
    // 0xb7b6f4: DecompressPointer r0
    //     0xb7b6f4: add             x0, x0, HEAP, lsl #32
    // 0xb7b6f8: tbnz            w0, #4, #0xb7b75c
    // 0xb7b6fc: LoadField: r0 = r2->field_b
    //     0xb7b6fc: ldur            w0, [x2, #0xb]
    // 0xb7b700: DecompressPointer r0
    //     0xb7b700: add             x0, x0, HEAP, lsl #32
    // 0xb7b704: LoadField: r3 = r1->field_13
    //     0xb7b704: ldur            w3, [x1, #0x13]
    // 0xb7b708: DecompressPointer r3
    //     0xb7b708: add             x3, x3, HEAP, lsl #32
    // 0xb7b70c: r4 = LoadClassIdInstr(r0)
    //     0xb7b70c: ldur            x4, [x0, #-1]
    //     0xb7b710: ubfx            x4, x4, #0xc, #0x14
    // 0xb7b714: stp             x3, x0, [SP]
    // 0xb7b718: mov             x0, x4
    // 0xb7b71c: mov             lr, x0
    // 0xb7b720: ldr             lr, [x21, lr, lsl #3]
    // 0xb7b724: blr             lr
    // 0xb7b728: tbnz            w0, #4, #0xb7b75c
    // 0xb7b72c: ldur            x0, [fp, #-0x10]
    // 0xb7b730: LoadField: r2 = r0->field_13
    //     0xb7b730: ldur            w2, [x0, #0x13]
    // 0xb7b734: DecompressPointer r2
    //     0xb7b734: add             x2, x2, HEAP, lsl #32
    // 0xb7b738: ldur            x1, [fp, #-0x18]
    // 0xb7b73c: r0 = __unknown_function__()
    //     0xb7b73c: bl              #0xb7b784  ; [] ::__unknown_function__
    // 0xb7b740: mov             x1, x0
    // 0xb7b744: stur            x1, [fp, #-0x18]
    // 0xb7b748: r0 = Await()
    //     0xb7b748: bl              #0xb0c534  ; AwaitStub
    // 0xb7b74c: ldur            x1, [fp, #-0x20]
    // 0xb7b750: r0 = call 0x430ba8
    //     0xb7b750: bl              #0x430ba8
    // 0xb7b754: r0 = Null
    //     0xb7b754: mov             x0, NULL
    // 0xb7b758: r0 = ReturnAsyncNotFuture()
    //     0xb7b758: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb7b75c: r0 = StateError()
    //     0xb7b75c: bl              #0xb09194  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb7b760: mov             x1, x0
    // 0xb7b764: r0 = "roaming invalid-cursor task belongs to another user"
    //     0xb7b764: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2d1c8] "roaming invalid-cursor task belongs to another user"
    //     0xb7b768: ldr             x0, [x0, #0x1c8]
    // 0xb7b76c: StoreField: r1->field_b = r0
    //     0xb7b76c: stur            w0, [x1, #0xb]
    // 0xb7b770: mov             x0, x1
    // 0xb7b774: r0 = Throw()
    //     0xb7b774: bl              #0xc53a04  ; ThrowStub
    // 0xb7b778: brk             #0
    // 0xb7b77c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7b77c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7b780: b               #0xb7b6d8
  }
  [closure] static Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xb7cc7c, size: 0x6ac
    // 0xb7cc7c: EnterFrame
    //     0xb7cc7c: stp             fp, lr, [SP, #-0x10]!
    //     0xb7cc80: mov             fp, SP
    // 0xb7cc84: AllocStack(0xc8)
    //     0xb7cc84: sub             SP, SP, #0xc8
    // 0xb7cc88: SetupParameters(dynamic _ /* r1 */)
    //     0xb7cc88: stur            NULL, [fp, #-8]
    //     0xb7cc8c: movz            x0, #0
    //     0xb7cc90: add             x1, fp, w0, sxtw #2
    //     0xb7cc94: ldr             x1, [x1, #0x10]
    //     0xb7cc98: ldur            w2, [x1, #0x17]
    //     0xb7cc9c: add             x2, x2, HEAP, lsl #32
    //     0xb7cca0: stur            x2, [fp, #-0x10]
    // 0xb7cca4: CheckStackOverflow
    //     0xb7cca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7cca8: cmp             SP, x16
    //     0xb7ccac: b.ls            #0xb7d30c
    // 0xb7ccb0: InitAsync() -> Future<Null?>
    //     0xb7ccb0: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xb7ccb4: bl              #0xb0c86c  ; InitAsyncStub
    // 0xb7ccb8: ldur            x0, [fp, #-0x10]
    // 0xb7ccbc: LoadField: r1 = r0->field_2b
    //     0xb7ccbc: ldur            w1, [x0, #0x2b]
    // 0xb7ccc0: DecompressPointer r1
    //     0xb7ccc0: add             x1, x1, HEAP, lsl #32
    // 0xb7ccc4: r0 = call 0x9efcf8
    //     0xb7ccc4: bl              #0x9efcf8
    // 0xb7ccc8: mov             x1, x0
    // 0xb7cccc: r0 = call 0x5b482c
    //     0xb7cccc: bl              #0x5b482c
    // 0xb7ccd0: mov             x2, x0
    // 0xb7ccd4: stur            x2, [fp, #-0x60]
    // 0xb7ccd8: LoadField: r3 = r2->field_f
    //     0xb7ccd8: ldur            w3, [x2, #0xf]
    // 0xb7ccdc: DecompressPointer r3
    //     0xb7ccdc: add             x3, x3, HEAP, lsl #32
    // 0xb7cce0: stur            x3, [fp, #-0x58]
    // 0xb7cce4: LoadField: r4 = r2->field_13
    //     0xb7cce4: ldur            w4, [x2, #0x13]
    // 0xb7cce8: DecompressPointer r4
    //     0xb7cce8: add             x4, x4, HEAP, lsl #32
    // 0xb7ccec: ldur            x5, [fp, #-0x10]
    // 0xb7ccf0: stur            x4, [fp, #-0x50]
    // 0xb7ccf4: LoadField: r6 = r5->field_23
    //     0xb7ccf4: ldur            w6, [x5, #0x23]
    // 0xb7ccf8: DecompressPointer r6
    //     0xb7ccf8: add             x6, x6, HEAP, lsl #32
    // 0xb7ccfc: stur            x6, [fp, #-0x48]
    // 0xb7cd00: ArrayLoad: r7 = r6[0]  ; List_4
    //     0xb7cd00: ldur            w7, [x6, #0x17]
    // 0xb7cd04: DecompressPointer r7
    //     0xb7cd04: add             x7, x7, HEAP, lsl #32
    // 0xb7cd08: stur            x7, [fp, #-0x40]
    // 0xb7cd0c: LoadField: r8 = r7->field_f
    //     0xb7cd0c: ldur            w8, [x7, #0xf]
    // 0xb7cd10: DecompressPointer r8
    //     0xb7cd10: add             x8, x8, HEAP, lsl #32
    // 0xb7cd14: stur            x8, [fp, #-0x38]
    // 0xb7cd18: LoadField: r9 = r5->field_27
    //     0xb7cd18: ldur            w9, [x5, #0x27]
    // 0xb7cd1c: DecompressPointer r9
    //     0xb7cd1c: add             x9, x9, HEAP, lsl #32
    // 0xb7cd20: stur            x9, [fp, #-0x30]
    // 0xb7cd24: LoadField: r10 = r5->field_2f
    //     0xb7cd24: ldur            w10, [x5, #0x2f]
    // 0xb7cd28: DecompressPointer r10
    //     0xb7cd28: add             x10, x10, HEAP, lsl #32
    // 0xb7cd2c: stur            x10, [fp, #-0x28]
    // 0xb7cd30: LoadField: r11 = r5->field_f
    //     0xb7cd30: ldur            w11, [x5, #0xf]
    // 0xb7cd34: DecompressPointer r11
    //     0xb7cd34: add             x11, x11, HEAP, lsl #32
    // 0xb7cd38: stur            x11, [fp, #-0x20]
    // 0xb7cd3c: LoadField: r12 = r2->field_7
    //     0xb7cd3c: ldur            w12, [x2, #7]
    // 0xb7cd40: DecompressPointer r12
    //     0xb7cd40: add             x12, x12, HEAP, lsl #32
    // 0xb7cd44: stur            x12, [fp, #-0x18]
    // 0xb7cd48: CheckStackOverflow
    //     0xb7cd48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7cd4c: cmp             SP, x16
    //     0xb7cd50: b.ls            #0xb7d314
    // 0xb7cd54: r0 = LoadClassIdInstr(r3)
    //     0xb7cd54: ldur            x0, [x3, #-1]
    //     0xb7cd58: ubfx            x0, x0, #0xc, #0x14
    // 0xb7cd5c: mov             x1, x3
    // 0xb7cd60: r0 = GDT[cid_x0 + 0x14761]()
    //     0xb7cd60: movz            x17, #0x4761
    //     0xb7cd64: movk            x17, #0x1, lsl #16
    //     0xb7cd68: add             lr, x0, x17
    //     0xb7cd6c: ldr             lr, [x21, lr, lsl #3]
    //     0xb7cd70: blr             lr
    // 0xb7cd74: tbnz            w0, #4, #0xb7d1fc
    // 0xb7cd78: ldur            x2, [fp, #-0x60]
    // 0xb7cd7c: ldur            x3, [fp, #-0x58]
    // 0xb7cd80: r0 = LoadClassIdInstr(r3)
    //     0xb7cd80: ldur            x0, [x3, #-1]
    //     0xb7cd84: ubfx            x0, x0, #0xc, #0x14
    // 0xb7cd88: mov             x1, x3
    // 0xb7cd8c: r0 = GDT[cid_x0 + 0x14caa]()
    //     0xb7cd8c: movz            x17, #0x4caa
    //     0xb7cd90: movk            x17, #0x1, lsl #16
    //     0xb7cd94: add             lr, x0, x17
    //     0xb7cd98: ldr             lr, [x21, lr, lsl #3]
    //     0xb7cd9c: blr             lr
    // 0xb7cda0: ldur            x16, [fp, #-0x50]
    // 0xb7cda4: stp             x0, x16, [SP]
    // 0xb7cda8: ldur            x0, [fp, #-0x50]
    // 0xb7cdac: ClosureCall
    //     0xb7cdac: ldr             x4, [PP, #0x158]  ; [pp+0x158] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xb7cdb0: ldur            x2, [x0, #0x1f]
    //     0xb7cdb4: blr             x2
    // 0xb7cdb8: mov             x4, x0
    // 0xb7cdbc: ldur            x3, [fp, #-0x60]
    // 0xb7cdc0: stur            x4, [fp, #-0x68]
    // 0xb7cdc4: StoreField: r3->field_b = r0
    //     0xb7cdc4: stur            w0, [x3, #0xb]
    //     0xb7cdc8: tbz             w0, #0, #0xb7cde4
    //     0xb7cdcc: ldurb           w16, [x3, #-1]
    //     0xb7cdd0: ldurb           w17, [x0, #-1]
    //     0xb7cdd4: and             x16, x17, x16, lsr #2
    //     0xb7cdd8: tst             x16, HEAP, lsr #32
    //     0xb7cddc: b.eq            #0xb7cde4
    //     0xb7cde0: bl              #0xc53fb4  ; WriteBarrierWrappersStub
    // 0xb7cde4: cmp             w4, NULL
    // 0xb7cde8: b.ne            #0xb7ce1c
    // 0xb7cdec: mov             x0, x4
    // 0xb7cdf0: ldur            x2, [fp, #-0x18]
    // 0xb7cdf4: r1 = Null
    //     0xb7cdf4: mov             x1, NULL
    // 0xb7cdf8: cmp             w2, NULL
    // 0xb7cdfc: b.eq            #0xb7ce1c
    // 0xb7ce00: LoadField: r4 = r2->field_1b
    //     0xb7ce00: ldur            w4, [x2, #0x1b]
    // 0xb7ce04: DecompressPointer r4
    //     0xb7ce04: add             x4, x4, HEAP, lsl #32
    // 0xb7ce08: r8 = X1
    //     0xb7ce08: ldr             x8, [PP, #0xe68]  ; [pp+0xe68] TypeParameter: X1
    // 0xb7ce0c: LoadField: r9 = r4->field_7
    //     0xb7ce0c: ldur            x9, [x4, #7]
    // 0xb7ce10: r3 = Null
    //     0xb7ce10: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d238] Null
    //     0xb7ce14: ldr             x3, [x3, #0x238]
    // 0xb7ce18: blr             x9
    // 0xb7ce1c: ldur            x0, [fp, #-0x40]
    // 0xb7ce20: ldur            x1, [fp, #-0x38]
    // 0xb7ce24: r0 = call 0x430ba8
    //     0xb7ce24: bl              #0x430ba8
    // 0xb7ce28: ldur            x1, [fp, #-0x40]
    // 0xb7ce2c: LoadField: r0 = r1->field_1b
    //     0xb7ce2c: ldur            w0, [x1, #0x1b]
    // 0xb7ce30: DecompressPointer r0
    //     0xb7ce30: add             x0, x0, HEAP, lsl #32
    // 0xb7ce34: str             x0, [SP]
    // 0xb7ce38: ClosureCall
    //     0xb7ce38: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xb7ce3c: ldur            x2, [x0, #0x1f]
    //     0xb7ce40: blr             x2
    // 0xb7ce44: r1 = 60
    //     0xb7ce44: movz            x1, #0x3c
    // 0xb7ce48: branchIfSmi(r0, 0xb7ce54)
    //     0xb7ce48: tbz             w0, #0, #0xb7ce54
    // 0xb7ce4c: r1 = LoadClassIdInstr(r0)
    //     0xb7ce4c: ldur            x1, [x0, #-1]
    //     0xb7ce50: ubfx            x1, x1, #0xc, #0x14
    // 0xb7ce54: r16 = true
    //     0xb7ce54: add             x16, NULL, #0x20  ; true
    // 0xb7ce58: stp             x16, x0, [SP]
    // 0xb7ce5c: mov             x0, x1
    // 0xb7ce60: mov             lr, x0
    // 0xb7ce64: ldr             lr, [x21, lr, lsl #3]
    // 0xb7ce68: blr             lr
    // 0xb7ce6c: tbz             w0, #4, #0xb7d2c4
    // 0xb7ce70: ldur            x0, [fp, #-0x68]
    // 0xb7ce74: LoadField: r3 = r0->field_b
    //     0xb7ce74: ldur            w3, [x0, #0xb]
    // 0xb7ce78: DecompressPointer r3
    //     0xb7ce78: add             x3, x3, HEAP, lsl #32
    // 0xb7ce7c: stur            x3, [fp, #-0x78]
    // 0xb7ce80: LoadField: r4 = r0->field_f
    //     0xb7ce80: ldur            w4, [x0, #0xf]
    // 0xb7ce84: DecompressPointer r4
    //     0xb7ce84: add             x4, x4, HEAP, lsl #32
    // 0xb7ce88: stur            x4, [fp, #-0x70]
    // 0xb7ce8c: r1 = Function '<anonymous closure>': static.
    //     0xb7ce8c: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d248] AnonymousClosure: static (0x454048), in [fbn] ::<anonymous closure> (0xb6f91c)
    //     0xb7ce90: ldr             x1, [x1, #0x248]
    // 0xb7ce94: r2 = Null
    //     0xb7ce94: mov             x2, NULL
    // 0xb7ce98: r0 = AllocateClosure()
    //     0xb7ce98: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb7ce9c: ldur            x1, [fp, #-0x70]
    // 0xb7cea0: r2 = LoadClassIdInstr(r1)
    //     0xb7cea0: ldur            x2, [x1, #-1]
    //     0xb7cea4: ubfx            x2, x2, #0xc, #0x14
    // 0xb7cea8: r16 = <String>
    //     0xb7cea8: ldr             x16, [PP, #0x928]  ; [pp+0x928] TypeArguments: <String>
    // 0xb7ceac: stp             x1, x16, [SP, #8]
    // 0xb7ceb0: str             x0, [SP]
    // 0xb7ceb4: mov             x0, x2
    // 0xb7ceb8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb7ceb8: ldr             x4, [PP, #0x58]  ; [pp+0x58] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb7cebc: r0 = GDT[cid_x0 + 0xd511]()
    //     0xb7cebc: movz            x17, #0xd511
    //     0xb7cec0: add             lr, x0, x17
    //     0xb7cec4: ldr             lr, [x21, lr, lsl #3]
    //     0xb7cec8: blr             lr
    // 0xb7cecc: r1 = Function '<anonymous closure>': static.
    //     0xb7cecc: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d250] AnonymousClosure: static (0x39da88), of [gMm] HP
    //     0xb7ced0: ldr             x1, [x1, #0x250]
    // 0xb7ced4: r2 = Null
    //     0xb7ced4: mov             x2, NULL
    // 0xb7ced8: stur            x0, [fp, #-0x68]
    // 0xb7cedc: r0 = AllocateClosure()
    //     0xb7cedc: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xb7cee0: ldur            x1, [fp, #-0x68]
    // 0xb7cee4: r2 = LoadClassIdInstr(r1)
    //     0xb7cee4: ldur            x2, [x1, #-1]
    //     0xb7cee8: ubfx            x2, x2, #0xc, #0x14
    // 0xb7ceec: mov             x16, x0
    // 0xb7cef0: mov             x0, x2
    // 0xb7cef4: mov             x2, x16
    // 0xb7cef8: r0 = GDT[cid_x0 + 0xe0e0]()
    //     0xb7cef8: movz            x17, #0xe0e0
    //     0xb7cefc: add             lr, x0, x17
    //     0xb7cf00: ldr             lr, [x21, lr, lsl #3]
    //     0xb7cf04: blr             lr
    // 0xb7cf08: r1 = LoadClassIdInstr(r0)
    //     0xb7cf08: ldur            x1, [x0, #-1]
    //     0xb7cf0c: ubfx            x1, x1, #0xc, #0x14
    // 0xb7cf10: mov             x16, x0
    // 0xb7cf14: mov             x0, x1
    // 0xb7cf18: mov             x1, x16
    // 0xb7cf1c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xb7cf1c: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xb7cf20: r0 = GDT[cid_x0 + 0xcc10]()
    //     0xb7cf20: movz            x17, #0xcc10
    //     0xb7cf24: add             lr, x0, x17
    //     0xb7cf28: ldr             lr, [x21, lr, lsl #3]
    //     0xb7cf2c: blr             lr
    // 0xb7cf30: ldur            x1, [fp, #-0x30]
    // 0xb7cf34: ldur            x2, [fp, #-0x78]
    // 0xb7cf38: mov             x3, x0
    // 0xb7cf3c: stur            x0, [fp, #-0x68]
    // 0xb7cf40: r0 = __unknown_function__()
    //     0xb7cf40: bl              #0xb69584  ; [] ::__unknown_function__
    // 0xb7cf44: mov             x1, x0
    // 0xb7cf48: stur            x1, [fp, #-0x80]
    // 0xb7cf4c: r0 = Await()
    //     0xb7cf4c: bl              #0xb0c534  ; AwaitStub
    // 0xb7cf50: ldur            x1, [fp, #-0x30]
    // 0xb7cf54: ldur            x2, [fp, #-0x68]
    // 0xb7cf58: stur            x0, [fp, #-0x68]
    // 0xb7cf5c: r0 = __unknown_function__()
    //     0xb7cf5c: bl              #0xb5ecb8  ; [] ::__unknown_function__
    // 0xb7cf60: mov             x1, x0
    // 0xb7cf64: stur            x1, [fp, #-0x80]
    // 0xb7cf68: r0 = Await()
    //     0xb7cf68: bl              #0xb0c534  ; AwaitStub
    // 0xb7cf6c: mov             x3, x0
    // 0xb7cf70: ldur            x2, [fp, #-0x70]
    // 0xb7cf74: stur            x3, [fp, #-0x80]
    // 0xb7cf78: r0 = LoadClassIdInstr(r2)
    //     0xb7cf78: ldur            x0, [x2, #-1]
    //     0xb7cf7c: ubfx            x0, x0, #0xc, #0x14
    // 0xb7cf80: mov             x1, x2
    // 0xb7cf84: r0 = GDT[cid_x0 + 0xca1c]()
    //     0xb7cf84: movz            x17, #0xca1c
    //     0xb7cf88: add             lr, x0, x17
    //     0xb7cf8c: ldr             lr, [x21, lr, lsl #3]
    //     0xb7cf90: blr             lr
    // 0xb7cf94: mov             x2, x0
    // 0xb7cf98: stur            x2, [fp, #-0x88]
    // 0xb7cf9c: ldur            x4, [fp, #-0x10]
    // 0xb7cfa0: ldur            x3, [fp, #-0x68]
    // 0xb7cfa4: CheckStackOverflow
    //     0xb7cfa4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb7cfa8: cmp             SP, x16
    //     0xb7cfac: b.ls            #0xb7d31c
    // 0xb7cfb0: r0 = LoadClassIdInstr(r2)
    //     0xb7cfb0: ldur            x0, [x2, #-1]
    //     0xb7cfb4: ubfx            x0, x0, #0xc, #0x14
    // 0xb7cfb8: mov             x1, x2
    // 0xb7cfbc: r0 = GDT[cid_x0 + 0x14761]()
    //     0xb7cfbc: movz            x17, #0x4761
    //     0xb7cfc0: movk            x17, #0x1, lsl #16
    //     0xb7cfc4: add             lr, x0, x17
    //     0xb7cfc8: ldr             lr, [x21, lr, lsl #3]
    //     0xb7cfcc: blr             lr
    // 0xb7cfd0: tbnz            w0, #4, #0xb7d150
    // 0xb7cfd4: ldur            x2, [fp, #-0x88]
    // 0xb7cfd8: r0 = LoadClassIdInstr(r2)
    //     0xb7cfd8: ldur            x0, [x2, #-1]
    //     0xb7cfdc: ubfx            x0, x0, #0xc, #0x14
    // 0xb7cfe0: mov             x1, x2
    // 0xb7cfe4: r0 = GDT[cid_x0 + 0x14caa]()
    //     0xb7cfe4: movz            x17, #0x4caa
    //     0xb7cfe8: movk            x17, #0x1, lsl #16
    //     0xb7cfec: add             lr, x0, x17
    //     0xb7cff0: ldr             lr, [x21, lr, lsl #3]
    //     0xb7cff4: blr             lr
    // 0xb7cff8: stur            x0, [fp, #-0xa0]
    // 0xb7cffc: LoadField: r2 = r0->field_73
    //     0xb7cffc: ldur            w2, [x0, #0x73]
    // 0xb7d000: DecompressPointer r2
    //     0xb7d000: add             x2, x2, HEAP, lsl #32
    // 0xb7d004: stur            x2, [fp, #-0x98]
    // 0xb7d008: cmp             w2, NULL
    // 0xb7d00c: b.eq            #0xb7d324
    // 0xb7d010: LoadField: r3 = r2->field_7
    //     0xb7d010: ldur            w3, [x2, #7]
    // 0xb7d014: mov             x1, x2
    // 0xb7d018: stur            x3, [fp, #-0x90]
    // 0xb7d01c: r0 = call 0x35e91c
    //     0xb7d01c: bl              #0x35e91c
    // 0xb7d020: mov             x2, x0
    // 0xb7d024: ldur            x0, [fp, #-0x90]
    // 0xb7d028: stur            x2, [fp, #-0xb0]
    // 0xb7d02c: r3 = LoadInt32Instr(r0)
    //     0xb7d02c: sbfx            x3, x0, #1, #0x1f
    // 0xb7d030: stur            x3, [fp, #-0xa8]
    // 0xb7d034: cmp             x3, x2
    // 0xb7d038: b.ne            #0xb7d044
    // 0xb7d03c: r2 = ""
    //     0xb7d03c: ldr             x2, [PP, #0x958]  ; [pp+0x958] ""
    // 0xb7d040: b               #0xb7d078
    // 0xb7d044: ldur            x1, [fp, #-0x98]
    // 0xb7d048: r0 = call 0x35ea78
    //     0xb7d048: bl              #0x35ea78
    // 0xb7d04c: add             x3, x0, #1
    // 0xb7d050: ldur            x2, [fp, #-0xb0]
    // 0xb7d054: cbnz            x2, #0xb7d06c
    // 0xb7d058: ldur            x0, [fp, #-0xa8]
    // 0xb7d05c: cmp             x3, x0
    // 0xb7d060: b.ne            #0xb7d06c
    // 0xb7d064: ldur            x2, [fp, #-0x98]
    // 0xb7d068: b               #0xb7d078
    // 0xb7d06c: ldur            x1, [fp, #-0x98]
    // 0xb7d070: r0 = call 0x358e24
    //     0xb7d070: bl              #0x358e24
    // 0xb7d074: mov             x2, x0
    // 0xb7d078: ldur            x3, [fp, #-0x68]
    // 0xb7d07c: r0 = LoadClassIdInstr(r3)
    //     0xb7d07c: ldur            x0, [x3, #-1]
    //     0xb7d080: ubfx            x0, x0, #0xc, #0x14
    // 0xb7d084: mov             x1, x3
    // 0xb7d088: r0 = GDT[cid_x0 + 0x447]()
    //     0xb7d088: add             lr, x0, #0x447
    //     0xb7d08c: ldr             lr, [x21, lr, lsl #3]
    //     0xb7d090: blr             lr
    // 0xb7d094: tbz             w0, #4, #0xb7d148
    // 0xb7d098: ldur            x3, [fp, #-0xa0]
    // 0xb7d09c: LoadField: r0 = r3->field_6f
    //     0xb7d09c: ldur            w0, [x3, #0x6f]
    // 0xb7d0a0: DecompressPointer r0
    //     0xb7d0a0: add             x0, x0, HEAP, lsl #32
    // 0xb7d0a4: cmp             w0, NULL
    // 0xb7d0a8: b.ne            #0xb7d0b8
    // 0xb7d0ac: r1 = 4
    //     0xb7d0ac: movz            x1, #0x4
    // 0xb7d0b0: StoreField: r3->field_6f = r1
    //     0xb7d0b0: stur            w1, [x3, #0x6f]
    // 0xb7d0b4: b               #0xb7d0bc
    // 0xb7d0b8: r1 = 4
    //     0xb7d0b8: movz            x1, #0x4
    // 0xb7d0bc: ldur            x2, [fp, #-0x10]
    // 0xb7d0c0: LoadField: r0 = r3->field_b
    //     0xb7d0c0: ldur            w0, [x3, #0xb]
    // 0xb7d0c4: DecompressPointer r0
    //     0xb7d0c4: add             x0, x0, HEAP, lsl #32
    // 0xb7d0c8: LoadField: r4 = r2->field_1f
    //     0xb7d0c8: ldur            w4, [x2, #0x1f]
    // 0xb7d0cc: DecompressPointer r4
    //     0xb7d0cc: add             x4, x4, HEAP, lsl #32
    // 0xb7d0d0: r5 = LoadClassIdInstr(r0)
    //     0xb7d0d0: ldur            x5, [x0, #-1]
    //     0xb7d0d4: ubfx            x5, x5, #0xc, #0x14
    // 0xb7d0d8: stp             x4, x0, [SP]
    // 0xb7d0dc: mov             x0, x5
    // 0xb7d0e0: mov             lr, x0
    // 0xb7d0e4: ldr             lr, [x21, lr, lsl #3]
    // 0xb7d0e8: blr             lr
    // 0xb7d0ec: tbz             w0, #4, #0xb7d118
    // 0xb7d0f0: ldur            x3, [fp, #-0xa0]
    // 0xb7d0f4: LoadField: r0 = r3->field_2b
    //     0xb7d0f4: ldur            w0, [x3, #0x2b]
    // 0xb7d0f8: DecompressPointer r0
    //     0xb7d0f8: add             x0, x0, HEAP, lsl #32
    // 0xb7d0fc: cmp             w0, #2
    // 0xb7d100: b.ne            #0xb7d110
    // 0xb7d104: r0 = 1
    //     0xb7d104: movz            x0, #0x1
    // 0xb7d108: StoreField: r3->field_37 = r0
    //     0xb7d108: stur            x0, [x3, #0x37]
    // 0xb7d10c: b               #0xb7d120
    // 0xb7d110: r0 = 1
    //     0xb7d110: movz            x0, #0x1
    // 0xb7d114: b               #0xb7d120
    // 0xb7d118: ldur            x3, [fp, #-0xa0]
    // 0xb7d11c: r0 = 1
    //     0xb7d11c: movz            x0, #0x1
    // 0xb7d120: ldur            x16, [fp, #-0x80]
    // 0xb7d124: str             x16, [SP]
    // 0xb7d128: ldur            x1, [fp, #-0x30]
    // 0xb7d12c: ldur            x2, [fp, #-0x78]
    // 0xb7d130: r4 = const [0, 0x4, 0x1, 0x3, sti, 0x3, null]
    //     0xb7d130: add             x4, PP, #0x2c, lsl #12  ; [pp+0x2cf48] List(7) [0, 0x4, 0x1, 0x3, "sti", 0x3, Null]
    //     0xb7d134: ldr             x4, [x4, #0xf48]
    // 0xb7d138: r0 = __unknown_function__()
    //     0xb7d138: bl              #0xb5067c  ; [] ::__unknown_function__
    // 0xb7d13c: mov             x1, x0
    // 0xb7d140: stur            x1, [fp, #-0x90]
    // 0xb7d144: r0 = Await()
    //     0xb7d144: bl              #0xb0c534  ; AwaitStub
    // 0xb7d148: ldur            x2, [fp, #-0x88]
    // 0xb7d14c: b               #0xb7cf9c
    // 0xb7d150: ldur            x0, [fp, #-0x10]
    // 0xb7d154: ldur            x3, [fp, #-0x28]
    // 0xb7d158: LoadField: r4 = r0->field_1f
    //     0xb7d158: ldur            w4, [x0, #0x1f]
    // 0xb7d15c: DecompressPointer r4
    //     0xb7d15c: add             x4, x4, HEAP, lsl #32
    // 0xb7d160: mov             x1, x3
    // 0xb7d164: ldur            x2, [fp, #-0x78]
    // 0xb7d168: stur            x4, [fp, #-0x68]
    // 0xb7d16c: r0 = call 0xafeaa4
    //     0xb7d16c: bl              #0xafeaa4
    // 0xb7d170: mov             x1, x0
    // 0xb7d174: ldur            x0, [fp, #-0x28]
    // 0xb7d178: LoadField: r2 = r0->field_f
    //     0xb7d178: ldur            w2, [x0, #0xf]
    // 0xb7d17c: DecompressPointer r2
    //     0xb7d17c: add             x2, x2, HEAP, lsl #32
    // 0xb7d180: cmp             w2, w1
    // 0xb7d184: b.ne            #0xb7d18c
    // 0xb7d188: r1 = Null
    //     0xb7d188: mov             x1, NULL
    // 0xb7d18c: cmp             w1, NULL
    // 0xb7d190: b.ne            #0xb7d19c
    // 0xb7d194: r2 = 0
    //     0xb7d194: movz            x2, #0
    // 0xb7d198: b               #0xb7d1a8
    // 0xb7d19c: r2 = LoadInt32Instr(r1)
    //     0xb7d19c: sbfx            x2, x1, #1, #0x1f
    //     0xb7d1a0: tbz             w1, #0, #0xb7d1a8
    //     0xb7d1a4: ldur            x2, [x1, #7]
    // 0xb7d1a8: ldur            x1, [fp, #-0x20]
    // 0xb7d1ac: ldur            x3, [fp, #-0x68]
    // 0xb7d1b0: ldur            x5, [fp, #-0x30]
    // 0xb7d1b4: ldur            x6, [fp, #-0x70]
    // 0xb7d1b8: ldur            x7, [fp, #-0x78]
    // 0xb7d1bc: r0 = __unknown_function__()
    //     0xb7d1bc: bl              #0xb7d528  ; [] ::__unknown_function__
    // 0xb7d1c0: mov             x1, x0
    // 0xb7d1c4: stur            x1, [fp, #-0x68]
    // 0xb7d1c8: r0 = Await()
    //     0xb7d1c8: bl              #0xb0c534  ; AwaitStub
    // 0xb7d1cc: ldur            x5, [fp, #-0x10]
    // 0xb7d1d0: ldur            x2, [fp, #-0x60]
    // 0xb7d1d4: ldur            x6, [fp, #-0x48]
    // 0xb7d1d8: ldur            x9, [fp, #-0x30]
    // 0xb7d1dc: ldur            x10, [fp, #-0x28]
    // 0xb7d1e0: ldur            x11, [fp, #-0x20]
    // 0xb7d1e4: ldur            x12, [fp, #-0x18]
    // 0xb7d1e8: ldur            x3, [fp, #-0x58]
    // 0xb7d1ec: ldur            x4, [fp, #-0x50]
    // 0xb7d1f0: ldur            x7, [fp, #-0x40]
    // 0xb7d1f4: ldur            x8, [fp, #-0x38]
    // 0xb7d1f8: b               #0xb7cd48
    // 0xb7d1fc: ldur            x0, [fp, #-0x60]
    // 0xb7d200: ldur            x1, [fp, #-0x48]
    // 0xb7d204: StoreField: r0->field_b = rNULL
    //     0xb7d204: stur            NULL, [x0, #0xb]
    // 0xb7d208: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xb7d208: ldur            w0, [x1, #0x17]
    // 0xb7d20c: DecompressPointer r0
    //     0xb7d20c: add             x0, x0, HEAP, lsl #32
    // 0xb7d210: stur            x0, [fp, #-0x18]
    // 0xb7d214: LoadField: r1 = r0->field_f
    //     0xb7d214: ldur            w1, [x0, #0xf]
    // 0xb7d218: DecompressPointer r1
    //     0xb7d218: add             x1, x1, HEAP, lsl #32
    // 0xb7d21c: r0 = call 0x430ba8
    //     0xb7d21c: bl              #0x430ba8
    // 0xb7d220: ldur            x0, [fp, #-0x18]
    // 0xb7d224: LoadField: r1 = r0->field_1b
    //     0xb7d224: ldur            w1, [x0, #0x1b]
    // 0xb7d228: DecompressPointer r1
    //     0xb7d228: add             x1, x1, HEAP, lsl #32
    // 0xb7d22c: str             x1, [SP]
    // 0xb7d230: mov             x0, x1
    // 0xb7d234: ClosureCall
    //     0xb7d234: ldr             x4, [PP, #0x2c0]  ; [pp+0x2c0] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xb7d238: ldur            x2, [x0, #0x1f]
    //     0xb7d23c: blr             x2
    // 0xb7d240: r1 = 60
    //     0xb7d240: movz            x1, #0x3c
    // 0xb7d244: branchIfSmi(r0, 0xb7d250)
    //     0xb7d244: tbz             w0, #0, #0xb7d250
    // 0xb7d248: r1 = LoadClassIdInstr(r0)
    //     0xb7d248: ldur            x1, [x0, #-1]
    //     0xb7d24c: ubfx            x1, x1, #0xc, #0x14
    // 0xb7d250: r16 = true
    //     0xb7d250: add             x16, NULL, #0x20  ; true
    // 0xb7d254: stp             x16, x0, [SP]
    // 0xb7d258: mov             x0, x1
    // 0xb7d25c: mov             lr, x0
    // 0xb7d260: ldr             lr, [x21, lr, lsl #3]
    // 0xb7d264: blr             lr
    // 0xb7d268: tbz             w0, #4, #0xb7d2e4
    // 0xb7d26c: ldur            x0, [fp, #-0x10]
    // 0xb7d270: LoadField: r6 = r0->field_1f
    //     0xb7d270: ldur            w6, [x0, #0x1f]
    // 0xb7d274: DecompressPointer r6
    //     0xb7d274: add             x6, x6, HEAP, lsl #32
    // 0xb7d278: ArrayLoad: r3 = r0[0]  ; List_4
    //     0xb7d278: ldur            w3, [x0, #0x17]
    // 0xb7d27c: DecompressPointer r3
    //     0xb7d27c: add             x3, x3, HEAP, lsl #32
    // 0xb7d280: LoadField: r1 = r0->field_13
    //     0xb7d280: ldur            w1, [x0, #0x13]
    // 0xb7d284: DecompressPointer r1
    //     0xb7d284: add             x1, x1, HEAP, lsl #32
    // 0xb7d288: LoadField: r2 = r1->field_b
    //     0xb7d288: ldur            w2, [x1, #0xb]
    // 0xb7d28c: LoadField: r1 = r0->field_33
    //     0xb7d28c: ldur            w1, [x0, #0x33]
    // 0xb7d290: DecompressPointer r1
    //     0xb7d290: add             x1, x1, HEAP, lsl #32
    // 0xb7d294: r4 = LoadInt32Instr(r2)
    //     0xb7d294: sbfx            x4, x2, #1, #0x1f
    // 0xb7d298: r5 = LoadInt32Instr(r1)
    //     0xb7d298: sbfx            x5, x1, #1, #0x1f
    //     0xb7d29c: tbz             w1, #0, #0xb7d2a4
    //     0xb7d2a0: ldur            x5, [x1, #7]
    // 0xb7d2a4: ldur            x1, [fp, #-0x30]
    // 0xb7d2a8: mov             x2, x4
    // 0xb7d2ac: r0 = __unknown_function__()
    //     0xb7d2ac: bl              #0xb7d328  ; [] ::__unknown_function__
    // 0xb7d2b0: mov             x1, x0
    // 0xb7d2b4: stur            x1, [fp, #-0x18]
    // 0xb7d2b8: r0 = Await()
    //     0xb7d2b8: bl              #0xb0c534  ; AwaitStub
    // 0xb7d2bc: r0 = Null
    //     0xb7d2bc: mov             x0, NULL
    // 0xb7d2c0: r0 = ReturnAsyncNotFuture()
    //     0xb7d2c0: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xb7d2c4: r0 = StateError()
    //     0xb7d2c4: bl              #0xb09194  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb7d2c8: mov             x1, x0
    // 0xb7d2cc: r0 = "roaming page commit cancelled"
    //     0xb7d2cc: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2d220] "roaming page commit cancelled"
    //     0xb7d2d0: ldr             x0, [x0, #0x220]
    // 0xb7d2d4: StoreField: r1->field_b = r0
    //     0xb7d2d4: stur            w0, [x1, #0xb]
    // 0xb7d2d8: mov             x0, x1
    // 0xb7d2dc: r0 = Throw()
    //     0xb7d2dc: bl              #0xc53a04  ; ThrowStub
    // 0xb7d2e0: brk             #0
    // 0xb7d2e4: r0 = "roaming page commit cancelled"
    //     0xb7d2e4: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2d220] "roaming page commit cancelled"
    //     0xb7d2e8: ldr             x0, [x0, #0x220]
    // 0xb7d2ec: r0 = StateError()
    //     0xb7d2ec: bl              #0xb09194  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0xb7d2f0: mov             x1, x0
    // 0xb7d2f4: r0 = "roaming page commit cancelled"
    //     0xb7d2f4: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2d220] "roaming page commit cancelled"
    //     0xb7d2f8: ldr             x0, [x0, #0x220]
    // 0xb7d2fc: StoreField: r1->field_b = r0
    //     0xb7d2fc: stur            w0, [x1, #0xb]
    // 0xb7d300: mov             x0, x1
    // 0xb7d304: r0 = Throw()
    //     0xb7d304: bl              #0xc53a04  ; ThrowStub
    // 0xb7d308: brk             #0
    // 0xb7d30c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7d30c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7d310: b               #0xb7ccb0
    // 0xb7d314: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7d314: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7d318: b               #0xb7cd54
    // 0xb7d31c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb7d31c: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb7d320: b               #0xb7cfb0
    // 0xb7d324: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb7d324: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static Future<void> <anonymous closure>(dynamic) async {
    // ** addr: 0xbf8e88, size: 0x17c
    // 0xbf8e88: EnterFrame
    //     0xbf8e88: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8e8c: mov             fp, SP
    // 0xbf8e90: AllocStack(0x70)
    //     0xbf8e90: sub             SP, SP, #0x70
    // 0xbf8e94: SetupParameters(dynamic _ /* r1, fp-0x60 */)
    //     0xbf8e94: stur            NULL, [fp, #-8]
    //     0xbf8e98: movz            x0, #0
    //     0xbf8e9c: add             x1, fp, w0, sxtw #2
    //     0xbf8ea0: ldr             x1, [x1, #0x10]
    //     0xbf8ea4: stur            x1, [fp, #-0x60]
    //     0xbf8ea8: ldur            w2, [x1, #0x17]
    //     0xbf8eac: add             x2, x2, HEAP, lsl #32
    //     0xbf8eb0: stur            x2, [fp, #-0x58]
    // 0xbf8eb4: CheckStackOverflow
    //     0xbf8eb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf8eb8: cmp             SP, x16
    //     0xbf8ebc: b.ls            #0xbf8ffc
    // 0xbf8ec0: InitAsync() -> Future<void?>
    //     0xbf8ec0: ldr             x0, [PP, #0x2e8]  ; [pp+0x2e8] TypeArguments: <void?>
    //     0xbf8ec4: bl              #0xb0c86c  ; InitAsyncStub
    // 0xbf8ec8: ldur            x0, [fp, #-0x58]
    // 0xbf8ecc: mov             x2, x0
    // 0xbf8ed0: r1 = Function 'Nrl': static.
    //     0xbf8ed0: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2d6f8] AnonymousClosure: static (0x78bdcc), in [fbn] ::<anonymous closure> (0xbf8e88)
    //     0xbf8ed4: ldr             x1, [x1, #0x6f8]
    // 0xbf8ed8: r0 = AllocateClosure()
    //     0xbf8ed8: bl              #0xc54b7c  ; AllocateClosureStub
    // 0xbf8edc: mov             x2, x0
    // 0xbf8ee0: ldur            x1, [fp, #-0x58]
    // 0xbf8ee4: stur            x2, [fp, #-0x60]
    // 0xbf8ee8: LoadField: r0 = r1->field_f
    //     0xbf8ee8: ldur            w0, [x1, #0xf]
    // 0xbf8eec: DecompressPointer r0
    //     0xbf8eec: add             x0, x0, HEAP, lsl #32
    // 0xbf8ef0: LoadField: r3 = r0->field_1f
    //     0xbf8ef0: ldur            x3, [x0, #0x1f]
    // 0xbf8ef4: LoadField: r4 = r1->field_1b
    //     0xbf8ef4: ldur            w4, [x1, #0x1b]
    // 0xbf8ef8: DecompressPointer r4
    //     0xbf8ef8: add             x4, x4, HEAP, lsl #32
    // 0xbf8efc: r5 = LoadInt32Instr(r4)
    //     0xbf8efc: sbfx            x5, x4, #1, #0x1f
    //     0xbf8f00: tbz             w4, #0, #0xbf8f08
    //     0xbf8f04: ldur            x5, [x4, #7]
    // 0xbf8f08: cmp             x3, x5
    // 0xbf8f0c: b.ne            #0xbf8f88
    // 0xbf8f10: LoadField: r3 = r0->field_27
    //     0xbf8f10: ldur            w3, [x0, #0x27]
    // 0xbf8f14: DecompressPointer r3
    //     0xbf8f14: add             x3, x3, HEAP, lsl #32
    // 0xbf8f18: tbnz            w3, #4, #0xbf8f88
    // 0xbf8f1c: LoadField: r3 = r0->field_7
    //     0xbf8f1c: ldur            w3, [x0, #7]
    // 0xbf8f20: DecompressPointer r3
    //     0xbf8f20: add             x3, x3, HEAP, lsl #32
    // 0xbf8f24: LoadField: r4 = r1->field_13
    //     0xbf8f24: ldur            w4, [x1, #0x13]
    // 0xbf8f28: DecompressPointer r4
    //     0xbf8f28: add             x4, x4, HEAP, lsl #32
    // 0xbf8f2c: cmp             w3, w4
    // 0xbf8f30: b.ne            #0xbf8f88
    // 0xbf8f34: LoadField: r3 = r0->field_b
    //     0xbf8f34: ldur            w3, [x0, #0xb]
    // 0xbf8f38: DecompressPointer r3
    //     0xbf8f38: add             x3, x3, HEAP, lsl #32
    // 0xbf8f3c: ArrayLoad: r0 = r1[0]  ; List_4
    //     0xbf8f3c: ldur            w0, [x1, #0x17]
    // 0xbf8f40: DecompressPointer r0
    //     0xbf8f40: add             x0, x0, HEAP, lsl #32
    // 0xbf8f44: r4 = LoadClassIdInstr(r3)
    //     0xbf8f44: ldur            x4, [x3, #-1]
    //     0xbf8f48: ubfx            x4, x4, #0xc, #0x14
    // 0xbf8f4c: stp             x0, x3, [SP]
    // 0xbf8f50: mov             x0, x4
    // 0xbf8f54: mov             lr, x0
    // 0xbf8f58: ldr             lr, [x21, lr, lsl #3]
    // 0xbf8f5c: blr             lr
    // 0xbf8f60: tbnz            w0, #4, #0xbf8f88
    // 0xbf8f64: ldur            x0, [fp, #-0x58]
    // 0xbf8f68: LoadField: r1 = r0->field_13
    //     0xbf8f68: ldur            w1, [x0, #0x13]
    // 0xbf8f6c: DecompressPointer r1
    //     0xbf8f6c: add             x1, x1, HEAP, lsl #32
    // 0xbf8f70: ldur            x2, [fp, #-0x60]
    // 0xbf8f74: r0 = __unknown_function__()
    //     0xbf8f74: bl              #0xbf9004  ; [] ::__unknown_function__
    // 0xbf8f78: mov             x1, x0
    // 0xbf8f7c: stur            x1, [fp, #-0x60]
    // 0xbf8f80: r0 = Await()
    //     0xbf8f80: bl              #0xb0c534  ; AwaitStub
    // 0xbf8f84: b               #0xbf8ff4
    // 0xbf8f88: r0 = Null
    //     0xbf8f88: mov             x0, NULL
    // 0xbf8f8c: r0 = ReturnAsyncNotFuture()
    //     0xbf8f8c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf8f90: sub             SP, fp, #0x70
    // 0xbf8f94: mov             x3, x0
    // 0xbf8f98: stur            x0, [fp, #-0x58]
    // 0xbf8f9c: mov             x0, x1
    // 0xbf8fa0: stur            x1, [fp, #-0x60]
    // 0xbf8fa4: r1 = Null
    //     0xbf8fa4: mov             x1, NULL
    // 0xbf8fa8: r2 = 12
    //     0xbf8fa8: movz            x2, #0xc
    // 0xbf8fac: r0 = AllocateArray()
    //     0xbf8fac: bl              #0xc55848  ; AllocateArrayStub
    // 0xbf8fb0: r16 = "[DBManager] 最近消息表预热失败 userId="
    //     0xbf8fb0: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d700] "[DBManager] 最近消息表预热失败 userId="
    //     0xbf8fb4: ldr             x16, [x16, #0x700]
    // 0xbf8fb8: StoreField: r0->field_f = r16
    //     0xbf8fb8: stur            w16, [x0, #0xf]
    // 0xbf8fbc: ldur            x1, [fp, #-0x20]
    // 0xbf8fc0: ArrayLoad: r2 = r1[0]  ; List_4
    //     0xbf8fc0: ldur            w2, [x1, #0x17]
    // 0xbf8fc4: DecompressPointer r2
    //     0xbf8fc4: add             x2, x2, HEAP, lsl #32
    // 0xbf8fc8: StoreField: r0->field_13 = r2
    //     0xbf8fc8: stur            w2, [x0, #0x13]
    // 0xbf8fcc: r16 = ": "
    //     0xbf8fcc: ldr             x16, [PP, #0xc90]  ; [pp+0xc90] ": "
    // 0xbf8fd0: ArrayStore: r0[0] = r16  ; List_4
    //     0xbf8fd0: stur            w16, [x0, #0x17]
    // 0xbf8fd4: ldur            x1, [fp, #-0x58]
    // 0xbf8fd8: StoreField: r0->field_1b = r1
    //     0xbf8fd8: stur            w1, [x0, #0x1b]
    // 0xbf8fdc: r16 = "\n"
    //     0xbf8fdc: ldr             x16, [PP, #0x918]  ; [pp+0x918] "\n"
    // 0xbf8fe0: StoreField: r0->field_1f = r16
    //     0xbf8fe0: stur            w16, [x0, #0x1f]
    // 0xbf8fe4: ldur            x1, [fp, #-0x60]
    // 0xbf8fe8: StoreField: r0->field_23 = r1
    //     0xbf8fe8: stur            w1, [x0, #0x23]
    // 0xbf8fec: str             x0, [SP]
    // 0xbf8ff0: r0 = _interpolate()
    //     0xbf8ff0: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xbf8ff4: r0 = Null
    //     0xbf8ff4: mov             x0, NULL
    // 0xbf8ff8: r0 = ReturnAsyncNotFuture()
    //     0xbf8ff8: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xbf8ffc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8ffc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf9000: b               #0xbf8ec0
  }
  [closure] static JVa <anonymous closure>(dynamic, bWa) {
    // ** addr: 0x42e018, size: -0x1
  }
  [closure] static bWa <anonymous closure>(dynamic, IVa) {
    // ** addr: 0x3e1134, size: -0x1
  }
  [closure] static bool <anonymous closure>(dynamic, int) {
    // ** addr: 0x42d2b8, size: -0x1
  }
  [closure] static iWa <anonymous closure>(dynamic, DVa) {
    // ** addr: 0x431038, size: -0x1
  }
  [closure] static int <anonymous closure>(dynamic) {
    // ** addr: 0x430ae8, size: -0x1
  }
  [closure] static FWa <anonymous closure>(dynamic, yVa) {
    // ** addr: 0x432ce4, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x444148, size: -0x1
  }
  [closure] static Future<qWa?> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x445850, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x447010, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44878c, size: -0x1
  }
  [closure] static Future<Map<String, List<String>>> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44ad34, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44bba0, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44c810, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44c8e8, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44c9f0, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44cab4, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44cc68, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44cd90, size: -0x1
  }
  [closure] static Future<Map<String, Map<String, List<String>>>> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44d548, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x44e304, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x450900, size: -0x1
  }
  [closure] static bool <anonymous closure>(dynamic, qWa) {
    // ** addr: 0x4540a8, size: -0x1
  }
  [closure] static String <anonymous closure>(dynamic, qWa) {
    // ** addr: 0x454048, size: -0x1
  }
  [closure] static bool <anonymous closure>(dynamic, qWa) {
    // ** addr: 0x453fac, size: -0x1
  }
  [closure] static String <anonymous closure>(dynamic, qWa) {
    // ** addr: 0x453f4c, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x455934, size: -0x1
  }
  [closure] static Future<bool> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x456b54, size: -0x1
  }
  [closure] static void vZg(dynamic) {
    // ** addr: 0x456ba8, size: -0x1
  }
  [closure] static Future<bool> <anonymous closure>(dynamic, tVa) {
    // ** addr: 0x457120, size: -0x1
  }
  [closure] static void vZg(dynamic) {
    // ** addr: 0x458788, size: -0x1
  }
  [closure] static int <anonymous closure>(dynamic, qWa, qWa) {
    // ** addr: 0x45866c, size: -0x1
  }
  [closure] static qWa <anonymous closure>(dynamic, qWa, qWa) {
    // ** addr: 0x458600, size: -0x1
  }
  [closure] static Future<void> <anonymous closure>(dynamic) {
    // ** addr: 0x78bc54, size: -0x1
  }
  [closure] static Null <anonymous closure>(dynamic) {
    // ** addr: 0x78bbb4, size: -0x1
  }
  [closure] static Future<int> <anonymous closure>(dynamic, String) {
    // ** addr: 0x7923d8, size: -0x1
  }
  [closure] static void <anonymous closure>(dynamic) {
    // ** addr: 0x7922f8, size: -0x1
  }
  [closure] static bool Nrl(dynamic) {
    // ** addr: 0x78bdcc, size: -0x1
  }
}

// class id: 1819, size: 0x3c, field offset: 0x8
class iVa extends Object {

  static late final iVa _UMc; // offset: 0x14e0
  static late final Object _ITh; // offset: 0x14e4
}

// class id: 1820, size: 0x20, field offset: 0x8
class _hVa extends Object {
}

// class id: 1821, size: 0x18, field offset: 0x8
//   const constructor, 
class gVa extends Object {
}
