// lib: , url: lsn

// class id: 1050416, size: 0x8
class :: {
}

// class id: 722, size: 0x8, field offset: 0x8
abstract class Xvb extends Object
    implements List<X0> {
}

// class id: 723, size: 0x10, field offset: 0x8
//   const constructor, 
class Wvb extends Object {

  _Mint field_8;
}
