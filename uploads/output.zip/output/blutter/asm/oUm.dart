// lib: , url: oUm

// class id: 1049375, size: 0x8
class :: {
}

// class id: 2496, size: 0x10, field offset: 0x8
//   const constructor, 
class rGa extends pGa {
}
