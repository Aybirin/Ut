// lib: , url: Lyn

// class id: 1050749, size: 0x8
class :: {
}

// class id: 4698, size: 0x2c, field offset: 0xc
//   const constructor, 
class XIb extends Zu {

  [closure] static XIb <anonymous closure>(dynamic, iva) {
    // ** addr: 0x716dcc, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x86c6bc, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x86c634, size: -0x1
  }
}
