// lib: , url: oBn

// class id: 1050869, size: 0x8
class :: {
}

// class id: 2868, size: 0x50, field offset: 0x50
abstract class xOb extends Xha {

  static late Map<YK, (dynamic) => void> _Kfh; // offset: 0x1cd8
  static late Map<YK, BOb> _Zgk; // offset: 0x1cdc

  [closure] static void _ahk(dynamic) {
    // ** addr: 0x52d380, size: -0x1
  }
  [closure] static void _bhk(dynamic) {
    // ** addr: 0x52e524, size: -0x1
  }
}

// class id: 2950, size: 0x70, field offset: 0x5c
//   transformed mixin,
abstract class _yOb extends oX
     with xOb {

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x52e570, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic, Yia) {
    // ** addr: 0x52d1ec, size: -0x1
  }
}

// class id: 2951, size: 0x74, field offset: 0x70
class zOb extends _yOb {
}
