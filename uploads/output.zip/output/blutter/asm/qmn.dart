// lib: jCn, url: qmn

// class id: 1050135, size: 0x8
class :: {
}

// class id: 1057, size: 0x8, field offset: 0x8
class Flb extends Blb {

  static late final fqb GEg; // offset: 0xe38

  [closure] static Flb <anonymous closure>(dynamic) {
    // ** addr: 0x42192c, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x4218d4, size: -0x1
  }
}
