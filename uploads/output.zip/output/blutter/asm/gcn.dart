// lib: , url: gcn

// class id: 1049662, size: 0x8
class :: {
}

// class id: 1724, size: 0x1c, field offset: 0x8
//   const constructor, 
class JXa extends Object {
}

// class id: 7125, size: 0x14, field offset: 0x14
enum IXa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
