// lib: , url: Gcn

// class id: 1049688, size: 0x8
class :: {
}

// class id: 1696, size: 0x3c, field offset: 0x8
abstract class tYa extends Object {
}

// class id: 1697, size: 0x54, field offset: 0x3c
class xYa extends tYa {
}

// class id: 1698, size: 0x4c, field offset: 0x3c
class wYa extends tYa {
}

// class id: 1699, size: 0x48, field offset: 0x3c
class vYa extends tYa {
}

// class id: 1700, size: 0x68, field offset: 0x3c
class uYa extends tYa {
}
