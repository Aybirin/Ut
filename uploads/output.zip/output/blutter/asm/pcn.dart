// lib: , url: pcn

// class id: 1049671, size: 0x8
class :: {
}

// class id: 1719, size: 0x38, field offset: 0x8
class bYa extends Object {
}
