// lib: , url: smn

// class id: 1050137, size: 0x8
class :: {
}

// class id: 1054, size: 0x8, field offset: 0x8
abstract class Ilb extends Object {

  static late final List<int> zFg; // offset: 0xe78
  static late final List<int> xFg; // offset: 0xe70
  static late final List<int> vFg; // offset: 0xe68
  static late final List<int> tFg; // offset: 0xe60
  static late final List<int> AFg; // offset: 0xe7c
  static late final List<int> yFg; // offset: 0xe74
  static late final List<int> wFg; // offset: 0xe6c
  static late final List<int> uFg; // offset: 0xe64
  static late final Uint8List qFg; // offset: 0xe54
  static late final List<int> oFg; // offset: 0xe4c
  static late final Uint8List rFg; // offset: 0xe58
  static late final Uint8List sFg; // offset: 0xe5c
  static late final List<int> pFg; // offset: 0xe50
}
