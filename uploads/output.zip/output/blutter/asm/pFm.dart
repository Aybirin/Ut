// lib: , url: pFm

// class id: 1048677, size: 0x8
class :: {
}

// class id: 6040, size: 0xa0, field offset: 0x8
class ay extends Object {

  late final Map<String, dynamic> _Atg; // offset: 0x9c
  late final String Smc; // offset: 0xc

  Map<String, dynamic> Gxc(ay) {
    // ** addr: 0xbbc3c8, size: 0x48
    // 0xbbc3c8: EnterFrame
    //     0xbbc3c8: stp             fp, lr, [SP, #-0x10]!
    //     0xbbc3cc: mov             fp, SP
    // 0xbbc3d0: CheckStackOverflow
    //     0xbbc3d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbbc3d4: cmp             SP, x16
    //     0xbbc3d8: b.ls            #0xbbc3f0
    // 0xbbc3dc: ldr             x1, [fp, #0x10]
    // 0xbbc3e0: r0 = call 0x653c60
    //     0xbbc3e0: bl              #0x653c60
    // 0xbbc3e4: LeaveFrame
    //     0xbbc3e4: mov             SP, fp
    //     0xbbc3e8: ldp             fp, lr, [SP], #0x10
    // 0xbbc3ec: ret
    //     0xbbc3ec: ret             
    // 0xbbc3f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbbc3f0: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbbc3f4: b               #0xbbc3dc
  }
}
