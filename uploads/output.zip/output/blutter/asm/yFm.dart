// lib: , url: yFm

// class id: 1048686, size: 0x8
class :: {
}

// class id: 6033, size: 0x10, field offset: 0x8
class iy extends Object {

  static late final iy ZLc; // offset: 0xd78

  [closure] Set<String> <anonymous closure>(dynamic) {
    // ** addr: 0x3ae4f8, size: -0x1
  }
  [closure] int <anonymous closure>(dynamic, int, Set<String>) {
    // ** addr: 0x3ae474, size: -0x1
  }
  [closure] bool <anonymous closure>(dynamic, String) {
    // ** addr: 0x3d1568, size: -0x1
  }
}
