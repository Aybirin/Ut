// lib: , url: oEm

// class id: 1048628, size: 0x8
class :: {
}

// class id: 6099, size: 0x8, field offset: 0x8
abstract class nw extends Object {

  static late final Map<String, Da> _Mig; // offset: 0xc50

  [closure] static bool <anonymous closure>(dynamic, String, Da) {
    // ** addr: 0x6487e8, size: -0x1
  }
}
