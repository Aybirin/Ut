// lib: , url: NBn

// class id: 1050894, size: 0x8
class :: {
}

// class id: 197, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class _hPb extends Object
     with iPb {
}

// class id: 198, size: 0x10, field offset: 0x8
class _jPb extends _hPb
    implements Df<X0> {

  [closure] void add(dynamic, Object?) {
    // ** addr: 0x4cef54, size: -0x1
  }
}

// class id: 6713, size: 0x10, field offset: 0xc
class fPb extends Ze<dynamic, dynamic> {
}
