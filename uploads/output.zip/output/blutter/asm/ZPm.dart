// lib: , url: ZPm

// class id: 1049156, size: 0x8
class :: {
}

// class id: 3024, size: 0x90, field offset: 0x68
class Eha extends UU {

  late final AM _Pgc; // offset: 0x68
  late final SM _UFd; // offset: 0x6c
  late bool _Sue; // offset: 0x74

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x93b714, size: -0x1
  }
  [closure] void _fQe(dynamic, nM) {
    // ** addr: 0x5876ac, size: -0x1
  }
}

// class id: 7265, size: 0x14, field offset: 0x14
enum Dha extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}
