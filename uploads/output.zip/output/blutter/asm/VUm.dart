// lib: , url: VUm

// class id: 1049408, size: 0x8
class :: {
}

// class id: 7167, size: 0x14, field offset: 0x14
enum tHa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7169, size: 0x14, field offset: 0x14
enum rHa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7170, size: 0x14, field offset: 0x14
enum qHa extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
}

// class id: 7171, size: 0x28, field offset: 0x14
enum Ut extends _Enum {

  _Mint field_8;
  _OneByteString field_10;
  qHa field_14;
  rHa field_18;
  bool field_1c;
  tHa field_24;
}
