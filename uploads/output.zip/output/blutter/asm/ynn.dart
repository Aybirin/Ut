// lib: QDn, url: ynn

// class id: 1050195, size: 0x8
class :: {
}

// class id: 998, size: 0xc, field offset: 0xc
class bob extends hnb {

  static late final fqb GEg; // offset: 0x1018

  [closure] static bob <anonymous closure>(dynamic) {
    // ** addr: 0x40e2f8, size: -0x1
  }
  [closure] static bob _VJg(dynamic, String, enb, dnb, za, za, List<int>) {
    // ** addr: 0x40e410, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40e2a0, size: -0x1
  }
}
