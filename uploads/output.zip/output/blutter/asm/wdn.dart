// lib: , url: wdn

// class id: 1049726, size: 0x8
class :: {
}

// class id: 1668, size: 0x64, field offset: 0x8
class RZa extends Object {
}
