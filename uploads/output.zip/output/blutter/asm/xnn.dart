// lib: PDn, url: xnn

// class id: 1050194, size: 0x8
class :: {
}

// class id: 999, size: 0xc, field offset: 0xc
class Znb extends hnb {

  static late final fqb GEg; // offset: 0x1014

  [closure] static Znb <anonymous closure>(dynamic) {
    // ** addr: 0x40e488, size: -0x1
  }
  [closure] static Znb _VJg(dynamic, String, enb, dnb, za, za, List<int>) {
    // ** addr: 0x40e5a0, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x40e430, size: -0x1
  }
}
