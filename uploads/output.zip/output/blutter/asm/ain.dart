// lib: , url: ain

// class id: 1049960, size: 0x8
class :: {
}

// class id: 1391, size: 0x18, field offset: 0x8
//   const constructor, 
class Ghb extends Object {
}

// class id: 1392, size: 0x1c, field offset: 0x18
//   const constructor, 
class Fhb extends Ghb {
}
