// lib: , url: Uqn

// class id: 1050353, size: 0x8
class :: {
}

// class id: 818, size: 0x8, field offset: 0x8
class wtb extends Object {
}
