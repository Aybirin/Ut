// lib: , url: oQm

// class id: 1049177, size: 0x8
class :: {
}

// class id: 2947, size: 0x6c, field offset: 0x5c
class Uka extends _cka {

  [closure] double hJd(dynamic, double) {
    // ** addr: 0x569fdc, size: -0x1
  }
  [closure] double fJd(dynamic, double) {
    // ** addr: 0x50c830, size: -0x1
  }
  [closure] double eJd(dynamic, double) {
    // ** addr: 0x501804, size: -0x1
  }
  [closure] void _Fcf(dynamic, xja, Dr) {
    // ** addr: 0x52f038, size: -0x1
  }
  [closure] double gJd(dynamic, double) {
    // ** addr: 0x508718, size: -0x1
  }
}
