// lib: , url: HBn

// class id: 1050888, size: 0x8
class :: {
}

// class id: 203, size: 0x1c, field offset: 0x8
class ZOb<X0, X1> extends Object {

  X1 [](ZOb<X0, X1>, X0) {
    // ** addr: 0xbaa0d0, size: 0x4c
    // 0xbaa0d0: EnterFrame
    //     0xbaa0d0: stp             fp, lr, [SP, #-0x10]!
    //     0xbaa0d4: mov             fp, SP
    // 0xbaa0d8: CheckStackOverflow
    //     0xbaa0d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbaa0dc: cmp             SP, x16
    //     0xbaa0e0: b.ls            #0xbaa0fc
    // 0xbaa0e4: ldr             x1, [fp, #0x18]
    // 0xbaa0e8: ldr             x2, [fp, #0x10]
    // 0xbaa0ec: r0 = call 0x5b6390
    //     0xbaa0ec: bl              #0x5b6390
    // 0xbaa0f0: LeaveFrame
    //     0xbaa0f0: mov             SP, fp
    //     0xbaa0f4: ldp             fp, lr, [SP], #0x10
    // 0xbaa0f8: ret
    //     0xbaa0f8: ret             
    // 0xbaa0fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbaa0fc: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbaa100: b               #0xbaa0e4
  }
}
