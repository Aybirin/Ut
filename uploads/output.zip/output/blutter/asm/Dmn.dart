// lib: uCn, url: Dmn

// class id: 1050148, size: 0x8
class :: {
}

// class id: 1093, size: 0x14, field offset: 0x14
class emb extends alb {

  static late final fqb GEg; // offset: 0xea8

  [closure] static (dynamic) => emb <anonymous closure>(dynamic, String, wa) {
    // ** addr: 0x4204c4, size: -0x1
  }
  [closure] static emb <anonymous closure>(dynamic) {
    // ** addr: 0x420518, size: -0x1
  }
  static fqb GEg() {
    // ** addr: 0x420460, size: -0x1
  }
}
