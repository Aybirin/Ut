// lib: , url: Qfn

// class id: 1049846, size: 0x8
class :: {
}

// class id: 1541, size: 0x8, field offset: 0x8
class Beb extends Edb {
}
