// lib: , url: aRm

// class id: 1049213, size: 0x8
class :: {
}

// class id: 3707, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class zoa extends _FM {
}

// class id: 3708, size: 0x10, field offset: 0x8
//   const constructor, 
class qoa extends zoa {

  _Mint field_8;
}

// class id: 3709, size: 0x10, field offset: 0x8
//   const constructor, 
class poa extends zoa {

  _Mint field_8;
  static late final Map<poa, Set<poa>> _hmd; // offset: 0x6cc

  [closure] static Set<poa> <anonymous closure>(dynamic, poa) {
    // ** addr: 0x69bc18, size: -0x1
  }
}
