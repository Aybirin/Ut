// lib: , url: XTm

// class id: 1049482, size: 0x8
class :: {
}

// class id: 2380, size: 0x18, field offset: 0x8
//   const constructor, 
class KJa extends Object {

  _Mint field_8;
  _Mint field_10;
}
