// lib: , url: Xtn

// class id: 1050504, size: 0x8
class :: {
}

// class id: 565, size: 0x10, field offset: 0x8
//   const constructor, 
class bzb extends Object {

  _OneByteString field_8;
  _OneByteString field_c;
}

// class id: 566, size: 0x8, field offset: 0x8
abstract class azb extends Object {

  static late bzb Erj; // offset: 0x19fc
  static late String yrj; // offset: 0x19e0
  static late String xrj; // offset: 0x19d8
  static late String wrj; // offset: 0x19d4
  static late List<bzb> Crj; // offset: 0x19f4
  static late String MDg; // offset: 0x19dc
  static late String zrj; // offset: 0x19e4
  static late List<bzb> Drj; // offset: 0x19f8
}
