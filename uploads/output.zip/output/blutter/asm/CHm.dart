// lib: , url: CHm

// class id: 1048783, size: 0x8
class :: {
}

// class id: 5775, size: 0x1c, field offset: 0x8
//   const constructor, 
class UB extends Object {
}
