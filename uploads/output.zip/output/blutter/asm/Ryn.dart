// lib: , url: Ryn

// class id: 1050755, size: 0x8
class :: {
}

// class id: 4695, size: 0x2c, field offset: 0xc
//   const constructor, 
class nJb extends Zu {
}
