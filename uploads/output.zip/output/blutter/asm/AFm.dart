// lib: , url: AFm

// class id: 1048688, size: 0x8
class :: {
}

// class id: 6031, size: 0x28, field offset: 0x8
class Ju extends Object {

  static late final Ju ZLc; // offset: 0xd80

  [closure] Future<Null> <anonymous closure>(dynamic) async {
    // ** addr: 0xc0c2d0, size: 0x124
    // 0xc0c2d0: EnterFrame
    //     0xc0c2d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc0c2d4: mov             fp, SP
    // 0xc0c2d8: AllocStack(0x58)
    //     0xc0c2d8: sub             SP, SP, #0x58
    // 0xc0c2dc: SetupParameters(Ju this /* r1, fp-0x50 */)
    //     0xc0c2dc: stur            NULL, [fp, #-8]
    //     0xc0c2e0: movz            x0, #0
    //     0xc0c2e4: add             x1, fp, w0, sxtw #2
    //     0xc0c2e8: ldr             x1, [x1, #0x10]
    //     0xc0c2ec: stur            x1, [fp, #-0x50]
    //     0xc0c2f0: ldur            w2, [x1, #0x17]
    //     0xc0c2f4: add             x2, x2, HEAP, lsl #32
    //     0xc0c2f8: stur            x2, [fp, #-0x48]
    // 0xc0c2fc: CheckStackOverflow
    //     0xc0c2fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0c300: cmp             SP, x16
    //     0xc0c304: b.ls            #0xc0c3ec
    // 0xc0c308: InitAsync() -> Future<Null?>
    //     0xc0c308: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xc0c30c: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc0c310: ldur            x0, [fp, #-0x48]
    // 0xc0c314: r0 = InitLateStaticField(0xd04) // [aFm] Jx::ntg
    //     0xc0c314: ldr             x0, [THR, #0x68]  ; THR::field_table_values
    //     0xc0c318: ldr             x0, [x0, #0x1a08]
    //     0xc0c31c: ldr             x16, [PP, #0x40]  ; [pp+0x40] Sentinel
    //     0xc0c320: cmp             w0, w16
    //     0xc0c324: b.ne            #0xc0c334
    //     0xc0c328: add             x2, PP, #0x28, lsl #12  ; [pp+0x28248] Field <Jx.ntg>: static late (offset: 0xd04)
    //     0xc0c32c: ldr             x2, [x2, #0x248]
    //     0xc0c330: bl              #0xc5392c  ; InitLateStaticFieldStub
    // 0xc0c334: ldur            x0, [fp, #-0x48]
    // 0xc0c338: LoadField: r2 = r0->field_f
    //     0xc0c338: ldur            w2, [x0, #0xf]
    // 0xc0c33c: DecompressPointer r2
    //     0xc0c33c: add             x2, x2, HEAP, lsl #32
    // 0xc0c340: mov             x1, x2
    // 0xc0c344: stur            x2, [fp, #-0x50]
    // 0xc0c348: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc0c348: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc0c34c: r0 = call 0x3ab42c
    //     0xc0c34c: bl              #0x3ab42c
    // 0xc0c350: mov             x2, x0
    // 0xc0c354: r1 = "data_plus_domains_cache.json"
    //     0xc0c354: add             x1, PP, #0x28, lsl #12  ; [pp+0x28250] "data_plus_domains_cache.json"
    //     0xc0c358: ldr             x1, [x1, #0x250]
    // 0xc0c35c: stur            x0, [fp, #-0x48]
    // 0xc0c360: r0 = __unknown_function__()
    //     0xc0c360: bl              #0xc08708  ; [] ::__unknown_function__
    // 0xc0c364: mov             x1, x0
    // 0xc0c368: stur            x1, [fp, #-0x48]
    // 0xc0c36c: r0 = Await()
    //     0xc0c36c: bl              #0xb0c534  ; AwaitStub
    // 0xc0c370: r1 = Null
    //     0xc0c370: mov             x1, NULL
    // 0xc0c374: r2 = 4
    //     0xc0c374: movz            x2, #0x4
    // 0xc0c378: r0 = AllocateArray()
    //     0xc0c378: bl              #0xc55848  ; AllocateArrayStub
    // 0xc0c37c: r16 = "域名缓存已写入: "
    //     0xc0c37c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28310] "域名缓存已写入: "
    //     0xc0c380: ldr             x16, [x16, #0x310]
    // 0xc0c384: StoreField: r0->field_f = r16
    //     0xc0c384: stur            w16, [x0, #0xf]
    // 0xc0c388: ldur            x1, [fp, #-0x50]
    // 0xc0c38c: StoreField: r0->field_13 = r1
    //     0xc0c38c: stur            w1, [x0, #0x13]
    // 0xc0c390: str             x0, [SP]
    // 0xc0c394: r0 = _interpolate()
    //     0xc0c394: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc0c398: mov             x1, x0
    // 0xc0c39c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc0c39c: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc0c3a0: r0 = call 0x3ade38
    //     0xc0c3a0: bl              #0x3ade38
    // 0xc0c3a4: b               #0xc0c3e4
    // 0xc0c3a8: sub             SP, fp, #0x58
    // 0xc0c3ac: stur            x0, [fp, #-0x48]
    // 0xc0c3b0: r1 = Null
    //     0xc0c3b0: mov             x1, NULL
    // 0xc0c3b4: r2 = 4
    //     0xc0c3b4: movz            x2, #0x4
    // 0xc0c3b8: r0 = AllocateArray()
    //     0xc0c3b8: bl              #0xc55848  ; AllocateArrayStub
    // 0xc0c3bc: r16 = "写入域名缓存失败: "
    //     0xc0c3bc: add             x16, PP, #0x28, lsl #12  ; [pp+0x28318] "写入域名缓存失败: "
    //     0xc0c3c0: ldr             x16, [x16, #0x318]
    // 0xc0c3c4: StoreField: r0->field_f = r16
    //     0xc0c3c4: stur            w16, [x0, #0xf]
    // 0xc0c3c8: ldur            x1, [fp, #-0x48]
    // 0xc0c3cc: StoreField: r0->field_13 = r1
    //     0xc0c3cc: stur            w1, [x0, #0x13]
    // 0xc0c3d0: str             x0, [SP]
    // 0xc0c3d4: r0 = _interpolate()
    //     0xc0c3d4: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc0c3d8: mov             x1, x0
    // 0xc0c3dc: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc0c3dc: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc0c3e0: r0 = call 0x3ade38
    //     0xc0c3e0: bl              #0x3ade38
    // 0xc0c3e4: r0 = Null
    //     0xc0c3e4: mov             x0, NULL
    // 0xc0c3e8: r0 = ReturnAsyncNotFuture()
    //     0xc0c3e8: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc0c3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0c3ec: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0c3f0: b               #0xc0c308
  }
  [closure] Future<Null> <anonymous closure>(dynamic, String) async {
    // ** addr: 0xc0c604, size: 0x174
    // 0xc0c604: EnterFrame
    //     0xc0c604: stp             fp, lr, [SP, #-0x10]!
    //     0xc0c608: mov             fp, SP
    // 0xc0c60c: AllocStack(0x68)
    //     0xc0c60c: sub             SP, SP, #0x68
    // 0xc0c610: SetupParameters(Ju this /* r1, fp-0x60 */, dynamic _ /* r2, fp-0x58 */)
    //     0xc0c610: stur            NULL, [fp, #-8]
    //     0xc0c614: movz            x0, #0
    //     0xc0c618: add             x1, fp, w0, sxtw #2
    //     0xc0c61c: ldr             x1, [x1, #0x18]
    //     0xc0c620: stur            x1, [fp, #-0x60]
    //     0xc0c624: add             x2, fp, w0, sxtw #2
    //     0xc0c628: ldr             x2, [x2, #0x10]
    //     0xc0c62c: stur            x2, [fp, #-0x58]
    //     0xc0c630: ldur            w3, [x1, #0x17]
    //     0xc0c634: add             x3, x3, HEAP, lsl #32
    //     0xc0c638: stur            x3, [fp, #-0x50]
    // 0xc0c63c: CheckStackOverflow
    //     0xc0c63c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0c640: cmp             SP, x16
    //     0xc0c644: b.ls            #0xc0c770
    // 0xc0c648: InitAsync() -> Future<Null?>
    //     0xc0c648: ldr             x0, [PP, #0x88]  ; [pp+0x88] TypeArguments: <Null?>
    //     0xc0c64c: bl              #0xb0c86c  ; InitAsyncStub
    // 0xc0c650: ldur            x0, [fp, #-0x50]
    // 0xc0c654: LoadField: r1 = r0->field_f
    //     0xc0c654: ldur            w1, [x0, #0xf]
    // 0xc0c658: DecompressPointer r1
    //     0xc0c658: add             x1, x1, HEAP, lsl #32
    // 0xc0c65c: ldur            x2, [fp, #-0x58]
    // 0xc0c660: r0 = __unknown_function__()
    //     0xc0c660: bl              #0xc0c778  ; [] ::__unknown_function__
    // 0xc0c664: mov             x1, x0
    // 0xc0c668: stur            x1, [fp, #-0x60]
    // 0xc0c66c: r0 = Await()
    //     0xc0c66c: bl              #0xb0c534  ; AwaitStub
    // 0xc0c670: stur            x0, [fp, #-0x60]
    // 0xc0c674: cmp             w0, NULL
    // 0xc0c678: b.eq            #0xc0c768
    // 0xc0c67c: ldur            x4, [fp, #-0x58]
    // 0xc0c680: ldur            x1, [fp, #-0x50]
    // 0xc0c684: LoadField: r2 = r1->field_13
    //     0xc0c684: ldur            w2, [x1, #0x13]
    // 0xc0c688: DecompressPointer r2
    //     0xc0c688: add             x2, x2, HEAP, lsl #32
    // 0xc0c68c: mov             x1, x2
    // 0xc0c690: mov             x2, x4
    // 0xc0c694: mov             x3, x0
    // 0xc0c698: r0 = call 0x9ffed4
    //     0xc0c698: bl              #0x9ffed4
    // 0xc0c69c: r1 = Null
    //     0xc0c69c: mov             x1, NULL
    // 0xc0c6a0: r2 = 10
    //     0xc0c6a0: movz            x2, #0xa
    // 0xc0c6a4: r0 = AllocateArray()
    //     0xc0c6a4: bl              #0xc55848  ; AllocateArrayStub
    // 0xc0c6a8: mov             x2, x0
    // 0xc0c6ac: r16 = "域名 "
    //     0xc0c6ac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28370] "域名 "
    //     0xc0c6b0: ldr             x16, [x16, #0x370]
    // 0xc0c6b4: StoreField: r2->field_f = r16
    //     0xc0c6b4: stur            w16, [x2, #0xf]
    // 0xc0c6b8: ldur            x3, [fp, #-0x58]
    // 0xc0c6bc: StoreField: r2->field_13 = r3
    //     0xc0c6bc: stur            w3, [x2, #0x13]
    // 0xc0c6c0: r16 = " 测速: "
    //     0xc0c6c0: add             x16, PP, #0x28, lsl #12  ; [pp+0x28378] " 测速: "
    //     0xc0c6c4: ldr             x16, [x16, #0x378]
    // 0xc0c6c8: ArrayStore: r2[0] = r16  ; List_4
    //     0xc0c6c8: stur            w16, [x2, #0x17]
    // 0xc0c6cc: ldur            x0, [fp, #-0x60]
    // 0xc0c6d0: LoadField: r1 = r0->field_7
    //     0xc0c6d0: ldur            x1, [x0, #7]
    // 0xc0c6d4: r0 = 1000
    //     0xc0c6d4: movz            x0, #0x3e8
    // 0xc0c6d8: sdiv            x4, x1, x0
    // 0xc0c6dc: r0 = BoxInt64Instr(r4)
    //     0xc0c6dc: sbfiz           x0, x4, #1, #0x1f
    //     0xc0c6e0: cmp             x4, x0, asr #1
    //     0xc0c6e4: b.eq            #0xc0c6f0
    //     0xc0c6e8: bl              #0xc55ad0  ; AllocateMintSharedWithoutFPURegsStub
    //     0xc0c6ec: stur            x4, [x0, #7]
    // 0xc0c6f0: StoreField: r2->field_1b = r0
    //     0xc0c6f0: stur            w0, [x2, #0x1b]
    // 0xc0c6f4: r16 = "ms"
    //     0xc0c6f4: add             x16, PP, #0x27, lsl #12  ; [pp+0x27390] "ms"
    //     0xc0c6f8: ldr             x16, [x16, #0x390]
    // 0xc0c6fc: StoreField: r2->field_1f = r16
    //     0xc0c6fc: stur            w16, [x2, #0x1f]
    // 0xc0c700: str             x2, [SP]
    // 0xc0c704: r0 = _interpolate()
    //     0xc0c704: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc0c708: mov             x1, x0
    // 0xc0c70c: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc0c70c: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc0c710: r0 = call 0x3ade38
    //     0xc0c710: bl              #0x3ade38
    // 0xc0c714: b               #0xc0c768
    // 0xc0c718: sub             SP, fp, #0x68
    // 0xc0c71c: stur            x0, [fp, #-0x50]
    // 0xc0c720: r1 = Null
    //     0xc0c720: mov             x1, NULL
    // 0xc0c724: r2 = 8
    //     0xc0c724: movz            x2, #0x8
    // 0xc0c728: r0 = AllocateArray()
    //     0xc0c728: bl              #0xc55848  ; AllocateArrayStub
    // 0xc0c72c: r16 = "域名 "
    //     0xc0c72c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28370] "域名 "
    //     0xc0c730: ldr             x16, [x16, #0x370]
    // 0xc0c734: StoreField: r0->field_f = r16
    //     0xc0c734: stur            w16, [x0, #0xf]
    // 0xc0c738: ldur            x1, [fp, #-0x18]
    // 0xc0c73c: StoreField: r0->field_13 = r1
    //     0xc0c73c: stur            w1, [x0, #0x13]
    // 0xc0c740: r16 = " 测速失败: "
    //     0xc0c740: add             x16, PP, #0x28, lsl #12  ; [pp+0x28380] " 测速失败: "
    //     0xc0c744: ldr             x16, [x16, #0x380]
    // 0xc0c748: ArrayStore: r0[0] = r16  ; List_4
    //     0xc0c748: stur            w16, [x0, #0x17]
    // 0xc0c74c: ldur            x1, [fp, #-0x50]
    // 0xc0c750: StoreField: r0->field_1b = r1
    //     0xc0c750: stur            w1, [x0, #0x1b]
    // 0xc0c754: str             x0, [SP]
    // 0xc0c758: r0 = _interpolate()
    //     0xc0c758: bl              #0x357060  ; [dart:core] _StringBase::_interpolate
    // 0xc0c75c: mov             x1, x0
    // 0xc0c760: r4 = const [0, 0x1, 0, 0x1, null]
    //     0xc0c760: ldr             x4, [PP, #0xb0]  ; [pp+0xb0] List(5) [0, 0x1, 0, 0x1, Null]
    // 0xc0c764: r0 = call 0x3ade38
    //     0xc0c764: bl              #0x3ade38
    // 0xc0c768: r0 = Null
    //     0xc0c768: mov             x0, NULL
    // 0xc0c76c: r0 = ReturnAsyncNotFuture()
    //     0xc0c76c: b               #0xb0a540  ; ReturnAsyncNotFutureStub
    // 0xc0c770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0c770: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0c774: b               #0xc0c648
  }
  [closure] Ra<String, Ea> <anonymous closure>(dynamic, Ra<String, Ea>, Ra<String, Ea>) {
    // ** addr: 0x7ab2b0, size: -0x1
  }
}
