// lib: , url: etn

// class id: 1050461, size: 0x8
class :: {
}

// class id: 649, size: 0x10, field offset: 0x8
class vxb extends Object {
}

// class id: 650, size: 0x1c, field offset: 0x8
class uxb extends Object {
}

// class id: 651, size: 0x10, field offset: 0x8
class txb extends Object {
}

// class id: 652, size: 0x20, field offset: 0x8
class sxb extends Object {

  Map<String, dynamic> Gxc(sxb) {
    // ** addr: 0xbcd8f8, size: 0x48
    // 0xbcd8f8: EnterFrame
    //     0xbcd8f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbcd8fc: mov             fp, SP
    // 0xbcd900: CheckStackOverflow
    //     0xbcd900: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbcd904: cmp             SP, x16
    //     0xbcd908: b.ls            #0xbcd920
    // 0xbcd90c: ldr             x1, [fp, #0x10]
    // 0xbcd910: r0 = call 0x6d54c8
    //     0xbcd910: bl              #0x6d54c8
    // 0xbcd914: LeaveFrame
    //     0xbcd914: mov             SP, fp
    //     0xbcd918: ldp             fp, lr, [SP], #0x10
    // 0xbcd91c: ret
    //     0xbcd91c: ret             
    // 0xbcd920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbcd920: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbcd924: b               #0xbcd90c
  }
}

// class id: 653, size: 0x10, field offset: 0x8
class rxb extends Object {

  [closure] static sxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8329a4, size: -0x1
  }
}

// class id: 654, size: 0x20, field offset: 0x8
class qxb extends Object {
}

// class id: 655, size: 0x1c, field offset: 0x8
class pxb extends Object {
}

// class id: 656, size: 0xbc, field offset: 0x8
class oxb extends Object {

  [closure] static pxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x832c28, size: -0x1
  }
  [closure] static Exb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x832bd8, size: -0x1
  }
  [closure] static qxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8329f4, size: -0x1
  }
  [closure] static rxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x832800, size: -0x1
  }
  [closure] static kyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8327b0, size: -0x1
  }
  [closure] static kyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x832760, size: -0x1
  }
  [closure] static wxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x832710, size: -0x1
  }
  [closure] static jyb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x8326c0, size: -0x1
  }
  [closure] static vxb <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0x83258c, size: -0x1
  }
}
