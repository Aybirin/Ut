// lib: , url: qpn

// class id: 1050292, size: 0x8
class :: {
}

// class id: 878, size: 0x18, field offset: 0x8
class qrb extends Object {
}
