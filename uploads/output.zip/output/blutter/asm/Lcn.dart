// lib: , url: Lcn

// class id: 1049693, size: 0x8
class :: {
}

// class id: 4132, size: 0x1c, field offset: 0x14
class _FYa extends Xu<dynamic> {

  late Set<XXa> yzi; // offset: 0x18
  late (dynamic, Mca) => Mca xzi; // offset: 0x14

  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc10b60, size: 0x198
    // 0xc10b60: EnterFrame
    //     0xc10b60: stp             fp, lr, [SP, #-0x10]!
    //     0xc10b64: mov             fp, SP
    // 0xc10b68: AllocStack(0x58)
    //     0xc10b68: sub             SP, SP, #0x58
    // 0xc10b6c: SetupParameters([dynamic _ /* r0 */])
    //     0xc10b6c: ldr             x0, [fp, #0x10]
    //     0xc10b70: ldur            w1, [x0, #0x17]
    //     0xc10b74: add             x1, x1, HEAP, lsl #32
    // 0xc10b78: CheckStackOverflow
    //     0xc10b78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc10b7c: cmp             SP, x16
    //     0xc10b80: b.ls            #0xc10cec
    // 0xc10b84: LoadField: r3 = r1->field_f
    //     0xc10b84: ldur            w3, [x1, #0xf]
    // 0xc10b88: DecompressPointer r3
    //     0xc10b88: add             x3, x3, HEAP, lsl #32
    // 0xc10b8c: stur            x3, [fp, #-0x50]
    // 0xc10b90: LoadField: r0 = r3->field_b
    //     0xc10b90: ldur            w0, [x3, #0xb]
    // 0xc10b94: DecompressPointer r0
    //     0xc10b94: add             x0, x0, HEAP, lsl #32
    // 0xc10b98: cmp             w0, NULL
    // 0xc10b9c: b.eq            #0xc10cf4
    // 0xc10ba0: LoadField: r4 = r0->field_b
    //     0xc10ba0: ldur            w4, [x0, #0xb]
    // 0xc10ba4: DecompressPointer r4
    //     0xc10ba4: add             x4, x4, HEAP, lsl #32
    // 0xc10ba8: stur            x4, [fp, #-0x48]
    // 0xc10bac: r0 = LoadClassIdInstr(r4)
    //     0xc10bac: ldur            x0, [x4, #-1]
    //     0xc10bb0: ubfx            x0, x0, #0xc, #0x14
    // 0xc10bb4: r17 = 5104
    //     0xc10bb4: movz            x17, #0x13f0
    // 0xc10bb8: cmp             x0, x17
    // 0xc10bbc: b.ne            #0xc10c08
    // 0xc10bc0: mov             x0, x4
    // 0xc10bc4: r2 = Null
    //     0xc10bc4: mov             x2, NULL
    // 0xc10bc8: r1 = Null
    //     0xc10bc8: mov             x1, NULL
    // 0xc10bcc: r4 = LoadClassIdInstr(r0)
    //     0xc10bcc: ldur            x4, [x0, #-1]
    //     0xc10bd0: ubfx            x4, x4, #0xc, #0x14
    // 0xc10bd4: r17 = 5104
    //     0xc10bd4: movz            x17, #0x13f0
    // 0xc10bd8: cmp             x4, x17
    // 0xc10bdc: b.eq            #0xc10bf4
    // 0xc10be0: r8 = Fxa
    //     0xc10be0: add             x8, PP, #0x3b, lsl #12  ; [pp+0x3b400] Type: Fxa
    //     0xc10be4: ldr             x8, [x8, #0x400]
    // 0xc10be8: r3 = Null
    //     0xc10be8: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b408] Null
    //     0xc10bec: ldr             x3, [x3, #0x408]
    // 0xc10bf0: r0 = Fxa()
    //     0xc10bf0: bl              #0xb8f5a8  ; IsType_Fxa_Stub
    // 0xc10bf4: ldur            x1, [fp, #-0x50]
    // 0xc10bf8: ldur            x2, [fp, #-0x48]
    // 0xc10bfc: r0 = call 0x7d19a8
    //     0xc10bfc: bl              #0x7d19a8
    // 0xc10c00: mov             x2, x0
    // 0xc10c04: b               #0xc10ccc
    // 0xc10c08: r17 = -5113
    //     0xc10c08: movn            x17, #0x13f8
    // 0xc10c0c: add             x16, x0, x17
    // 0xc10c10: cmp             x16, #1
    // 0xc10c14: b.hi            #0xc10cc8
    // 0xc10c18: ldur            x3, [fp, #-0x48]
    // 0xc10c1c: mov             x0, x3
    // 0xc10c20: r2 = Null
    //     0xc10c20: mov             x2, NULL
    // 0xc10c24: r1 = Null
    //     0xc10c24: mov             x1, NULL
    // 0xc10c28: r4 = LoadClassIdInstr(r0)
    //     0xc10c28: ldur            x4, [x0, #-1]
    //     0xc10c2c: ubfx            x4, x4, #0xc, #0x14
    // 0xc10c30: r17 = -5113
    //     0xc10c30: movn            x17, #0x13f8
    // 0xc10c34: add             x4, x4, x17
    // 0xc10c38: cmp             x4, #1
    // 0xc10c3c: b.ls            #0xc10c54
    // 0xc10c40: r8 = Aua
    //     0xc10c40: add             x8, PP, #0x3b, lsl #12  ; [pp+0x3b418] Type: Aua
    //     0xc10c44: ldr             x8, [x8, #0x418]
    // 0xc10c48: r3 = Null
    //     0xc10c48: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b420] Null
    //     0xc10c4c: ldr             x3, [x3, #0x420]
    // 0xc10c50: r0 = DefaultTypeTest()
    //     0xc10c50: bl              #0xc5360c  ; DefaultTypeTestStub
    // 0xc10c54: ldur            x0, [fp, #-0x48]
    // 0xc10c58: LoadField: r3 = r0->field_f
    //     0xc10c58: ldur            w3, [x0, #0xf]
    // 0xc10c5c: DecompressPointer r3
    //     0xc10c5c: add             x3, x3, HEAP, lsl #32
    // 0xc10c60: stur            x3, [fp, #-0x58]
    // 0xc10c64: r0 = LoadClassIdInstr(r3)
    //     0xc10c64: ldur            x0, [x3, #-1]
    //     0xc10c68: ubfx            x0, x0, #0xc, #0x14
    // 0xc10c6c: r17 = 5104
    //     0xc10c6c: movz            x17, #0x13f0
    // 0xc10c70: cmp             x0, x17
    // 0xc10c74: b.ne            #0xc10cc0
    // 0xc10c78: mov             x0, x3
    // 0xc10c7c: r2 = Null
    //     0xc10c7c: mov             x2, NULL
    // 0xc10c80: r1 = Null
    //     0xc10c80: mov             x1, NULL
    // 0xc10c84: r4 = LoadClassIdInstr(r0)
    //     0xc10c84: ldur            x4, [x0, #-1]
    //     0xc10c88: ubfx            x4, x4, #0xc, #0x14
    // 0xc10c8c: r17 = 5104
    //     0xc10c8c: movz            x17, #0x13f0
    // 0xc10c90: cmp             x4, x17
    // 0xc10c94: b.eq            #0xc10cac
    // 0xc10c98: r8 = Fxa
    //     0xc10c98: add             x8, PP, #0x3b, lsl #12  ; [pp+0x3b400] Type: Fxa
    //     0xc10c9c: ldr             x8, [x8, #0x400]
    // 0xc10ca0: r3 = Null
    //     0xc10ca0: add             x3, PP, #0x3b, lsl #12  ; [pp+0x3b430] Null
    //     0xc10ca4: ldr             x3, [x3, #0x430]
    // 0xc10ca8: r0 = Fxa()
    //     0xc10ca8: bl              #0xb8f5a8  ; IsType_Fxa_Stub
    // 0xc10cac: ldur            x1, [fp, #-0x50]
    // 0xc10cb0: ldur            x2, [fp, #-0x58]
    // 0xc10cb4: r0 = call 0x7d19a8
    //     0xc10cb4: bl              #0x7d19a8
    // 0xc10cb8: mov             x2, x0
    // 0xc10cbc: b               #0xc10ccc
    // 0xc10cc0: r2 = Null
    //     0xc10cc0: mov             x2, NULL
    // 0xc10cc4: b               #0xc10ccc
    // 0xc10cc8: r2 = Null
    //     0xc10cc8: mov             x2, NULL
    // 0xc10ccc: StoreStaticField(0x1720, r2)
    //     0xc10ccc: ldr             x3, [THR, #0x68]  ; THR::field_table_values
    //     0xc10cd0: str             x2, [x3, #0x2e40]
    // 0xc10cd4: b               #0xc10cdc
    // 0xc10cd8: sub             SP, fp, #0x58
    // 0xc10cdc: r0 = Null
    //     0xc10cdc: mov             x0, NULL
    // 0xc10ce0: LeaveFrame
    //     0xc10ce0: mov             SP, fp
    //     0xc10ce4: ldp             fp, lr, [SP], #0x10
    // 0xc10ce8: ret
    //     0xc10ce8: ret             
    // 0xc10cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc10cec: bl              #0xc55950  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc10cf0: b               #0xc10b84
    // 0xc10cf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc10cf4: bl              #0xc55ef8  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Mca <anonymous closure>(dynamic, iva) {
    // ** addr: 0x6aaa3c, size: -0x1
  }
  [closure] Raa <anonymous closure>(dynamic, Mca) {
    // ** addr: 0x7d194c, size: -0x1
  }
  [closure] UYa <anonymous closure>(dynamic, String) {
    // ** addr: 0x7d192c, size: -0x1
  }
}

// class id: 5063, size: 0x24, field offset: 0xc
//   const constructor, 
class EYa extends Vu {

  [closure] static Mca <anonymous closure>(dynamic, iva, Mca?) {
    // ** addr: 0x6d8370, size: -0x1
  }
}
