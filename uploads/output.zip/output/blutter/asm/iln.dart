// lib: , url: iln

// class id: 1050094, size: 0x8
class :: {
}

// class id: 1104, size: 0x10, field offset: 0x8
//   const constructor, 
class nkb extends okb {
}
