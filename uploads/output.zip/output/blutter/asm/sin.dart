// lib: , url: sin

// class id: 1049976, size: 0x8
class :: {
}

// class id: 1377, size: 0x14, field offset: 0x8
class aib extends Object {
}
