// lib: , url: uun

// class id: 1050527, size: 0x8
class :: {
}

// class id: 5358, size: 0xc, field offset: 0xc
//   const constructor, 
class Gzb extends IL {
}
