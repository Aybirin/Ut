// lib: , url: FBn

// class id: 1050886, size: 0x8
class :: {
}

// class id: 206, size: 0x18, field offset: 0xc
//   transformed mixin,
abstract class _WOb extends UOb
     with VOb {

  late final int LTb; // offset: 0xc
  late final int sbc; // offset: 0x10
  late final List<int> _eXf; // offset: 0x14
}

// class id: 208, size: 0x24, field offset: 0x18
class XOb extends _WOb {
}
