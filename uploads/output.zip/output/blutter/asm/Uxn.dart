// lib: , url: Uxn

// class id: 1050705, size: 0x8
class :: {
}

// class id: 543, size: 0x2c, field offset: 0x28
class VGb extends tzb<dynamic> {
}

// class id: 3997, size: 0x18, field offset: 0x14
class UGb extends Xu<dynamic> {

  late VGb JAj; // offset: 0x14

  [closure] vBa <anonymous closure>(dynamic, iva, List<Syb>, IL) {
    // ** addr: 0x768ab8, size: -0x1
  }
  [closure] Mca <anonymous closure>(dynamic, iva, int) {
    // ** addr: 0x768b78, size: -0x1
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x768cd8, size: -0x1
  }
  [closure] void sJc(dynamic) {
    // ** addr: 0x816548, size: -0x1
  }
}

// class id: 4964, size: 0x10, field offset: 0xc
//   const constructor, 
class TGb extends Vu {
}
